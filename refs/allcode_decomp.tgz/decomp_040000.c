// ==== sub_7FF91DCA12F0 @ rva 0x412F0 ====
__int64 __fastcall sub_7FF91DCA12F0(__int64 a1, __int64 a2, _QWORD *a3, __int64 a4)
{
  unsigned __int64 v4; // kr00_8
  __int64 v5; // rax
  unsigned __int64 v6; // rbx
  __int64 v7; // rsi
  unsigned int *v8; // r11
  __int64 v9; // rsi
  unsigned __int64 v10; // rbx
  __int64 v11; // rbp
  __int64 v12; // r12
  __int64 v13; // r13
  __int64 v14; // r14
  __int64 v15; // r15
  __int64 v16; // rdi
  __int64 v17; // rsi

  v4 = __readeflags();
  v5 = a3[15];
  v6 = a3[31];
  v7 = *(_QWORD *)(a4 + 8);
  v8 = *(unsigned int **)(a4 + 56);
  if ( v6 >= v7 + (unsigned __int64)*v8 )
  {
    v5 = a3[19];
    if ( v6 < v7 + (unsigned __int64)v8[1] )
    {
      if ( v6 >= (unsigned __int64)&loc_7FF91DC9FB96 )
        v5 = (v5 & 0xFFFFFFFFFFFFF800uLL) + 1152;
      v9 = v5;
      v5 = *(_QWORD *)(v5 + 152) + 48LL;
      v10 = *(_QWORD *)(v5 - 8);
      v11 = *(_QWORD *)(v5 - 16);
      v12 = *(_QWORD *)(v5 - 24);
      v13 = *(_QWORD *)(v5 - 32);
      v14 = *(_QWORD *)(v5 - 40);
      v15 = *(_QWORD *)(v5 - 48);
      a3[18] = v10;
      a3[20] = v11;
      a3[27] = v12;
      a3[28] = v13;
      a3[29] = v14;
      a3[30] = v15;
      if ( v10 >= (unsigned __int64)&loc_7FF91DC9D396 )
        qmemcpy(a3 + 64, (const void *)(v9 + 160), 0x60u);
    }
  }
  v16 = *(_QWORD *)(v5 + 8);
  v17 = *(_QWORD *)(v5 + 16);
  a3[19] = v5;
  a3[21] = v17;
  a3[22] = v16;
  qmemcpy(*(void **)(a4 + 40), a3, 0x4D0u);
  RtlVirtualUnwind(
    0,
    *(_QWORD *)(a4 + 8),
    *(_QWORD *)a4,
    *(PRUNTIME_FUNCTION *)(a4 + 16),
    *(PCONTEXT *)(a4 + 40),
    (PVOID *)(a4 + 56),
    (PULONG64)(a4 + 24),
    nullptr);
  __writeeflags(v4);
  return 1;
}


// ==== sub_7FF91DCA18C0 @ rva 0x418C0 ====
__int64 __fastcall sub_7FF91DCA18C0(_QWORD *a1, _QWORD *a2)
{
  bool v4; // cf
  __int64 v5; // r10
  __int128 v6; // rax
  __int64 v7; // rtt
  __int64 v8; // r13
  __int128 v9; // kr00_16
  __int64 v10; // rcx
  __int64 v11; // r10
  __int64 v12; // r12
  __int64 v13; // r11

  v4 = ((*a2 != 0) + a2[1] != 0) + a2[2] != 0;
  v5 = (unsigned __int128)-(__int128)__PAIR128__(a2[2], (unsigned __int64)(*a2 != 0) + a2[1]) >> 64;
  v6 = 0LL - *(_OWORD *)a2;
  v7 = v4 + a2[3];
  v8 = -(__int64)(v7 != 0);
  v10 = v5;
  v9 = *(_OWORD *)&qword_7FF91DCA1480 + v6;
  v4 = __CFADD__(
         __CFADD__(v6 != 0, *((_QWORD *)&v6 + 1))
       | (unsigned __int8)__CFADD__((unsigned __int128)(*(_OWORD *)&qword_7FF91DCA1480 + v6) >> 64, 0xFFFFFFFFLL),
         v5);
  v11 = (__CFADD__(v6 != 0, *((_QWORD *)&v6 + 1))
       | (unsigned __int8)__CFADD__((unsigned __int128)(*(_OWORD *)&qword_7FF91DCA1480 + v6) >> 64, 0xFFFFFFFFLL))
      + v5;
  v12 = -v7;
  v13 = v4 - v7 - 0xFFFFFFFFLL;
  if ( !v7 )
    v9 = v6;
  *a1 = v9;
  if ( !v8 )
    v11 = v10;
  a1[1] = *((_QWORD *)&v9 + 1);
  if ( !v8 )
    v13 = v12;
  a1[2] = v11;
  a1[3] = v13;
  return v6;
}


// ==== sub_7FF91DCA19A0 @ rva 0x419A0 ====
__int64 __fastcall sub_7FF91DCA19A0(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  __int64 v3; // rcx

  v3 = dword_7FF91E91A5F8 & 0x80100;
  if ( (_DWORD)v3 == 524544 )
    return sub_7FF91DCA1EE0(v3, *a3, a3, *a2);
  else
    return sub_7FF91DCA1A40(v3, a3, a3, *a2);
}


// ==== sub_7FF91DCA1A40 @ rva 0x41A40 ====
__int64 __fastcall sub_7FF91DCA1A40(__int64 a1, __int64 a2, __int64 a3, unsigned __int64 a4)
{
  unsigned __int64 v4; // rax
  unsigned __int64 *v5; // rbx
  __int64 *v6; // rdi
  unsigned __int64 *v7; // rsi
  unsigned __int64 v8; // r10
  unsigned __int64 v9; // r11
  unsigned __int64 v10; // r12
  unsigned __int64 v11; // rbp
  unsigned __int128 v12; // rax
  __int128 v13; // kr70_16
  __int64 v14; // kr20_8
  unsigned __int128 v15; // kr50_16
  __int64 v16; // kr60_8
  __int64 v17; // r12
  unsigned __int64 v18; // rbp
  __int64 v19; // r8
  unsigned __int128 v20; // rax
  __int64 v21; // r10
  __int64 v22; // r11
  __int64 v23; // rtt
  unsigned __int64 v24; // r12
  __int64 v25; // rtt
  _BOOL8 v26; // r13
  __int64 v27; // r10
  __int64 v28; // kr90_8
  unsigned __int64 v29; // rcx
  unsigned __int128 v30; // rax
  __int64 v31; // r12
  __int64 v32; // r13
  _BOOL8 v33; // rtt
  _BOOL8 v34; // r8
  unsigned __int64 v35; // rbp
  __int64 v36; // r9
  unsigned __int128 v37; // rax
  __int64 v38; // r11
  __int64 v39; // r12
  __int64 v40; // rtt
  unsigned __int64 v41; // r13
  __int64 v42; // rtt
  _BOOL8 v43; // r8
  __int64 v44; // krC0_8
  __int64 v45; // krD0_8
  unsigned __int64 v46; // rcx
  unsigned __int128 v47; // rax
  __int64 v48; // r13
  __int64 v49; // r8
  _BOOL8 v50; // rtt
  _BOOL8 v51; // r9
  unsigned __int64 v52; // rbp
  __int64 v53; // r10
  unsigned __int128 v54; // rax
  __int64 v55; // r12
  __int64 v56; // r13
  __int64 v57; // rtt
  unsigned __int64 v58; // r8
  __int64 v59; // rtt
  _BOOL8 v60; // r9
  __int64 v61; // r12
  __int64 v62; // kr110_8
  unsigned __int64 v63; // rcx
  unsigned __int128 v64; // rax
  __int64 v65; // r8
  __int64 v66; // r9
  _BOOL8 v67; // rtt
  _BOOL8 v68; // r10
  unsigned __int64 v69; // rbp
  __int64 v70; // r11
  __int64 v71; // r13
  __int64 v72; // rcx
  __int64 v73; // r8
  __int64 v74; // rtt
  __int64 v75; // r9
  __int64 v76; // rtt
  unsigned __int64 v77; // rbp
  _BOOL8 v78; // r10
  __int64 v79; // r12
  __int64 v80; // rbx
  unsigned __int64 v81; // r13
  __int64 v82; // r8
  _BOOL8 v83; // rtt
  unsigned __int128 v84; // rax
  __int64 v85; // r9
  bool v86; // cf

  v11 = v4;
  v13 = v4;
  v12 = a4 * (unsigned __int128)v4;
  v14 = (__PAIR128__(v8, a4) * v13) >> 64;
  v15 = v9 * (unsigned __int128)v11 + ((v8 * (unsigned __int128)v11 + *((unsigned __int64 *)&v12 + 1)) >> 64);
  v16 = v10 * v11 + *((_QWORD *)&v15 + 1);
  v17 = (v10 * (unsigned __int128)v11 + *((unsigned __int64 *)&v15 + 1)) >> 64;
  v18 = v12;
  v19 = (_QWORD)v12 << 32;
  v20 = 0xFFFFFFFF00000001uLL * (unsigned __int128)(unsigned __int64)v12;
  v18 >>= 32;
  v21 = __CFADD__(v19, v14) + (_QWORD)v15;
  v23 = __CFADD__(__CFADD__(v19, v14), (_QWORD)v15) | (unsigned __int8)__CFADD__(v18, v21);
  v22 = v23 + v16;
  v25 = __CFADD__(v23, v16) | (unsigned __int8)__CFADD__((_QWORD)v20, v23 + v16);
  v86 = __CFADD__(v25, v17);
  v24 = v25 + v17;
  v86 |= __CFADD__(*((_QWORD *)&v20 + 1), v24);
  v24 += *((_QWORD *)&v20 + 1);
  v26 = v86;
  *((_QWORD *)&v20 + 1) = (__PAIR128__(
                             (v7[1] * (unsigned __int128)v5[1]) >> 64,
                             (*v7 * (unsigned __int128)v5[1] + (unsigned __int64)(v19 + v14)) >> 64)
                         + v18
                         + v21
                         + v7[1] * v5[1]) >> 64;
  v27 = ((*v7 * (unsigned __int128)v5[1] + (unsigned __int64)(v19 + v14)) >> 64) + v18 + v21 + v7[1] * v5[1];
  v28 = *((_QWORD *)&v20 + 1) + v20 + v22 + v7[2] * v5[1];
  v29 = (__PAIR128__((v7[2] * (unsigned __int128)v5[1]) >> 64, *((unsigned __int64 *)&v20 + 1))
       + (unsigned __int64)(v20 + v22)
       + v7[2] * v5[1]) >> 64;
  v30 = v7[3] * (unsigned __int128)v5[1];
  *((_QWORD *)&v30 + 1) = (__PAIR128__(*((unsigned __int64 *)&v30 + 1), v29) + v24) >> 64;
  v86 = __CFADD__((_QWORD)v30, v29 + v24);
  v31 = v30 + v29 + v24;
  *(_QWORD *)&v30 = *v7 * v5[1] + v19 + v14;
  v33 = v86;
  v86 = __CFADD__(v86, v26);
  v32 = v33 + v26;
  v86 |= __CFADD__(*((_QWORD *)&v30 + 1), v32);
  v32 += *((_QWORD *)&v30 + 1);
  v34 = v86;
  v35 = v30;
  v36 = (_QWORD)v30 << 32;
  v37 = 0xFFFFFFFF00000001uLL * (unsigned __int128)(unsigned __int64)v30;
  v35 >>= 32;
  v38 = __CFADD__(v36, v27) + v28;
  v40 = __CFADD__(__CFADD__(v36, v27), v28) | (unsigned __int8)__CFADD__(v35, v38);
  v86 = __CFADD__(v40, v31);
  v39 = v40 + v31;
  v42 = v86 | (unsigned __int8)__CFADD__((_QWORD)v37, v39);
  v86 = __CFADD__(v42, v32);
  v41 = v42 + v32;
  v86 |= __CFADD__(*((_QWORD *)&v37 + 1), v41);
  v41 += *((_QWORD *)&v37 + 1);
  v43 = v86 + v34;
  v44 = ((*v7 * (unsigned __int128)v5[2] + (unsigned __int64)(v36 + v27)) >> 64) + v35 + v38 + v7[1] * v5[2];
  v45 = ((__PAIR128__(
            (v7[1] * (unsigned __int128)v5[2]) >> 64,
            (*v7 * (unsigned __int128)v5[2] + (unsigned __int64)(v36 + v27)) >> 64)
        + v35
        + v38
        + v7[1] * v5[2]) >> 64)
      + v37
      + v39
      + v7[2] * v5[2];
  v46 = (__PAIR128__(
           (v7[2] * (unsigned __int128)v5[2]) >> 64,
           (__PAIR128__(
              (v7[1] * (unsigned __int128)v5[2]) >> 64,
              (*v7 * (unsigned __int128)v5[2] + (unsigned __int64)(v36 + v27)) >> 64)
          + v35
          + v38
          + v7[1] * v5[2]) >> 64)
       + (unsigned __int64)(v37 + v39)
       + v7[2] * v5[2]) >> 64;
  v47 = v7[3] * (unsigned __int128)v5[2];
  *((_QWORD *)&v47 + 1) = (__PAIR128__(*((unsigned __int64 *)&v47 + 1), v46) + v41) >> 64;
  v86 = __CFADD__((_QWORD)v47, v46 + v41);
  v48 = v47 + v46 + v41;
  *(_QWORD *)&v47 = *v7 * v5[2] + v36 + v27;
  v50 = v86;
  v86 = __CFADD__(v86, v43);
  v49 = v50 + v43;
  v86 |= __CFADD__(*((_QWORD *)&v47 + 1), v49);
  v49 += *((_QWORD *)&v47 + 1);
  v51 = v86;
  v52 = v47;
  v53 = (_QWORD)v47 << 32;
  v54 = 0xFFFFFFFF00000001uLL * (unsigned __int128)(unsigned __int64)v47;
  v52 >>= 32;
  v55 = __CFADD__(v53, v44) + v45;
  v57 = __CFADD__(__CFADD__(v53, v44), v45) | (unsigned __int8)__CFADD__(v52, v55);
  v86 = __CFADD__(v57, v48);
  v56 = v57 + v48;
  v59 = v86 | (unsigned __int8)__CFADD__((_QWORD)v54, v56);
  v86 = __CFADD__(v59, v49);
  v58 = v59 + v49;
  v86 |= __CFADD__(*((_QWORD *)&v54 + 1), v58);
  v58 += *((_QWORD *)&v54 + 1);
  v60 = v86 + v51;
  *((_QWORD *)&v54 + 1) = (__PAIR128__(
                             (v7[1] * (unsigned __int128)v5[3]) >> 64,
                             (*v7 * (unsigned __int128)v5[3] + (unsigned __int64)(v53 + v44)) >> 64)
                         + v52
                         + v55
                         + v7[1] * v5[3]) >> 64;
  v61 = ((*v7 * (unsigned __int128)v5[3] + (unsigned __int64)(v53 + v44)) >> 64) + v52 + v55 + v7[1] * v5[3];
  v62 = *((_QWORD *)&v54 + 1) + v54 + v56 + v7[2] * v5[3];
  v63 = (__PAIR128__((v7[2] * (unsigned __int128)v5[3]) >> 64, *((unsigned __int64 *)&v54 + 1))
       + (unsigned __int64)(v54 + v56)
       + v7[2] * v5[3]) >> 64;
  v64 = v7[3] * (unsigned __int128)v5[3];
  *((_QWORD *)&v64 + 1) = (__PAIR128__(*((unsigned __int64 *)&v64 + 1), v63) + v58) >> 64;
  v86 = __CFADD__((_QWORD)v64, v63 + v58);
  v65 = v64 + v63 + v58;
  *(_QWORD *)&v64 = *v7 * v5[3] + v53 + v44;
  v67 = v86;
  v86 = __CFADD__(v86, v60);
  v66 = v67 + v60;
  v86 |= __CFADD__(*((_QWORD *)&v64 + 1), v66);
  v66 += *((_QWORD *)&v64 + 1);
  v68 = v86;
  v69 = v64;
  v70 = (_QWORD)v64 << 32;
  v84 = 0xFFFFFFFF00000001uLL * (unsigned __int128)(unsigned __int64)v64;
  v69 >>= 32;
  v71 = __CFADD__(v70, v61) + v62;
  v72 = v70 + v61;
  v74 = __CFADD__(__CFADD__(v70, v61), v62) | (unsigned __int8)__CFADD__(v69, v71);
  v86 = __CFADD__(v74, v65);
  v73 = v74 + v65;
  v76 = v86 | (unsigned __int8)__CFADD__((_QWORD)v84, v73);
  v86 = __CFADD__(v76, v66);
  v75 = v76 + v66;
  v77 = v69 + v71;
  v78 = (v86 | (unsigned __int8)__CFADD__(*((_QWORD *)&v84 + 1), v75)) + v68;
  v86 = v70 + v61 != -1;
  v79 = v70 + v61 + 1;
  v80 = v84 + v73;
  v81 = v77 - (v86 + 0xFFFFFFFFLL);
  v83 = v77 < (unsigned __int64)v86 + 0xFFFFFFFF;
  v86 = __PAIR128__((__int64)v84 + v73, v77) < (unsigned __int64)v86 + 0xFFFFFFFF;
  v82 = v84 + v73 - v83;
  *((_QWORD *)&v84 + 1) += v75;
  v85 = *((_QWORD *)&v84 + 1) - (v86 - 0xFFFFFFFFLL);
  v86 = __PAIR128__(v78, *((unsigned __int64 *)&v84 + 1)) < (unsigned __int64)v86 - 0xFFFFFFFF;
  if ( v86 )
  {
    v79 = v72;
    v81 = v77;
  }
  *v6 = v79;
  if ( v86 )
    v82 = v80;
  v6[1] = v81;
  if ( v86 )
    v85 = *((_QWORD *)&v84 + 1);
  v6[2] = v82;
  v6[3] = v85;
  return v84;
}


// ==== sub_7FF91DCA1C80 @ rva 0x41C80 ====
__int64 __fastcall sub_7FF91DCA1C80(__int64 a1, _QWORD *a2)
{
  __int64 v2; // rcx

  v2 = dword_7FF91E91A5F8 & 0x80100;
  if ( (_DWORD)v2 == 524544 )
    return sub_7FF91DCA2140(v2, *a2, a2[3]);
  else
    return sub_7FF91DCA1D20(v2, a2, a2[3]);
}


// ==== sub_7FF91DCA1D20 @ rva 0x41D20 ====
__int64 __fastcall sub_7FF91DCA1D20(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rax
  _QWORD *v4; // rdi
  unsigned __int64 *v5; // rsi
  unsigned __int64 v6; // r14
  unsigned __int64 v7; // r15
  unsigned __int64 v8; // r13
  unsigned __int128 v9; // rax
  __int128 v10; // kr60_16
  __int64 v11; // r10
  __int64 v12; // kr50_8
  unsigned __int128 v13; // kr70_16
  __int64 v14; // r13
  __int64 v15; // r14
  __int64 v16; // r9
  __int64 v17; // r10
  __int64 v18; // r11
  __int64 v19; // rtt
  __int64 v20; // r12
  __int64 v21; // rtt
  __int64 v22; // r13
  __int64 v23; // rtt
  __int64 v24; // r14
  __int64 v25; // rtt
  _BOOL8 v26; // r15
  __int64 v27; // rcx
  unsigned __int128 v28; // rax
  __int64 v29; // r9
  __int64 v30; // r10
  _BOOL8 v31; // rtt
  __int64 v32; // rcx
  unsigned __int128 v33; // rax
  __int64 v34; // r11
  __int64 v35; // r12
  _BOOL8 v36; // rtt
  __int64 v37; // rcx
  unsigned __int128 v38; // rax
  __int64 v39; // r13
  __int64 v40; // r14
  _BOOL8 v41; // rtt
  __int64 v42; // r15
  unsigned __int64 v43; // rcx
  unsigned __int64 v44; // r8
  unsigned __int128 v45; // rax
  __int64 v46; // r10
  __int64 v47; // r11
  _BOOL8 v48; // rtt
  unsigned __int64 v49; // rcx
  unsigned __int64 v50; // r9
  __int64 v51; // r8
  unsigned __int128 v52; // rax
  __int64 v53; // r11
  __int64 v54; // r8
  _BOOL8 v55; // rtt
  unsigned __int64 v56; // rcx
  __int64 v57; // r10
  __int64 v58; // r9
  unsigned __int128 v59; // rax
  __int64 v60; // r8
  __int64 v61; // r9
  _BOOL8 v62; // rtt
  unsigned __int64 v63; // rcx
  __int64 v64; // r11
  __int64 v65; // r10
  __int64 v66; // r8
  __int64 v67; // r9
  _BOOL8 v68; // rtt
  __int64 v69; // r10
  _BOOL8 v70; // rtt
  unsigned __int128 v71; // rax
  __int64 v72; // r13
  __int64 v73; // r8
  __int64 v74; // r14
  __int64 v75; // rtt
  __int64 v76; // r15
  __int64 v77; // rtt
  unsigned __int64 v78; // r9
  __int64 v79; // r12
  unsigned __int64 v80; // r10
  unsigned __int64 v81; // r13
  __int64 v82; // r14
  __int64 v83; // rcx
  __int64 v84; // r15
  bool v85; // cf

  v8 = v3;
  v10 = v3;
  v9 = v6 * (unsigned __int128)v3;
  v11 = (__PAIR128__(v7, v6) * v10) >> 64;
  v12 = v6 * v7 + v8 * a3 + ((v8 * (unsigned __int128)v7 + *((unsigned __int64 *)&v9 + 1)) >> 64);
  v13 = v6 * (unsigned __int128)a3
      + ((v8 * (unsigned __int128)a3 + ((v8 * (unsigned __int128)v7 + *((unsigned __int64 *)&v9 + 1)) >> 64)) >> 64)
      + ((v6 * (unsigned __int128)v7
        + (unsigned __int64)(v8 * a3 + ((v8 * (unsigned __int128)v7 + *((unsigned __int64 *)&v9 + 1)) >> 64))) >> 64);
  v15 = (v7 * (unsigned __int128)a3 + *((unsigned __int64 *)&v13 + 1)) >> 64;
  v14 = v7 * a3 + *((_QWORD *)&v13 + 1);
  v16 = 2 * v9;
  v85 = __CFADD__(__CFADD__((_QWORD)v9, (_QWORD)v9), v11) | __CFADD__(v11, __CFADD__((_QWORD)v9, (_QWORD)v9) + v11);
  v17 = v11 + __CFADD__((_QWORD)v9, (_QWORD)v9) + v11;
  v19 = v85 + v12;
  v85 = __CFADD__(v85, v12) | __CFADD__(v12, v19);
  v18 = v12 + v19;
  v21 = v85 + (_QWORD)v13;
  v85 = __CFADD__(v85, (_QWORD)v13) | __CFADD__((_QWORD)v13, v21);
  v20 = v13 + v21;
  v23 = v85 + v14;
  v85 = __CFADD__(v85, v14) | __CFADD__(v14, v23);
  v22 = v14 + v23;
  v25 = v85 + v15;
  v85 = __CFADD__(v85, v15) | __CFADD__(v15, v25);
  v24 = v15 + v25;
  v26 = v85;
  v27 = (*v5 * (unsigned __int128)*v5) >> 64;
  v28 = v5[1] * (unsigned __int128)v5[1];
  v85 = __CFADD__(v27, v16);
  v29 = v27 + v16;
  v31 = v85;
  v85 = __CFADD__(v85, v17);
  v30 = v31 + v17;
  v85 |= __CFADD__((_QWORD)v28, v30);
  v30 += v28;
  v32 = v85 + *((_QWORD *)&v28 + 1);
  v33 = v5[2] * (unsigned __int128)v5[2];
  v85 = __CFADD__(v32, v18);
  v34 = v32 + v18;
  v36 = v85;
  v85 = __CFADD__(v85, v20);
  v35 = v36 + v20;
  v85 |= __CFADD__((_QWORD)v33, v35);
  v35 += v33;
  v37 = v85 + *((_QWORD *)&v33 + 1);
  v38 = v5[3] * (unsigned __int128)v5[3];
  v85 = __CFADD__(v37, v22);
  v39 = v37 + v22;
  v41 = v85;
  v85 = __CFADD__(v85, v24);
  v40 = v41 + v24;
  v85 |= __CFADD__((_QWORD)v38, v40);
  v40 += v38;
  v42 = *((_QWORD *)&v38 + 1) + v85 + v26;
  v43 = *v5 * *v5;
  v44 = v43 << 32;
  v45 = 0xFFFFFFFF00000001uLL * (unsigned __int128)v43;
  v43 >>= 32;
  v85 = __CFADD__(__CFADD__(v44, v29), v30);
  v46 = __CFADD__(v44, v29) + v30;
  v85 |= __CFADD__(v43, v46);
  v46 += v43;
  v48 = v85;
  v85 = __CFADD__(v85, v34);
  v47 = v48 + v34;
  v85 |= __CFADD__((_QWORD)v45, v47);
  v47 += v45;
  v49 = v44 + v29;
  v50 = (v44 + v29) << 32;
  v51 = v85 + *((_QWORD *)&v45 + 1);
  v52 = 0xFFFFFFFF00000001uLL * (unsigned __int128)v49;
  v49 >>= 32;
  v85 = __CFADD__(__CFADD__(v50, v46), v47);
  v53 = __CFADD__(v50, v46) + v47;
  v85 |= __CFADD__(v49, v53);
  v53 += v49;
  v55 = v85;
  v85 = __CFADD__(v85, v51);
  v54 = v55 + v51;
  v85 |= __CFADD__((_QWORD)v52, v54);
  v54 += v52;
  v56 = v50 + v46;
  v57 = (v50 + v46) << 32;
  v58 = v85 + *((_QWORD *)&v52 + 1);
  v59 = 0xFFFFFFFF00000001uLL * (unsigned __int128)v56;
  v56 >>= 32;
  v85 = __CFADD__(__CFADD__(v57, v53), v54);
  v60 = __CFADD__(v57, v53) + v54;
  v85 |= __CFADD__(v56, v60);
  v60 += v56;
  v62 = v85;
  v85 = __CFADD__(v85, v58);
  v61 = v62 + v58;
  v85 |= __CFADD__((_QWORD)v59, v61);
  v61 += v59;
  v63 = v57 + v53;
  v64 = (v57 + v53) << 32;
  v65 = v85 + *((_QWORD *)&v59 + 1);
  v71 = 0xFFFFFFFF00000001uLL * (unsigned __int128)v63;
  v63 >>= 32;
  v85 = __CFADD__(v64, v60);
  v66 = v64 + v60;
  v68 = v85;
  v85 = __CFADD__(v85, v61);
  v67 = v68 + v61;
  v85 |= __CFADD__(v63, v67);
  v67 += v63;
  v70 = v85;
  v85 = __CFADD__(v85, v65);
  v69 = v70 + v65;
  v85 |= __CFADD__((_QWORD)v71, v69);
  v69 += v71;
  *((_QWORD *)&v71 + 1) += v85;
  v85 = __CFADD__(__CFADD__(v66, v35), v39);
  v72 = __CFADD__(v66, v35) + v39;
  v73 = v66 + v35;
  v75 = v85 | (unsigned __int8)__CFADD__(v67, v72);
  v85 = __CFADD__(v75, v40);
  v74 = v75 + v40;
  v77 = v85 | (unsigned __int8)__CFADD__(v69, v74);
  v85 = __CFADD__(v77, v42);
  v76 = v77 + v42;
  v78 = v67 + v72;
  v79 = v73 + 1;
  v80 = v69 + v74;
  v82 = (__PAIR128__(v80, v78) - ((unsigned __int64)(v73 != -1) + 0xFFFFFFFF)) >> 64;
  v81 = v78 - ((v73 != -1) + 0xFFFFFFFFLL);
  v83 = *((_QWORD *)&v71 + 1) + v76;
  v85 = __PAIR128__(v85 | (unsigned __int8)__CFADD__(*((_QWORD *)&v71 + 1), v76), *((_QWORD *)&v71 + 1) + v76) < (unsigned __int64)(__PAIR128__(v80, v78) < (unsigned __int64)(v73 != -1) + 0xFFFFFFFF) - 0xFFFFFFFF;
  v84 = *((_QWORD *)&v71 + 1)
      + v76
      - ((__PAIR128__(v80, v78) < (unsigned __int64)(v73 != -1) + 0xFFFFFFFF)
       - 0xFFFFFFFFLL);
  if ( v85 )
  {
    v79 = v73;
    v81 = v78;
  }
  *v4 = v79;
  if ( v85 )
    v82 = v80;
  v4[1] = v81;
  if ( v85 )
    v84 = v83;
  v4[2] = v82;
  v4[3] = v84;
  return v71;
}


// ==== sub_7FF91DCA1EE0 @ rva 0x41EE0 ====
// local variable allocation has failed, the output may be wrong!
__int64 __fastcall sub_7FF91DCA1EE0(__int64 a1, unsigned __int64 a2, __int64 a3, unsigned __int64 a4)
{
  _QWORD *v4; // rbx
  _QWORD *v5; // rdi
  unsigned __int64 *v6; // rsi
  unsigned __int64 v7; // r8
  __int64 v8; // r9
  __int64 v9; // rtt
  __int64 v11; // rtt
  bool v13; // cf
  __int64 v14; // rtt
  _BOOL8 v16; // rtt
  __int64 v17; // rbp
  __int64 v18; // rtt
  _BOOL8 v19; // rtt
  unsigned __int64 v21; // rdx
  __int64 v32; // rtt
  __int64 v33; // rbp
  _BOOL8 v34; // rtt
  __int64 v35; // rtt
  unsigned __int64 v38; // rdx
  _BOOL8 v50; // rtt
  __int64 v51; // rbp
  __int64 v52; // rtt
  _BOOL8 v54; // rtt
  unsigned __int64 v56; // rdx
  __int64 v69; // rbp
  __int64 v70; // rbx
  __int64 v71; // r8
  __int64 v72; // rtt
  unsigned __int64 v73; // rdx
  __int64 v74; // r9
  __int64 v75; // rtt
  unsigned __int64 v76; // r10
  __int64 result; // rax
  unsigned __int64 v78; // rcx
  __int64 v79; // r12
  __int64 v80; // r8
  unsigned __int64 v81; // r13
  unsigned __int64 v82; // rbp
  unsigned __int64 v83; // r9

  *(_OWORD *)&a4 = a4;
  v9 = a2 * a4;
  v8 = (a2 * (unsigned __int128)a4) >> 64;
  v7 = v9;
  _R10 = (unsigned __int64)_R10;
  *(_QWORD *)&_R10 = (a2 * (unsigned __int128)(unsigned __int64)_R10) >> 64;
  *(__int128 *)((char *)&_R10 + 8) = *((unsigned __int64 *)&_R10 + 1);
  v11 = a2 * *((_QWORD *)&_R10 + 1);
  *((_QWORD *)&_R10 + 1) = (a2 * (unsigned __int128)*((unsigned __int64 *)&_R10 + 1)) >> 64;
  _R12 = (unsigned __int64)_R12;
  v13 = __CFADD__(v11, (_QWORD)_R10);
  *(_QWORD *)&_R10 = v11 + _R10;
  v14 = v13;
  v13 = __CFADD__(v13, *((_QWORD *)&_R10 + 1));
  *((_QWORD *)&_R10 + 1) += v14;
  v13 |= __CFADD__(a2 * _R12, *((_QWORD *)&_R10 + 1));
  *((_QWORD *)&_R10 + 1) += a2 * _R12;
  *(_QWORD *)&_R12 = v13 + ((a2 * (unsigned __int128)(unsigned __int64)_R12) >> 64);
  v13 = __CFADD__(v7 << 32, v8);
  _R9 = (v7 << 32) + v8;
  v16 = v13;
  v13 = __CFADD__(v13, (_QWORD)_R10);
  *(_QWORD *)&_R10 = v16 + _R10;
  v13 |= __CFADD__(HIDWORD(v7), (_QWORD)_R10);
  *(_QWORD *)&_R10 = HIDWORD(v7) + _R10;
  v17 = (v7 * (unsigned __int128)0xFFFFFFFF00000001uLL) >> 64;
  v18 = v13;
  v13 = __CFADD__(v13, *((_QWORD *)&_R10 + 1));
  *((_QWORD *)&_R10 + 1) += v18;
  v13 |= __CFADD__(0xFFFFFFFF00000001uLL * v7, *((_QWORD *)&_R10 + 1));
  *((_QWORD *)&_R10 + 1) += 0xFFFFFFFF00000001uLL * v7;
  v19 = v13;
  v13 = __CFADD__(v13, (_QWORD)_R12);
  *(_QWORD *)&_R12 = v19 + _R12;
  v13 |= __CFADD__(v17, (_QWORD)_R12);
  *(_QWORD *)&_R12 = v17 + _R12;
  *((_QWORD *)&_R12 + 1) += v13;
  _R8 = 0;
  v21 = v4[1];
  _RBP = (v21 * (unsigned __int128)v6[16]) >> 64;
  _RCX = v21 * v6[16];
  __asm
  {
    adcx    r9, rcx
    adox    r10, rbp
  }
  _RBP = (v21 * (unsigned __int128)v6[17]) >> 64;
  _RCX = v21 * v6[17];
  __asm
  {
    adcx    r10, rcx
    adox    r11, rbp
  }
  _RBP = (v21 * (unsigned __int128)v6[18]) >> 64;
  _RCX = v21 * v6[18];
  __asm
  {
    adcx    r11, rcx
    adox    r12, rbp
  }
  _RBP = (v21 * (unsigned __int128)v6[19]) >> 64;
  _RCX = v21 * v6[19];
  __asm { adcx    r12, rcx }
  __asm { adox    r13, rbp }
  __asm
  {
    adcx    r13, r8
    adox    r8, r8
  }
  v13 = __CFADD__(_R9 << 32, (_QWORD)_R10);
  *(_QWORD *)&_R10 = (_R9 << 32) + _R10;
  v32 = v13;
  v13 = __CFADD__(v13, *((_QWORD *)&_R10 + 1));
  *((_QWORD *)&_R10 + 1) += v32;
  v13 |= __CFADD__(HIDWORD(_R9), *((_QWORD *)&_R10 + 1));
  *((_QWORD *)&_R10 + 1) += HIDWORD(_R9);
  v33 = (_R9 * (unsigned __int128)0xFFFFFFFF00000001uLL) >> 64;
  v34 = v13;
  v13 = __CFADD__(v13, (_QWORD)_R12);
  *(_QWORD *)&_R12 = v34 + _R12;
  v13 |= __CFADD__(0xFFFFFFFF00000001uLL * _R9, (_QWORD)_R12);
  *(_QWORD *)&_R12 = 0xFFFFFFFF00000001uLL * _R9 + _R12;
  v35 = v13;
  v13 = __CFADD__(v13, *((_QWORD *)&_R12 + 1));
  *((_QWORD *)&_R12 + 1) += v35;
  v13 |= __CFADD__(v33, *((_QWORD *)&_R12 + 1));
  *((_QWORD *)&_R12 + 1) += v33;
  _R8 = v13 + _R8;
  _R9 = 0;
  v38 = v4[2];
  _RBP = (v38 * (unsigned __int128)v6[16]) >> 64;
  _RCX = v38 * v6[16];
  __asm
  {
    adcx    r10, rcx
    adox    r11, rbp
  }
  _RBP = (v38 * (unsigned __int128)v6[17]) >> 64;
  _RCX = v38 * v6[17];
  __asm
  {
    adcx    r11, rcx
    adox    r12, rbp
  }
  _RBP = (v38 * (unsigned __int128)v6[18]) >> 64;
  _RCX = v38 * v6[18];
  __asm
  {
    adcx    r12, rcx
    adox    r13, rbp
  }
  _RBP = (v38 * (unsigned __int128)v6[19]) >> 64;
  _RCX = v38 * v6[19];
  __asm { adcx    r13, rcx }
  __asm { adox    r8, rbp }
  __asm
  {
    adcx    r8, r9
    adox    r9, r9
  }
  v13 = __CFADD__((_QWORD)_R10 << 32, *((_QWORD *)&_R10 + 1));
  *((_QWORD *)&_R10 + 1) += (_QWORD)_R10 << 32;
  v50 = v13;
  v13 = __CFADD__(v13, (_QWORD)_R12);
  *(_QWORD *)&_R12 = v50 + _R12;
  v13 |= __CFADD__(DWORD1(_R10), (_QWORD)_R12);
  *(_QWORD *)&_R12 = DWORD1(_R10) + _R12;
  v51 = ((unsigned __int64)_R10 * (unsigned __int128)0xFFFFFFFF00000001uLL) >> 64;
  v52 = v13;
  v13 = __CFADD__(v13, *((_QWORD *)&_R12 + 1));
  *((_QWORD *)&_R12 + 1) += v52;
  v13 |= __CFADD__(0xFFFFFFFF00000001uLL * _R10, *((_QWORD *)&_R12 + 1));
  *((_QWORD *)&_R12 + 1) += 0xFFFFFFFF00000001uLL * _R10;
  v54 = v13;
  v13 = __CFADD__(v13, _R8);
  _R8 = v54 + _R8;
  v13 |= __CFADD__(v51, _R8);
  _R8 += v51;
  _R9 = v13 + _R9;
  *(_QWORD *)&_R10 = 0;
  v56 = v4[3];
  _RBP = (v56 * (unsigned __int128)v6[16]) >> 64;
  _RCX = v56 * v6[16];
  __asm
  {
    adcx    r11, rcx
    adox    r12, rbp
  }
  _RBP = (v56 * (unsigned __int128)v6[17]) >> 64;
  _RCX = v56 * v6[17];
  __asm
  {
    adcx    r12, rcx
    adox    r13, rbp
  }
  _RBP = (v56 * (unsigned __int128)v6[18]) >> 64;
  _RCX = v56 * v6[18];
  __asm
  {
    adcx    r13, rcx
    adox    r8, rbp
  }
  _RBP = (v56 * (unsigned __int128)v6[19]) >> 64;
  _RCX = v56 * v6[19];
  __asm { adcx    r8, rcx }
  __asm { adox    r9, rbp }
  __asm
  {
    adcx    r9, r10
    adox    r10, r10
  }
  v13 = __CFADD__(__CFADD__(*((_QWORD *)&_R10 + 1) << 32, (_QWORD)_R12), *((_QWORD *)&_R12 + 1));
  *((_QWORD *)&_R12 + 1) += __CFADD__(*((_QWORD *)&_R10 + 1) << 32, (_QWORD)_R12);
  v69 = (*((unsigned __int64 *)&_R10 + 1) * (unsigned __int128)0xFFFFFFFF00000001uLL) >> 64;
  v70 = (*((_QWORD *)&_R10 + 1) << 32) + _R12;
  v72 = v13 | (unsigned __int8)__CFADD__(HIDWORD(*((_QWORD *)&_R10 + 1)), *((_QWORD *)&_R12 + 1));
  v13 = __CFADD__(v72, _R8);
  v71 = v72 + _R8;
  v73 = HIDWORD(*((_QWORD *)&_R10 + 1)) + *((_QWORD *)&_R12 + 1);
  v75 = v13 | (unsigned __int8)__CFADD__(0xFFFFFFFF00000001uLL * *((_QWORD *)&_R10 + 1), v71);
  v13 = __CFADD__(v75, _R9);
  v74 = v75 + _R9;
  v76 = (v13 | (unsigned __int8)__CFADD__(v69, v74)) + (_QWORD)_R10;
  result = 0;
  v78 = 0xFFFFFFFF00000001uLL * *((_QWORD *)&_R10 + 1) + v71;
  v79 = v70 + 1;
  v80 = (__PAIR128__(v78, v73) - ((unsigned __int64)(v70 != -1) + 0xFFFFFFFF)) >> 64;
  v81 = v73 - ((v70 != -1) + 0xFFFFFFFFLL);
  v82 = v69 + v74;
  v83 = v82 - ((__PAIR128__(v78, v73) < (unsigned __int64)(v70 != -1) + 0xFFFFFFFF) - 0xFFFFFFFFLL);
  if ( __PAIR128__(v76, v82) < (unsigned __int64)(__PAIR128__(v78, v73) < (unsigned __int64)(v70 != -1) + 0xFFFFFFFF)
                             - 0xFFFFFFFF )
  {
    v79 = v70;
    v81 = v73;
  }
  *v5 = v79;
  if ( __PAIR128__(v76, v82) < (unsigned __int64)(__PAIR128__(v78, v73) < (unsigned __int64)(v70 != -1) + 0xFFFFFFFF)
                             - 0xFFFFFFFF )
    v80 = v78;
  v5[1] = v81;
  if ( __PAIR128__(v76, v82) < (unsigned __int64)(__PAIR128__(v78, v73) < (unsigned __int64)(v70 != -1) + 0xFFFFFFFF)
                             - 0xFFFFFFFF )
    v83 = v82;
  v5[2] = v80;
  v5[3] = v83;
  return result;
}


// ==== sub_7FF91DCA2140 @ rva 0x42140 ====
// local variable allocation has failed, the output may be wrong!
__int64 __fastcall sub_7FF91DCA2140(__int64 a1, unsigned __int64 a2, unsigned __int64 a3)
{
  _QWORD *v3; // rdi
  unsigned __int64 *v4; // rsi
  unsigned __int64 v5; // r14
  __int128 v27; // r8 OVERLAPPED
  unsigned __int64 v38; // rdx
  __int64 v47; // r10
  __int64 v48; // r11
  _BOOL8 v49; // rtt
  __int64 v50; // r11
  _BOOL8 v51; // rtt
  __int128 v52; // r10 OVERLAPPED
  __int64 v53; // rtt
  __int64 result; // rax
  __int64 v55; // rtt
  _BOOL8 v56; // rtt
  __int64 v57; // r12
  __int64 v58; // r13
  __int64 v59; // r8
  __int64 v60; // r14
  __int64 v61; // rtt
  __int64 v62; // r15
  __int64 v63; // rtt
  unsigned __int64 v64; // r9
  __int64 v65; // r12
  unsigned __int64 v66; // r10
  unsigned __int64 v67; // r13
  __int64 v68; // r14
  unsigned __int64 v69; // r11
  unsigned __int64 v70; // r15
  bool v71; // cf

  _R10 = (a2 * (unsigned __int128)v5) >> 64;
  _R12 = (a2 * (unsigned __int128)a3 + ((a2 * (unsigned __int128)0LL) >> 64)) >> 64;
  _R11 = (__PAIR128__(a3, 0) * a2) >> 64;
  _R13 = 0;
  _RBP = (v5 * (unsigned __int128)0LL) >> 64;
  _RCX = 0;
  __asm
  {
    adcx    r11, rcx
    adox    r12, rbp
  }
  _RBP = (v5 * (unsigned __int128)a3) >> 64;
  _RCX = v5 * a3;
  __asm
  {
    adcx    r12, rcx
    adox    r13, rbp
  }
  *(_OWORD *)&a3 = a3;
  _R14 = (0 * (unsigned __int128)a3) >> 64;
  _RCX = 0;
  _R15 = 0;
  __asm
  {
    adcx    r9, r9
    adox    r13, rcx
    adcx    r10, r10
    adox    r14, r15
  }
  _RBP = (v4[16] * (unsigned __int128)v4[16]) >> 64;
  *(_QWORD *)&v27 = v4[16] * v4[16];
  __asm
  {
    adcx    r11, r11
    adox    r9, rbp
    adcx    r12, r12
  }
  _RAX = (v4[17] * (unsigned __int128)v4[17]) >> 64;
  _RCX = v4[17] * v4[17];
  __asm
  {
    adcx    r13, r13
    adox    r10, rcx
    adcx    r14, r14
  }
  _RBP = (v4[18] * (unsigned __int128)v4[18]) >> 64;
  _RCX = v4[18] * v4[18];
  v38 = v4[19];
  __asm
  {
    adox    r11, rax
    adcx    r15, r15
    adox    r12, rcx
  }
  __asm { adox    r13, rbp }
  _RAX = (v38 * (unsigned __int128)v38) >> 64;
  _RCX = v38 * v38;
  __asm { adox    r14, rcx }
  __asm { adox    r15, rax }
  v71 = __CFADD__(__CFADD__((_QWORD)v27 << 32, _R9), _R10);
  v47 = __CFADD__((_QWORD)v27 << 32, _R9) + _R10;
  v71 |= __CFADD__(DWORD1(v27), v47);
  v47 += DWORD1(v27);
  v27 = (unsigned __int64)v27;
  v49 = v71;
  v71 = __CFADD__(v71, _R11);
  v48 = v49 + _R11;
  v71 |= __CFADD__(0xFFFFFFFF00000001uLL * v27, v48);
  v48 += 0xFFFFFFFF00000001uLL * v27;
  *(_QWORD *)&v27 = v71 + ((0xFFFFFFFF00000001uLL * (unsigned __int128)(unsigned __int64)v27) >> 64);
  v71 = __CFADD__(__CFADD__(*((_QWORD *)&v27 + 1) << 32, v47), v48);
  v50 = __CFADD__(*((_QWORD *)&v27 + 1) << 32, v47) + v48;
  *(__int128 *)((char *)&v27 + 8) = *((unsigned __int64 *)&v27 + 1);
  v51 = v71;
  v71 = __CFADD__(v71, (_QWORD)v27);
  *(_QWORD *)&v27 = v51 + v27;
  v71 |= __CFADD__(0xFFFFFFFF00000001uLL * *((_QWORD *)&v27 + 1), (_QWORD)v27);
  *(_QWORD *)&v27 = 0xFFFFFFFF00000001uLL * *((_QWORD *)&v27 + 1) + v27;
  *((_QWORD *)&v27 + 1) = v71 + ((0xFFFFFFFF00000001uLL * (unsigned __int128)*((unsigned __int64 *)&v27 + 1)) >> 64);
  v71 = __CFADD__(__CFADD__((_QWORD)v52 << 32, v50), (_QWORD)v27);
  *(_QWORD *)&v27 = __CFADD__((_QWORD)v52 << 32, v50) + (_QWORD)v27;
  v52 = (unsigned __int64)v52;
  v53 = v71;
  v71 = __CFADD__(v71, *((_QWORD *)&v27 + 1));
  *((_QWORD *)&v27 + 1) += v53;
  v71 |= __CFADD__(0xFFFFFFFF00000001uLL * v52, *((_QWORD *)&v27 + 1));
  *((_QWORD *)&v27 + 1) += 0xFFFFFFFF00000001uLL * v52;
  *(_QWORD *)&v52 = v71 + ((0xFFFFFFFF00000001uLL * (unsigned __int128)(unsigned __int64)v52) >> 64);
  result = 0;
  v71 = __CFADD__(*((_QWORD *)&v52 + 1) << 32, (_QWORD)v27);
  *(_QWORD *)&v27 = (*((_QWORD *)&v52 + 1) << 32) + v27;
  v55 = v71;
  v71 = __CFADD__(v71, *((_QWORD *)&v27 + 1));
  *((_QWORD *)&v27 + 1) += v55;
  *(__int128 *)((char *)&v52 + 8) = *((unsigned __int64 *)&v52 + 1);
  v56 = v71;
  v71 = __CFADD__(v71, (_QWORD)v52);
  *(_QWORD *)&v52 = v56 + v52;
  v71 |= __CFADD__(0xFFFFFFFF00000001uLL * *((_QWORD *)&v52 + 1), (_QWORD)v52);
  *(_QWORD *)&v52 = 0xFFFFFFFF00000001uLL * *((_QWORD *)&v52 + 1) + v52;
  *((_QWORD *)&v52 + 1) = v71 + ((0xFFFFFFFF00000001uLL * (unsigned __int128)*((unsigned __int64 *)&v52 + 1)) >> 64);
  v71 = __CFADD__(__CFADD__((_QWORD)v27, v57), _R13);
  v58 = __CFADD__((_QWORD)v27, v57) + _R13;
  v59 = v27 + v57;
  v61 = v71 | (unsigned __int8)__CFADD__(*((_QWORD *)&v27 + 1), v58);
  v71 = __CFADD__(v61, _R14);
  v60 = v61 + _R14;
  v63 = v71 | (unsigned __int8)__CFADD__((_QWORD)v52, v60);
  v71 = __CFADD__(v63, _R15);
  v62 = v63 + _R15;
  v71 |= __CFADD__(*((_QWORD *)&v52 + 1), v62);
  v64 = *((_QWORD *)&v27 + 1) + v58;
  v65 = v59 + 1;
  v66 = v52 + v60;
  v68 = (__PAIR128__(v66, v64) - ((unsigned __int64)(v59 != -1) + 0xFFFFFFFF)) >> 64;
  v67 = v64 - ((v59 != -1) + 0xFFFFFFFFLL);
  v69 = *((_QWORD *)&v52 + 1) + v62;
  v70 = v69 - ((__PAIR128__(v66, v64) < (unsigned __int64)(v59 != -1) + 0xFFFFFFFF) - 0xFFFFFFFFLL);
  v71 = __PAIR128__(v71, v69) < (unsigned __int64)(__PAIR128__(v66, v64) < (unsigned __int64)(v59 != -1) + 0xFFFFFFFF)
                              - 0xFFFFFFFF;
  if ( v71 )
  {
    v65 = v59;
    v67 = v64;
  }
  *v3 = v65;
  if ( v71 )
    v68 = v66;
  v3[1] = v67;
  if ( v71 )
    v70 = v69;
  v3[2] = v68;
  v3[3] = v70;
  return result;
}


// ==== sub_7FF91DCA2300 @ rva 0x42300 ====
unsigned __int64 __fastcall sub_7FF91DCA2300(__int64 *a1, unsigned __int64 *a2)
{
  unsigned __int64 v3; // r9
  unsigned __int64 v4; // r10
  unsigned __int64 v5; // r11
  unsigned __int64 v6; // rcx
  unsigned __int64 v7; // r8
  unsigned __int128 v8; // rax
  unsigned __int64 v9; // r10
  unsigned __int64 v10; // r11
  _BOOL8 v11; // rtt
  unsigned __int64 v12; // rcx
  unsigned __int64 v13; // r9
  __int64 v14; // r8
  unsigned __int128 v15; // rax
  unsigned __int64 v16; // r11
  __int64 v17; // r8
  _BOOL8 v18; // rtt
  unsigned __int64 v19; // rcx
  unsigned __int64 v20; // r10
  __int64 v21; // r9
  unsigned __int128 v22; // rax
  __int64 v23; // r8
  __int64 v24; // r9
  _BOOL8 v25; // rtt
  unsigned __int64 v26; // rcx
  __int64 v27; // r11
  __int64 v28; // r10
  unsigned __int128 v29; // rax
  unsigned __int64 v30; // r9
  __int64 v31; // rcx
  __int64 v32; // r10
  _BOOL8 v33; // rtt
  unsigned __int64 v34; // rsi
  __int64 v35; // rdx
  __int64 v36; // r8
  unsigned __int64 result; // rax
  bool v38; // cf
  __int64 v39; // r9
  __int64 v40; // r10
  unsigned __int64 v41; // rtt
  __int64 v42; // r11
  unsigned __int128 v43; // kr10_16

  v3 = a2[1];
  v4 = a2[2];
  v5 = a2[3];
  v6 = *a2;
  v7 = *a2 << 32;
  v8 = 0xFFFFFFFF00000001uLL * (unsigned __int128)*a2;
  v6 >>= 32;
  v38 = __CFADD__(__CFADD__(v7, v3), v4);
  v9 = __CFADD__(v7, v3) + v4;
  v38 |= __CFADD__(v6, v9);
  v9 += v6;
  v11 = v38;
  v38 = __CFADD__(v38, v5);
  v10 = v11 + v5;
  v38 |= __CFADD__((_QWORD)v8, v10);
  v10 += v8;
  v12 = v7 + v3;
  v13 = (v7 + v3) << 32;
  v14 = v38 + *((_QWORD *)&v8 + 1);
  v15 = 0xFFFFFFFF00000001uLL * (unsigned __int128)v12;
  v12 >>= 32;
  v38 = __CFADD__(__CFADD__(v13, v9), v10);
  v16 = __CFADD__(v13, v9) + v10;
  v38 |= __CFADD__(v12, v16);
  v16 += v12;
  v18 = v38;
  v38 = __CFADD__(v38, v14);
  v17 = v18 + v14;
  v38 |= __CFADD__((_QWORD)v15, v17);
  v17 += v15;
  v19 = v13 + v9;
  v20 = (v13 + v9) << 32;
  v21 = v38 + *((_QWORD *)&v15 + 1);
  v22 = 0xFFFFFFFF00000001uLL * (unsigned __int128)v19;
  v19 >>= 32;
  v38 = __CFADD__(__CFADD__(v20, v16), v17);
  v23 = __CFADD__(v20, v16) + v17;
  v38 |= __CFADD__(v19, v23);
  v23 += v19;
  v25 = v38;
  v38 = __CFADD__(v38, v21);
  v24 = v25 + v21;
  v38 |= __CFADD__((_QWORD)v22, v24);
  v24 += v22;
  v26 = v20 + v16;
  v27 = (v20 + v16) << 32;
  v28 = v38 + *((_QWORD *)&v22 + 1);
  v29 = 0xFFFFFFFF00000001uLL * (unsigned __int128)v26;
  v26 >>= 32;
  v38 = __CFADD__(__CFADD__(v27, v23), v24);
  v30 = __CFADD__(v27, v23) + v24;
  v38 |= __CFADD__(v26, v30);
  v30 += v26;
  v31 = v27 + v23;
  v33 = v38;
  v38 = __CFADD__(v38, v28);
  v32 = v33 + v28;
  v34 = v30;
  v35 = (v38 | (unsigned __int8)__CFADD__((_QWORD)v29, v32)) + *((_QWORD *)&v29 + 1);
  v38 = v27 + v23 != -1;
  v36 = v27 + v23 + 1;
  result = v29 + v32;
  v41 = v38 + 0xFFFFFFFFLL;
  v38 = v30 < v41;
  v40 = (__PAIR128__(result, v30) - v41) >> 64;
  v39 = v30 - v41;
  v42 = v35;
  v43 = (unsigned __int64)v35 - (unsigned __int128)((unsigned __int64)(result < v38) - 0xFFFFFFFF);
  if ( *((_QWORD *)&v43 + 1) )
  {
    v36 = v31;
    v39 = v34;
  }
  *a1 = v36;
  if ( *((_QWORD *)&v43 + 1) )
    v40 = result;
  a1[1] = v39;
  if ( !*((_QWORD *)&v43 + 1) )
    v42 = v35 - ((result < v38) - 0xFFFFFFFFLL);
  a1[2] = v40;
  a1[3] = v42;
  return result;
}


// ==== sub_7FF91DCA2420 @ rva 0x42420 ====
__int64 __fastcall sub_7FF91DCA2420(__m128i *a1, const __m128i *a2, unsigned int a3)
{
  __m128i si128; // xmm0
  __m128i v4; // xmm2
  __m128i v5; // xmm3
  __m128i v6; // xmm4
  __m128i v7; // xmm5
  __m128i v8; // xmm6
  __m128i v9; // xmm7
  __m128i v10; // xmm8
  __m128i v11; // xmm1
  __int64 result; // rax
  __m128i v13; // xmm15
  __m128i v14; // xmm15
  __m128i v15; // xmm9
  __m128i v16; // xmm10
  __m128i v17; // xmm11
  __m128i v18; // xmm12
  __m128i v19; // xmm13
  __m128i v20; // xmm14

  if ( (dword_7FF91E91A5F8 & 0x20) != 0 )
    JUMPOUT(0x7FF91DCA26C0LL);
  si128 = _mm_load_si128((const __m128i *)&ymmword_7FF91DCA14C0);
  v4 = 0;
  v5 = 0;
  v6 = 0;
  v7 = 0;
  v8 = 0;
  v9 = 0;
  v10 = si128;
  v11 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a3), 0);
  result = 16;
  do
  {
    v13 = v10;
    v10 = _mm_add_epi32(v10, si128);
    v14 = _mm_cmpeq_epi32(v13, v11);
    v15 = _mm_load_si128(a2);
    v16 = _mm_load_si128(a2 + 1);
    v17 = _mm_load_si128(a2 + 2);
    v18 = _mm_load_si128(a2 + 3);
    v19 = _mm_load_si128(a2 + 4);
    v20 = _mm_load_si128(a2 + 5);
    a2 += 6;
    v4 = _mm_or_si128(v4, _mm_and_si128(v15, v14));
    v5 = _mm_or_si128(v5, _mm_and_si128(v16, v14));
    v6 = _mm_or_si128(v6, _mm_and_si128(v17, v14));
    v7 = _mm_or_si128(v7, _mm_and_si128(v18, v14));
    v8 = _mm_or_si128(v8, _mm_and_si128(v19, v14));
    v9 = _mm_or_si128(v9, _mm_and_si128(v20, v14));
    --result;
  }
  while ( result );
  *a1 = v4;
  a1[1] = v5;
  a1[2] = v6;
  a1[3] = v7;
  a1[4] = v8;
  a1[5] = v9;
  return result;
}


// ==== sub_7FF91DCA2580 @ rva 0x42580 ====
__int64 __fastcall sub_7FF91DCA2580(__m128i *_RCX, const __m128i *_RDX, unsigned int _R8D)
{
  __m128i si128; // xmm8
  __m128i v16; // xmm2
  __m128i v17; // xmm3
  __m128i v18; // xmm4
  __m128i v19; // xmm5
  __m128i v20; // xmm0
  __m128i v21; // xmm1
  __int64 result; // rax
  __m128i v23; // xmm15
  __m128i v24; // xmm9
  __m128i v25; // xmm10
  __m128i v26; // xmm15
  __m128i v27; // xmm11
  __m128i v28; // xmm12
  _OWORD v64[8]; // [rsp+20h] [rbp-88h] BYREF

  if ( (dword_7FF91E91A5F8 & 0x20) != 0 )
  {
    __asm { vzeroupper }
    _RAX = v64;
    __asm
    {
      vmovaps xmmword ptr [rax-20h], xmm6
      vmovaps xmmword ptr [rax-10h], xmm7
      vmovaps xmmword ptr [rax+0], xmm8
      vmovaps xmmword ptr [rax+10h], xmm9
      vmovaps xmmword ptr [rax+20h], xmm10
      vmovaps xmmword ptr [rax+30h], xmm11
      vmovaps xmmword ptr [rax+40h], xmm12
      vmovaps xmmword ptr [rax+50h], xmm13
      vmovaps xmmword ptr [rax+60h], xmm14
      vmovaps xmmword ptr [rax+70h], xmm15
      vmovdqa ymm0, cs:ymmword_7FF91DCA1500
      vpxor   ymm2, ymm2, ymm2
      vpxor   ymm3, ymm3, ymm3
      vmovdqa ymm4, cs:ymmword_7FF91DCA14C0
      vmovdqa ymm8, cs:ymmword_7FF91DCA14E0
      vmovdqa ymm12, cs:ymmword_7FF91DCA1500
      vmovd   xmm1, r8d
      vpermd  ymm1, ymm2, ymm1
    }
    result = 21;
    do
    {
      __asm
      {
        vmovdqa ymm5, ymmword ptr [rdx]
        vmovdqa ymm6, ymmword ptr [rdx+20h]
        vmovdqa ymm9, ymmword ptr [rdx+40h]
        vmovdqa ymm10, ymmword ptr [rdx+60h]
        vmovdqa ymm13, ymmword ptr [rdx+80h]
        vmovdqa ymm14, ymmword ptr [rdx+0A0h]
        vpcmpeqd ymm7, ymm4, ymm1
        vpcmpeqd ymm11, ymm8, ymm1
        vpcmpeqd ymm15, ymm12, ymm1
        vpaddd  ymm4, ymm4, ymm0
        vpaddd  ymm8, ymm8, ymm0
        vpaddd  ymm12, ymm12, ymm0
      }
      _RDX += 12;
      __asm
      {
        vpand   ymm5, ymm5, ymm7
        vpand   ymm6, ymm6, ymm7
        vpand   ymm9, ymm9, ymm11
        vpand   ymm10, ymm10, ymm11
        vpand   ymm13, ymm13, ymm15
        vpand   ymm14, ymm14, ymm15
        vpxor   ymm2, ymm2, ymm5
        vpxor   ymm3, ymm3, ymm6
        vpxor   ymm2, ymm2, ymm9
        vpxor   ymm3, ymm3, ymm10
        vpxor   ymm2, ymm2, ymm13
        vpxor   ymm3, ymm3, ymm14
      }
      --result;
    }
    while ( result );
    __asm
    {
      vmovdqa ymm5, ymmword ptr [rdx]
      vmovdqa ymm6, ymmword ptr [rdx+20h]
      vpcmpeqd ymm7, ymm4, ymm1
      vpand   ymm5, ymm5, ymm7
      vpand   ymm6, ymm6, ymm7
      vpxor   ymm2, ymm2, ymm5
      vpxor   ymm3, ymm3, ymm6
      vmovdqu ymmword ptr [rcx], ymm2
      vmovdqu ymmword ptr [rcx+20h], ymm3
      vzeroupper
    }
  }
  else
  {
    v64[0] = _XMM8;
    v64[1] = _XMM9;
    v64[2] = _XMM10;
    v64[3] = _XMM11;
    v64[4] = _XMM12;
    v64[5] = _XMM13;
    v64[6] = _XMM14;
    v64[7] = _XMM15;
    si128 = _mm_load_si128((const __m128i *)&ymmword_7FF91DCA14C0);
    v16 = 0;
    v17 = 0;
    v18 = 0;
    v19 = 0;
    v20 = si128;
    v21 = _mm_shuffle_epi32(_mm_cvtsi32_si128(_R8D), 0);
    result = 64;
    do
    {
      v23 = si128;
      si128 = _mm_add_epi32(si128, v20);
      v24 = _mm_load_si128(_RDX);
      v25 = _mm_load_si128(_RDX + 1);
      v26 = _mm_cmpeq_epi32(v23, v21);
      v27 = _mm_load_si128(_RDX + 2);
      v28 = _mm_load_si128(_RDX + 3);
      _RDX += 4;
      v16 = _mm_or_si128(v16, _mm_and_si128(v24, v26));
      v17 = _mm_or_si128(v17, _mm_and_si128(v25, v26));
      v18 = _mm_or_si128(v18, _mm_and_si128(v27, v26));
      _mm_prefetch(&_RDX[15].m128i_i8[15], 1);
      v19 = _mm_or_si128(v19, _mm_and_si128(v28, v26));
      --result;
    }
    while ( result );
    *_RCX = v16;
    _RCX[1] = v17;
    _RCX[2] = v18;
    _RCX[3] = v19;
  }
  return result;
}


// ==== sub_7FF91DCA29A0 @ rva 0x429A0 ====
__int64 __fastcall sub_7FF91DCA29A0(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  _QWORD *v4; // rbx
  _QWORD *v5; // rdi
  __int64 v6; // r12
  __int64 v7; // r13
  __int64 v8; // r14
  __int64 v9; // r15
  __int64 v10; // r13
  __int64 result; // rax
  __int64 v12; // r8
  __int64 v13; // rtt
  __int64 v14; // r9
  __int64 v15; // rtt
  unsigned __int64 v16; // rbp
  __int64 v17; // r12
  unsigned __int64 v18; // rcx
  __int64 v19; // r8
  unsigned __int64 v20; // r13
  unsigned __int64 v21; // r10
  unsigned __int64 v22; // r9
  bool v23; // cf

  v23 = __CFADD__(__CFADD__(*v4, v6), v7);
  v10 = __CFADD__(*v4, v6) + v7;
  result = *v4 + v6;
  v13 = v23 | (unsigned __int8)__CFADD__(v4[1], v10);
  v23 = __CFADD__(v13, a3);
  v12 = v13 + a3;
  v15 = v23 | (unsigned __int8)__CFADD__(v4[2], v12);
  v23 = __CFADD__(v15, a4);
  v14 = v15 + a4;
  v23 |= __CFADD__(v4[3], v14);
  v16 = v4[1] + v10;
  v17 = result + 1;
  v18 = v4[2] + v12;
  v19 = (__PAIR128__(v18, v16) - ((unsigned __int64)(result != -1) + v8)) >> 64;
  v20 = v16 - ((result != -1) + v8);
  v21 = v4[3] + v14;
  v22 = v21 - ((__PAIR128__(v18, v16) < (unsigned __int64)(result != -1) + v8) + v9);
  v23 = __PAIR128__(v23, v21) < (unsigned __int64)(__PAIR128__(v18, v16) < (unsigned __int64)(result != -1) + v8) + v9;
  if ( v23 )
  {
    v17 = result;
    v20 = v16;
  }
  *v5 = v17;
  if ( v23 )
    v19 = v18;
  v5[1] = v20;
  if ( v23 )
    v22 = v21;
  v5[2] = v19;
  v5[3] = v22;
  return result;
}


// ==== sub_7FF91DCA2A00 @ rva 0x42A00 ====
unsigned __int64 __fastcall sub_7FF91DCA2A00(__int64 a1, __int64 a2, unsigned __int64 a3, unsigned __int64 a4)
{
  __int64 v4; // rbx
  _QWORD *v5; // rdi
  unsigned __int64 v6; // r12
  unsigned __int64 v7; // r13
  unsigned __int64 v8; // r14
  __int64 v9; // r15
  __int64 v10; // r9
  __int64 v11; // r11
  unsigned __int64 result; // rax
  unsigned __int64 v13; // rbp
  unsigned __int128 v14; // kr00_16
  unsigned __int128 v15; // kr20_16
  unsigned __int64 v16; // rcx
  unsigned __int64 v17; // r8
  __int64 v18; // r10
  __int64 v19; // r9

  v14 = __PAIR128__(v7, v6) - *(_OWORD *)v4;
  v13 = *((_QWORD *)&v14 + 1);
  result = v14;
  v11 = (a4
       - (unsigned __int128)((unsigned __int64)(a3 < (unsigned __int64)(__PAIR128__(v7, v6) < *(_OWORD *)v4)
                                                   + *(_QWORD *)(v4 + 16))
                           + *(_QWORD *)(v4 + 24))) >> 64;
  v10 = (__PAIR128__(a4, a3)
       - __PAIR128__(
           *(_QWORD *)(v4 + 24),
           (unsigned __int64)(__PAIR128__(v7, v6) < *(_OWORD *)v4) + *(_QWORD *)(v4 + 16))) >> 64;
  v16 = a3 - ((__PAIR128__(v7, v6) < *(_OWORD *)v4) + *(_QWORD *)(v4 + 16));
  v15 = v14 + __PAIR128__(v8, -1);
  v17 = (__CFADD__(result != 0, v13)
       | (unsigned __int8)__CFADD__(v8, (__PAIR128__(v13, result) + __PAIR128__(v8, -1)) >> 64))
      + v16;
  v18 = v10;
  v19 = v9
      + __CFADD__(
          __CFADD__(result != 0, v13)
        | (unsigned __int8)__CFADD__(v8, (__PAIR128__(v13, result) + __PAIR128__(v8, -1)) >> 64),
          v16)
      + v10;
  if ( !v11 )
    v15 = v14;
  *v5 = v15;
  if ( !v11 )
    v17 = v16;
  v5[1] = *((_QWORD *)&v15 + 1);
  if ( !v11 )
    v19 = v18;
  v5[2] = v17;
  v5[3] = v19;
  return result;
}


// ==== sub_7FF91DCA2A60 @ rva 0x42A60 ====
__int64 __fastcall sub_7FF91DCA2A60()
{
  __int64 v0; // rax
  __int64 v1; // r12

  return v0 - v1 - 1;
}


// ==== sub_7FF91DCA2AA0 @ rva 0x42AA0 ====
__int64 __fastcall sub_7FF91DCA2AA0(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 *v4; // rdi
  __int64 v5; // r12
  __int64 v6; // r13
  __int64 v7; // r14
  __int64 v8; // r15
  __int64 result; // rax
  unsigned __int64 v10; // r8
  unsigned __int64 v11; // r9
  __int64 v12; // rtt
  unsigned __int64 v13; // rbp
  unsigned __int64 v14; // r11
  __int64 v15; // r12
  __int64 v16; // rcx
  __int64 v17; // r13
  __int64 v18; // r8
  _BOOL8 v19; // rtt
  __int64 v20; // r10
  __int64 v21; // r9
  unsigned __int64 v22; // rtt
  char v23; // cf

  v23 = __CFADD__(__CFADD__(v5, v5), v6) | __CFADD__(v6, __CFADD__(v5, v5) + v6);
  result = 2 * v5;
  v23 = __CFADD__(v23, a3) | __CFADD__(a3, v23 + a3);
  v10 = a3 + (__CFADD__(__CFADD__(v5, v5), v6) | (unsigned __int8)__CFADD__(v6, __CFADD__(v5, v5) + v6)) + a3;
  v12 = v23 + a4;
  v23 = __CFADD__(v23, a4) | __CFADD__(a4, v12);
  v11 = a4 + v12;
  v13 = v6 + __CFADD__(v5, v5) + v6;
  v14 = v23;
  v23 = 2 * v5 != -1;
  v15 = 2 * v5 + 1;
  v16 = v10;
  v17 = v13 - (v23 + v7);
  v19 = v13 < (unsigned __int64)v23 + v7;
  v23 = __PAIR128__(v10, v13) < (unsigned __int64)v23 + v7;
  v18 = v10 - v19;
  v20 = v11;
  v22 = v23 + v8;
  v23 = v11 < v22;
  v21 = v11 - v22;
  v23 = v14 < v23;
  if ( v23 )
  {
    v15 = result;
    v17 = v13;
  }
  *v4 = v15;
  if ( v23 )
    v18 = v16;
  v4[1] = v17;
  if ( v23 )
    v21 = v20;
  v4[2] = v18;
  v4[3] = v21;
  return result;
}


// ==== sub_7FF91DCA2B00 @ rva 0x42B00 ====
unsigned __int64 __fastcall sub_7FF91DCA2B00(_QWORD *a1, const __m128i *a2)
{
  __int64 v2; // rbp
  __int64 v5; // rcx
  __int64 v7; // r8
  __int64 v8; // r9
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // rdx
  __int64 v12; // rcx
  __int64 v13; // rdx
  __int64 v14; // rcx
  __int64 v15; // r8
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // r8
  __int64 v19; // r9
  __int64 v20; // rdx
  __int64 v21; // rcx
  __int64 v22; // rdx
  __int64 v23; // rcx
  unsigned __int64 v24; // r14
  __int64 v25; // r15
  __int64 v26; // rdx
  __int64 v27; // rcx
  __int64 v28; // rdx
  __int128 v29; // kr00_16
  unsigned __int64 v30; // rcx
  bool v31; // cf
  unsigned __int64 v32; // r14
  __int64 v33; // r8
  unsigned __int64 v34; // r15
  _BOOL8 v35; // rtt
  __int64 v36; // r9
  __int64 v37; // rdx
  __int64 v38; // rcx
  __int64 v39; // r8
  __int64 v40; // r9
  __int64 v41; // rdx
  __int64 v42; // rcx
  __int64 v43; // r8
  __int64 v44; // r9
  unsigned __int64 v45; // r12
  __int64 v46; // rdx
  __int64 v47; // rcx
  __int64 v48; // r8
  __int64 v49; // rdx
  __int64 v50; // rcx
  __int64 v51; // r8
  __int64 v52; // r9
  unsigned __int64 v53; // r14
  unsigned __int64 v54; // r15
  __int64 v55; // rdx
  __int64 v56; // rcx
  __int64 v57; // rdx
  __int64 v58; // rcx
  __int64 v59; // rdx
  __int64 v60; // r8
  __int64 v61; // rdx
  __int64 v62; // rcx
  unsigned __int64 v63; // r8
  unsigned __int64 v64; // r9
  unsigned __int64 v66[2]; // [rsp+0h] [rbp-D8h] BYREF
  __int64 v67; // [rsp+10h] [rbp-C8h]
  unsigned __int64 v68; // [rsp+18h] [rbp-C0h]
  unsigned __int64 v69; // [rsp+20h] [rbp-B8h]
  unsigned __int64 v70; // [rsp+28h] [rbp-B0h]
  unsigned __int64 v71; // [rsp+30h] [rbp-A8h]
  unsigned __int64 v72; // [rsp+38h] [rbp-A0h]
  __m128i v73; // [rsp+60h] [rbp-78h]
  __m128i v74; // [rsp+70h] [rbp-68h]
  __int64 v75; // [rsp+D0h] [rbp-8h]

  v5 = dword_7FF91E91A5F8 & 0x80100;
  if ( (_DWORD)v5 == 524544 )
    return sub_7FF91DCA3CF3();
  v75 = v2;
  v7 = a2[3].m128i_i64[0];
  v8 = a2[3].m128i_i64[1];
  v73 = _mm_loadu_si128(a2);
  v74 = _mm_loadu_si128(a2 + 1);
  sub_7FF91DCA2AA0(v5, (__int64)a2, v7, v8);
  sub_7FF91DCA1D20(v10, v9, a2[5].m128i_u64[1]);
  sub_7FF91DCA1D20(v12, v11, v68);
  sub_7FF91DCA1A40(v14, v13, v15, a2[4].m128i_u64[0]);
  sub_7FF91DCA2AA0(v17, v16, v18, v19);
  sub_7FF91DCA29A0(v21, v20, v74.m128i_i64[0], v74.m128i_i64[1]);
  sub_7FF91DCA2A00(v23, v22, v74.m128i_u64[0], v74.m128i_u64[1]);
  v24 = v66[1];
  v25 = v67;
  sub_7FF91DCA1D20(v27, v26, v68);
  v29 = *(_OWORD *)&v73 + __PAIR128__(v66, -1);
  v30 = v24;
  v31 = __CFADD__(
          __CFADD__(v73.m128i_i64[0] != 0, v73.m128i_i64[1])
        | (unsigned __int8)__CFADD__(v66, (*(_OWORD *)&v73 + __PAIR128__(v66, -1)) >> 64),
          v24);
  v32 = (__CFADD__(v73.m128i_i64[0] != 0, v73.m128i_i64[1])
       | (unsigned __int8)__CFADD__(v66, (*(_OWORD *)&v73 + __PAIR128__(v66, -1)) >> 64))
      + v24;
  v33 = v25;
  v35 = v31;
  v31 = __CFADD__(v31, v25);
  v34 = v35 + v25;
  v31 |= __CFADD__(v2, v34);
  v34 += v2;
  v36 = v31;
  if ( (v73.m128i_i8[0] & 1) == 0 )
  {
    v32 = v30;
    v34 = v33;
    v36 = 0;
    v29 = (__int128)v73;
  }
  a1[4] = v29 >> 1;
  a1[5] = (v32 << 63) | (*((_QWORD *)&v29 + 1) >> 1);
  a1[6] = (v34 << 63) | (v32 >> 1);
  a1[7] = (v36 << 63) | (v34 >> 1);
  sub_7FF91DCA1A40(v34 << 63, v28, v33, v69);
  sub_7FF91DCA2AA0(v38, v37, v39, v40);
  sub_7FF91DCA29A0(v42, v41, v43, v44);
  v45 = v68;
  sub_7FF91DCA1A40(v47, v46, v48, v66[0]);
  sub_7FF91DCA2AA0(v50, v49, v51, v52);
  v53 = v70;
  v54 = v71;
  sub_7FF91DCA1D20(v56, v55, v72);
  sub_7FF91DCA2A00(v58, v57, v53, v54);
  sub_7FF91DCA2A60(v67);
  sub_7FF91DCA1A40(0, v59, v60, v45);
  return sub_7FF91DCA2A00(v62, v61, v63, v64);
}


// ==== sub_7FF91DCA2E20 @ rva 0x42E20 ====
unsigned __int64 __fastcall sub_7FF91DCA2E20(__m128i *a1, const __m128i *a2, __int64 a3)
{
  __int64 v3; // r13
  __int64 v6; // rcx
  __int64 v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // rdx
  __int64 v10; // rcx
  __int64 v11; // r8
  __int64 v12; // rdx
  __int64 v13; // rcx
  __int64 v14; // r8
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // r8
  __int64 v18; // rdx
  __int64 v19; // rcx
  __int64 v20; // r8
  __int64 v21; // rdx
  __int64 v22; // rcx
  unsigned __int64 v23; // r8
  unsigned __int64 v24; // r9
  __int64 v25; // r8
  __m128i v26; // xmm4
  __m128i v27; // xmm5
  unsigned __int64 v28; // xmm2_8
  __int64 v29; // r9
  __int64 v30; // xmm3_8
  __int64 v31; // rdx
  __int64 v32; // rcx
  __int64 v33; // rdx
  __int64 v34; // rcx
  __int64 v35; // r8
  __int64 v36; // rdx
  __int64 v37; // rcx
  unsigned __int64 v38; // r8
  unsigned __int64 v39; // r9
  unsigned __int64 result; // rax
  __int64 v41; // rdx
  __int64 v42; // rcx
  __int64 v43; // r8
  __int64 v44; // r9
  __int64 v45; // rdx
  __int64 v46; // rcx
  __int64 v47; // r8
  __int64 v48; // r14
  __int64 v49; // r15
  __int64 v50; // rdx
  __int64 v51; // rcx
  __int64 v52; // rdx
  __int64 v53; // rcx
  __int64 v54; // r8
  __int64 v55; // rdx
  __int64 v56; // rcx
  __int64 v57; // r8
  __int64 v58; // r12
  __int64 v59; // rdx
  __int64 v60; // rcx
  __int64 v61; // r8
  char v62; // cf
  __int64 v63; // r8
  unsigned __int64 v64; // r8
  __int64 v65; // rbp
  __int64 v66; // r12
  __int64 v67; // r13
  __int64 v68; // r9
  __int64 v69; // rdx
  __int64 v70; // rcx
  unsigned __int64 v71; // r8
  unsigned __int64 v72; // r9
  __int64 v73; // r8
  __int64 v74; // r9
  __int64 v75; // rdx
  __int64 v76; // rcx
  __int64 v77; // rdx
  __int64 v78; // rcx
  __int64 v79; // r8
  __int64 v80; // rdx
  __int64 v81; // rcx
  unsigned __int64 v82; // r8
  unsigned __int64 v83; // r9
  __m128i v84; // xmm5
  __m128i v85; // xmm4
  unsigned __int64 v86; // [rsp+0h] [rbp-278h]
  __int64 v87; // [rsp+8h] [rbp-270h]
  __int64 v88; // [rsp+10h] [rbp-268h]
  unsigned __int64 v89; // [rsp+18h] [rbp-260h]
  unsigned __int64 v90; // [rsp+20h] [rbp-258h]
  __int64 v91; // [rsp+38h] [rbp-240h]
  unsigned __int64 v92; // [rsp+40h] [rbp-238h]
  unsigned __int64 v93; // [rsp+58h] [rbp-220h]
  unsigned __int64 v94; // [rsp+60h] [rbp-218h]
  unsigned __int64 v95; // [rsp+E0h] [rbp-198h]
  unsigned __int64 v96; // [rsp+100h] [rbp-178h]
  __int64 v97; // [rsp+118h] [rbp-160h]
  __m128i v98; // [rsp+120h] [rbp-158h]
  __m128i v99; // [rsp+130h] [rbp-148h]
  __m128i v100; // [rsp+140h] [rbp-138h]
  __m128i v101; // [rsp+150h] [rbp-128h]
  __m128i v102; // [rsp+160h] [rbp-118h]
  __m128i v103; // [rsp+170h] [rbp-108h]
  __m128i v104; // [rsp+180h] [rbp-F8h]
  __m128i v105; // [rsp+190h] [rbp-E8h]
  __m128i v106; // [rsp+1A0h] [rbp-D8h]
  __m128i v107; // [rsp+1B0h] [rbp-C8h]
  __m128i v108; // [rsp+1C0h] [rbp-B8h]
  __m128i v109; // [rsp+1D0h] [rbp-A8h]
  __m128i v110; // [rsp+1E0h] [rbp-98h]
  __m128i v111; // [rsp+1F0h] [rbp-88h]
  __m128i v112; // [rsp+200h] [rbp-78h]
  __m128i v113; // [rsp+210h] [rbp-68h]
  __m128i v114; // [rsp+220h] [rbp-58h]
  __m128i v115; // [rsp+230h] [rbp-48h]

  v6 = dword_7FF91E91A5F8 & 0x80100;
  if ( (_DWORD)v6 == 524544 )
    return sub_7FF91DCA4016(v6, a3);
  v104 = _mm_loadu_si128(a2);
  v105 = _mm_loadu_si128(a2 + 1);
  v106 = _mm_loadu_si128(a2 + 2);
  v107 = _mm_loadu_si128(a2 + 3);
  v108 = _mm_loadu_si128(a2 + 4);
  v109 = _mm_loadu_si128(a2 + 5);
  v110 = _mm_loadu_si128((const __m128i *)a3);
  v111 = _mm_loadu_si128((const __m128i *)(a3 + 16));
  v112 = _mm_loadu_si128((const __m128i *)(a3 + 32));
  v113 = _mm_loadu_si128((const __m128i *)(a3 + 48));
  v114 = *(__m128i *)(a3 + 64);
  v115 = *(__m128i *)(a3 + 80);
  sub_7FF91DCA1D20(v6, a3, v115.m128i_u64[1]);
  sub_7FF91DCA1D20(v8, v7, a2[5].m128i_u64[1]);
  sub_7FF91DCA1A40(v10, v9, v11, v94);
  sub_7FF91DCA1A40(v13, v12, v14, v90);
  sub_7FF91DCA1A40(v16, v15, v17, v95);
  sub_7FF91DCA1A40(v19, v18, v20, v96);
  sub_7FF91DCA2A00(v22, v21, v23, v24);
  v28 = _mm_or_si128(v26, v27).m128i_u64[0];
  v30 = v29 | v25 | v3 | v97;
  sub_7FF91DCA1A40(v32, v31, v25, v94);
  sub_7FF91DCA1A40(v34, v33, v35, v90);
  result = sub_7FF91DCA2A00(v37, v36, v38, v39);
  if ( v44 | v43 | v3 | v91 || v28 )
  {
    sub_7FF91DCA1D20(v42, v41, v93);
    sub_7FF91DCA1A40(v46, v45, v47, v86);
    v48 = v87;
    v49 = v88;
    sub_7FF91DCA1D20(v51, v50, v89);
    sub_7FF91DCA1A40(v53, v52, v54, v102.m128i_u64[0]);
    sub_7FF91DCA1A40(v56, v55, v57, v90);
    v58 = v91;
    sub_7FF91DCA1A40(v60, v59, v61, v90);
    v62 = __CFADD__(__CFADD__(v58, v58), v3) | __CFADD__(v3, __CFADD__(v58, v58) + v3);
    v62 = __CFADD__(v62, v63) | __CFADD__(v63, v62 + v63);
    v64 = v63 + (__CFADD__(__CFADD__(v58, v58), v3) | (unsigned __int8)__CFADD__(v3, __CFADD__(v58, v58) + v3)) + v63;
    v65 = v3 + __CFADD__(v58, v58) + v3;
    v66 = 2 * v91 + 1;
    v67 = v65 - ((2 * v91 != -1) + v48);
    if ( __PAIR128__(
           __CFADD__(v62, v68) | (unsigned __int8)__CFADD__(v68, v62 + v68),
           v68 + (unsigned __int64)v62 + v68) < (unsigned __int64)(__PAIR128__(v64, v65) < (unsigned __int64)(2 * v91 != -1)
                                                                                         + v48)
                                              + v49 )
    {
      v66 = 2 * v91;
      v67 = v65;
    }
    sub_7FF91DCA2A60();
    sub_7FF91DCA2A00(v70, v69, v71, v72);
    sub_7FF91DCA2A60();
    v100.m128i_i64[0] = v66;
    v100.m128i_i64[1] = v67;
    v101.m128i_i64[0] = v73;
    v101.m128i_i64[1] = v74;
    sub_7FF91DCA1A40(v76, v75, v73, v95);
    sub_7FF91DCA1A40(v78, v77, v79, v92);
    result = sub_7FF91DCA2A00(v81, v80, v82, v83);
    a1[4] = _mm_or_si128(
              _mm_and_si128(v85, v108),
              _mm_andnot_si128(v85, _mm_or_si128(_mm_and_si128(v84, v114), _mm_andnot_si128(v84, v102))));
    a1[5] = _mm_or_si128(
              _mm_and_si128(v85, v109),
              _mm_andnot_si128(v85, _mm_or_si128(_mm_and_si128(v84, v115), _mm_andnot_si128(v84, v103))));
    *a1 = _mm_or_si128(
            _mm_and_si128(v85, v104),
            _mm_andnot_si128(v85, _mm_or_si128(_mm_and_si128(v84, v110), _mm_andnot_si128(v84, v98))));
    a1[1] = _mm_or_si128(
              _mm_and_si128(v85, v105),
              _mm_andnot_si128(v85, _mm_or_si128(_mm_and_si128(v84, v111), _mm_andnot_si128(v84, v99))));
    a1[2] = _mm_or_si128(
              _mm_and_si128(v85, v106),
              _mm_andnot_si128(v85, _mm_or_si128(_mm_and_si128(v84, v112), _mm_andnot_si128(v84, v100))));
    a1[3] = _mm_or_si128(
              _mm_and_si128(v85, v107),
              _mm_andnot_si128(v85, _mm_or_si128(_mm_and_si128(v84, v113), _mm_andnot_si128(v84, v101))));
  }
  else
  {
    if ( !v30 )
      JUMPOUT(0x7FF91DCA2B3BLL);
    *a1 = 0;
    a1[1] = 0;
    a1[2] = 0;
    a1[3] = 0;
    a1[4] = 0;
    a1[5] = 0;
  }
  return result;
}


// ==== sub_7FF91DCA35C0 @ rva 0x435C0 ====
unsigned __int64 __fastcall sub_7FF91DCA35C0(__m128i *a1, const __m128i *a2, const __m128i *a3)
{
  unsigned __int64 v3; // r12
  __int64 v4; // r13
  __int64 v6; // rcx
  __int64 v7; // rdx
  __int64 v8; // rcx
  __int64 v9; // r8
  __int64 v10; // rdx
  __int64 v11; // rcx
  unsigned __int64 v12; // r8
  unsigned __int64 v13; // r9
  __int64 v14; // rdx
  __int64 v15; // rcx
  __int64 v16; // r8
  __int64 v17; // rdx
  __int64 v18; // rcx
  __int64 v19; // r8
  __int64 v20; // rdx
  __int64 v21; // rcx
  __int64 v22; // r8
  __int64 v23; // rdx
  __int64 v24; // rcx
  unsigned __int64 v25; // r8
  unsigned __int64 v26; // r9
  __int64 v27; // rdx
  __int64 v28; // rcx
  __int64 v29; // rdx
  __int64 v30; // rcx
  __int64 v31; // rdx
  __int64 v32; // rcx
  __int64 v33; // r8
  __int64 v34; // r12
  __int64 v35; // rdx
  __int64 v36; // rcx
  __int64 v37; // r8
  char v38; // cf
  __int64 v39; // r8
  unsigned __int64 v40; // r8
  unsigned __int64 v41; // rbp
  unsigned __int64 v42; // r12
  __int64 v43; // r9
  __int64 v44; // rdx
  __int64 v45; // rcx
  unsigned __int64 v46; // r8
  unsigned __int64 v47; // r9
  __int64 v48; // rdx
  __int64 v49; // rcx
  __int64 v50; // r8
  __int64 v51; // rdx
  __int64 v52; // rcx
  __int64 v53; // r8
  __int64 v54; // rdx
  __int64 v55; // rcx
  unsigned __int64 v56; // r8
  unsigned __int64 v57; // r9
  unsigned __int64 result; // rax
  __m128i v59; // xmm5
  __m128i v60; // xmm4
  unsigned __int64 v61; // [rsp+20h] [rbp-1F8h]
  unsigned __int64 v62; // [rsp+40h] [rbp-1D8h]
  unsigned __int64 v63; // [rsp+58h] [rbp-1C0h]
  __int64 v64; // [rsp+68h] [rbp-1B0h]
  __int64 v65; // [rsp+70h] [rbp-1A8h]
  unsigned __int64 v66; // [rsp+78h] [rbp-1A0h]
  unsigned __int64 v67; // [rsp+80h] [rbp-198h]
  __int64 v68; // [rsp+98h] [rbp-180h]
  unsigned __int64 v69; // [rsp+A0h] [rbp-178h]
  __m128i v70; // [rsp+E0h] [rbp-138h]
  __m128i v71; // [rsp+F0h] [rbp-128h]
  __m128i v72; // [rsp+100h] [rbp-118h]
  __m128i v73; // [rsp+110h] [rbp-108h]
  __m128i v74; // [rsp+120h] [rbp-F8h]
  __m128i v75; // [rsp+130h] [rbp-E8h]
  __m128i v76; // [rsp+140h] [rbp-D8h]
  __m128i v77; // [rsp+150h] [rbp-C8h]
  __m128i v78; // [rsp+160h] [rbp-B8h]
  __m128i v79; // [rsp+170h] [rbp-A8h]
  __m128i v80; // [rsp+180h] [rbp-98h]
  __m128i v81; // [rsp+190h] [rbp-88h]
  __m128i v82; // [rsp+1A0h] [rbp-78h]
  __m128i v83; // [rsp+1B0h] [rbp-68h]
  __m128i v84; // [rsp+1C0h] [rbp-58h]
  __m128i v85; // [rsp+1D0h] [rbp-48h]

  v6 = dword_7FF91E91A5F8 & 0x80100;
  if ( (_DWORD)v6 == 524544 )
    return sub_7FF91DCA4796(v6, a3);
  v76 = _mm_loadu_si128(a2);
  v77 = _mm_loadu_si128(a2 + 1);
  v78 = _mm_loadu_si128(a2 + 2);
  v79 = _mm_loadu_si128(a2 + 3);
  v80 = _mm_loadu_si128(a2 + 4);
  v81 = _mm_loadu_si128(a2 + 5);
  v82 = _mm_loadu_si128(a3);
  v83 = _mm_loadu_si128(a3 + 1);
  v84 = _mm_loadu_si128(a3 + 2);
  v85 = _mm_loadu_si128(a3 + 3);
  sub_7FF91DCA1D20(v6, (__int64)a3, a2[5].m128i_u64[1]);
  sub_7FF91DCA1A40(v8, v7, v9, v3);
  sub_7FF91DCA2A00(v11, v10, v12, v13);
  sub_7FF91DCA1A40(v15, v14, v16, v61);
  sub_7FF91DCA1A40(v18, v17, v19, v62);
  sub_7FF91DCA1A40(v21, v20, v22, v61);
  sub_7FF91DCA2A00(v24, v23, v25, v26);
  sub_7FF91DCA1D20(v28, v27, v63);
  sub_7FF91DCA1D20(v30, v29, v66);
  sub_7FF91DCA1A40(v32, v31, v33, v62);
  v34 = v68;
  sub_7FF91DCA1A40(v36, v35, v37, v67);
  v38 = __CFADD__(__CFADD__(v34, v34), v4) | __CFADD__(v4, __CFADD__(v34, v34) + v4);
  v38 = __CFADD__(v38, v39) | __CFADD__(v39, v38 + v39);
  v40 = v39 + (__CFADD__(__CFADD__(v34, v34), v4) | (unsigned __int8)__CFADD__(v4, __CFADD__(v34, v34) + v4)) + v39;
  v41 = v4 + __CFADD__(v34, v34) + v4;
  v42 = 2 * v68 + 1;
  if ( __PAIR128__(__CFADD__(v38, v43) | (unsigned __int8)__CFADD__(v43, v38 + v43), v43 + (unsigned __int64)v38 + v43) < (unsigned __int64)(__PAIR128__(v40, v41) < (unsigned __int64)(2 * v68 != -1) + v64) + v65 )
    v42 = 2 * v68;
  sub_7FF91DCA2A60();
  sub_7FF91DCA2A00(v45, v44, v46, v47);
  sub_7FF91DCA2A60();
  sub_7FF91DCA1A40(v49, v48, v50, v69);
  sub_7FF91DCA1A40(v52, v51, v53, v42);
  result = sub_7FF91DCA2A00(v55, v54, v56, v57);
  a1[4] = _mm_or_si128(
            _mm_and_si128(v60, v80),
            _mm_andnot_si128(
              v60,
              _mm_or_si128(_mm_and_si128(v59, (__m128i)xmmword_7FF91DCA1520), _mm_andnot_si128(v59, v74))));
  a1[5] = _mm_or_si128(
            _mm_and_si128(v60, v81),
            _mm_andnot_si128(
              v60,
              _mm_or_si128(_mm_and_si128(v59, (__m128i)xmmword_7FF91DCA1530), _mm_andnot_si128(v59, v75))));
  *a1 = _mm_or_si128(
          _mm_and_si128(v60, v76),
          _mm_andnot_si128(v60, _mm_or_si128(_mm_and_si128(v59, v82), _mm_andnot_si128(v59, v70))));
  a1[1] = _mm_or_si128(
            _mm_and_si128(v60, v77),
            _mm_andnot_si128(v60, _mm_or_si128(_mm_and_si128(v59, v83), _mm_andnot_si128(v59, v71))));
  a1[2] = _mm_or_si128(
            _mm_and_si128(v60, v78),
            _mm_andnot_si128(v60, _mm_or_si128(_mm_and_si128(v59, v84), _mm_andnot_si128(v59, v72))));
  a1[3] = _mm_or_si128(
            _mm_and_si128(v60, v79),
            _mm_andnot_si128(v60, _mm_or_si128(_mm_and_si128(v59, v85), _mm_andnot_si128(v59, v73))));
  return result;
}


// ==== sub_7FF91DCA3B60 @ rva 0x43B60 ====
__int64 __fastcall sub_7FF91DCA3B60(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  _QWORD *v4; // rbx
  _QWORD *v5; // rdi
  __int64 v6; // r12
  __int64 v7; // r13
  __int64 v8; // r14
  __int64 v9; // r15
  __int64 v10; // r13
  __int64 result; // rax
  __int64 v12; // r8
  __int64 v13; // rtt
  __int64 v14; // r9
  __int64 v15; // rtt
  unsigned __int64 v16; // rbp
  __int64 v17; // r12
  unsigned __int64 v18; // rcx
  __int64 v19; // r8
  unsigned __int64 v20; // r13
  unsigned __int64 v21; // r10
  unsigned __int64 v22; // r9
  bool v23; // cf

  v23 = __CFADD__(__CFADD__(*v4, v6), v7);
  v10 = __CFADD__(*v4, v6) + v7;
  result = *v4 + v6;
  v13 = v23 | (unsigned __int8)__CFADD__(v4[1], v10);
  v23 = __CFADD__(v13, a3);
  v12 = v13 + a3;
  v15 = v23 | (unsigned __int8)__CFADD__(v4[2], v12);
  v23 = __CFADD__(v15, a4);
  v14 = v15 + a4;
  v23 |= __CFADD__(v4[3], v14);
  v16 = v4[1] + v10;
  v17 = result + 1;
  v18 = v4[2] + v12;
  v19 = (__PAIR128__(v18, v16) - ((unsigned __int64)(result != -1) + v8)) >> 64;
  v20 = v16 - ((result != -1) + v8);
  v21 = v4[3] + v14;
  v22 = v21 - ((__PAIR128__(v18, v16) < (unsigned __int64)(result != -1) + v8) + v9);
  v23 = __PAIR128__(v23, v21) < (unsigned __int64)(__PAIR128__(v18, v16) < (unsigned __int64)(result != -1) + v8) + v9;
  if ( v23 )
  {
    v17 = result;
    v20 = v16;
  }
  *v5 = v17;
  if ( v23 )
    v19 = v18;
  v5[1] = v20;
  if ( v23 )
    v22 = v21;
  v5[2] = v19;
  v5[3] = v22;
  return result;
}


// ==== sub_7FF91DCA3BC0 @ rva 0x43BC0 ====
unsigned __int64 __fastcall sub_7FF91DCA3BC0(__int64 a1, __int64 a2, unsigned __int64 a3, unsigned __int64 a4)
{
  _QWORD *v4; // rbx
  unsigned __int64 *v5; // rdi
  unsigned __int64 v6; // r12
  unsigned __int64 v7; // r13
  unsigned __int64 v8; // r14
  unsigned __int64 v9; // r15
  unsigned __int64 result; // rax
  unsigned __int64 v11; // rtt
  __int64 v12; // r11
  unsigned __int64 v13; // rbp
  unsigned __int64 v14; // r12
  unsigned __int64 v15; // r13
  __int64 v16; // rcx
  unsigned __int64 v17; // r10
  __int64 v18; // r8
  unsigned __int64 v19; // r9

  result = v6 - *v4;
  v11 = (__PAIR128__(v7, v6) < *(_OWORD *)v4) + v4[2];
  v13 = (__PAIR128__(v7, v6) - *(_OWORD *)v4) >> 64;
  v12 = (a4 - (unsigned __int128)((unsigned __int64)(a3 < v11) + v4[3])) >> 64;
  v17 = (__PAIR128__(a4, a3) - __PAIR128__(v4[3], v11)) >> 64;
  v16 = a3 - v11;
  v15 = (__PAIR128__(v7, v6) - *(_OWORD *)v4 + __PAIR128__(v8, -1)) >> 64;
  v14 = result - 1;
  v19 = (__PAIR128__(v9, __CFADD__(result != 0, v13) | (unsigned __int8)__CFADD__(v8, v15))
       + __PAIR128__(a4, a3)
       - __PAIR128__(v4[3], v11)) >> 64;
  v18 = (__CFADD__(result != 0, v13) | (unsigned __int8)__CFADD__(v8, v15)) + a3 - v11;
  if ( (v12 & 1) == 0 )
  {
    v14 = result;
    v15 = v13;
  }
  *v5 = v14;
  if ( (v12 & 1) == 0 )
    v18 = v16;
  v5[1] = v15;
  if ( (v12 & 1) == 0 )
    v19 = v17;
  v5[2] = v18;
  v5[3] = v19;
  return result;
}


// ==== sub_7FF91DCA3C20 @ rva 0x43C20 ====
__int64 __fastcall sub_7FF91DCA3C20()
{
  __int64 v0; // rax
  __int64 v1; // r12

  return v0 - v1 - 1;
}


// ==== sub_7FF91DCA3C80 @ rva 0x43C80 ====
__int64 __fastcall sub_7FF91DCA3C80(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 *v4; // rdi
  __int64 v5; // r12
  __int64 v6; // r13
  __int64 v7; // r14
  __int64 v8; // r15
  __int64 result; // rax
  unsigned __int64 v10; // r8
  unsigned __int64 v11; // r9
  __int64 v12; // rtt
  unsigned __int64 v13; // rbp
  unsigned __int64 v14; // r11
  __int64 v15; // r12
  __int64 v16; // rcx
  __int64 v17; // r13
  __int64 v18; // r8
  _BOOL8 v19; // rtt
  __int64 v20; // r10
  __int64 v21; // r9
  unsigned __int64 v22; // rtt
  char v23; // cf

  v23 = __CFADD__(__CFADD__(v5, v5), v6) | __CFADD__(v6, __CFADD__(v5, v5) + v6);
  result = 2 * v5;
  v23 = __CFADD__(v23, a3) | __CFADD__(a3, v23 + a3);
  v10 = a3 + (__CFADD__(__CFADD__(v5, v5), v6) | (unsigned __int8)__CFADD__(v6, __CFADD__(v5, v5) + v6)) + a3;
  v12 = v23 + a4;
  v23 = __CFADD__(v23, a4) | __CFADD__(a4, v12);
  v11 = a4 + v12;
  v13 = v6 + __CFADD__(v5, v5) + v6;
  v14 = v23;
  v23 = 2 * v5 != -1;
  v15 = 2 * v5 + 1;
  v16 = v10;
  v17 = v13 - (v23 + v7);
  v19 = v13 < (unsigned __int64)v23 + v7;
  v23 = __PAIR128__(v10, v13) < (unsigned __int64)v23 + v7;
  v18 = v10 - v19;
  v20 = v11;
  v22 = v23 + v8;
  v23 = v11 < v22;
  v21 = v11 - v22;
  v23 = v14 < v23;
  if ( v23 )
  {
    v15 = result;
    v17 = v13;
  }
  *v4 = v15;
  if ( v23 )
    v18 = v16;
  v4[1] = v17;
  if ( v23 )
    v21 = v20;
  v4[2] = v18;
  v4[3] = v21;
  return result;
}


// ==== sub_7FF91DCA3CF3 @ rva 0x43CF3 ====
unsigned __int64 __fastcall sub_7FF91DCA3CF3(__int64 a1, __int64 a2)
{
  __int64 v2; // rbp
  _QWORD *v3; // rdi
  const __m128i *v4; // rsi
  __int64 v5; // r8
  __int64 v6; // r9
  __int64 v7; // rcx
  __int64 v8; // rcx
  __int64 v9; // rcx
  __int64 v10; // r8
  __int64 v11; // rdx
  __int64 v12; // rcx
  __int64 v13; // r8
  __int64 v14; // r9
  __int64 v15; // rdx
  __int64 v16; // rcx
  __int64 v17; // rdx
  __int64 v18; // rcx
  unsigned __int64 v19; // r14
  __int64 v20; // r15
  __int64 v21; // rcx
  __int128 v22; // kr00_16
  unsigned __int64 v23; // rcx
  bool v24; // cf
  unsigned __int64 v25; // r14
  __int64 v26; // r8
  unsigned __int64 v27; // r15
  _BOOL8 v28; // rtt
  __int64 v29; // r9
  __int64 v30; // rdx
  __int64 v31; // rcx
  __int64 v32; // r8
  __int64 v33; // r9
  __int64 v34; // rdx
  __int64 v35; // rcx
  __int64 v36; // r8
  __int64 v37; // r9
  unsigned __int64 v38; // r12
  __int64 v39; // rcx
  __int64 v40; // r8
  __int64 v41; // rdx
  __int64 v42; // rcx
  __int64 v43; // r8
  __int64 v44; // r9
  unsigned __int64 v45; // r14
  unsigned __int64 v46; // r15
  __int64 v47; // rcx
  __int64 v48; // rdx
  __int64 v49; // rcx
  __int64 v50; // r8
  __int64 v51; // rdx
  __int64 v52; // rcx
  unsigned __int64 v53; // r8
  unsigned __int64 v54; // r9
  _BYTE v56[32]; // [rsp+0h] [rbp-158h] BYREF
  unsigned __int64 v57; // [rsp+80h] [rbp-D8h]
  unsigned __int64 v58; // [rsp+88h] [rbp-D0h]
  __int64 v59; // [rsp+90h] [rbp-C8h]
  unsigned __int64 v60; // [rsp+98h] [rbp-C0h]
  unsigned __int64 v61; // [rsp+A0h] [rbp-B8h]
  unsigned __int64 v62; // [rsp+A8h] [rbp-B0h]
  unsigned __int64 v63; // [rsp+B0h] [rbp-A8h]
  unsigned __int64 v64; // [rsp+B8h] [rbp-A0h]
  unsigned __int64 v65; // [rsp+C0h] [rbp-98h]
  __m128i v66; // [rsp+E0h] [rbp-78h]
  __m128i v67; // [rsp+F0h] [rbp-68h]

  v5 = v4[3].m128i_i64[0];
  v6 = v4[3].m128i_i64[1];
  v66 = _mm_loadu_si128(v4);
  v67 = _mm_loadu_si128(v4 + 1);
  sub_7FF91DCA3C80(a1, a2, v5, v6);
  sub_7FF91DCA2140(v7, v4[4].m128i_u64[0], v4[5].m128i_u64[1]);
  sub_7FF91DCA2140(v8, v57, v60);
  sub_7FF91DCA1EE0(v9, v4[2].m128i_u64[0], v10, v4[4].m128i_u64[0]);
  sub_7FF91DCA3C80(v12, v11, v13, v14);
  sub_7FF91DCA3B60(v16, v15, v67.m128i_i64[0], v67.m128i_i64[1]);
  sub_7FF91DCA3BC0(v18, v17, v67.m128i_u64[0], v67.m128i_u64[1]);
  v19 = v58;
  v20 = v59;
  sub_7FF91DCA2140(v21, v57, v60);
  v22 = *(_OWORD *)&v66 + __PAIR128__(v56, -1);
  v23 = v19;
  v24 = __CFADD__(
          __CFADD__(v66.m128i_i64[0] != 0, v66.m128i_i64[1])
        | (unsigned __int8)__CFADD__(v56, (*(_OWORD *)&v66 + __PAIR128__(v56, -1)) >> 64),
          v19);
  v25 = (__CFADD__(v66.m128i_i64[0] != 0, v66.m128i_i64[1])
       | (unsigned __int8)__CFADD__(v56, (*(_OWORD *)&v66 + __PAIR128__(v56, -1)) >> 64))
      + v19;
  v26 = v20;
  v28 = v24;
  v24 = __CFADD__(v24, v20);
  v27 = v28 + v20;
  v24 |= __CFADD__(v2, v27);
  v27 += v2;
  v29 = v24;
  if ( (v66.m128i_i8[0] & 1) == 0 )
  {
    v25 = v23;
    v27 = v26;
    v29 = 0;
    v22 = (__int128)v66;
  }
  v3[4] = v22 >> 1;
  v3[5] = (v25 << 63) | (*((_QWORD *)&v22 + 1) >> 1);
  v3[6] = (v27 << 63) | (v25 >> 1);
  v3[7] = (v29 << 63) | (v27 >> 1);
  sub_7FF91DCA1EE0(v27 << 63, v65, v26, v61);
  sub_7FF91DCA3C80(v31, v30, v32, v33);
  sub_7FF91DCA3B60(v35, v34, v36, v37);
  v38 = v60;
  sub_7FF91DCA1EE0(v39, v66.m128i_u64[0], v40, v57);
  sub_7FF91DCA3C80(v42, v41, v43, v44);
  v45 = v62;
  v46 = v63;
  sub_7FF91DCA2140(v47, v61, v64);
  sub_7FF91DCA3BC0(v49, v48, v45, v46);
  sub_7FF91DCA3C20(v59);
  sub_7FF91DCA1EE0(0, v61, v50, v38);
  return sub_7FF91DCA3BC0(v52, v51, v53, v54);
}


// ==== sub_7FF91DCA4016 @ rva 0x44016 ====
unsigned __int64 __fastcall sub_7FF91DCA4016(__int64 a1, const __m128i *a2)
{
  __m128i *v2; // rdi
  const __m128i *v3; // rsi
  __int64 v4; // r13
  __int64 v5; // rcx
  __int64 v6; // rcx
  __int64 v7; // r8
  __int64 v8; // rcx
  __int64 v9; // r8
  __int64 v10; // rcx
  __int64 v11; // r8
  __int64 v12; // rcx
  __int64 v13; // r8
  __int64 v14; // rdx
  __int64 v15; // rcx
  unsigned __int64 v16; // r8
  unsigned __int64 v17; // r9
  __int64 v18; // r8
  __m128i v19; // xmm4
  __m128i v20; // xmm5
  unsigned __int64 v21; // xmm2_8
  __int64 v22; // r9
  __int64 v23; // xmm3_8
  __int64 v24; // rcx
  __int64 v25; // rcx
  __int64 v26; // r8
  __int64 v27; // rdx
  __int64 v28; // rcx
  unsigned __int64 v29; // r8
  unsigned __int64 v30; // r9
  unsigned __int64 result; // rax
  __int64 v32; // rcx
  __int64 v33; // r8
  __int64 v34; // r9
  __int64 v35; // rcx
  __int64 v36; // r8
  __int64 v37; // r14
  __int64 v38; // r15
  __int64 v39; // rcx
  __int64 v40; // rcx
  __int64 v41; // r8
  __int64 v42; // rcx
  __int64 v43; // r8
  __int64 v44; // r12
  __int64 v45; // rcx
  __int64 v46; // r8
  char v47; // cf
  __int64 v48; // r8
  unsigned __int64 v49; // r8
  __int64 v50; // rbp
  unsigned __int64 v51; // r12
  __int64 v52; // r13
  __int64 v53; // r9
  __int64 v54; // rdx
  __int64 v55; // rcx
  unsigned __int64 v56; // r8
  unsigned __int64 v57; // r9
  __int64 v58; // r8
  __int64 v59; // r9
  __int64 v60; // rcx
  __int64 v61; // rcx
  __int64 v62; // r8
  __int64 v63; // rdx
  __int64 v64; // rcx
  unsigned __int64 v65; // r8
  unsigned __int64 v66; // r9
  __m128i v67; // xmm5
  __m128i v68; // xmm4
  unsigned __int64 v69; // [rsp+80h] [rbp-278h]
  unsigned __int64 v70; // [rsp+80h] [rbp-278h]
  unsigned __int64 v71; // [rsp+80h] [rbp-278h]
  __int64 v72; // [rsp+88h] [rbp-270h]
  __int64 v73; // [rsp+90h] [rbp-268h]
  unsigned __int64 v74; // [rsp+98h] [rbp-260h]
  unsigned __int64 v75; // [rsp+A0h] [rbp-258h]
  __int64 v76; // [rsp+B8h] [rbp-240h]
  unsigned __int64 v77; // [rsp+C0h] [rbp-238h]
  unsigned __int64 v78; // [rsp+D8h] [rbp-220h]
  unsigned __int64 v79; // [rsp+E0h] [rbp-218h]
  unsigned __int64 v80; // [rsp+100h] [rbp-1F8h]
  unsigned __int64 v81; // [rsp+120h] [rbp-1D8h]
  unsigned __int64 v82; // [rsp+160h] [rbp-198h]
  unsigned __int64 v83; // [rsp+180h] [rbp-178h]
  __int64 v84; // [rsp+198h] [rbp-160h]
  __m128i v85; // [rsp+1A0h] [rbp-158h]
  __m128i v86; // [rsp+1B0h] [rbp-148h]
  __m128i v87; // [rsp+1C0h] [rbp-138h]
  __m128i v88; // [rsp+1D0h] [rbp-128h]
  __m128i v89; // [rsp+1E0h] [rbp-118h]
  __m128i v90; // [rsp+1F0h] [rbp-108h]
  __m128i v91; // [rsp+200h] [rbp-F8h]
  __m128i v92; // [rsp+210h] [rbp-E8h]
  __m128i v93; // [rsp+220h] [rbp-D8h]
  __m128i v94; // [rsp+230h] [rbp-C8h]
  __m128i v95; // [rsp+240h] [rbp-B8h]
  __m128i v96; // [rsp+250h] [rbp-A8h]
  __m128i v97; // [rsp+260h] [rbp-98h]
  __m128i v98; // [rsp+270h] [rbp-88h]
  __m128i v99; // [rsp+280h] [rbp-78h]
  __m128i v100; // [rsp+290h] [rbp-68h]
  __m128i v101; // [rsp+2A0h] [rbp-58h]
  __m128i v102; // [rsp+2B0h] [rbp-48h]

  v91 = _mm_loadu_si128(v3);
  v92 = _mm_loadu_si128(v3 + 1);
  v93 = _mm_loadu_si128(v3 + 2);
  v94 = _mm_loadu_si128(v3 + 3);
  v95 = _mm_loadu_si128(v3 + 4);
  v96 = _mm_loadu_si128(v3 + 5);
  v97 = _mm_loadu_si128(a2);
  v98 = _mm_loadu_si128(a2 + 1);
  v99 = _mm_loadu_si128(a2 + 2);
  v100 = _mm_loadu_si128(a2 + 3);
  v101 = a2[4];
  v102 = a2[5];
  sub_7FF91DCA2140(a1, v101.m128i_u64[0], v102.m128i_u64[1]);
  sub_7FF91DCA2140(v5, v3[4].m128i_u64[0], v3[5].m128i_u64[1]);
  sub_7FF91DCA1EE0(v6, v101.m128i_u64[0], v7, v79);
  sub_7FF91DCA1EE0(v8, v95.m128i_u64[0], v9, v75);
  sub_7FF91DCA1EE0(v10, v93.m128i_u64[0], v11, v82);
  sub_7FF91DCA1EE0(v12, v99.m128i_u64[0], v13, v83);
  sub_7FF91DCA3BC0(v15, v14, v16, v17);
  v21 = _mm_or_si128(v19, v20).m128i_u64[0];
  v23 = v22 | v18 | v4 | v84;
  sub_7FF91DCA1EE0(v24, v91.m128i_u64[0], v18, v79);
  sub_7FF91DCA1EE0(v25, v97.m128i_u64[0], v26, v75);
  result = sub_7FF91DCA3BC0(v28, v27, v29, v30);
  if ( v34 | v33 | v4 | v76 || v21 )
  {
    sub_7FF91DCA2140(v32, v77, v78);
    sub_7FF91DCA1EE0(v35, v95.m128i_u64[0], v36, v69);
    v37 = v72;
    v38 = v73;
    sub_7FF91DCA2140(v39, v70, v74);
    sub_7FF91DCA1EE0(v40, v101.m128i_u64[0], v41, v89.m128i_u64[0]);
    sub_7FF91DCA1EE0(v42, v71, v43, v75);
    v44 = v76;
    sub_7FF91DCA1EE0(v45, v81, v46, v75);
    v47 = __CFADD__(__CFADD__(v44, v44), v4) | __CFADD__(v4, __CFADD__(v44, v44) + v4);
    v47 = __CFADD__(v47, v48) | __CFADD__(v48, v47 + v48);
    v49 = v48 + (__CFADD__(__CFADD__(v44, v44), v4) | (unsigned __int8)__CFADD__(v4, __CFADD__(v44, v44) + v4)) + v48;
    v50 = v4 + __CFADD__(v44, v44) + v4;
    v51 = 2 * v76 + 1;
    v52 = v50 - ((2 * v76 != -1) + v37);
    if ( __PAIR128__(
           __CFADD__(v47, v53) | (unsigned __int8)__CFADD__(v53, v47 + v53),
           v53 + (unsigned __int64)v47 + v53) < (unsigned __int64)(__PAIR128__(v49, v50) < (unsigned __int64)(2 * v76 != -1)
                                                                                         + v37)
                                              + v38 )
    {
      v51 = 2 * v76;
      v52 = v50;
    }
    sub_7FF91DCA3C20();
    sub_7FF91DCA3BC0(v55, v54, v56, v57);
    sub_7FF91DCA3C20();
    v87.m128i_i64[0] = v51;
    v87.m128i_i64[1] = v52;
    v88.m128i_i64[0] = v58;
    v88.m128i_i64[1] = v59;
    sub_7FF91DCA1EE0(v60, v80, v58, v82);
    sub_7FF91DCA1EE0(v61, v51, v62, v77);
    result = sub_7FF91DCA3BC0(v64, v63, v65, v66);
    v2[4] = _mm_or_si128(
              _mm_and_si128(v68, v95),
              _mm_andnot_si128(v68, _mm_or_si128(_mm_and_si128(v67, v101), _mm_andnot_si128(v67, v89))));
    v2[5] = _mm_or_si128(
              _mm_and_si128(v68, v96),
              _mm_andnot_si128(v68, _mm_or_si128(_mm_and_si128(v67, v102), _mm_andnot_si128(v67, v90))));
    *v2 = _mm_or_si128(
            _mm_and_si128(v68, v91),
            _mm_andnot_si128(v68, _mm_or_si128(_mm_and_si128(v67, v97), _mm_andnot_si128(v67, v85))));
    v2[1] = _mm_or_si128(
              _mm_and_si128(v68, v92),
              _mm_andnot_si128(v68, _mm_or_si128(_mm_and_si128(v67, v98), _mm_andnot_si128(v67, v86))));
    v2[2] = _mm_or_si128(
              _mm_and_si128(v68, v93),
              _mm_andnot_si128(v68, _mm_or_si128(_mm_and_si128(v67, v99), _mm_andnot_si128(v67, v87))));
    v2[3] = _mm_or_si128(
              _mm_and_si128(v68, v94),
              _mm_andnot_si128(v68, _mm_or_si128(_mm_and_si128(v67, v100), _mm_andnot_si128(v67, v88))));
  }
  else
  {
    if ( !v23 )
      JUMPOUT(0x7FF91DCA3D04LL);
    *v2 = 0;
    v2[1] = 0;
    v2[2] = 0;
    v2[3] = 0;
    v2[4] = 0;
    v2[5] = 0;
  }
  return result;
}


// ==== sub_7FF91DCA4796 @ rva 0x44796 ====
unsigned __int64 __fastcall sub_7FF91DCA4796(__int64 a1, const __m128i *a2)
{
  __m128i *v2; // rdi
  const __m128i *v3; // rsi
  unsigned __int64 v4; // r12
  __int64 v5; // r13
  __int64 v7; // rcx
  __int64 v8; // r8
  __int64 v9; // rdx
  __int64 v10; // rcx
  unsigned __int64 v11; // r8
  unsigned __int64 v12; // r9
  __int64 v13; // rcx
  __int64 v14; // r8
  __int64 v15; // rcx
  __int64 v16; // r8
  __int64 v17; // rcx
  __int64 v18; // r8
  __int64 v19; // rdx
  __int64 v20; // rcx
  unsigned __int64 v21; // r8
  unsigned __int64 v22; // r9
  __int64 v23; // rcx
  __int64 v24; // rcx
  __int64 v25; // rcx
  __int64 v26; // r8
  __int64 v27; // r12
  __int64 v28; // rcx
  __int64 v29; // r8
  char v30; // cf
  __int64 v31; // r8
  unsigned __int64 v32; // r8
  unsigned __int64 v33; // rbp
  unsigned __int64 v34; // r12
  __int64 v35; // r9
  __int64 v36; // rdx
  __int64 v37; // rcx
  unsigned __int64 v38; // r8
  unsigned __int64 v39; // r9
  __int64 v40; // rcx
  __int64 v41; // r8
  __int64 v42; // rcx
  __int64 v43; // r8
  __int64 v44; // rdx
  __int64 v45; // rcx
  unsigned __int64 v46; // r8
  unsigned __int64 v47; // r9
  unsigned __int64 result; // rax
  __m128i v49; // xmm5
  __m128i v50; // xmm4
  unsigned __int64 v51; // [rsp+80h] [rbp-1F8h]
  unsigned __int64 v52; // [rsp+A0h] [rbp-1D8h]
  unsigned __int64 v53; // [rsp+B8h] [rbp-1C0h]
  unsigned __int64 v54; // [rsp+C0h] [rbp-1B8h]
  __int64 v55; // [rsp+C8h] [rbp-1B0h]
  __int64 v56; // [rsp+D0h] [rbp-1A8h]
  unsigned __int64 v57; // [rsp+D8h] [rbp-1A0h]
  unsigned __int64 v58; // [rsp+E0h] [rbp-198h]
  __int64 v59; // [rsp+F8h] [rbp-180h]
  unsigned __int64 v60; // [rsp+100h] [rbp-178h]
  __m128i v61; // [rsp+140h] [rbp-138h]
  __m128i v62; // [rsp+150h] [rbp-128h]
  __m128i v63; // [rsp+160h] [rbp-118h]
  __m128i v64; // [rsp+170h] [rbp-108h]
  __m128i v65; // [rsp+180h] [rbp-F8h]
  __m128i v66; // [rsp+190h] [rbp-E8h]
  __m128i v67; // [rsp+1A0h] [rbp-D8h]
  __m128i v68; // [rsp+1B0h] [rbp-C8h]
  __m128i v69; // [rsp+1C0h] [rbp-B8h]
  __m128i v70; // [rsp+1D0h] [rbp-A8h]
  __m128i v71; // [rsp+1E0h] [rbp-98h]
  __m128i v72; // [rsp+1F0h] [rbp-88h]
  __m128i v73; // [rsp+200h] [rbp-78h]
  __m128i v74; // [rsp+210h] [rbp-68h]
  __m128i v75; // [rsp+220h] [rbp-58h]
  __m128i v76; // [rsp+230h] [rbp-48h]

  v67 = _mm_loadu_si128(v3);
  v68 = _mm_loadu_si128(v3 + 1);
  v69 = _mm_loadu_si128(v3 + 2);
  v70 = _mm_loadu_si128(v3 + 3);
  v71 = _mm_loadu_si128(v3 + 4);
  v72 = _mm_loadu_si128(v3 + 5);
  v73 = _mm_loadu_si128(a2);
  v74 = _mm_loadu_si128(a2 + 1);
  v75 = _mm_loadu_si128(a2 + 2);
  v76 = _mm_loadu_si128(a2 + 3);
  sub_7FF91DCA2140(a1, v3[4].m128i_u64[0], v3[5].m128i_u64[1]);
  sub_7FF91DCA1EE0(v7, a2->m128i_i64[0], v8, v4);
  sub_7FF91DCA3BC0(v10, v9, v11, v12);
  sub_7FF91DCA1EE0(v13, v71.m128i_u64[0], v14, v51);
  sub_7FF91DCA1EE0(v15, v71.m128i_u64[0], v16, v52);
  sub_7FF91DCA1EE0(v17, v75.m128i_u64[0], v18, v51);
  sub_7FF91DCA3BC0(v20, v19, v21, v22);
  sub_7FF91DCA2140(v23, v52, v53);
  sub_7FF91DCA2140(v24, v54, v57);
  sub_7FF91DCA1EE0(v25, v58, v26, v52);
  v27 = v59;
  sub_7FF91DCA1EE0(v28, v67.m128i_u64[0], v29, v58);
  v30 = __CFADD__(__CFADD__(v27, v27), v5) | __CFADD__(v5, __CFADD__(v27, v27) + v5);
  v30 = __CFADD__(v30, v31) | __CFADD__(v31, v30 + v31);
  v32 = v31 + (__CFADD__(__CFADD__(v27, v27), v5) | (unsigned __int8)__CFADD__(v5, __CFADD__(v27, v27) + v5)) + v31;
  v33 = v5 + __CFADD__(v27, v27) + v5;
  v34 = 2 * v59 + 1;
  if ( __PAIR128__(__CFADD__(v30, v35) | (unsigned __int8)__CFADD__(v35, v30 + v35), v35 + (unsigned __int64)v30 + v35) < (unsigned __int64)(__PAIR128__(v32, v33) < (unsigned __int64)(2 * v59 != -1) + v55) + v56 )
    v34 = 2 * v59;
  sub_7FF91DCA3C20();
  sub_7FF91DCA3BC0(v37, v36, v38, v39);
  sub_7FF91DCA3C20();
  sub_7FF91DCA1EE0(v40, v69.m128i_u64[0], v41, v60);
  sub_7FF91DCA1EE0(v42, v54, v43, v34);
  result = sub_7FF91DCA3BC0(v45, v44, v46, v47);
  v2[4] = _mm_or_si128(
            _mm_and_si128(v50, v71),
            _mm_andnot_si128(
              v50,
              _mm_or_si128(_mm_and_si128(v49, (__m128i)xmmword_7FF91DCA1520), _mm_andnot_si128(v49, v65))));
  v2[5] = _mm_or_si128(
            _mm_and_si128(v50, v72),
            _mm_andnot_si128(
              v50,
              _mm_or_si128(_mm_and_si128(v49, (__m128i)xmmword_7FF91DCA1530), _mm_andnot_si128(v49, v66))));
  *v2 = _mm_or_si128(
          _mm_and_si128(v50, v67),
          _mm_andnot_si128(v50, _mm_or_si128(_mm_and_si128(v49, v73), _mm_andnot_si128(v49, v61))));
  v2[1] = _mm_or_si128(
            _mm_and_si128(v50, v68),
            _mm_andnot_si128(v50, _mm_or_si128(_mm_and_si128(v49, v74), _mm_andnot_si128(v49, v62))));
  v2[2] = _mm_or_si128(
            _mm_and_si128(v50, v69),
            _mm_andnot_si128(v50, _mm_or_si128(_mm_and_si128(v49, v75), _mm_andnot_si128(v49, v63))));
  v2[3] = _mm_or_si128(
            _mm_and_si128(v50, v70),
            _mm_andnot_si128(v50, _mm_or_si128(_mm_and_si128(v49, v76), _mm_andnot_si128(v49, v64))));
  return result;
}


// ==== sub_7FF91DCA4D00 @ rva 0x44D00 ====
_UNKNOWN **__fastcall sub_7FF91DCA4D00(__int64 a1, const __m128i *a2, __int64 a3, int *a4, _DWORD *a5, __int64 a6)
{
  _UNKNOWN **result; // rax
  const __m128i *v7; // r13
  _DWORD *v8; // r15
  __int64 v9; // rdi
  __int64 v10; // rbp
  __int64 v11; // r14
  __int64 v12; // rcx
  _DWORD *v13; // rsi
  int v14; // r8d
  int v15; // r9d
  int v16; // r10d
  int v17; // r11d
  int v18; // edx
  int v19; // ebx
  int v20; // r8d
  __m128i v21; // xmm0
  int v22; // r8d
  int v23; // edx
  int v24; // eax
  int v25; // r11d
  __m128i v26; // xmm1
  int v27; // r11d
  int v28; // edx
  int v29; // ebx
  int v30; // r10d
  __m128i inserted; // xmm0
  int v32; // r10d
  int v33; // edx
  int v34; // eax
  int v35; // r9d
  __m128i v36; // xmm1
  int v37; // r9d
  int v38; // edx
  int v39; // ebx
  int v40; // r8d
  __m128i v41; // xmm0
  int v42; // r8d
  int v43; // edx
  int v44; // eax
  int v45; // r11d
  __m128i v46; // xmm1
  int v47; // r11d
  int v48; // edx
  int v49; // ebx
  int v50; // r10d
  __m128i v51; // xmm0
  int v52; // r10d
  int v53; // edx
  int v54; // eax
  int v55; // r9d
  __m128i v56; // xmm1
  int v57; // r9d
  int v58; // edx
  int v59; // ebx
  int v60; // r8d
  __m128i v61; // xmm0
  int v62; // r8d
  int v63; // edx
  int v64; // eax
  int v65; // r11d
  __m128i v66; // xmm1
  int v67; // r11d
  int v68; // edx
  int v69; // ebx
  int v70; // r10d
  __m128i v71; // xmm0
  int v72; // r10d
  int v73; // edx
  int v74; // eax
  int v75; // r9d
  __m128i v76; // xmm1
  int v77; // r9d
  int v78; // edx
  int v79; // ebx
  int v80; // r8d
  __m128i v81; // xmm0
  int v82; // r8d
  int v83; // edx
  int v84; // eax
  int v85; // r11d
  __m128i v86; // xmm1
  int v87; // r11d
  int v88; // edx
  int v89; // ebx
  int v90; // r10d
  __m128i v91; // xmm0
  int v92; // r10d
  __m128i v93; // xmm2
  int v94; // edx
  int v95; // eax
  int v96; // r9d
  int v97; // r9d
  __m128i v98; // xmm2
  int v99; // edx
  int v100; // ebx
  int v101; // r8d
  __m128i v102; // xmm0
  int v103; // r8d
  int v104; // edx
  int v105; // eax
  int v106; // r11d
  __m128i v107; // xmm1
  int v108; // r11d
  int v109; // edx
  int v110; // ebx
  int v111; // r10d
  __m128i v112; // xmm0
  int v113; // r10d
  int v114; // edx
  int v115; // eax
  int v116; // r9d
  __m128i v117; // xmm1
  int v118; // r9d
  int v119; // edx
  int v120; // ebx
  int v121; // r8d
  __m128i v122; // xmm0
  int v123; // r8d
  int v124; // edx
  int v125; // eax
  int v126; // r11d
  __m128i v127; // xmm1
  int v128; // r11d
  int v129; // edx
  int v130; // ebx
  int v131; // r10d
  __m128i v132; // xmm0
  int v133; // r10d
  int v134; // edx
  int v135; // eax
  int v136; // r9d
  __m128i v137; // xmm1
  int v138; // r9d
  int v139; // edx
  int v140; // ebx
  int v141; // r8d
  __m128i v142; // xmm0
  int v143; // r8d
  int v144; // edx
  int v145; // eax
  int v146; // r11d
  __m128i v147; // xmm1
  int v148; // r11d
  int v149; // edx
  int v150; // ebx
  int v151; // r10d
  __m128i v152; // xmm0
  int v153; // r10d
  int v154; // edx
  int v155; // eax
  int v156; // r9d
  __m128i v157; // xmm1
  int v158; // r9d
  int v159; // edx
  int v160; // ebx
  int v161; // r8d
  __m128i v162; // xmm0
  int v163; // r8d
  int v164; // edx
  int v165; // eax
  int v166; // r11d
  __m128i v167; // xmm1
  int v168; // r11d
  int v169; // edx
  int v170; // ebx
  int v171; // r10d
  __m128i v172; // xmm0
  int v173; // r10d
  __m128i v174; // xmm3
  int v175; // edx
  int v176; // eax
  int v177; // r9d
  int v178; // r9d
  __int64 v179; // rcx
  _DWORD *v180; // rsi
  __m128i v181; // xmm3
  int v182; // edx
  int v183; // ebx
  int v184; // r8d
  __int64 v185; // rcx
  __m128i v186; // xmm0
  int v187; // r8d
  int v188; // edx
  int v189; // eax
  int v190; // r11d
  __int64 v191; // rcx
  __m128i v192; // xmm1
  int v193; // r11d
  int v194; // edx
  int v195; // ebx
  int v196; // r10d
  __int64 v197; // rcx
  __m128i v198; // xmm0
  int v199; // r10d
  int v200; // edx
  int v201; // eax
  int v202; // r9d
  __int64 v203; // rcx
  __m128i v204; // xmm1
  int v205; // r9d
  int v206; // edx
  int v207; // ebx
  int v208; // r8d
  __int64 v209; // rcx
  __m128i v210; // xmm0
  int v211; // r8d
  int v212; // edx
  int v213; // eax
  int v214; // r11d
  __int64 v215; // rcx
  __m128i v216; // xmm1
  int v217; // r11d
  int v218; // edx
  int v219; // ebx
  int v220; // r10d
  __int64 v221; // rcx
  __m128i v222; // xmm0
  int v223; // r10d
  int v224; // edx
  int v225; // eax
  int v226; // r9d
  __int64 v227; // rcx
  __m128i v228; // xmm1
  int v229; // r9d
  int v230; // edx
  int v231; // ebx
  int v232; // r8d
  __int64 v233; // rcx
  __m128i v234; // xmm0
  int v235; // r8d
  int v236; // edx
  int v237; // eax
  int v238; // r11d
  __int64 v239; // rcx
  __m128i v240; // xmm1
  int v241; // r11d
  int v242; // edx
  int v243; // ebx
  int v244; // r10d
  __int64 v245; // rcx
  __m128i v246; // xmm0
  int v247; // r10d
  int v248; // edx
  int v249; // eax
  int v250; // r9d
  __int64 v251; // rcx
  __m128i v252; // xmm1
  int v253; // r9d
  int v254; // edx
  int v255; // ebx
  int v256; // r8d
  __int64 v257; // rcx
  __m128i v258; // xmm0
  int v259; // r8d
  int v260; // edx
  int v261; // eax
  int v262; // r11d
  __int64 v263; // rcx
  __m128i v264; // xmm1
  int v265; // r11d
  int v266; // edx
  int v267; // ebx
  int v268; // r10d
  __int64 v269; // rcx
  __m128i v270; // xmm0
  int v271; // r10d
  __m128i v272; // xmm4
  int v273; // edx
  int v274; // eax
  int v275; // r9d
  __int64 v276; // rcx
  int v277; // r9d
  __m128i v278; // xmm4
  int v279; // edx
  int v280; // ebx
  int v281; // r8d
  __int64 v282; // rcx
  __m128i v283; // xmm0
  int v284; // r8d
  int v285; // edx
  int v286; // eax
  int v287; // r11d
  __int64 v288; // rcx
  __m128i v289; // xmm1
  int v290; // r11d
  int v291; // edx
  int v292; // ebx
  int v293; // r10d
  __int64 v294; // rcx
  __m128i v295; // xmm0
  int v296; // r10d
  int v297; // edx
  int v298; // eax
  int v299; // r9d
  __int64 v300; // rcx
  __m128i v301; // xmm1
  int v302; // r9d
  int v303; // edx
  int v304; // ebx
  int v305; // r8d
  __int64 v306; // rcx
  __m128i v307; // xmm0
  int v308; // r8d
  int v309; // edx
  int v310; // eax
  int v311; // r11d
  __int64 v312; // rcx
  __m128i v313; // xmm1
  int v314; // r11d
  int v315; // edx
  int v316; // ebx
  int v317; // r10d
  __int64 v318; // rcx
  __m128i v319; // xmm0
  int v320; // r10d
  int v321; // edx
  int v322; // eax
  int v323; // r9d
  __int64 v324; // rcx
  __m128i v325; // xmm1
  int v326; // r9d
  int v327; // edx
  int v328; // ebx
  int v329; // r8d
  __int64 v330; // rcx
  __m128i v331; // xmm0
  int v332; // r8d
  int v333; // edx
  int v334; // eax
  int v335; // r11d
  __int64 v336; // rcx
  __m128i v337; // xmm1
  int v338; // r11d
  int v339; // edx
  int v340; // ebx
  int v341; // r10d
  __int64 v342; // rcx
  __m128i v343; // xmm0
  int v344; // r10d
  int v345; // edx
  int v346; // eax
  int v347; // r9d
  __int64 v348; // rcx
  __m128i v349; // xmm1
  int v350; // r9d
  int v351; // edx
  int v352; // ebx
  int v353; // r8d
  __int64 v354; // rcx
  __m128i v355; // xmm0
  int v356; // r8d
  int v357; // edx
  int v358; // eax
  int v359; // r11d
  __int64 v360; // rcx
  __m128i v361; // xmm1
  int v362; // r11d
  int v363; // edx
  int v364; // ebx
  int v365; // r10d
  __int64 v366; // rcx
  __m128i v367; // xmm0
  int v368; // r10d
  __m128i v369; // xmm5
  int v370; // edx
  int v371; // r9d
  int v372; // r9d
  __m128i v373; // xmm5
  int v374; // [rsp+0h] [rbp-58h]
  int v375; // [rsp+4h] [rbp-54h]
  int v376; // [rsp+8h] [rbp-50h]
  int v377; // [rsp+Ch] [rbp-4Ch]
  _UNKNOWN *retaddr; // [rsp+58h] [rbp+0h] BYREF

  result = &retaddr;
  if ( a6 )
  {
    v7 = a2;
    v8 = a5;
    v9 = a1 + 8;
    v12 = *(unsigned __int8 *)(a1 + 4);
    v10 = (unsigned __int8)(*(_BYTE *)(v9 - 8) + 1);
    v11 = a3 - (_QWORD)a2;
    LODWORD(result) = *(_DWORD *)(v9 + 4 * v10);
    LOBYTE(v12) = (_BYTE)result + v12;
    v13 = (_DWORD *)(v9 + 4 * v10);
    v14 = *a4;
    v15 = a4[1];
    v16 = a4[2];
    v17 = a4[3];
    do
    {
      v374 = v14;
      v375 = v15;
      v376 = v16;
      v377 = v17;
      v18 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = (_DWORD)result;
      v19 = v13[1];
      v20 = *v8 + v14 - 680876936;
      *v13 = v18;
      LOBYTE(v12) = v19 + v12;
      v21 = _mm_cvtsi32_si128(*(_DWORD *)(v9 + 4LL * (unsigned __int8)(v18 + (_BYTE)result)));
      v22 = v15 + __ROL4__((v17 ^ v15 & (v16 ^ v17)) + v20, 7);
      v23 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v19;
      v24 = v13[2];
      v25 = v8[1] + v17 - 389564586;
      v13[1] = v23;
      LOBYTE(v12) = v24 + v12;
      v26 = _mm_cvtsi32_si128(*(_DWORD *)(v9 + 4LL * (unsigned __int8)(v23 + v19)));
      v27 = v22 + __ROL4__((v16 ^ v22 & (v15 ^ v16)) + v25, 12);
      v28 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v24;
      v29 = v13[3];
      v30 = v8[2] + v16 + 606105819;
      v13[2] = v28;
      LOBYTE(v12) = v29 + v12;
      inserted = _mm_insert_epi16(v21, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v28 + v24)), 1);
      v32 = v27 + __ROL4__((v15 ^ v27 & (v22 ^ v15)) + v30, 17);
      v33 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v29;
      v34 = v13[4];
      v35 = v8[3] + v15 - 1044525330;
      v13[3] = v33;
      LOBYTE(v12) = v34 + v12;
      v36 = _mm_insert_epi16(v26, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v33 + v29)), 1);
      v37 = v32 + __ROL4__((v22 ^ v32 & (v27 ^ v22)) + v35, 22);
      v38 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v34;
      v39 = v13[5];
      v40 = v8[4] + v22 - 176418897;
      v13[4] = v38;
      LOBYTE(v12) = v39 + v12;
      v41 = _mm_insert_epi16(inserted, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v38 + v34)), 2);
      v42 = v37 + __ROL4__((v27 ^ v37 & (v32 ^ v27)) + v40, 7);
      v43 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v39;
      v44 = v13[6];
      v45 = v8[5] + v27 + 1200080426;
      v13[5] = v43;
      LOBYTE(v12) = v44 + v12;
      v46 = _mm_insert_epi16(v36, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v43 + v39)), 2);
      v47 = v42 + __ROL4__((v32 ^ v42 & (v37 ^ v32)) + v45, 12);
      v48 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v44;
      v49 = v13[7];
      v50 = v8[6] + v32 - 1473231341;
      v13[6] = v48;
      LOBYTE(v12) = v49 + v12;
      v51 = _mm_insert_epi16(v41, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v48 + v44)), 3);
      v52 = v47 + __ROL4__((v37 ^ v47 & (v42 ^ v37)) + v50, 17);
      v53 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v49;
      v54 = v13[8];
      v55 = v8[7] + v37 - 45705983;
      v13[7] = v53;
      LOBYTE(v12) = v54 + v12;
      v56 = _mm_insert_epi16(v46, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v53 + v49)), 3);
      v57 = v52 + __ROL4__((v42 ^ v52 & (v47 ^ v42)) + v55, 22);
      v58 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v54;
      v59 = v13[9];
      v60 = v8[8] + v42 + 1770035416;
      v13[8] = v58;
      LOBYTE(v12) = v59 + v12;
      v61 = _mm_insert_epi16(v51, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v58 + v54)), 4);
      v62 = v57 + __ROL4__((v47 ^ v57 & (v52 ^ v47)) + v60, 7);
      v63 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v59;
      v64 = v13[10];
      v65 = v8[9] + v47 - 1958414417;
      v13[9] = v63;
      LOBYTE(v12) = v64 + v12;
      v66 = _mm_insert_epi16(v56, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v63 + v59)), 4);
      v67 = v62 + __ROL4__((v52 ^ v62 & (v57 ^ v52)) + v65, 12);
      v68 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v64;
      v69 = v13[11];
      v70 = v8[10] + v52 - 42063;
      v13[10] = v68;
      LOBYTE(v12) = v69 + v12;
      v71 = _mm_insert_epi16(v61, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v68 + v64)), 5);
      v72 = v67 + __ROL4__((v57 ^ v67 & (v62 ^ v57)) + v70, 17);
      v73 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v69;
      v74 = v13[12];
      v75 = v8[11] + v57 - 1990404162;
      v13[11] = v73;
      LOBYTE(v12) = v74 + v12;
      v76 = _mm_insert_epi16(v66, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v73 + v69)), 5);
      v77 = v72 + __ROL4__((v62 ^ v72 & (v67 ^ v62)) + v75, 22);
      v78 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v74;
      v79 = v13[13];
      v80 = v8[12] + v62 + 1804603682;
      v13[12] = v78;
      LOBYTE(v12) = v79 + v12;
      v81 = _mm_insert_epi16(v71, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v78 + v74)), 6);
      v82 = v77 + __ROL4__((v67 ^ v77 & (v72 ^ v67)) + v80, 7);
      v83 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v79;
      v84 = v13[14];
      v85 = v8[13] + v67 - 40341101;
      v13[13] = v83;
      LOBYTE(v12) = v84 + v12;
      v86 = _mm_insert_epi16(v76, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v83 + v79)), 6);
      v87 = v82 + __ROL4__((v72 ^ v82 & (v77 ^ v72)) + v85, 12);
      v88 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v84;
      v89 = v13[15];
      v90 = v8[14] + v72 - 1502002290;
      v13[14] = v88;
      LOBYTE(v12) = v89 + v12;
      v91 = _mm_insert_epi16(v81, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v88 + v84)), 7);
      v92 = v87 + __ROL4__((v77 ^ v87 & (v82 ^ v77)) + v90, 17);
      v93 = _mm_loadu_si128(v7);
      v94 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v89;
      v95 = v13[16];
      v96 = v8[15] + v77 + 1236535329;
      v13[15] = v94;
      LOBYTE(v12) = v95 + v12;
      v97 = v92 + __ROL4__((v82 ^ v92 & (v87 ^ v82)) + v96, 22);
      v98 = _mm_xor_si128(
              _mm_xor_si128(v93, v91),
              _mm_slli_epi64(
                _mm_insert_epi16(v86, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v94 + v89)), 7),
                8u));
      v99 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v95;
      v100 = v13[17];
      v101 = v8[1] + v82 - 165796510;
      v13[16] = v99;
      LOBYTE(v12) = v100 + v12;
      v102 = _mm_cvtsi32_si128(*(_DWORD *)(v9 + 4LL * (unsigned __int8)(v99 + v95)));
      v103 = v97 + __ROL4__((v92 ^ v87 & (v97 ^ v92)) + v101, 5);
      v104 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v100;
      v105 = v13[18];
      v106 = v8[6] + v87 - 1069501632;
      v13[17] = v104;
      LOBYTE(v12) = v105 + v12;
      v107 = _mm_cvtsi32_si128(*(_DWORD *)(v9 + 4LL * (unsigned __int8)(v104 + v100)));
      v108 = v103 + __ROL4__((v97 ^ v92 & (v103 ^ v97)) + v106, 9);
      v109 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v105;
      v110 = v13[19];
      v111 = v8[11] + v92 + 643717713;
      v13[18] = v109;
      LOBYTE(v12) = v110 + v12;
      v112 = _mm_insert_epi16(v102, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v109 + v105)), 1);
      v113 = v108 + __ROL4__((v103 ^ v97 & (v108 ^ v103)) + v111, 14);
      v114 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v110;
      v115 = v13[20];
      v116 = *v8 + v97 - 373897302;
      v13[19] = v114;
      LOBYTE(v12) = v115 + v12;
      v117 = _mm_insert_epi16(v107, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v114 + v110)), 1);
      v118 = v113 + __ROL4__((v108 ^ v103 & (v113 ^ v108)) + v116, 20);
      v119 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v115;
      v120 = v13[21];
      v121 = v8[5] + v103 - 701558691;
      v13[20] = v119;
      LOBYTE(v12) = v120 + v12;
      v122 = _mm_insert_epi16(v112, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v119 + v115)), 2);
      v123 = v118 + __ROL4__((v113 ^ v108 & (v118 ^ v113)) + v121, 5);
      v124 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v120;
      v125 = v13[22];
      v126 = v8[10] + v108 + 38016083;
      v13[21] = v124;
      LOBYTE(v12) = v125 + v12;
      v127 = _mm_insert_epi16(v117, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v124 + v120)), 2);
      v128 = v123 + __ROL4__((v118 ^ v113 & (v123 ^ v118)) + v126, 9);
      v129 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v125;
      v130 = v13[23];
      v131 = v8[15] + v113 - 660478335;
      v13[22] = v129;
      LOBYTE(v12) = v130 + v12;
      v132 = _mm_insert_epi16(v122, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v129 + v125)), 3);
      v133 = v128 + __ROL4__((v123 ^ v118 & (v128 ^ v123)) + v131, 14);
      v134 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v130;
      v135 = v13[24];
      v136 = v8[4] + v118 - 405537848;
      v13[23] = v134;
      LOBYTE(v12) = v135 + v12;
      v137 = _mm_insert_epi16(v127, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v134 + v130)), 3);
      v138 = v133 + __ROL4__((v128 ^ v123 & (v133 ^ v128)) + v136, 20);
      v139 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v135;
      v140 = v13[25];
      v141 = v8[9] + v123 + 568446438;
      v13[24] = v139;
      LOBYTE(v12) = v140 + v12;
      v142 = _mm_insert_epi16(v132, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v139 + v135)), 4);
      v143 = v138 + __ROL4__((v133 ^ v128 & (v138 ^ v133)) + v141, 5);
      v144 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v140;
      v145 = v13[26];
      v146 = v8[14] + v128 - 1019803690;
      v13[25] = v144;
      LOBYTE(v12) = v145 + v12;
      v147 = _mm_insert_epi16(v137, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v144 + v140)), 4);
      v148 = v143 + __ROL4__((v138 ^ v133 & (v143 ^ v138)) + v146, 9);
      v149 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v145;
      v150 = v13[27];
      v151 = v8[3] + v133 - 187363961;
      v13[26] = v149;
      LOBYTE(v12) = v150 + v12;
      v152 = _mm_insert_epi16(v142, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v149 + v145)), 5);
      v153 = v148 + __ROL4__((v143 ^ v138 & (v148 ^ v143)) + v151, 14);
      v154 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v150;
      v155 = v13[28];
      v156 = v8[8] + v138 + 1163531501;
      v13[27] = v154;
      LOBYTE(v12) = v155 + v12;
      v157 = _mm_insert_epi16(v147, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v154 + v150)), 5);
      v158 = v153 + __ROL4__((v148 ^ v143 & (v153 ^ v148)) + v156, 20);
      v159 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v155;
      v160 = v13[29];
      v161 = v8[13] + v143 - 1444681467;
      v13[28] = v159;
      LOBYTE(v12) = v160 + v12;
      v162 = _mm_insert_epi16(v152, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v159 + v155)), 6);
      v163 = v158 + __ROL4__((v153 ^ v148 & (v158 ^ v153)) + v161, 5);
      v164 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v160;
      v165 = v13[30];
      v166 = v8[2] + v148 - 51403784;
      v13[29] = v164;
      LOBYTE(v12) = v165 + v12;
      v167 = _mm_insert_epi16(v157, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v164 + v160)), 6);
      v168 = v163 + __ROL4__((v158 ^ v153 & (v163 ^ v158)) + v166, 9);
      v169 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v165;
      v170 = v13[31];
      v171 = v8[7] + v153 + 1735328473;
      v13[30] = v169;
      LOBYTE(v12) = v170 + v12;
      v172 = _mm_insert_epi16(v162, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v169 + v165)), 7);
      v173 = v168 + __ROL4__((v163 ^ v158 & (v168 ^ v163)) + v171, 14);
      v174 = _mm_loadu_si128(v7 + 1);
      LOBYTE(v10) = v10 + 32;
      v175 = *(_DWORD *)(v9 + 4 * v12);
      *(_DWORD *)(v9 + 4 * v12) = v170;
      v176 = *(_DWORD *)(v9 + 4 * v10);
      v177 = v8[12] + v158 - 1926607734;
      v13[31] = v175;
      v178 = v173 + __ROL4__((v168 ^ v163 & (v173 ^ v168)) + v177, 20);
      v179 = (unsigned __int8)(v176 + v12);
      v180 = (_DWORD *)(v9 + 4 * v10);
      v181 = _mm_xor_si128(
               _mm_xor_si128(v174, v172),
               _mm_slli_epi64(
                 _mm_insert_epi16(v167, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v175 + v170)), 7),
                 8u));
      v182 = *(_DWORD *)(v9 + 4 * v179);
      *(_DWORD *)(v9 + 4 * v179) = v176;
      v183 = v180[1];
      v184 = (v178 ^ v173 ^ v168) + v8[5] + v163 - 378558;
      *v180 = v182;
      v185 = (unsigned __int8)(v183 + v179);
      v186 = _mm_cvtsi32_si128(*(_DWORD *)(v9 + 4LL * (unsigned __int8)(v182 + v176)));
      v187 = v178 + __ROL4__(v184, 4);
      v188 = *(_DWORD *)(v9 + 4 * v185);
      *(_DWORD *)(v9 + 4 * v185) = v183;
      v189 = v180[2];
      v190 = (v187 ^ v178 ^ v173) + v8[8] + v168 - 2022574463;
      v180[1] = v188;
      v191 = (unsigned __int8)(v189 + v185);
      v192 = _mm_cvtsi32_si128(*(_DWORD *)(v9 + 4LL * (unsigned __int8)(v188 + v183)));
      v193 = v187 + __ROL4__(v190, 11);
      v194 = *(_DWORD *)(v9 + 4 * v191);
      *(_DWORD *)(v9 + 4 * v191) = v189;
      v195 = v180[3];
      v196 = (v193 ^ v187 ^ v178) + v8[11] + v173 + 1839030562;
      v180[2] = v194;
      v197 = (unsigned __int8)(v195 + v191);
      v198 = _mm_insert_epi16(v186, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v194 + v189)), 1);
      v199 = v193 + __ROL4__(v196, 16);
      v200 = *(_DWORD *)(v9 + 4 * v197);
      *(_DWORD *)(v9 + 4 * v197) = v195;
      v201 = v180[4];
      v202 = (v199 ^ v193 ^ v187) + v8[14] + v178 - 35309556;
      v180[3] = v200;
      v203 = (unsigned __int8)(v201 + v197);
      v204 = _mm_insert_epi16(v192, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v200 + v195)), 1);
      v205 = v199 + __ROL4__(v202, 23);
      v206 = *(_DWORD *)(v9 + 4 * v203);
      *(_DWORD *)(v9 + 4 * v203) = v201;
      v207 = v180[5];
      v208 = (v205 ^ v199 ^ v193) + v8[1] + v187 - 1530992060;
      v180[4] = v206;
      v209 = (unsigned __int8)(v207 + v203);
      v210 = _mm_insert_epi16(v198, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v206 + v201)), 2);
      v211 = v205 + __ROL4__(v208, 4);
      v212 = *(_DWORD *)(v9 + 4 * v209);
      *(_DWORD *)(v9 + 4 * v209) = v207;
      v213 = v180[6];
      v214 = (v211 ^ v205 ^ v199) + v8[4] + v193 + 1272893353;
      v180[5] = v212;
      v215 = (unsigned __int8)(v213 + v209);
      v216 = _mm_insert_epi16(v204, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v212 + v207)), 2);
      v217 = v211 + __ROL4__(v214, 11);
      v218 = *(_DWORD *)(v9 + 4 * v215);
      *(_DWORD *)(v9 + 4 * v215) = v213;
      v219 = v180[7];
      v220 = (v217 ^ v211 ^ v205) + v8[7] + v199 - 155497632;
      v180[6] = v218;
      v221 = (unsigned __int8)(v219 + v215);
      v222 = _mm_insert_epi16(v210, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v218 + v213)), 3);
      v223 = v217 + __ROL4__(v220, 16);
      v224 = *(_DWORD *)(v9 + 4 * v221);
      *(_DWORD *)(v9 + 4 * v221) = v219;
      v225 = v180[8];
      v226 = (v223 ^ v217 ^ v211) + v8[10] + v205 - 1094730640;
      v180[7] = v224;
      v227 = (unsigned __int8)(v225 + v221);
      v228 = _mm_insert_epi16(v216, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v224 + v219)), 3);
      v229 = v223 + __ROL4__(v226, 23);
      v230 = *(_DWORD *)(v9 + 4 * v227);
      *(_DWORD *)(v9 + 4 * v227) = v225;
      v231 = v180[9];
      v232 = (v229 ^ v223 ^ v217) + v8[13] + v211 + 681279174;
      v180[8] = v230;
      v233 = (unsigned __int8)(v231 + v227);
      v234 = _mm_insert_epi16(v222, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v230 + v225)), 4);
      v235 = v229 + __ROL4__(v232, 4);
      v236 = *(_DWORD *)(v9 + 4 * v233);
      *(_DWORD *)(v9 + 4 * v233) = v231;
      v237 = v180[10];
      v238 = (v235 ^ v229 ^ v223) + *v8 + v217 - 358537222;
      v180[9] = v236;
      v239 = (unsigned __int8)(v237 + v233);
      v240 = _mm_insert_epi16(v228, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v236 + v231)), 4);
      v241 = v235 + __ROL4__(v238, 11);
      v242 = *(_DWORD *)(v9 + 4 * v239);
      *(_DWORD *)(v9 + 4 * v239) = v237;
      v243 = v180[11];
      v244 = (v241 ^ v235 ^ v229) + v8[3] + v223 - 722521979;
      v180[10] = v242;
      v245 = (unsigned __int8)(v243 + v239);
      v246 = _mm_insert_epi16(v234, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v242 + v237)), 5);
      v247 = v241 + __ROL4__(v244, 16);
      v248 = *(_DWORD *)(v9 + 4 * v245);
      *(_DWORD *)(v9 + 4 * v245) = v243;
      v249 = v180[12];
      v250 = (v247 ^ v241 ^ v235) + v8[6] + v229 + 76029189;
      v180[11] = v248;
      v251 = (unsigned __int8)(v249 + v245);
      v252 = _mm_insert_epi16(v240, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v248 + v243)), 5);
      v253 = v247 + __ROL4__(v250, 23);
      v254 = *(_DWORD *)(v9 + 4 * v251);
      *(_DWORD *)(v9 + 4 * v251) = v249;
      v255 = v180[13];
      v256 = (v253 ^ v247 ^ v241) + v8[9] + v235 - 640364487;
      v180[12] = v254;
      v257 = (unsigned __int8)(v255 + v251);
      v258 = _mm_insert_epi16(v246, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v254 + v249)), 6);
      v259 = v253 + __ROL4__(v256, 4);
      v260 = *(_DWORD *)(v9 + 4 * v257);
      *(_DWORD *)(v9 + 4 * v257) = v255;
      v261 = v180[14];
      v262 = (v259 ^ v253 ^ v247) + v8[12] + v241 - 421815835;
      v180[13] = v260;
      v263 = (unsigned __int8)(v261 + v257);
      v264 = _mm_insert_epi16(v252, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v260 + v255)), 6);
      v265 = v259 + __ROL4__(v262, 11);
      v266 = *(_DWORD *)(v9 + 4 * v263);
      *(_DWORD *)(v9 + 4 * v263) = v261;
      v267 = v180[15];
      v268 = (v265 ^ v259 ^ v253) + v8[15] + v247 + 530742520;
      v180[14] = v266;
      v269 = (unsigned __int8)(v267 + v263);
      v270 = _mm_insert_epi16(v258, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v266 + v261)), 7);
      v271 = v265 + __ROL4__(v268, 16);
      v272 = _mm_loadu_si128(v7 + 2);
      v273 = *(_DWORD *)(v9 + 4 * v269);
      *(_DWORD *)(v9 + 4 * v269) = v267;
      v274 = v180[16];
      v275 = (v271 ^ v265 ^ v259) + v8[2] + v253 - 995338651;
      v180[15] = v273;
      v276 = (unsigned __int8)(v274 + v269);
      v277 = v271 + __ROL4__(v275, 23);
      v278 = _mm_xor_si128(
               _mm_xor_si128(v272, v270),
               _mm_slli_epi64(
                 _mm_insert_epi16(v264, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v273 + v267)), 7),
                 8u));
      v279 = *(_DWORD *)(v9 + 4 * v276);
      *(_DWORD *)(v9 + 4 * v276) = v274;
      v280 = v180[17];
      v281 = *v8 + v259 - 198630844;
      v180[16] = v279;
      v282 = (unsigned __int8)(v280 + v276);
      v283 = _mm_cvtsi32_si128(*(_DWORD *)(v9 + 4LL * (unsigned __int8)(v279 + v274)));
      v284 = v277 + __ROL4__((v271 ^ (v277 | ~v265)) + v281, 6);
      v285 = *(_DWORD *)(v9 + 4 * v282);
      *(_DWORD *)(v9 + 4 * v282) = v280;
      v286 = v180[18];
      v287 = v8[7] + v265 + 1126891415;
      v180[17] = v285;
      v288 = (unsigned __int8)(v286 + v282);
      v289 = _mm_cvtsi32_si128(*(_DWORD *)(v9 + 4LL * (unsigned __int8)(v285 + v280)));
      v290 = v284 + __ROL4__((v277 ^ (v284 | ~v271)) + v287, 10);
      v291 = *(_DWORD *)(v9 + 4 * v288);
      *(_DWORD *)(v9 + 4 * v288) = v286;
      v292 = v180[19];
      v293 = v8[14] + v271 - 1416354905;
      v180[18] = v291;
      v294 = (unsigned __int8)(v292 + v288);
      v295 = _mm_insert_epi16(v283, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v291 + v286)), 1);
      v296 = v290 + __ROL4__((v284 ^ (v290 | ~v277)) + v293, 15);
      v297 = *(_DWORD *)(v9 + 4 * v294);
      *(_DWORD *)(v9 + 4 * v294) = v292;
      v298 = v180[20];
      v299 = v8[5] + v277 - 57434055;
      v180[19] = v297;
      v300 = (unsigned __int8)(v298 + v294);
      v301 = _mm_insert_epi16(v289, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v297 + v292)), 1);
      v302 = v296 + __ROL4__((v290 ^ (v296 | ~v284)) + v299, 21);
      v303 = *(_DWORD *)(v9 + 4 * v300);
      *(_DWORD *)(v9 + 4 * v300) = v298;
      v304 = v180[21];
      v305 = v8[12] + v284 + 1700485571;
      v180[20] = v303;
      v306 = (unsigned __int8)(v304 + v300);
      v307 = _mm_insert_epi16(v295, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v303 + v298)), 2);
      v308 = v302 + __ROL4__((v296 ^ (v302 | ~v290)) + v305, 6);
      v309 = *(_DWORD *)(v9 + 4 * v306);
      *(_DWORD *)(v9 + 4 * v306) = v304;
      v310 = v180[22];
      v311 = v8[3] + v290 - 1894986606;
      v180[21] = v309;
      v312 = (unsigned __int8)(v310 + v306);
      v313 = _mm_insert_epi16(v301, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v309 + v304)), 2);
      v314 = v308 + __ROL4__((v302 ^ (v308 | ~v296)) + v311, 10);
      v315 = *(_DWORD *)(v9 + 4 * v312);
      *(_DWORD *)(v9 + 4 * v312) = v310;
      v316 = v180[23];
      v317 = v8[10] + v296 - 1051523;
      v180[22] = v315;
      v318 = (unsigned __int8)(v316 + v312);
      v319 = _mm_insert_epi16(v307, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v315 + v310)), 3);
      v320 = v314 + __ROL4__((v308 ^ (v314 | ~v302)) + v317, 15);
      v321 = *(_DWORD *)(v9 + 4 * v318);
      *(_DWORD *)(v9 + 4 * v318) = v316;
      v322 = v180[24];
      v323 = v8[1] + v302 - 2054922799;
      v180[23] = v321;
      v324 = (unsigned __int8)(v322 + v318);
      v325 = _mm_insert_epi16(v313, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v321 + v316)), 3);
      v326 = v320 + __ROL4__((v314 ^ (v320 | ~v308)) + v323, 21);
      v327 = *(_DWORD *)(v9 + 4 * v324);
      *(_DWORD *)(v9 + 4 * v324) = v322;
      v328 = v180[25];
      v329 = v8[8] + v308 + 1873313359;
      v180[24] = v327;
      v330 = (unsigned __int8)(v328 + v324);
      v331 = _mm_insert_epi16(v319, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v327 + v322)), 4);
      v332 = v326 + __ROL4__((v320 ^ (v326 | ~v314)) + v329, 6);
      v333 = *(_DWORD *)(v9 + 4 * v330);
      *(_DWORD *)(v9 + 4 * v330) = v328;
      v334 = v180[26];
      v335 = v8[15] + v314 - 30611744;
      v180[25] = v333;
      v336 = (unsigned __int8)(v334 + v330);
      v337 = _mm_insert_epi16(v325, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v333 + v328)), 4);
      v338 = v332 + __ROL4__((v326 ^ (v332 | ~v320)) + v335, 10);
      v339 = *(_DWORD *)(v9 + 4 * v336);
      *(_DWORD *)(v9 + 4 * v336) = v334;
      v340 = v180[27];
      v341 = v8[6] + v320 - 1560198380;
      v180[26] = v339;
      v342 = (unsigned __int8)(v340 + v336);
      v343 = _mm_insert_epi16(v331, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v339 + v334)), 5);
      v344 = v338 + __ROL4__((v332 ^ (v338 | ~v326)) + v341, 15);
      v345 = *(_DWORD *)(v9 + 4 * v342);
      *(_DWORD *)(v9 + 4 * v342) = v340;
      v346 = v180[28];
      v347 = v8[13] + v326 + 1309151649;
      v180[27] = v345;
      v348 = (unsigned __int8)(v346 + v342);
      v349 = _mm_insert_epi16(v337, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v345 + v340)), 5);
      v350 = v344 + __ROL4__((v338 ^ (v344 | ~v332)) + v347, 21);
      v351 = *(_DWORD *)(v9 + 4 * v348);
      *(_DWORD *)(v9 + 4 * v348) = v346;
      v352 = v180[29];
      v353 = v8[4] + v332 - 145523070;
      v180[28] = v351;
      v354 = (unsigned __int8)(v352 + v348);
      v355 = _mm_insert_epi16(v343, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v351 + v346)), 6);
      v356 = v350 + __ROL4__((v344 ^ (v350 | ~v338)) + v353, 6);
      v357 = *(_DWORD *)(v9 + 4 * v354);
      *(_DWORD *)(v9 + 4 * v354) = v352;
      v358 = v180[30];
      v359 = v8[11] + v338 - 1120210379;
      v180[29] = v357;
      v360 = (unsigned __int8)(v358 + v354);
      v361 = _mm_insert_epi16(v349, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v357 + v352)), 6);
      v362 = v356 + __ROL4__((v350 ^ (v356 | ~v344)) + v359, 10);
      v363 = *(_DWORD *)(v9 + 4 * v360);
      *(_DWORD *)(v9 + 4 * v360) = v358;
      v364 = v180[31];
      v365 = v8[2] + v344 + 718787259;
      v180[30] = v363;
      v366 = (unsigned __int8)(v364 + v360);
      v367 = _mm_insert_epi16(v355, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v363 + v358)), 7);
      v368 = v362 + __ROL4__((v356 ^ (v362 | ~v350)) + v365, 15);
      v369 = _mm_loadu_si128(v7 + 3);
      LOBYTE(v10) = v10 + 32;
      v370 = *(_DWORD *)(v9 + 4 * v366);
      *(_DWORD *)(v9 + 4 * v366) = v364;
      result = (_UNKNOWN **)*(unsigned int *)(v9 + 4 * v10);
      v371 = v8[9] + v350 - 343485551;
      v180[31] = v370;
      v372 = __ROL4__((v362 ^ (v368 | ~v356)) + v371, 21);
      v10 = (unsigned __int8)v10;
      v12 = (unsigned __int8)((_BYTE)result + v366);
      v13 = (_DWORD *)(v9 + 4LL * (unsigned __int8)v10);
      v373 = _mm_xor_si128(
               _mm_xor_si128(v369, v367),
               _mm_slli_epi64(
                 _mm_insert_epi16(v361, *(unsigned __int16 *)(v9 + 4LL * (unsigned __int8)(v370 + v364)), 7),
                 8u));
      v14 = v374 + v356;
      v15 = v375 + v368 + v372;
      v16 = v376 + v368;
      v17 = v377 + v362;
      *(__m128i *)((char *)v7 + v11) = v98;
      *(__m128i *)((char *)v7 + v11 + 16) = v181;
      *(__m128i *)((char *)v7 + v11 + 32) = v278;
      *(__m128i *)((char *)v7 + v11 + 48) = v373;
      v8 += 16;
      v7 += 4;
    }
    while ( v8 < &a5[16 * a6] );
    LOBYTE(v12) = v12 - (_BYTE)result;
    *a4 = v14;
    a4[1] = v15;
    a4[2] = v16;
    a4[3] = v17;
    LOBYTE(v10) = v10 - 1;
    *(_DWORD *)(v9 - 8) = v10;
    *(_DWORD *)(v9 - 4) = v12;
  }
  return result;
}


// ==== sub_7FF91DCA5D50 @ rva 0x45D50 ====
__int64 __fastcall sub_7FF91DCA5D50(__int64 a1, __int64 a2, _QWORD *a3, __int64 a4)
{
  unsigned __int64 v4; // kr00_8
  _QWORD *v5; // rax
  unsigned __int64 v6; // rbx
  __int64 v7; // r15
  __int64 v8; // r14
  __int64 v9; // r13
  __int64 v10; // r12
  __int64 v11; // rbp
  __int64 v12; // rbx
  __int64 v13; // rdi
  __int64 v14; // rsi

  v4 = __readeflags();
  v5 = (_QWORD *)a3[15];
  v6 = a3[31];
  if ( v6 >= (unsigned __int64)&loc_7FF91DCA4D3B )
  {
    v5 = (_QWORD *)a3[19];
    if ( v6 < (unsigned __int64)&loc_7FF91DCA5D3A )
    {
      v7 = v5[5];
      v8 = v5[6];
      v9 = v5[7];
      v10 = v5[8];
      v11 = v5[9];
      v12 = v5[10];
      v5 += 11;
      a3[18] = v12;
      a3[20] = v11;
      a3[27] = v10;
      a3[28] = v9;
      a3[29] = v8;
      a3[30] = v7;
    }
  }
  v13 = v5[1];
  v14 = v5[2];
  a3[19] = v5;
  a3[21] = v14;
  a3[22] = v13;
  qmemcpy(*(void **)(a4 + 40), a3, 0x4D0u);
  RtlVirtualUnwind(
    0,
    *(_QWORD *)(a4 + 8),
    *(_QWORD *)a4,
    *(PRUNTIME_FUNCTION *)(a4 + 16),
    *(PCONTEXT *)(a4 + 40),
    (PVOID *)(a4 + 56),
    (PULONG64)(a4 + 24),
    nullptr);
  __writeeflags(v4);
  return 1;
}


// ==== sub_7FF91DCA5E80 @ rva 0x45E80 ====
__int64 __fastcall sub_7FF91DCA5E80(int a1, int a2, int a3, int a4, __int64 a5)
{
  return sub_7FF91DCA5E8D(a1, a2, a3, a4, a5);
}


// ==== sub_7FF91DCA5E8D @ rva 0x45E8D ====
// local variable allocation has failed, the output may be wrong!
_UNKNOWN **__fastcall sub_7FF91DCA5E8D(_QWORD *a1, _QWORD *a2, __int64 a3, __int64 a4, __int64 a5)
{
  int v8; // r8d
  __int64 v9; // rbp
  __int128 v10; // rax OVERLAPPED
  unsigned __int64 v11; // rbx
  unsigned __int128 v12; // rax
  unsigned __int64 v13; // kr130_8
  __int128 v14; // kr140_16
  unsigned __int128 v15; // kr150_16
  unsigned __int128 v16; // kr160_16
  unsigned __int128 v17; // kr170_16
  unsigned __int128 v18; // kr180_16
  unsigned __int128 v19; // kr190_16
  unsigned __int128 v20; // kr1A0_16
  __int64 v21; // r9
  unsigned __int64 v22; // r8
  __int64 v23; // r10
  unsigned __int64 v24; // r12
  unsigned __int64 v25; // kr260_8
  bool v26; // cf
  unsigned __int64 v27; // r10
  unsigned __int64 v28; // rbx
  __int64 v29; // r11
  unsigned __int64 v30; // r9
  unsigned __int64 v31; // kr290_8
  unsigned __int64 v32; // rcx
  unsigned __int64 v33; // kr2B0_8
  unsigned __int64 v34; // r10
  __int64 v35; // r12
  unsigned __int64 v36; // kr2D0_8
  unsigned __int64 v37; // kr2F0_8
  unsigned __int128 v38; // rax
  __int64 v39; // r12
  __int64 v40; // r13
  unsigned __int64 v41; // r10
  unsigned __int64 v42; // r12
  __int64 v43; // r14
  unsigned __int128 v44; // kr360_16
  unsigned __int64 v45; // rbx
  unsigned __int128 v46; // rax
  __int64 v47; // r14
  __int64 v48; // r15
  unsigned __int64 v49; // r11
  unsigned __int64 v50; // r12
  __int64 v51; // r8
  unsigned __int128 v52; // kr3B0_16
  unsigned __int64 v53; // rcx
  unsigned __int128 v54; // rax
  __int64 v55; // r8
  __int64 v56; // r9
  unsigned __int64 v57; // r12
  unsigned __int64 v58; // r15
  unsigned __int64 v59; // r10
  unsigned __int128 v60; // kr3E0_16
  unsigned __int128 v61; // rax
  unsigned __int64 v62; // r10
  __int64 v63; // r11
  __int64 v64; // r12
  __int64 v65; // r13
  __int64 v66; // r12
  __int64 v67; // rtt
  unsigned __int128 v68; // rax
  __int64 v69; // r12
  __int64 v70; // kr400_8
  __int64 v71; // r12
  __int64 v72; // r13
  __int64 v73; // r14
  __int64 v74; // r15
  __int64 v75; // r8
  __int64 v76; // r9
  __int64 v77; // r9
  __int64 v78; // r10
  __int64 v79; // r11
  __int64 v80; // rtt
  __int64 v81; // rtt
  __int64 v82; // rdx
  __int64 v83; // r8
  __int64 v84; // r9
  _QWORD *v85; // xmm0_8
  __int64 v86; // xmm1_8
  __int128 v108; // rt0
  __int64 v138; // rbx
  __int64 v189; // rbx
  __int64 v225; // rbx
  __int64 v237; // r14
  __int64 v248; // r12
  __int64 v249; // r13
  __int64 v250; // r14
  __int64 v251; // r15
  __int64 v252; // r8
  __int64 v253; // r9
  __int64 v254; // r9
  __int64 v255; // r10
  __int64 v256; // r11
  __int64 v257; // rtt
  __int64 v258; // rtt
  __int64 v259; // rdx
  __int64 v260; // r8
  __int64 v261; // r9
  int v263; // [rsp+0h] [rbp-C8h]
  int v264; // [rsp+8h] [rbp-C0h]
  int v265; // [rsp+8h] [rbp-C0h]
  __int64 v266; // [rsp+20h] [rbp-A8h]
  __int64 v267; // [rsp+20h] [rbp-A8h]
  __int64 v268; // [rsp+28h] [rbp-A0h]
  __int64 v269; // [rsp+28h] [rbp-A0h]
  __int64 v270; // [rsp+30h] [rbp-98h]
  __int64 v271; // [rsp+30h] [rbp-98h]
  __int64 v272; // [rsp+38h] [rbp-90h]
  __int64 v273; // [rsp+38h] [rbp-90h]
  int v274; // [rsp+40h] [rbp-88h]
  __int64 v275; // [rsp+40h] [rbp-88h]
  int v276; // [rsp+40h] [rbp-88h]
  __int64 v277; // [rsp+40h] [rbp-88h]
  int v278; // [rsp+48h] [rbp-80h]
  __int64 v279; // [rsp+48h] [rbp-80h]
  __int64 v280; // [rsp+48h] [rbp-80h]
  int v281; // [rsp+50h] [rbp-78h]
  __int64 v282; // [rsp+50h] [rbp-78h]
  __int64 v283; // [rsp+50h] [rbp-78h]
  int v284; // [rsp+58h] [rbp-70h]
  __int64 v285; // [rsp+58h] [rbp-70h]
  __int64 v286; // [rsp+58h] [rbp-70h]
  __int64 v287; // [rsp+60h] [rbp-68h]
  __int64 v288; // [rsp+60h] [rbp-68h]
  int v289; // [rsp+68h] [rbp-60h]
  __int64 v290; // [rsp+68h] [rbp-60h]
  int v291; // [rsp+68h] [rbp-60h]
  __int64 v292; // [rsp+68h] [rbp-60h]
  __int64 v293; // [rsp+70h] [rbp-58h]
  int v294; // [rsp+70h] [rbp-58h]
  __int64 v295; // [rsp+70h] [rbp-58h]
  int v296; // [rsp+78h] [rbp-50h]
  __int64 v297; // [rsp+78h] [rbp-50h]
  int v298; // [rsp+78h] [rbp-50h]
  __int64 v299; // [rsp+78h] [rbp-50h]
  __int64 v300; // [rsp+80h] [rbp-48h]
  int v301; // [rsp+88h] [rbp-40h]
  int v302; // [rsp+88h] [rbp-40h]
  _UNKNOWN *retaddr; // [rsp+C8h] [rbp+0h] BYREF

  v8 = a5;
  v9 = a3;
  *((_QWORD *)&v10 + 1) = *a2;
  *(_QWORD *)&v10 = a2[1];
  v300 = a4;
  if ( (dword_7FF91E91A5F8 & 0x80100) == 0x80100 )
  {
    do
    {
      v302 = v8;
      v85 = a1;
      v86 = v9;
      *(__int128 *)((char *)&v10 + 8) = *((unsigned __int64 *)&v10 + 1);
      v10 = (unsigned __int64)v10;
      _R9 = (*(__int128 *)((char *)&v10 + 8) * (unsigned __int128)(unsigned __int64)v10) >> 64;
      _R10 = (0 * (unsigned __int128)(unsigned __int64)a2[2]) >> 64;
      _RBP = 0;
      _RDX = 0u;
      _R11 = (0 * (unsigned __int128)(unsigned __int64)a2[3]) >> 64;
      _RAX = 0;
      __asm { adcx    r9, rcx }
      _R12 = (0 * (unsigned __int128)(unsigned __int64)a2[4]) >> 64;
      __asm { adcx    r10, rax }
      _RDX = 0u;
      _R13 = (0 * (unsigned __int128)(unsigned __int64)a2[5]) >> 64;
      _RAX = 0;
      __asm { adcx    r11, rcx }
      _R14 = (0 * (unsigned __int128)(unsigned __int64)a2[6]) >> 64;
      *((_QWORD *)&_RDX + 1) = 0;
      __asm
      {
        adcx    r12, rax
        adcx    r13, rcx
      }
      _R15 = (0 * (unsigned __int128)(unsigned __int64)a2[7]) >> 64;
      _RAX = 0;
      __asm
      {
        adcx    r14, rax
        adcx    r15, rbp
      }
      *((_QWORD *)&v108 + 1) = _R9;
      *(_QWORD *)&v108 = 0;
      _R9 = v108 >> 63;
      _R8 = 0;
      _RBP = 0;
      *(__int128 *)((char *)&_RDX - 8) = 0 * (unsigned __int128)0LL;
      __asm { adcx    r8, rdx }
      *(_QWORD *)&_RDX = a2[1];
      __asm { adcx    r9, rbp }
      v265 = _R8;
      _RBX = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[2]) >> 64;
      _RAX = _RDX * a2[2];
      __asm
      {
        adox    r10, rax
        adcx    r11, rbx
      }
      _R8 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[3]) >> 64;
      _RDI = _RDX * a2[3];
      __asm
      {
        adox    r11, rdi
        adcx    r12, r8
      }
      _RBX = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[4]) >> 64;
      _RAX = _RDX * a2[4];
      __asm
      {
        adox    r12, rax
        adcx    r13, rbx
      }
      _R8 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[5]) >> 64;
      _RDI = _RDX * a2[5];
      __asm
      {
        adox    r13, rdi
        adcx    r14, r8
      }
      _RBX = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[6]) >> 64;
      _RAX = _RDX * a2[6];
      __asm
      {
        adox    r14, rax
        adcx    r15, rbx
      }
      _R8 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[7]) >> 64;
      _RDI = _RDX * a2[7];
      __asm
      {
        adox    r15, rdi
        adcx    r8, rbp
        adox    r8, rbp
      }
      v138 = _R11;
      *((_QWORD *)&v108 + 1) = _R11;
      *(_QWORD *)&v108 = _R10;
      _R11 = v108 >> 63;
      *((_QWORD *)&v108 + 1) = _R10;
      *(_QWORD *)&v108 = 0;
      _R10 = v108 >> 63;
      _RBP = 0;
      *((_QWORD *)&_RDX + 1) = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)_RDX) >> 64;
      _RAX = _RDX * _RDX;
      *(_QWORD *)&_RDX = a2[2];
      __asm
      {
        adcx    r9, rax
        adcx    r10, rcx
        adcx    r11, rbp
      }
      _R9 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[3]) >> 64;
      _RDI = _RDX * a2[3];
      __asm
      {
        adox    r12, rdi
        adcx    r13, r9
      }
      *((_QWORD *)&_RDX + 1) = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[4]) >> 64;
      _RAX = _RDX * a2[4];
      __asm
      {
        adox    r13, rax
        adcx    r14, rcx
      }
      _R9 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[5]) >> 64;
      _RDI = _RDX * a2[5];
      __asm
      {
        adox    r14, rdi
        adcx    r15, r9
      }
      *((_QWORD *)&_RDX + 1) = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[6]) >> 64;
      _RAX = _RDX * a2[6];
      __asm
      {
        adox    r15, rax
        adcx    r8, rcx
      }
      _R9 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[7]) >> 64;
      _RDI = _RDX * a2[7];
      __asm
      {
        adox    r8, rdi
        adcx    r9, rbp
        adox    r9, rbp
      }
      *((_QWORD *)&v108 + 1) = _R13;
      *(_QWORD *)&v108 = _R12;
      _R13 = v108 >> 63;
      *((_QWORD *)&v108 + 1) = _R12;
      *(_QWORD *)&v108 = v138;
      _R12 = v108 >> 63;
      _RBP = 0;
      *(__int128 *)((char *)&_RDX - 8) = (unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)_RDX;
      __asm
      {
        adcx    r11, rax
        adcx    r12, rdx
      }
      *(_QWORD *)&_RDX = a2[3];
      __asm { adcx    r13, rbp }
      v267 = _R11;
      v269 = _R12;
      _RBX = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[4]) >> 64;
      _RAX = _RDX * a2[4];
      __asm
      {
        adox    r14, rax
        adcx    r15, rbx
      }
      _R10 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[5]) >> 64;
      _RDI = _RDX * a2[5];
      __asm
      {
        adox    r15, rdi
        adcx    r8, r10
      }
      _RBX = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[6]) >> 64;
      _RAX = _RDX * a2[6];
      __asm
      {
        adox    r8, rax
        adcx    r9, rbx
      }
      _R10 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[7]) >> 64;
      _RDI = _RDX * a2[7];
      __asm
      {
        adox    r9, rdi
        adcx    r10, rbp
        adox    r10, rbp
      }
      v189 = _R15;
      *((_QWORD *)&v108 + 1) = _R15;
      *(_QWORD *)&v108 = _R14;
      _R15 = v108 >> 63;
      *((_QWORD *)&v108 + 1) = _R14;
      *(_QWORD *)&v108 = 0;
      _R14 = v108 >> 63;
      _RBP = 0;
      *(__int128 *)((char *)&_RDX - 8) = (unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)_RDX;
      __asm
      {
        adcx    r13, rax
        adcx    r14, rdx
      }
      *(_QWORD *)&_RDX = a2[4];
      __asm { adcx    r15, rbp }
      v271 = _R13;
      v273 = _R14;
      _R11 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[5]) >> 64;
      _RDI = _RDX * a2[5];
      __asm
      {
        adox    r8, rdi
        adcx    r9, r11
      }
      *((_QWORD *)&_RDX + 1) = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[6]) >> 64;
      _RAX = _RDX * a2[6];
      __asm
      {
        adox    r9, rax
        adcx    r10, rcx
      }
      _R11 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[7]) >> 64;
      _RDI = _RDX * a2[7];
      __asm
      {
        adox    r10, rdi
        adcx    r11, rbp
        adox    r11, rbp
      }
      *((_QWORD *)&v108 + 1) = _R9;
      *(_QWORD *)&v108 = _R8;
      _R9 = v108 >> 63;
      *((_QWORD *)&v108 + 1) = _R8;
      *(_QWORD *)&v108 = v189;
      _R8 = v108 >> 63;
      _RBP = 0;
      *(__int128 *)((char *)&_RDX - 8) = (unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)_RDX;
      __asm
      {
        adcx    r15, rax
        adcx    r8, rdx
      }
      *(_QWORD *)&_RDX = a2[5];
      __asm { adcx    r9, rbp }
      v276 = _R15;
      _RBX = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[6]) >> 64;
      _RAX = _RDX * a2[6];
      __asm
      {
        adox    r10, rax
        adcx    r11, rbx
      }
      _R12 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[7]) >> 64;
      _RDI = _RDX * a2[7];
      __asm
      {
        adox    r11, rdi
        adcx    r12, rbp
        adox    r12, rbp
      }
      v225 = _R11;
      *((_QWORD *)&v108 + 1) = _R11;
      *(_QWORD *)&v108 = _R10;
      _R11 = v108 >> 63;
      *((_QWORD *)&v108 + 1) = _R10;
      *(_QWORD *)&v108 = 0;
      _R10 = v108 >> 63;
      _RBP = 0;
      *(__int128 *)((char *)&_RDX - 8) = (unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)_RDX;
      __asm
      {
        adcx    r9, rax
        adcx    r10, rdx
      }
      *(_QWORD *)&_RDX = a2[6];
      __asm { adcx    r11, rbp }
      _R13 = ((unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)a2[7]) >> 64;
      _RAX = _RDX * a2[7];
      __asm
      {
        adox    r12, rax
        adox    r13, rbp
      }
      v237 = (__int128)_R13 >> 63;
      *((_QWORD *)&v108 + 1) = _R13;
      *(_QWORD *)&v108 = _R12;
      _R13 = v108 >> 63;
      *((_QWORD *)&v108 + 1) = _R12;
      *(_QWORD *)&v108 = v225;
      _R12 = v108 >> 63;
      _RBP = 0;
      *(__int128 *)((char *)&_RDX - 8) = (unsigned __int64)_RDX * (unsigned __int128)(unsigned __int64)_RDX;
      __asm
      {
        adcx    r11, rax
        adcx    r12, rdx
      }
      __asm { adcx    r13, rbp }
      v291 = _R12;
      _RDX = (unsigned __int64)a2[7];
      *(__int128 *)((char *)&_RDX - 8) = _RDX * _RDX;
      __asm
      {
        adox    r13, rax
        adox    rdx, rbp
      }
      v294 = _R13;
      v298 = _RDX + v237;
      a1 = v85;
      v9 = v86;
      v248 = v267;
      v249 = v269;
      v250 = v271;
      v251 = v273;
      sub_7FF91DCA73C0(
        DWORD2(_RDX),
        v300,
        0,
        v265,
        v267,
        v269,
        v271,
        v273,
        v276,
        _R8,
        _R9,
        _R10,
        _R11,
        v291,
        v294,
        v298,
        v300);
      v26 = __CFADD__(__CFADD__(v277, v252), v253);
      v254 = __CFADD__(v277, v252) + v253;
      v257 = __CFADD__(
               __CFADD__(
                 __CFADD__(
                   __CFADD__(v26 | (unsigned __int8)__CFADD__(v280, v253), v255)
                 | (unsigned __int8)__CFADD__(v283, (v26 | (unsigned __int8)__CFADD__(v280, v253)) + v255),
                   v256)
               | (unsigned __int8)__CFADD__(
                                    v286,
                                    (__CFADD__(v26 | (unsigned __int8)__CFADD__(v280, v253), v255)
                                   | (unsigned __int8)__CFADD__(
                                                        v283,
                                                        (v26 | (unsigned __int8)__CFADD__(v280, v253)) + v255))
                                  + v256),
                 v248)
             | (unsigned __int8)__CFADD__(
                                  v288,
                                  (__CFADD__(
                                     __CFADD__(v26 | (unsigned __int8)__CFADD__(v280, v253), v255)
                                   | (unsigned __int8)__CFADD__(
                                                        v283,
                                                        (v26 | (unsigned __int8)__CFADD__(v280, v253)) + v255),
                                     v256)
                                 | (unsigned __int8)__CFADD__(
                                                      v286,
                                                      (__CFADD__(v26 | (unsigned __int8)__CFADD__(v280, v253), v255)
                                                     | (unsigned __int8)__CFADD__(
                                                                          v283,
                                                                          (v26 | (unsigned __int8)__CFADD__(v280, v253))
                                                                        + v255))
                                                    + v256))
                                + v248),
               v249)
           | (unsigned __int8)__CFADD__(
                                v292,
                                (__CFADD__(
                                   __CFADD__(
                                     __CFADD__(v26 | (unsigned __int8)__CFADD__(v280, v253), v255)
                                   | (unsigned __int8)__CFADD__(
                                                        v283,
                                                        (v26 | (unsigned __int8)__CFADD__(v280, v253)) + v255),
                                     v256)
                                 | (unsigned __int8)__CFADD__(
                                                      v286,
                                                      (__CFADD__(v26 | (unsigned __int8)__CFADD__(v280, v253), v255)
                                                     | (unsigned __int8)__CFADD__(
                                                                          v283,
                                                                          (v26 | (unsigned __int8)__CFADD__(v280, v253))
                                                                        + v255))
                                                    + v256),
                                   v248)
                               | (unsigned __int8)__CFADD__(
                                                    v288,
                                                    (__CFADD__(
                                                       __CFADD__(v26 | (unsigned __int8)__CFADD__(v280, v253), v255)
                                                     | (unsigned __int8)__CFADD__(
                                                                          v283,
                                                                          (v26 | (unsigned __int8)__CFADD__(v280, v253))
                                                                        + v255),
                                                       v256)
                                                   | (unsigned __int8)__CFADD__(
                                                                        v286,
                                                                        (__CFADD__(
                                                                           v26 | (unsigned __int8)__CFADD__(v280, v253),
                                                                           v255)
                                                                       | (unsigned __int8)__CFADD__(
                                                                                            v283,
                                                                                            (v26
                                                                                           | (unsigned __int8)__CFADD__(v280, v253))
                                                                                          + v255))
                                                                      + v256))
                                                  + v248))
                              + v249);
      v258 = __CFADD__(v257, v250) | (unsigned __int8)__CFADD__(v295, v257 + v250);
      sub_7FF91DCA74A0(
        -(__int64)(__CFADD__(v258, v251) | (unsigned __int8)__CFADD__(v299, v258 + v251)),
        v259,
        v277 + v252,
        v280 + v253);
      *((_QWORD *)&v10 + 1) = v260;
      *(_QWORD *)&v10 = v261;
      a2 = v85;
      v8 = v302 - 1;
    }
    while ( v302 != 1 );
  }
  else
  {
    do
    {
      v301 = v8;
      v11 = *((_QWORD *)&v10 + 1);
      v13 = v10;
      v14 = *((unsigned __int64 *)&v10 + 1);
      v12 = *((unsigned __int64 *)&v10 + 1) * (unsigned __int128)(unsigned __int64)v10;
      v15 = v11 * (unsigned __int128)(unsigned __int64)a2[2] + *((unsigned __int64 *)&v12 + 1);
      v16 = v11 * (unsigned __int128)(unsigned __int64)a2[3] + *((unsigned __int64 *)&v15 + 1);
      v17 = v11 * (unsigned __int128)(unsigned __int64)a2[4] + *((unsigned __int64 *)&v16 + 1);
      v18 = v11 * (unsigned __int128)(unsigned __int64)a2[5] + *((unsigned __int64 *)&v17 + 1);
      v19 = v11 * (unsigned __int128)(unsigned __int64)a2[6] + *((unsigned __int64 *)&v18 + 1);
      v20 = v11 * (unsigned __int128)(unsigned __int64)a2[7] + *((unsigned __int64 *)&v19 + 1);
      v263 = v11 * v11;
      v21 = (__PAIR128__(
               (unsigned __int64)v15 + __CFADD__((_QWORD)v12, (_QWORD)v12) + (_QWORD)v15,
               (v11 * (unsigned __int128)v11) >> 64)
           + (unsigned __int64)(2 * v12)) >> 64;
      v264 = ((v11 * (unsigned __int128)v11) >> 64) + 2 * v12;
      v22 = a2[1];
      v23 = v22 * a2[2] + v16;
      v24 = v22 * a2[4]
          + v18
          + ((v22 * (unsigned __int128)(unsigned __int64)a2[3]
            + (unsigned __int64)v17
            + ((v22 * (unsigned __int128)(unsigned __int64)a2[2] + (unsigned __int64)v16) >> 64)) >> 64);
      v25 = v22 * a2[7]
          + *((_QWORD *)&v20 + 1)
          + ((v22 * (unsigned __int128)(unsigned __int64)a2[6]
            + (unsigned __int64)v20
            + ((v22 * (unsigned __int128)(unsigned __int64)a2[5]
              + (unsigned __int64)v19
              + ((v22 * (unsigned __int128)(unsigned __int64)a2[4]
                + (unsigned __int64)v18
                + ((v22 * (unsigned __int128)(unsigned __int64)a2[3]
                  + (unsigned __int64)v17
                  + ((v22 * (unsigned __int128)(unsigned __int64)a2[2] + (unsigned __int64)v16) >> 64)) >> 64)) >> 64)) >> 64)) >> 64);
      v26 = __CFADD__(v23, v23);
      v27 = ((unsigned __int64)((__PAIR128__(a2[2], v13) * v14) >> 64) >> 63) + 2 * v23;
      v28 = v22 * a2[3] + v17 + ((v22 * (unsigned __int128)(unsigned __int64)a2[2] + (unsigned __int64)v16) >> 64);
      v29 = (__CFADD__(__CFADD__(v22 * v22, v21), v27)
           | (unsigned __int8)__CFADD__((v22 * (unsigned __int128)v22) >> 64, __CFADD__(v22 * v22, v21) + v27))
          + v28
          + v26
          + v28;
      v30 = a2[2];
      v31 = v30 * a2[4]
          + v22 * a2[5]
          + v19
          + ((v22 * (unsigned __int128)(unsigned __int64)a2[4]
            + (unsigned __int64)v18
            + ((v22 * (unsigned __int128)(unsigned __int64)a2[3]
              + (unsigned __int64)v17
              + ((v22 * (unsigned __int128)v30 + (unsigned __int64)v16) >> 64)) >> 64)) >> 64)
          + ((v30 * (unsigned __int128)(unsigned __int64)a2[3] + v24) >> 64);
      v33 = v30 * a2[5]
          + v22 * a2[6]
          + v20
          + ((v22 * (unsigned __int128)(unsigned __int64)a2[5]
            + (unsigned __int64)v19
            + ((v22 * (unsigned __int128)(unsigned __int64)a2[4]
              + (unsigned __int64)v18
              + ((v22 * (unsigned __int128)(unsigned __int64)a2[3]
                + (unsigned __int64)v17
                + ((v22 * (unsigned __int128)v30 + (unsigned __int64)v16) >> 64)) >> 64)) >> 64)) >> 64)
          + ((v30 * (unsigned __int128)(unsigned __int64)a2[4]
            + (unsigned __int64)(v22 * a2[5]
                               + v19
                               + ((v22 * (unsigned __int128)(unsigned __int64)a2[4]
                                 + (unsigned __int64)v18
                                 + ((v22 * (unsigned __int128)(unsigned __int64)a2[3]
                                   + (unsigned __int64)v17
                                   + ((v22 * (unsigned __int128)v30 + (unsigned __int64)v16) >> 64)) >> 64)) >> 64))
            + ((v30 * (unsigned __int128)(unsigned __int64)a2[3] + v24) >> 64)) >> 64);
      v32 = (v30 * (unsigned __int128)(unsigned __int64)a2[5]
           + (unsigned __int64)(v22 * a2[6]
                              + v20
                              + ((v22 * (unsigned __int128)(unsigned __int64)a2[5]
                                + (unsigned __int64)v19
                                + ((v22 * (unsigned __int128)(unsigned __int64)a2[4]
                                  + (unsigned __int64)v18
                                  + ((v22 * (unsigned __int128)(unsigned __int64)a2[3]
                                    + (unsigned __int64)v17
                                    + ((v22 * (unsigned __int128)v30 + (unsigned __int64)v16) >> 64)) >> 64)) >> 64)) >> 64))
           + ((v30 * (unsigned __int128)(unsigned __int64)a2[4]
             + (unsigned __int64)(v22 * a2[5]
                                + v19
                                + ((v22 * (unsigned __int128)(unsigned __int64)a2[4]
                                  + (unsigned __int64)v18
                                  + ((v22 * (unsigned __int128)(unsigned __int64)a2[3]
                                    + (unsigned __int64)v17
                                    + ((v22 * (unsigned __int128)v30 + (unsigned __int64)v16) >> 64)) >> 64)) >> 64))
             + ((v30 * (unsigned __int128)(unsigned __int64)a2[3] + v24) >> 64)) >> 64)) >> 64;
      v34 = v30 * a2[3] + v24;
      v35 = (v28 >> 63) + 2 * v34;
      v36 = v30 * a2[6] + v25 + v32;
      v37 = v30 * a2[7]
          + ((v22 * (unsigned __int128)(unsigned __int64)a2[7]
            + *((unsigned __int64 *)&v20 + 1)
            + ((v22 * (unsigned __int128)(unsigned __int64)a2[6]
              + (unsigned __int64)v20
              + ((v22 * (unsigned __int128)(unsigned __int64)a2[5]
                + (unsigned __int64)v19
                + ((v22 * (unsigned __int128)(unsigned __int64)a2[4]
                  + (unsigned __int64)v18
                  + ((v22 * (unsigned __int128)(unsigned __int64)a2[3]
                    + (unsigned __int64)v17
                    + ((v22 * (unsigned __int128)v30 + (unsigned __int64)v16) >> 64)) >> 64)) >> 64)) >> 64)) >> 64)) >> 64)
          + ((v30 * (unsigned __int128)(unsigned __int64)a2[6] + v25 + v32) >> 64);
      v38 = v30 * (unsigned __int128)v30;
      v26 = __CFADD__(__CFADD__((_QWORD)v38, v29), v35);
      v39 = __CFADD__((_QWORD)v38, v29) + v35;
      v40 = (v26 | (unsigned __int8)__CFADD__(*((_QWORD *)&v38 + 1), v39)) + (v34 >> 63) + 2 * v31;
      v266 = v38 + v29;
      v268 = *((_QWORD *)&v38 + 1) + v39;
      v41 = a2[3];
      v42 = v41 * a2[4] + v33;
      v43 = (v31 >> 63) + 2 * v42;
      v44 = v41 * (unsigned __int128)(unsigned __int64)a2[7]
          + ((v30 * (unsigned __int128)(unsigned __int64)a2[7]
            + ((v22 * (unsigned __int128)(unsigned __int64)a2[7]
              + *((unsigned __int64 *)&v20 + 1)
              + ((v22 * (unsigned __int128)(unsigned __int64)a2[6]
                + (unsigned __int64)v20
                + ((v22 * (unsigned __int128)(unsigned __int64)a2[5]
                  + (unsigned __int64)v19
                  + ((v22 * (unsigned __int128)(unsigned __int64)a2[4]
                    + (unsigned __int64)v18
                    + ((v22 * (unsigned __int128)v41
                      + (unsigned __int64)v17
                      + ((v22 * (unsigned __int128)v30 + (unsigned __int64)v16) >> 64)) >> 64)) >> 64)) >> 64)) >> 64)) >> 64)
            + ((v30 * (unsigned __int128)(unsigned __int64)a2[6] + v25 + v32) >> 64)) >> 64)
          + ((v41 * (unsigned __int128)(unsigned __int64)a2[6]
            + v37
            + ((v41 * (unsigned __int128)(unsigned __int64)a2[5]
              + v36
              + ((v41 * (unsigned __int128)(unsigned __int64)a2[4] + v33) >> 64)) >> 64)) >> 64);
      v45 = v41 * a2[5] + v36 + ((v41 * (unsigned __int128)(unsigned __int64)a2[4] + v33) >> 64);
      v46 = v41 * (unsigned __int128)v41;
      v26 = __CFADD__(__CFADD__((_QWORD)v46, v40), v43);
      v47 = __CFADD__((_QWORD)v46, v40) + v43;
      v48 = (v26 | (unsigned __int8)__CFADD__(*((_QWORD *)&v46 + 1), v47)) + (v42 >> 63) + 2 * v45;
      v270 = v46 + v40;
      v272 = *((_QWORD *)&v46 + 1) + v47;
      v49 = a2[4];
      v50 = v49 * a2[5]
          + v41 * a2[6]
          + v37
          + ((v41 * (unsigned __int128)(unsigned __int64)a2[5] + v36 + ((v41 * (unsigned __int128)v49 + v33) >> 64)) >> 64);
      v51 = (v45 >> 63) + 2 * v50;
      v52 = v49 * (unsigned __int128)(unsigned __int64)a2[7]
          + *((unsigned __int64 *)&v44 + 1)
          + ((v49 * (unsigned __int128)(unsigned __int64)a2[6]
            + (unsigned __int64)v44
            + ((v49 * (unsigned __int128)(unsigned __int64)a2[5]
              + (unsigned __int64)(v41 * a2[6]
                                 + v37
                                 + ((v41 * (unsigned __int128)(unsigned __int64)a2[5]
                                   + v36
                                   + ((v41 * (unsigned __int128)v49 + v33) >> 64)) >> 64))) >> 64)) >> 64);
      v53 = v49 * a2[6]
          + v44
          + ((v49 * (unsigned __int128)(unsigned __int64)a2[5]
            + (unsigned __int64)(v41 * a2[6]
                               + v37
                               + ((v41 * (unsigned __int128)(unsigned __int64)a2[5]
                                 + v36
                                 + ((v41 * (unsigned __int128)v49 + v33) >> 64)) >> 64))) >> 64);
      v54 = v49 * (unsigned __int128)v49;
      v26 = __CFADD__(__CFADD__((_QWORD)v54, v48), v51);
      v55 = __CFADD__((_QWORD)v54, v48) + v51;
      v56 = (v26 | (unsigned __int8)__CFADD__(*((_QWORD *)&v54 + 1), v55)) + (v50 >> 63) + 2 * v53;
      v274 = v49 * v49 + v48;
      v278 = DWORD2(v54) + v55;
      v53 >>= 63;
      v57 = a2[5];
      v58 = v57 * a2[6] + v52;
      v59 = v53 + 2 * v58;
      v60 = v57 * (unsigned __int128)(unsigned __int64)a2[7]
          + *((unsigned __int64 *)&v52 + 1)
          + ((v57 * (unsigned __int128)(unsigned __int64)a2[6] + (unsigned __int64)v52) >> 64);
      v61 = v57 * (unsigned __int128)v57;
      v26 = __CFADD__(__CFADD__((_QWORD)v61, v56), v59);
      v62 = __CFADD__((_QWORD)v61, v56) + v59;
      v63 = (v26 | (unsigned __int8)__CFADD__(*((_QWORD *)&v61 + 1), v62)) + (v58 >> 63) + 2 * v60;
      v281 = v57 * v57 + v56;
      v284 = DWORD2(v61) + v62;
      v65 = ((unsigned __int64)a2[6] * (unsigned __int128)(unsigned __int64)a2[7] + *((unsigned __int64 *)&v60 + 1)) >> 64;
      v64 = a2[6] * a2[7] + *((_QWORD *)&v60 + 1);
      v26 = __CFADD__(__CFSHL__(v60, 1), v64) | __CFADD__(v64, __CFSHL__(v60, 1) + v64);
      v66 = v64 + __CFSHL__(v60, 1) + v64;
      v67 = v26 + v65;
      LODWORD(v47) = __CFADD__(v26, v65) | __CFADD__(v65, v67);
      v68 = (unsigned __int64)a2[6] * (unsigned __int128)(unsigned __int64)a2[6];
      v26 = __CFADD__(__CFADD__((_QWORD)v68, v63), v66);
      v69 = __CFADD__((_QWORD)v68, v63) + v66;
      v289 = DWORD2(v68) + v69;
      v70 = a2[7] * a2[7] + (v26 | (unsigned __int8)__CFADD__(*((_QWORD *)&v68 + 1), v69)) + v65 + v67;
      DWORD2(v68) = ((unsigned __int64)a2[7] * (unsigned __int128)(unsigned __int64)a2[7]
                   + (unsigned __int64)(v26 | (unsigned __int8)__CFADD__(*((_QWORD *)&v68 + 1), v69))
                   + v65
                   + v67) >> 64;
      v296 = DWORD2(v68) + v47;
      v71 = v266;
      v72 = v268;
      v73 = v270;
      v74 = v272;
      sub_7FF91DCA72C0(
        v53,
        DWORD2(v68),
        v263,
        v264,
        v266,
        v268,
        v270,
        v272,
        v274,
        v278,
        v281,
        v284,
        v68 + v63,
        v289,
        v70,
        v296,
        v300);
      v26 = __CFADD__(__CFADD__(v275, v75), v76);
      v77 = __CFADD__(v275, v75) + v76;
      v80 = __CFADD__(
              __CFADD__(
                __CFADD__(
                  __CFADD__(v26 | (unsigned __int8)__CFADD__(v279, v76), v78)
                | (unsigned __int8)__CFADD__(v282, (v26 | (unsigned __int8)__CFADD__(v279, v76)) + v78),
                  v79)
              | (unsigned __int8)__CFADD__(
                                   v285,
                                   (__CFADD__(v26 | (unsigned __int8)__CFADD__(v279, v76), v78)
                                  | (unsigned __int8)__CFADD__(
                                                       v282,
                                                       (v26 | (unsigned __int8)__CFADD__(v279, v76)) + v78))
                                 + v79),
                v71)
            | (unsigned __int8)__CFADD__(
                                 v287,
                                 (__CFADD__(
                                    __CFADD__(v26 | (unsigned __int8)__CFADD__(v279, v76), v78)
                                  | (unsigned __int8)__CFADD__(
                                                       v282,
                                                       (v26 | (unsigned __int8)__CFADD__(v279, v76)) + v78),
                                    v79)
                                | (unsigned __int8)__CFADD__(
                                                     v285,
                                                     (__CFADD__(v26 | (unsigned __int8)__CFADD__(v279, v76), v78)
                                                    | (unsigned __int8)__CFADD__(
                                                                         v282,
                                                                         (v26 | (unsigned __int8)__CFADD__(v279, v76))
                                                                       + v78))
                                                   + v79))
                               + v71),
              v72)
          | (unsigned __int8)__CFADD__(
                               v290,
                               (__CFADD__(
                                  __CFADD__(
                                    __CFADD__(v26 | (unsigned __int8)__CFADD__(v279, v76), v78)
                                  | (unsigned __int8)__CFADD__(
                                                       v282,
                                                       (v26 | (unsigned __int8)__CFADD__(v279, v76)) + v78),
                                    v79)
                                | (unsigned __int8)__CFADD__(
                                                     v285,
                                                     (__CFADD__(v26 | (unsigned __int8)__CFADD__(v279, v76), v78)
                                                    | (unsigned __int8)__CFADD__(
                                                                         v282,
                                                                         (v26 | (unsigned __int8)__CFADD__(v279, v76))
                                                                       + v78))
                                                   + v79),
                                  v71)
                              | (unsigned __int8)__CFADD__(
                                                   v287,
                                                   (__CFADD__(
                                                      __CFADD__(v26 | (unsigned __int8)__CFADD__(v279, v76), v78)
                                                    | (unsigned __int8)__CFADD__(
                                                                         v282,
                                                                         (v26 | (unsigned __int8)__CFADD__(v279, v76))
                                                                       + v78),
                                                      v79)
                                                  | (unsigned __int8)__CFADD__(
                                                                       v285,
                                                                       (__CFADD__(
                                                                          v26 | (unsigned __int8)__CFADD__(v279, v76),
                                                                          v78)
                                                                      | (unsigned __int8)__CFADD__(
                                                                                           v282,
                                                                                           (v26
                                                                                          | (unsigned __int8)__CFADD__(v279, v76))
                                                                                         + v78))
                                                                     + v79))
                                                 + v71))
                             + v72);
      v81 = __CFADD__(v80, v73) | (unsigned __int8)__CFADD__(v293, v80 + v73);
      sub_7FF91DCA74A0(
        -(__int64)(__CFADD__(v81, v74) | (unsigned __int8)__CFADD__(v297, v81 + v74)),
        v82,
        v275 + v75,
        v279 + v76);
      *((_QWORD *)&v10 + 1) = v83;
      *(_QWORD *)&v10 = v84;
      a2 = a1;
      v8 = v301 - 1;
    }
    while ( v301 != 1 );
  }
  return &retaddr;
}


// ==== sub_7FF91DCA67A0 @ rva 0x467A0 ====
__int64 __fastcall sub_7FF91DCA67A0(int a1, int a2, int a3, int a4, __int64 a5)
{
  return sub_7FF91DCA67AD(a1, a2, a3, a4, a5);
}


// ==== sub_7FF91DCA67AD @ rva 0x467AD ====
_UNKNOWN **__fastcall sub_7FF91DCA67AD(__int64 a1, __int64 a2, _QWORD *a3, __int64 a4, __int64 a5)
{
  __int64 v5; // r12
  __int64 v6; // r13
  __int64 v7; // r14
  __int64 v8; // r15
  int v9; // edx
  int v10; // ecx
  __int64 v11; // rdx
  __int64 v12; // r8
  __int64 v13; // r9
  __int64 v14; // r10
  __int64 v15; // r11
  int v16; // ecx
  bool v17; // cf
  __int64 v18; // r9
  __int64 v19; // rtt
  __int64 v20; // rtt
  int v22; // [rsp+0h] [rbp-C8h]
  int v23; // [rsp+0h] [rbp-C8h]
  int v24; // [rsp+8h] [rbp-C0h]
  int v25; // [rsp+8h] [rbp-C0h]
  __int64 v26; // [rsp+20h] [rbp-A8h]
  __int64 v27; // [rsp+28h] [rbp-A0h]
  __int64 v28; // [rsp+30h] [rbp-98h]
  __int64 v29; // [rsp+38h] [rbp-90h]
  __int64 v30; // [rsp+40h] [rbp-88h]
  __int64 v31; // [rsp+48h] [rbp-80h]
  __int64 v32; // [rsp+50h] [rbp-78h]
  __int64 v33; // [rsp+58h] [rbp-70h]
  __int64 v34; // [rsp+60h] [rbp-68h]
  __int64 v35; // [rsp+68h] [rbp-60h]
  __int64 v36; // [rsp+70h] [rbp-58h]
  __int64 v37; // [rsp+78h] [rbp-50h]
  _UNKNOWN *retaddr; // [rsp+C8h] [rbp+0h] BYREF

  if ( (dword_7FF91E91A5F8 & 0x80100) == 0x80100 )
  {
    sub_7FF91DCA7700(a4, *a3, a5, a4);
    v5 = v26;
    v6 = v27;
    v7 = v28;
    v8 = v29;
    sub_7FF91DCA73C0(v16, a5, v23, v25);
  }
  else
  {
    sub_7FF91DCA7560(a4, a3, a5);
    v5 = v26;
    v6 = v27;
    v7 = v28;
    v8 = v29;
    sub_7FF91DCA72C0(v10, v9, v22, v24);
  }
  v17 = __CFADD__(__CFADD__(v30, v12), v13);
  v18 = __CFADD__(v30, v12) + v13;
  v19 = __CFADD__(
          __CFADD__(
            __CFADD__(
              __CFADD__(v17 | (unsigned __int8)__CFADD__(v31, v18), v14)
            | (unsigned __int8)__CFADD__(v32, (v17 | (unsigned __int8)__CFADD__(v31, v18)) + v14),
              v15)
          | (unsigned __int8)__CFADD__(
                               v33,
                               (__CFADD__(v17 | (unsigned __int8)__CFADD__(v31, v18), v14)
                              | (unsigned __int8)__CFADD__(v32, (v17 | (unsigned __int8)__CFADD__(v31, v18)) + v14))
                             + v15),
            v5)
        | (unsigned __int8)__CFADD__(
                             v34,
                             (__CFADD__(
                                __CFADD__(v17 | (unsigned __int8)__CFADD__(v31, v18), v14)
                              | (unsigned __int8)__CFADD__(v32, (v17 | (unsigned __int8)__CFADD__(v31, v18)) + v14),
                                v15)
                            | (unsigned __int8)__CFADD__(
                                                 v33,
                                                 (__CFADD__(v17 | (unsigned __int8)__CFADD__(v31, v18), v14)
                                                | (unsigned __int8)__CFADD__(
                                                                     v32,
                                                                     (v17 | (unsigned __int8)__CFADD__(v31, v18)) + v14))
                                               + v15))
                           + v5),
          v6)
      | (unsigned __int8)__CFADD__(
                           v35,
                           (__CFADD__(
                              __CFADD__(
                                __CFADD__(v17 | (unsigned __int8)__CFADD__(v31, v18), v14)
                              | (unsigned __int8)__CFADD__(v32, (v17 | (unsigned __int8)__CFADD__(v31, v18)) + v14),
                                v15)
                            | (unsigned __int8)__CFADD__(
                                                 v33,
                                                 (__CFADD__(v17 | (unsigned __int8)__CFADD__(v31, v18), v14)
                                                | (unsigned __int8)__CFADD__(
                                                                     v32,
                                                                     (v17 | (unsigned __int8)__CFADD__(v31, v18)) + v14))
                                               + v15),
                              v5)
                          | (unsigned __int8)__CFADD__(
                                               v34,
                                               (__CFADD__(
                                                  __CFADD__(v17 | (unsigned __int8)__CFADD__(v31, v18), v14)
                                                | (unsigned __int8)__CFADD__(
                                                                     v32,
                                                                     (v17 | (unsigned __int8)__CFADD__(v31, v18)) + v14),
                                                  v15)
                                              | (unsigned __int8)__CFADD__(
                                                                   v33,
                                                                   (__CFADD__(
                                                                      v17 | (unsigned __int8)__CFADD__(v31, v18),
                                                                      v14)
                                                                  | (unsigned __int8)__CFADD__(
                                                                                       v32,
                                                                                       (v17
                                                                                      | (unsigned __int8)__CFADD__(v31, v18))
                                                                                     + v14))
                                                                 + v15))
                                             + v5))
                         + v6);
  v20 = __CFADD__(v19, v7) | (unsigned __int8)__CFADD__(v36, v19 + v7);
  sub_7FF91DCA74A0(
    -(__int64)(__CFADD__(v20, v8) | (unsigned __int8)__CFADD__(v37, v20 + v8)),
    v11,
    v30 + v12,
    v31 + v18);
  return &retaddr;
}


// ==== sub_7FF91DCA6900 @ rva 0x46900 ====
__int64 __fastcall sub_7FF91DCA6900(int a1, int a2, int a3, int a4, __int64 a5, __int64 a6)
{
  return sub_7FF91DCA690D(a1, a2, a3, a4, a5, a6);
}


// ==== sub_7FF91DCA690D @ rva 0x4690D ====
_UNKNOWN **__fastcall sub_7FF91DCA690D(
        __int64 a1,
        unsigned __int64 *a2,
        const __m128i *a3,
        __int64 a4,
        __int64 a5,
        __int64 a6)
{
  __m128i si128; // xmm0
  __m128i v8; // xmm8
  __m128i v9; // xmm7
  __m128i v10; // xmm1
  __m128i v11; // xmm0
  __m128i v12; // xmm2
  __m128i v13; // xmm1
  __m128i v14; // xmm3
  __m128i v15; // xmm2
  __m128i v16; // xmm4
  __m128i v17; // xmm3
  __m128i v18; // xmm5
  __m128i v19; // xmm4
  __m128i v20; // xmm6
  __m128i v21; // xmm5
  __m128i v22; // xmm7
  __m128i v23; // xmm6
  __m128i v24; // xmm7
  const __m128i *v25; // rbp
  __m128i v26; // xmm8
  unsigned __int64 v27; // xmm8_8
  unsigned __int64 v28; // rax
  _QWORD *v29; // rdi
  int v30; // ecx
  unsigned __int128 v31; // kr120_16
  unsigned __int128 v32; // kr140_16
  unsigned __int128 v33; // kr160_16
  unsigned __int128 v34; // kr180_16
  unsigned __int128 v35; // kr1A0_16
  unsigned __int128 v36; // kr1C0_16
  unsigned __int128 v37; // kr1E0_16
  __m128i v38; // xmm8
  __m128i v39; // xmm12
  __m128i v40; // xmm9
  __m128i v41; // xmm13
  __m128i v42; // xmm10
  __m128i v43; // xmm14
  __m128i v44; // xmm11
  __m128i v45; // xmm15
  __m128i v46; // xmm8
  unsigned __int64 v47; // rbx
  unsigned __int128 v48; // rax
  bool v49; // cf
  __int64 v50; // r8
  __int64 v51; // rdx
  __int64 v52; // r12
  __int64 v53; // r13
  __int64 v54; // r14
  __int64 v55; // r15
  __m128i v81; // xmm8
  __m128i v82; // xmm12
  __m128i v83; // xmm9
  __m128i v84; // xmm13
  __m128i v85; // xmm10
  __m128i v86; // xmm14
  __m128i v87; // xmm11
  __m128i v88; // xmm15
  __m128i v89; // xmm8
  __int64 v116; // r8
  __int64 v117; // r9
  __int64 v118; // r9
  __int64 v119; // r10
  __int64 v120; // r11
  __int64 v121; // rtt
  __int64 v122; // rtt
  __int64 v123; // rdx
  unsigned __int64 v125; // [rsp+0h] [rbp-178h]
  _QWORD v126[7]; // [rsp+8h] [rbp-170h] BYREF
  __int64 v127; // [rsp+40h] [rbp-138h]
  __int64 v128; // [rsp+48h] [rbp-130h]
  __int64 v129; // [rsp+50h] [rbp-128h]
  __int64 v130; // [rsp+58h] [rbp-120h]
  __int64 v131; // [rsp+60h] [rbp-118h]
  __int64 v132; // [rsp+68h] [rbp-110h]
  __int64 v133; // [rsp+70h] [rbp-108h]
  __int64 v134; // [rsp+78h] [rbp-100h]
  __int64 v135; // [rsp+80h] [rbp-F8h]
  __int64 v136; // [rsp+88h] [rbp-F0h]
  __int64 v137; // [rsp+90h] [rbp-E8h]
  _UNKNOWN *retaddr; // [rsp+178h] [rbp+0h] BYREF

  si128 = _mm_load_si128((const __m128i *)&xmmword_7FF91DCA7B00);
  v8 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a6), 0);
  v9 = _mm_load_si128((const __m128i *)&xmmword_7FF91DCA7B10);
  v10 = _mm_add_epi32(v9, si128);
  v11 = _mm_cmpeq_epi32(si128, v8);
  v12 = _mm_add_epi32(v9, v10);
  v13 = _mm_cmpeq_epi32(v10, v8);
  v14 = _mm_add_epi32(v9, v12);
  v15 = _mm_cmpeq_epi32(v12, v8);
  v16 = _mm_add_epi32(v9, v14);
  v17 = _mm_cmpeq_epi32(v14, v8);
  v18 = _mm_add_epi32(v9, v16);
  v19 = _mm_cmpeq_epi32(v16, v8);
  v20 = _mm_add_epi32(v9, v18);
  v21 = _mm_cmpeq_epi32(v18, v8);
  v22 = _mm_add_epi32(v9, v20);
  v23 = _mm_cmpeq_epi32(v20, v8);
  v24 = _mm_cmpeq_epi32(v22, v8);
  v25 = a3 + 8;
  v26 = _mm_or_si128(
          _mm_or_si128(
            _mm_or_si128(
              _mm_or_si128(_mm_and_si128(_mm_load_si128(a3), v11), _mm_and_si128(_mm_load_si128(a3 + 2), v15)),
              _mm_and_si128(_mm_load_si128(a3 + 4), v19)),
            _mm_and_si128(_mm_load_si128(a3 + 6), v23)),
          _mm_or_si128(
            _mm_or_si128(
              _mm_or_si128(_mm_and_si128(_mm_load_si128(a3 + 1), v13), _mm_and_si128(_mm_load_si128(a3 + 3), v17)),
              _mm_and_si128(_mm_load_si128(a3 + 5), v21)),
            _mm_and_si128(_mm_load_si128(a3 + 7), v24)));
  v27 = _mm_or_si128(v26, _mm_shuffle_epi32(v26, 78)).m128i_u64[0];
  if ( (dword_7FF91E91A5F8 & 0x80100) == 0x80100 )
  {
    v135 = a5;
    v136 = a1;
    v137 = a4;
    _R8 = (v27 * (unsigned __int128)*a2) >> 64;
    _RDI = 0;
    _R9 = (v27 * (unsigned __int128)a2[1]) >> 64;
    _RAX = v27 * a2[1];
    _R10 = (v27 * (unsigned __int128)a2[2]) >> 64;
    _RBX = v27 * a2[2];
    __asm { adcx    r8, rax }
    _R11 = (v27 * (unsigned __int128)a2[3]) >> 64;
    _RAX = v27 * a2[3];
    __asm { adcx    r9, rbx }
    _R12 = (v27 * (unsigned __int128)a2[4]) >> 64;
    _RBX = v27 * a2[4];
    __asm { adcx    r10, rax }
    _R13 = (v27 * (unsigned __int128)a2[5]) >> 64;
    _RAX = v27 * a2[5];
    __asm { adcx    r11, rbx }
    _R14 = (v27 * (unsigned __int128)a2[6]) >> 64;
    _RBX = v27 * a2[6];
    __asm { adcx    r12, rax }
    _R15 = (v27 * (unsigned __int128)a2[7]) >> 64;
    _RAX = v27 * a2[7];
    __asm
    {
      adcx    r13, rbx
      adcx    r14, rax
    }
    _RBX = _R8;
    __asm { adcx    r15, rdi }
    while ( 1 )
    {
      v81 = _mm_and_si128(_mm_load_si128(v25), v11);
      v82 = _mm_load_si128(v25 + 4);
      v83 = _mm_and_si128(_mm_load_si128(v25 + 1), v13);
      v84 = _mm_load_si128(v25 + 5);
      v85 = _mm_and_si128(_mm_load_si128(v25 + 2), v15);
      v86 = _mm_load_si128(v25 + 6);
      v87 = _mm_and_si128(_mm_load_si128(v25 + 3), v17);
      v88 = _mm_load_si128(v25 + 7);
      v25 += 8;
      v89 = _mm_or_si128(
              _mm_or_si128(_mm_or_si128(_mm_or_si128(v81, v85), _mm_and_si128(v82, v19)), _mm_and_si128(v86, v23)),
              _mm_or_si128(_mm_or_si128(_mm_or_si128(v83, v87), _mm_and_si128(v84, v21)), _mm_and_si128(v88, v24)));
      v89.m128i_i64[0] = _mm_or_si128(v89, _mm_shuffle_epi32(v89, 78)).m128i_u64[0];
      _R8 = (v89.m128i_u64[0] * (unsigned __int128)*a2) >> 64;
      _RAX = v89.m128i_i64[0] * *a2;
      __asm
      {
        adcx    rbx, rax
        adox    r8, r9
      }
      _R9 = (v89.m128i_u64[0] * (unsigned __int128)a2[1]) >> 64;
      _RAX = v89.m128i_i64[0] * a2[1];
      __asm
      {
        adcx    r8, rax
        adox    r9, r10
      }
      _R10 = (v89.m128i_u64[0] * (unsigned __int128)a2[2]) >> 64;
      _RAX = v89.m128i_i64[0] * a2[2];
      __asm
      {
        adcx    r9, rax
        adox    r10, r11
      }
      _R11 = (v89.m128i_u64[0] * (unsigned __int128)a2[3]) >> 64;
      _RAX = v89.m128i_i64[0] * a2[3];
      __asm
      {
        adcx    r10, rax
        adox    r11, r12
      }
      _R12 = (v89.m128i_u64[0] * (unsigned __int128)a2[4]) >> 64;
      _RAX = v89.m128i_i64[0] * a2[4];
      __asm
      {
        adcx    r11, rax
        adox    r12, r13
      }
      _R13 = (v89.m128i_u64[0] * (unsigned __int128)a2[5]) >> 64;
      _RAX = v89.m128i_i64[0] * a2[5];
      __asm
      {
        adcx    r12, rax
        adox    r13, r14
      }
      _R14 = (v89.m128i_u64[0] * (unsigned __int128)a2[6]) >> 64;
      _RAX = v89.m128i_i64[0] * a2[6];
      __asm
      {
        adcx    r13, rax
        adox    r14, r15
      }
      _R15 = (v89.m128i_u64[0] * (unsigned __int128)a2[7]) >> 64;
      _RAX = v89.m128i_i64[0] * a2[7];
      v127 = _RBX;
      __asm
      {
        adcx    r14, rax
        adox    r15, rdi
      }
      _RBX = _R8;
      __asm { adcx    r15, rdi }
    }
  }
  v135 = a5;
  v136 = a1;
  v137 = a4;
  v125 = v27 * *a2;
  v28 = *a2;
  v29 = v126;
  v30 = 7;
  *(_QWORD *)&v31 = (*(_OWORD *)a2 * v27) >> 64;
  *(_QWORD *)&v32 = v27 * a2[2] + ((v27 * (unsigned __int128)a2[1] + ((v27 * (unsigned __int128)*a2) >> 64)) >> 64);
  *(_QWORD *)&v33 = v27 * a2[3]
                  + ((v27 * (unsigned __int128)a2[2]
                    + ((v27 * (unsigned __int128)a2[1] + ((v27 * (unsigned __int128)*a2) >> 64)) >> 64)) >> 64);
  *(_QWORD *)&v34 = v27 * a2[4]
                  + ((v27 * (unsigned __int128)a2[3]
                    + ((v27 * (unsigned __int128)a2[2]
                      + ((v27 * (unsigned __int128)a2[1] + ((v27 * (unsigned __int128)*a2) >> 64)) >> 64)) >> 64)) >> 64);
  *(_QWORD *)&v35 = v27 * a2[5]
                  + ((v27 * (unsigned __int128)a2[4]
                    + ((v27 * (unsigned __int128)a2[3]
                      + ((v27 * (unsigned __int128)a2[2]
                        + ((v27 * (unsigned __int128)a2[1] + ((v27 * (unsigned __int128)*a2) >> 64)) >> 64)) >> 64)) >> 64)) >> 64);
  *(_QWORD *)&v36 = v27 * a2[6]
                  + ((v27 * (unsigned __int128)a2[5]
                    + ((v27 * (unsigned __int128)a2[4]
                      + ((v27 * (unsigned __int128)a2[3]
                        + ((v27 * (unsigned __int128)a2[2]
                          + ((v27 * (unsigned __int128)a2[1] + ((v27 * (unsigned __int128)*a2) >> 64)) >> 64)) >> 64)) >> 64)) >> 64)) >> 64);
  v37 = v27 * (unsigned __int128)a2[7]
      + ((v27 * (unsigned __int128)a2[6]
        + ((v27 * (unsigned __int128)a2[5]
          + ((v27 * (unsigned __int128)a2[4]
            + ((v27 * (unsigned __int128)a2[3]
              + ((v27 * (unsigned __int128)a2[2]
                + ((v27 * (unsigned __int128)a2[1] + ((v27 * (unsigned __int128)*a2) >> 64)) >> 64)) >> 64)) >> 64)) >> 64)) >> 64)) >> 64);
  do
  {
    v38 = _mm_and_si128(_mm_load_si128(v25), v11);
    v39 = _mm_load_si128(v25 + 4);
    v40 = _mm_and_si128(_mm_load_si128(v25 + 1), v13);
    v41 = _mm_load_si128(v25 + 5);
    v42 = _mm_and_si128(_mm_load_si128(v25 + 2), v15);
    v43 = _mm_load_si128(v25 + 6);
    v44 = _mm_and_si128(_mm_load_si128(v25 + 3), v17);
    v45 = _mm_load_si128(v25 + 7);
    v25 += 8;
    v46 = _mm_or_si128(
            _mm_or_si128(_mm_or_si128(_mm_or_si128(v38, v42), _mm_and_si128(v39, v19)), _mm_and_si128(v43, v23)),
            _mm_or_si128(_mm_or_si128(_mm_or_si128(v40, v44), _mm_and_si128(v41, v21)), _mm_and_si128(v45, v24)));
    v47 = _mm_or_si128(v46, _mm_shuffle_epi32(v46, 78)).m128i_u64[0];
    v48 = v47 * (unsigned __int128)v28;
    v49 = __CFADD__((_QWORD)v48, (_QWORD)v31);
    v50 = v48 + v31;
    *(_QWORD *)&v48 = a2[1];
    *v29 = v50;
    v31 = v47 * (unsigned __int128)(unsigned __int64)v48
        + (unsigned __int64)v32
        + (unsigned __int64)v49
        + *((_QWORD *)&v48 + 1);
    v32 = v47 * (unsigned __int128)a2[2] + (unsigned __int64)v33 + *((unsigned __int64 *)&v31 + 1);
    v33 = v47 * (unsigned __int128)a2[3] + (unsigned __int64)v34 + *((unsigned __int64 *)&v32 + 1);
    v34 = v47 * (unsigned __int128)a2[4] + (unsigned __int64)v35 + *((unsigned __int64 *)&v33 + 1);
    v35 = v47 * (unsigned __int128)a2[5] + (unsigned __int64)v36 + *((unsigned __int64 *)&v34 + 1);
    v36 = v47 * (unsigned __int128)a2[6] + (unsigned __int64)v37 + *((unsigned __int64 *)&v35 + 1);
    v28 = *a2;
    v51 = (v47 * (unsigned __int128)a2[7] + *((unsigned __int64 *)&v37 + 1)) >> 64;
    v37 = v47 * (unsigned __int128)a2[7] + *((unsigned __int64 *)&v37 + 1) + *((unsigned __int64 *)&v36 + 1);
    ++v29;
    --v30;
  }
  while ( v30 );
  *v29 = v31;
  v29[1] = v32;
  v29[2] = v33;
  v29[3] = v34;
  v29[4] = v35;
  v29[5] = v36;
  *((_OWORD *)v29 + 3) = v37;
  v52 = v126[3];
  v53 = v126[4];
  v54 = v126[5];
  v55 = v126[6];
  sub_7FF91DCA72C0(0, v51, v125, v126[0]);
  v49 = __CFADD__(__CFADD__(v127, v116), v117);
  v118 = __CFADD__(v127, v116) + v117;
  v121 = __CFADD__(
           __CFADD__(
             __CFADD__(
               __CFADD__(v49 | (unsigned __int8)__CFADD__(v128, v117), v119)
             | (unsigned __int8)__CFADD__(v129, (v49 | (unsigned __int8)__CFADD__(v128, v117)) + v119),
               v120)
           | (unsigned __int8)__CFADD__(
                                v130,
                                (__CFADD__(v49 | (unsigned __int8)__CFADD__(v128, v117), v119)
                               | (unsigned __int8)__CFADD__(v129, (v49 | (unsigned __int8)__CFADD__(v128, v117)) + v119))
                              + v120),
             v52)
         | (unsigned __int8)__CFADD__(
                              v131,
                              (__CFADD__(
                                 __CFADD__(v49 | (unsigned __int8)__CFADD__(v128, v117), v119)
                               | (unsigned __int8)__CFADD__(v129, (v49 | (unsigned __int8)__CFADD__(v128, v117)) + v119),
                                 v120)
                             | (unsigned __int8)__CFADD__(
                                                  v130,
                                                  (__CFADD__(v49 | (unsigned __int8)__CFADD__(v128, v117), v119)
                                                 | (unsigned __int8)__CFADD__(
                                                                      v129,
                                                                      (v49 | (unsigned __int8)__CFADD__(v128, v117))
                                                                    + v119))
                                                + v120))
                            + v52),
           v53)
       | (unsigned __int8)__CFADD__(
                            v132,
                            (__CFADD__(
                               __CFADD__(
                                 __CFADD__(v49 | (unsigned __int8)__CFADD__(v128, v117), v119)
                               | (unsigned __int8)__CFADD__(v129, (v49 | (unsigned __int8)__CFADD__(v128, v117)) + v119),
                                 v120)
                             | (unsigned __int8)__CFADD__(
                                                  v130,
                                                  (__CFADD__(v49 | (unsigned __int8)__CFADD__(v128, v117), v119)
                                                 | (unsigned __int8)__CFADD__(
                                                                      v129,
                                                                      (v49 | (unsigned __int8)__CFADD__(v128, v117))
                                                                    + v119))
                                                + v120),
                               v52)
                           | (unsigned __int8)__CFADD__(
                                                v131,
                                                (__CFADD__(
                                                   __CFADD__(v49 | (unsigned __int8)__CFADD__(v128, v117), v119)
                                                 | (unsigned __int8)__CFADD__(
                                                                      v129,
                                                                      (v49 | (unsigned __int8)__CFADD__(v128, v117))
                                                                    + v119),
                                                   v120)
                                               | (unsigned __int8)__CFADD__(
                                                                    v130,
                                                                    (__CFADD__(
                                                                       v49 | (unsigned __int8)__CFADD__(v128, v117),
                                                                       v119)
                                                                   | (unsigned __int8)__CFADD__(
                                                                                        v129,
                                                                                        (v49
                                                                                       | (unsigned __int8)__CFADD__(v128, v117))
                                                                                      + v119))
                                                                  + v120))
                                              + v52))
                          + v53);
  v122 = __CFADD__(v121, v54) | (unsigned __int8)__CFADD__(v133, v121 + v54);
  sub_7FF91DCA74A0(
    -(__int64)(__CFADD__(v122, v55) | (unsigned __int8)__CFADD__(v134, v122 + v55)),
    v123,
    v127 + v116,
    v128 + v117);
  return &retaddr;
}


// ==== sub_7FF91DCA7020 @ rva 0x47020 ====
__int64 __fastcall sub_7FF91DCA7020(int a1, int a2, int a3, int a4, __int64 a5, __int64 a6)
{
  return sub_7FF91DCA702D(a1, a2, a3, a4, a5, a6);
}


// ==== sub_7FF91DCA702D @ rva 0x4702D ====
_UNKNOWN **__fastcall sub_7FF91DCA702D(_QWORD *a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5, __int64 a6)
{
  _QWORD *v7; // r8
  _QWORD *v8; // xmm2_8
  __int64 v9; // r12
  __int64 v10; // r13
  __int64 v11; // r14
  __int64 v12; // r15
  int v13; // edx
  int v14; // ecx
  __int64 v15; // rdx
  __int64 v16; // r8
  __int64 v17; // r9
  __int64 v18; // r10
  __int64 v19; // r11
  int v20; // ecx
  bool v21; // cf
  __int64 v22; // r9
  __int64 v23; // r12
  __int64 v24; // rtt
  __int64 v25; // r13
  __int64 v26; // rtt
  __int64 v27; // r14
  __int64 v28; // rtt
  __int64 v29; // r15
  __int64 v30; // rtt
  __int64 v31; // r8
  __int64 v32; // r9
  __int64 v33; // r10
  __int64 v34; // r11
  int v36; // [rsp+0h] [rbp-C8h]
  int v37; // [rsp+0h] [rbp-C8h]
  int v38; // [rsp+8h] [rbp-C0h]
  int v39; // [rsp+8h] [rbp-C0h]
  __int64 v40; // [rsp+20h] [rbp-A8h]
  __int64 v41; // [rsp+28h] [rbp-A0h]
  __int64 v42; // [rsp+30h] [rbp-98h]
  __int64 v43; // [rsp+38h] [rbp-90h]
  __int64 v44; // [rsp+40h] [rbp-88h]
  __int64 v45; // [rsp+48h] [rbp-80h]
  __int64 v46; // [rsp+50h] [rbp-78h]
  __int64 v47; // [rsp+58h] [rbp-70h]
  __int64 v48; // [rsp+60h] [rbp-68h]
  __int64 v49; // [rsp+68h] [rbp-60h]
  __int64 v50; // [rsp+70h] [rbp-58h]
  __int64 v51; // [rsp+78h] [rbp-50h]
  int v52; // [rsp+80h] [rbp-48h]
  _UNKNOWN *retaddr; // [rsp+C8h] [rbp+0h] BYREF

  v7 = (_QWORD *)(a5 + 8LL * (unsigned int)a6);
  v8 = v7;
  v52 = a4;
  if ( (dword_7FF91E91A5F8 & 0x80100) == 0x80100 )
  {
    sub_7FF91DCA7700(a4, *a1, (_DWORD)v7, a6);
    v9 = v40;
    v10 = v41;
    v11 = v42;
    v12 = v43;
    sub_7FF91DCA73C0(v20, v52, v37, v39);
  }
  else
  {
    sub_7FF91DCA7560(a4, a3, v7);
    v9 = v40;
    v10 = v41;
    v11 = v42;
    v12 = v43;
    sub_7FF91DCA72C0(v14, v13, v36, v38);
  }
  v21 = __CFADD__(__CFADD__(v44, v16), v17);
  v22 = __CFADD__(v44, v16) + v17;
  v24 = __CFADD__(
          __CFADD__(v21 | (unsigned __int8)__CFADD__(v45, v22), v18)
        | (unsigned __int8)__CFADD__(v46, (v21 | (unsigned __int8)__CFADD__(v45, v22)) + v18),
          v19)
      | (unsigned __int8)__CFADD__(
                           v47,
                           (__CFADD__(v21 | (unsigned __int8)__CFADD__(v45, v22), v18)
                          | (unsigned __int8)__CFADD__(v46, (v21 | (unsigned __int8)__CFADD__(v45, v22)) + v18))
                         + v19);
  v21 = __CFADD__(v24, v9);
  v23 = v24 + v9;
  v26 = v21 | (unsigned __int8)__CFADD__(v48, v23);
  v21 = __CFADD__(v26, v10);
  v25 = v26 + v10;
  v28 = v21 | (unsigned __int8)__CFADD__(v49, v25);
  v21 = __CFADD__(v28, v11);
  v27 = v28 + v11;
  v30 = v21 | (unsigned __int8)__CFADD__(v50, v27);
  v21 = __CFADD__(v30, v12);
  v29 = v30 + v12;
  sub_7FF91DCA74A0(-(__int64)(v21 | (unsigned __int8)__CFADD__(v51, v29)), v15, v44 + v16, v45 + v22);
  *v8 = v31;
  v8[16] = v32;
  v8[32] = v33;
  v8[48] = v34;
  v8[64] = v48 + v23;
  v8[80] = v49 + v25;
  v8[96] = v50 + v27;
  v8[112] = v51 + v29;
  return &retaddr;
}


// ==== sub_7FF91DCA71C0 @ rva 0x471C0 ====
__int64 sub_7FF91DCA71C0()
{
  return sub_7FF91DCA71CD();
}


// ==== sub_7FF91DCA71CD @ rva 0x471CD ====
_UNKNOWN **__fastcall sub_7FF91DCA71CD(_QWORD *a1, __int64 *a2, int a3, int a4)
{
  __int64 v8; // r8
  __int64 v9; // r9
  __int64 v10; // r12
  __int64 v11; // r13
  __int64 v12; // r14
  __int64 v13; // r15
  __int64 v14; // r8
  __int64 v15; // r9
  __int64 v16; // r10
  __int64 v17; // r11
  _UNKNOWN *retaddr; // [rsp+C8h] [rbp+0h] BYREF

  v8 = *a2;
  v9 = a2[1];
  v10 = a2[4];
  v11 = a2[5];
  v12 = a2[6];
  v13 = a2[7];
  if ( (dword_7FF91E91A5F8 & 0x80100) == 0x80100 )
    sub_7FF91DCA73C0(a4, a4, v8, v9);
  else
    sub_7FF91DCA72C0(a4, a3, v8, v9);
  *a1 = v14;
  a1[1] = v15;
  a1[2] = v16;
  a1[3] = v17;
  a1[4] = v10;
  a1[5] = v11;
  a1[6] = v12;
  a1[7] = v13;
  return &retaddr;
}


// ==== sub_7FF91DCA72C0 @ rva 0x472C0 ====
unsigned __int64 __fastcall sub_7FF91DCA72C0(
        __int64 a1,
        __int64 a2,
        __int64 a3,
        unsigned __int64 a4,
        __int64 a5,
        __int64 a6,
        __int64 a7,
        __int64 a8,
        __int64 a9,
        __int64 a10,
        __int64 a11,
        __int64 a12,
        __int64 a13,
        __int64 a14,
        __int64 a15,
        __int64 a16,
        __int64 a17)
{
  unsigned __int64 *v17; // rbp
  unsigned __int64 v18; // r10
  unsigned __int64 v19; // r11
  unsigned __int64 v20; // r12
  unsigned __int64 v21; // r13
  unsigned __int64 v22; // r14
  unsigned __int64 v23; // r15
  __int64 v24; // rbx
  unsigned __int64 result; // rax
  int v26; // ecx
  unsigned __int128 v27; // kr70_16
  unsigned __int128 v28; // kr90_16
  unsigned __int64 v29; // rdx
  unsigned __int128 v30; // krF0_16
  unsigned __int128 v31; // kr110_16
  unsigned __int128 v32; // rax
  unsigned __int64 v33; // kr58_8
  __int64 v34; // kr120_8

  v24 = a17 * a3;
  result = *v17;
  v26 = 8;
  do
  {
    v27 = (unsigned __int64)v24 * (unsigned __int128)v17[1]
        + a4
        + (unsigned __int64)((a3 != 0) + (((unsigned __int64)v24 * (unsigned __int128)result) >> 64));
    a3 = v27;
    v28 = (unsigned __int64)v24 * (unsigned __int128)v17[2] + v18 + *((unsigned __int64 *)&v27 + 1);
    a4 = v28;
    v29 = ((unsigned __int64)v24 * (unsigned __int128)v17[3] + v19 + *((unsigned __int64 *)&v28 + 1)) >> 64;
    v18 = v24 * v17[3] + v19 + *((_QWORD *)&v28 + 1);
    v19 = v24 * v17[4] + v20 + v29;
    v30 = (unsigned __int64)v24 * (unsigned __int128)v17[5]
        + v21
        + (((unsigned __int64)v24 * (unsigned __int128)v17[4] + v20 + v29) >> 64);
    v20 = v30;
    v31 = (unsigned __int64)v24 * (unsigned __int128)v17[6] + v22 + *((unsigned __int64 *)&v30 + 1);
    v21 = v31;
    v32 = (unsigned __int64)v24 * (unsigned __int128)v17[7];
    v24 = v27 * a17;
    v33 = v32;
    result = *v17;
    v34 = v33 + v23 + *((_QWORD *)&v31 + 1);
    v23 = (__PAIR128__(*((unsigned __int64 *)&v32 + 1), v33) + v23 + *((unsigned __int64 *)&v31 + 1)) >> 64;
    v22 = v34;
    --v26;
  }
  while ( v26 );
  return result;
}


// ==== sub_7FF91DCA73C0 @ rva 0x473C0 ====
// local variable allocation has failed, the output may be wrong!
unsigned __int64 __fastcall sub_7FF91DCA73C0(
        __int64 a1,
        __int64 a2,
        __int64 _R8,
        __int64 _R9,
        __int64 a5,
        __int64 a6,
        __int64 a7,
        __int64 a8,
        __int64 a9,
        __int64 a10,
        __int64 a11,
        __int64 a12,
        __int64 a13,
        __int64 a14,
        __int64 a15,
        __int64 a16,
        __int64 a17)
{
  unsigned __int64 *v17; // rbp
  __int64 v24; // rdx OVERLAPPED
  unsigned __int64 result; // rax
  int v52; // ecx

  v24 = _R8 * a2;
  _RSI = 0;
  do
  {
    _RBX = _R8;
    _R8 = ((unsigned __int64)v24 * (unsigned __int128)*v17) >> 64;
    _RAX = v24 * *v17;
    __asm
    {
      adcx    rax, rbx
      adox    r8, r9
    }
    _R9 = ((unsigned __int64)v24 * (unsigned __int128)v17[1]) >> 64;
    _RAX = v24 * v17[1];
    __asm
    {
      adcx    r8, rax
      adox    r9, r10
    }
    _R10 = ((unsigned __int64)v24 * (unsigned __int128)v17[2]) >> 64;
    _RBX = v24 * v17[2];
    __asm
    {
      adcx    r9, rbx
      adox    r10, r11
    }
    _R11 = ((unsigned __int64)v24 * (unsigned __int128)v17[3]) >> 64;
    _RBX = v24 * v17[3];
    __asm
    {
      adcx    r10, rbx
      adox    r11, r12
    }
    _R12 = ((unsigned __int64)v24 * (unsigned __int128)v17[4]) >> 64;
    _RBX = v24 * v17[4];
    __asm
    {
      adcx    r11, rbx
      adox    r12, r13
    }
    _R13 = ((unsigned __int64)v24 * (unsigned __int128)v17[5]) >> 64;
    _RAX = v24 * v17[5];
    __asm
    {
      adcx    r12, rax
      adox    r13, r14
    }
    _R14 = ((unsigned __int64)v24 * (unsigned __int128)v17[6]) >> 64;
    _RAX = v24 * v17[6];
    __asm
    {
      adcx    r13, rax
      adox    r14, r15
    }
    *(_OWORD *)&v24 = (unsigned __int64)v24;
    _R15 = ((unsigned __int64)v24 * (unsigned __int128)v17[7]) >> 64;
    result = v24 * v17[7];
    v24 = _R8 * a17;
    __asm
    {
      adcx    r14, rax
      adox    r15, rsi
      adcx    r15, rsi
    }
  }
  while ( v52 != 1 );
  return result;
}


// ==== sub_7FF91DCA74A0 @ rva 0x474A0 ====
void __fastcall sub_7FF91DCA74A0(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  _QWORD *v4; // rbp
  _QWORD *v5; // rdi
  __int64 v6; // r10
  __int64 v7; // r11
  __int64 v8; // r12
  __int64 v9; // r13
  __int64 v10; // r14
  __int64 v11; // r15
  __int64 v12; // r8
  __int64 v13; // r9
  __int64 v14; // r10
  __int64 v15; // r11
  __int64 v16; // r12
  __int64 v17; // r13
  __int64 v18; // r14
  bool v19; // cf
  __int64 v20; // r9
  __int64 v21; // r10
  _BOOL8 v22; // rtt
  __int64 v23; // r11
  _BOOL8 v24; // rtt
  __int64 v25; // r12
  _BOOL8 v26; // rtt
  __int64 v27; // r13
  _BOOL8 v28; // rtt
  __int64 v29; // r14
  _BOOL8 v30; // rtt
  __int64 v31; // r15

  *v5 = a3;
  v5[1] = a4;
  v5[2] = v6;
  v5[3] = v7;
  v5[4] = v8;
  v5[5] = v9;
  v5[6] = v10;
  v5[7] = v11;
  v12 = a1 & -*v4;
  v13 = a1 & ~v4[1];
  v14 = a1 & ~v4[2];
  v15 = a1 & ~v4[3];
  v16 = a1 & ~v4[4];
  v17 = a1 & ~v4[5];
  v18 = a1 & ~v4[6];
  v19 = __CFADD__(__CFADD__(*v5, v12), v13);
  v20 = __CFADD__(*v5, v12) + v13;
  v19 |= __CFADD__(v5[1], v20);
  v20 += v5[1];
  v22 = v19;
  v19 = __CFADD__(v19, v14);
  v21 = v22 + v14;
  v19 |= __CFADD__(v5[2], v21);
  v21 += v5[2];
  v24 = v19;
  v19 = __CFADD__(v19, v15);
  v23 = v24 + v15;
  v19 |= __CFADD__(v5[3], v23);
  v23 += v5[3];
  v26 = v19;
  v19 = __CFADD__(v19, v16);
  v25 = v26 + v16;
  v19 |= __CFADD__(v5[4], v25);
  v25 += v5[4];
  v28 = v19;
  v19 = __CFADD__(v19, v17);
  v27 = v28 + v17;
  v19 |= __CFADD__(v5[5], v27);
  v27 += v5[5];
  v30 = v19;
  v19 = __CFADD__(v19, v18);
  v29 = v30 + v18;
  v19 |= __CFADD__(v5[6], v29);
  v29 += v5[6];
  v31 = v5[7] + v19 + (a1 & ~v4[7]);
  *v5 += v12;
  v5[1] = v20;
  v5[2] = v21;
  v5[3] = v23;
  v5[4] = v25;
  v5[5] = v27;
  v5[6] = v29;
  v5[7] = v31;
}


// ==== sub_7FF91DCA7560 @ rva 0x47560 ====
unsigned __int64 __fastcall sub_7FF91DCA7560()
{
  unsigned __int64 v0; // rbx
  __int64 v1; // rbp
  unsigned __int64 *v2; // rsi
  unsigned __int64 result; // rax
  unsigned __int64 *v4; // rbp
  __int64 *v5; // rdi
  int v6; // ecx
  unsigned __int128 v7; // kr120_16
  unsigned __int128 v8; // kr140_16
  unsigned __int128 v9; // kr160_16
  unsigned __int128 v10; // kr180_16
  unsigned __int128 v11; // kr1A0_16
  unsigned __int128 v12; // kr1C0_16
  unsigned __int128 v13; // kr1E0_16
  unsigned __int64 v14; // rbx
  unsigned __int128 v15; // rax
  bool v16; // cf
  __int64 v17; // r8
  __int64 v18; // [rsp+10h] [rbp+10h] BYREF

  result = *v2;
  v4 = (unsigned __int64 *)(v1 + 8);
  v5 = &v18;
  v6 = 7;
  *(_QWORD *)&v7 = (*(_OWORD *)v2 * v0) >> 64;
  *(_QWORD *)&v8 = v0 * v2[2] + ((v0 * (unsigned __int128)v2[1] + ((v0 * (unsigned __int128)*v2) >> 64)) >> 64);
  *(_QWORD *)&v9 = v0 * v2[3]
                 + ((v0 * (unsigned __int128)v2[2]
                   + ((v0 * (unsigned __int128)v2[1] + ((v0 * (unsigned __int128)*v2) >> 64)) >> 64)) >> 64);
  *(_QWORD *)&v10 = v0 * v2[4]
                  + ((v0 * (unsigned __int128)v2[3]
                    + ((v0 * (unsigned __int128)v2[2]
                      + ((v0 * (unsigned __int128)v2[1] + ((v0 * (unsigned __int128)*v2) >> 64)) >> 64)) >> 64)) >> 64);
  *(_QWORD *)&v11 = v0 * v2[5]
                  + ((v0 * (unsigned __int128)v2[4]
                    + ((v0 * (unsigned __int128)v2[3]
                      + ((v0 * (unsigned __int128)v2[2]
                        + ((v0 * (unsigned __int128)v2[1] + ((v0 * (unsigned __int128)*v2) >> 64)) >> 64)) >> 64)) >> 64)) >> 64);
  *(_QWORD *)&v12 = v0 * v2[6]
                  + ((v0 * (unsigned __int128)v2[5]
                    + ((v0 * (unsigned __int128)v2[4]
                      + ((v0 * (unsigned __int128)v2[3]
                        + ((v0 * (unsigned __int128)v2[2]
                          + ((v0 * (unsigned __int128)v2[1] + ((v0 * (unsigned __int128)*v2) >> 64)) >> 64)) >> 64)) >> 64)) >> 64)) >> 64);
  v13 = v0 * (unsigned __int128)v2[7]
      + ((v0 * (unsigned __int128)v2[6]
        + ((v0 * (unsigned __int128)v2[5]
          + ((v0 * (unsigned __int128)v2[4]
            + ((v0 * (unsigned __int128)v2[3]
              + ((v0 * (unsigned __int128)v2[2]
                + ((v0 * (unsigned __int128)v2[1] + ((v0 * (unsigned __int128)*v2) >> 64)) >> 64)) >> 64)) >> 64)) >> 64)) >> 64)) >> 64);
  do
  {
    v14 = *v4;
    v15 = *v4 * (unsigned __int128)result;
    v16 = __CFADD__((_QWORD)v15, (_QWORD)v7);
    v17 = v15 + v7;
    *(_QWORD *)&v15 = v2[1];
    *v5 = v17;
    v7 = v14 * (unsigned __int128)(unsigned __int64)v15
       + (unsigned __int64)v8
       + (unsigned __int64)v16
       + *((_QWORD *)&v15 + 1);
    v8 = v14 * (unsigned __int128)v2[2] + (unsigned __int64)v9 + *((unsigned __int64 *)&v7 + 1);
    v9 = v14 * (unsigned __int128)v2[3] + (unsigned __int64)v10 + *((unsigned __int64 *)&v8 + 1);
    v10 = v14 * (unsigned __int128)v2[4] + (unsigned __int64)v11 + *((unsigned __int64 *)&v9 + 1);
    v11 = v14 * (unsigned __int128)v2[5] + (unsigned __int64)v12 + *((unsigned __int64 *)&v10 + 1);
    ++v4;
    v12 = v14 * (unsigned __int128)v2[6] + (unsigned __int64)v13 + *((unsigned __int64 *)&v11 + 1);
    result = *v2;
    v13 = v14 * (unsigned __int128)v2[7] + *((unsigned __int64 *)&v13 + 1) + *((unsigned __int64 *)&v12 + 1);
    ++v5;
    --v6;
  }
  while ( v6 );
  *v5 = v7;
  v5[1] = v8;
  v5[2] = v9;
  v5[3] = v10;
  v5[4] = v11;
  v5[5] = v12;
  *((_OWORD *)v5 + 3) = v13;
  return result;
}


// ==== sub_7FF91DCA7700 @ rva 0x47700 ====
// local variable allocation has failed, the output may be wrong!
void __fastcall sub_7FF91DCA7700(
        __int64 a1,
        unsigned __int64 a2,
        __int64 a3,
        __int64 a4,
        __int64 a5,
        __int64 a6,
        __int64 a7,
        __int64 a8)
{
  bool v8; // cf
  __int64 v9; // rbp
  unsigned __int64 *v10; // rsi
  __int64 v11; // r8
  unsigned __int64 v12; // rax
  __int64 v13; // r9
  unsigned __int64 v14; // rbx
  __int64 v15; // r10
  _BOOL8 v17; // rtt
  unsigned __int64 v18; // rax
  __int64 v19; // r11
  _BOOL8 v21; // rtt
  unsigned __int64 v22; // rbx
  __int64 v23; // r12
  _BOOL8 v25; // rtt
  unsigned __int64 v26; // rax
  __int64 v27; // r13
  _BOOL8 v29; // rtt
  unsigned __int64 v30; // rbx
  __int64 v31; // r14
  _BOOL8 v33; // rtt
  unsigned __int64 v34; // rax
  __int64 v35; // r15
  unsigned __int64 v36; // rdx OVERLAPPED
  _BOOL8 v38; // rtt
  _BOOL8 v40; // rtt
  __int64 v68; // rcx

  v11 = (a2 * (unsigned __int128)*v10) >> 64;
  v13 = (a2 * (unsigned __int128)v10[1]) >> 64;
  v12 = a2 * v10[1];
  v15 = (a2 * (unsigned __int128)v10[2]) >> 64;
  v14 = a2 * v10[2];
  v17 = v8;
  v8 = __CFADD__(v8, v11);
  _R8 = v17 + v11;
  v8 |= __CFADD__(v12, _R8);
  _R8 += v12;
  v19 = (a2 * (unsigned __int128)v10[3]) >> 64;
  v18 = a2 * v10[3];
  v21 = v8;
  v8 = __CFADD__(v8, v13);
  _R9 = v21 + v13;
  v8 |= __CFADD__(v14, _R9);
  _R9 += v14;
  v23 = (a2 * (unsigned __int128)v10[4]) >> 64;
  v22 = a2 * v10[4];
  v25 = v8;
  v8 = __CFADD__(v8, v15);
  _R10 = v25 + v15;
  v8 |= __CFADD__(v18, _R10);
  _R10 += v18;
  v27 = (a2 * (unsigned __int128)v10[5]) >> 64;
  v26 = a2 * v10[5];
  v29 = v8;
  v8 = __CFADD__(v8, v19);
  _R11 = v29 + v19;
  v8 |= __CFADD__(v22, _R11);
  _R11 += v22;
  v31 = (a2 * (unsigned __int128)v10[6]) >> 64;
  v30 = a2 * v10[6];
  v33 = v8;
  v8 = __CFADD__(v8, v23);
  _R12 = v33 + v23;
  v8 |= __CFADD__(v26, _R12);
  _R12 += v26;
  v35 = (a2 * (unsigned __int128)v10[7]) >> 64;
  v34 = a2 * v10[7];
  v36 = *(_QWORD *)(v9 + 8);
  v38 = v8;
  v8 = __CFADD__(v8, v27);
  _R13 = v38 + v27;
  v8 |= __CFADD__(v30, _R13);
  _R13 += v30;
  v40 = v8;
  v8 = __CFADD__(v8, v31);
  _R14 = v40 + v31;
  v8 |= __CFADD__(v34, _R14);
  _R14 += v34;
  _R15 = v8 + v35;
  _RDI = 0;
  do
  {
    _RBX = _R8;
    _R8 = (v36 * (unsigned __int128)*v10) >> 64;
    _RAX = v36 * *v10;
    __asm
    {
      adcx    rbx, rax
      adox    r8, r9
    }
    _R9 = (v36 * (unsigned __int128)v10[1]) >> 64;
    _RAX = v36 * v10[1];
    __asm
    {
      adcx    r8, rax
      adox    r9, r10
    }
    _R10 = (v36 * (unsigned __int128)v10[2]) >> 64;
    _RAX = v36 * v10[2];
    __asm
    {
      adcx    r9, rax
      adox    r10, r11
    }
    _R11 = (v36 * (unsigned __int128)v10[3]) >> 64;
    _RAX = v36 * v10[3];
    __asm
    {
      adcx    r10, rax
      adox    r11, r12
    }
    _R12 = (v36 * (unsigned __int128)v10[4]) >> 64;
    _RAX = v36 * v10[4];
    __asm
    {
      adcx    r11, rax
      adox    r12, r13
    }
    _R13 = (v36 * (unsigned __int128)v10[5]) >> 64;
    _RAX = v36 * v10[5];
    __asm
    {
      adcx    r12, rax
      adox    r13, r14
    }
    _R14 = (v36 * (unsigned __int128)v10[6]) >> 64;
    _RAX = v36 * v10[6];
    __asm
    {
      adcx    r13, rax
      adox    r14, r15
    }
    *(_OWORD *)&v36 = v36;
    _R15 = (v36 * (unsigned __int128)v10[7]) >> 64;
    _RAX = v36 * v10[7];
    v36 = *(_QWORD *)(v9 + 64);
    *(&a8 + v68) = _RBX;
    __asm
    {
      adcx    r14, rax
      adox    r15, rdi
      adcx    r15, rdi
    }
  }
  while ( v68 != -1 );
  _RBX = _R8;
  _R8 = (v36 * (unsigned __int128)*v10) >> 64;
  _RAX = v36 * *v10;
  __asm
  {
    adcx    rbx, rax
    adox    r8, r9
  }
  _R9 = (v36 * (unsigned __int128)v10[1]) >> 64;
  _RAX = v36 * v10[1];
  __asm
  {
    adcx    r8, rax
    adox    r9, r10
  }
  _R10 = (v36 * (unsigned __int128)v10[2]) >> 64;
  _RAX = v36 * v10[2];
  __asm
  {
    adcx    r9, rax
    adox    r10, r11
  }
  _R11 = (v36 * (unsigned __int128)v10[3]) >> 64;
  _RAX = v36 * v10[3];
  __asm
  {
    adcx    r10, rax
    adox    r11, r12
  }
  _R12 = (v36 * (unsigned __int128)v10[4]) >> 64;
  _RAX = v36 * v10[4];
  __asm
  {
    adcx    r11, rax
    adox    r12, r13
  }
  _R13 = (v36 * (unsigned __int128)v10[5]) >> 64;
  _RAX = v36 * v10[5];
  __asm
  {
    adcx    r12, rax
    adox    r13, r14
  }
  _R14 = (v36 * (unsigned __int128)v10[6]) >> 64;
  _RAX = v36 * v10[6];
  __asm
  {
    adcx    r13, rax
    adox    r14, r15
  }
  _R15 = (v36 * (unsigned __int128)v10[7]) >> 64;
  _RAX = v36 * v10[7];
  __asm
  {
    adcx    r14, rax
    adox    r15, rdi
    adcx    r15, rdi
  }
}


// ==== sub_7FF91DCA78F0 @ rva 0x478F0 ====
__int64 __fastcall sub_7FF91DCA78F0(__int64 a1, __int64 *a2, __int64 a3)
{
  _QWORD *v3; // rcx
  int v4; // r9d
  __int64 result; // rax

  v3 = (_QWORD *)(a1 + 8 * a3);
  v4 = 8;
  do
  {
    result = *a2++;
    *v3 = result;
    v3 += 16;
    --v4;
  }
  while ( v4 );
  return result;
}


// ==== sub_7FF91DCA7920 @ rva 0x47920 ====
void __fastcall sub_7FF91DCA7920(_QWORD *a1, const __m128i *a2, unsigned int a3)
{
  __m128i si128; // xmm0
  __m128i v4; // xmm8
  __m128i v5; // xmm7
  __m128i v6; // xmm1
  __m128i v7; // xmm0
  __m128i v8; // xmm2
  __m128i v9; // xmm1
  __m128i v10; // xmm3
  __m128i v11; // xmm2
  __m128i v12; // xmm4
  __m128i v13; // xmm3
  __m128i v14; // xmm5
  __m128i v15; // xmm4
  __m128i v16; // xmm6
  __m128i v17; // xmm5
  __m128i v18; // xmm7
  __m128i v19; // xmm6
  __m128i v20; // xmm7
  int v21; // r9d
  __m128i v22; // xmm8
  __m128i v23; // xmm12
  __m128i v24; // xmm9
  __m128i v25; // xmm13
  __m128i v26; // xmm10
  __m128i v27; // xmm14
  __m128i v28; // xmm11
  __m128i v29; // xmm15
  __m128i v30; // xmm8

  si128 = _mm_load_si128((const __m128i *)&xmmword_7FF91DCA7B00);
  v4 = _mm_shuffle_epi32(_mm_cvtsi32_si128(a3), 0);
  v5 = _mm_load_si128((const __m128i *)&xmmword_7FF91DCA7B10);
  v6 = _mm_add_epi32(v5, si128);
  v7 = _mm_cmpeq_epi32(si128, v4);
  v8 = _mm_add_epi32(v5, v6);
  v9 = _mm_cmpeq_epi32(v6, v4);
  v10 = _mm_add_epi32(v5, v8);
  v11 = _mm_cmpeq_epi32(v8, v4);
  v12 = _mm_add_epi32(v5, v10);
  v13 = _mm_cmpeq_epi32(v10, v4);
  v14 = _mm_add_epi32(v5, v12);
  v15 = _mm_cmpeq_epi32(v12, v4);
  v16 = _mm_add_epi32(v5, v14);
  v17 = _mm_cmpeq_epi32(v14, v4);
  v18 = _mm_add_epi32(v5, v16);
  v19 = _mm_cmpeq_epi32(v16, v4);
  v20 = _mm_cmpeq_epi32(v18, v4);
  v21 = 8;
  do
  {
    v22 = _mm_and_si128(_mm_load_si128(a2), v7);
    v23 = _mm_load_si128(a2 + 4);
    v24 = _mm_and_si128(_mm_load_si128(a2 + 1), v9);
    v25 = _mm_load_si128(a2 + 5);
    v26 = _mm_and_si128(_mm_load_si128(a2 + 2), v11);
    v27 = _mm_load_si128(a2 + 6);
    v28 = _mm_and_si128(_mm_load_si128(a2 + 3), v13);
    v29 = _mm_load_si128(a2 + 7);
    a2 += 8;
    v30 = _mm_or_si128(
            _mm_or_si128(_mm_or_si128(_mm_or_si128(v22, v26), _mm_and_si128(v23, v15)), _mm_and_si128(v27, v19)),
            _mm_or_si128(_mm_or_si128(_mm_or_si128(v24, v28), _mm_and_si128(v25, v17)), _mm_and_si128(v29, v20)));
    *a1++ = _mm_or_si128(v30, _mm_shuffle_epi32(v30, 78)).m128i_u64[0];
    --v21;
  }
  while ( v21 );
}


// ==== sub_7FF91DCA7B20 @ rva 0x47B20 ====
__int64 __fastcall sub_7FF91DCA7B20(__int64 a1, __int64 a2, _QWORD *a3, __int64 a4)
{
  unsigned __int64 v4; // kr00_8
  __int64 v5; // rax
  unsigned __int64 v6; // rbx
  __int64 v7; // rsi
  unsigned int *v8; // r11
  void *v9; // r10
  __int64 v10; // rbp
  __int64 v11; // r12
  __int64 v12; // r13
  __int64 v13; // r14
  __int64 v14; // r15
  __int64 v15; // rdi
  __int64 v16; // rsi

  v4 = __readeflags();
  v5 = a3[15];
  v6 = a3[31];
  v7 = *(_QWORD *)(a4 + 8);
  v8 = *(unsigned int **)(a4 + 56);
  if ( v6 >= v7 + (unsigned __int64)*v8 )
  {
    v5 = a3[19];
    v9 = (void *)(v7 + v8[1]);
    if ( v6 < (unsigned __int64)v9 )
    {
      v5 += 200;
      if ( &loc_7FF91DCA6FF9 == v9 )
      {
        v5 += 176;
        qmemcpy(a3 + 64, (const void *)(v5 - 216), 0xA0u);
      }
      v10 = *(_QWORD *)(v5 - 16);
      v11 = *(_QWORD *)(v5 - 24);
      v12 = *(_QWORD *)(v5 - 32);
      v13 = *(_QWORD *)(v5 - 40);
      v14 = *(_QWORD *)(v5 - 48);
      a3[18] = *(_QWORD *)(v5 - 8);
      a3[20] = v10;
      a3[27] = v11;
      a3[28] = v12;
      a3[29] = v13;
      a3[30] = v14;
    }
  }
  v15 = *(_QWORD *)(v5 + 8);
  v16 = *(_QWORD *)(v5 + 16);
  a3[19] = v5;
  a3[21] = v16;
  a3[22] = v15;
  qmemcpy(*(void **)(a4 + 40), a3, 0x4D0u);
  RtlVirtualUnwind(
    0,
    *(_QWORD *)(a4 + 8),
    *(_QWORD *)a4,
    *(PRUNTIME_FUNCTION *)(a4 + 16),
    *(PCONTEXT *)(a4 + 40),
    (PVOID *)(a4 + 56),
    (PULONG64)(a4 + 24),
    nullptr);
  __writeeflags(v4);
  return 1;
}


// ==== sub_7FF91DCA7C80 @ rva 0x47C80 ====
__int64 sub_7FF91DCA7C80()
{
  return sub_7FF91DCA7C8D();
}


// ==== sub_7FF91DCA7C8D @ rva 0x47C8D ====
__int64 __fastcall sub_7FF91DCA7C8D(__int64 *a1, _QWORD *a2, __int64 a3)
{
  _QWORD *v3; // rsi
  __int64 v4; // r8
  __int64 v5; // r9
  __int64 v6; // r10
  __int64 v7; // r11
  __int64 v8; // r12
  __int64 v9; // r13
  __int64 v10; // r14
  __int64 v11; // r15
  __int64 v12; // rsi
  __int64 v13; // r15
  __int64 v14; // r9
  __int64 v15; // r10
  __int64 v16; // r11
  __int64 v17; // r12
  __int64 v18; // r13
  __int64 v19; // r14
  __int64 v20; // r15
  __int64 v21; // r9
  __int64 v22; // r10
  __int64 v23; // r11
  __int64 v24; // r12
  __int64 v25; // r13
  __int64 v26; // r14
  __int64 result; // rax
  __int64 v28; // [rsp+0h] [rbp-D8h]
  __int64 v29; // [rsp+8h] [rbp-D0h]
  __int64 v30; // [rsp+10h] [rbp-C8h]
  __int64 v31; // [rsp+18h] [rbp-C0h]
  __int64 v32; // [rsp+20h] [rbp-B8h]
  __int64 v33; // [rsp+28h] [rbp-B0h]
  __int64 v34; // [rsp+30h] [rbp-A8h]
  __int64 v35; // [rsp+38h] [rbp-A0h]
  __int64 v36; // [rsp+40h] [rbp-98h]
  __int64 v37; // [rsp+48h] [rbp-90h]
  __int64 v38; // [rsp+50h] [rbp-88h]
  __int64 v39; // [rsp+58h] [rbp-80h]
  __int64 v40; // [rsp+60h] [rbp-78h]
  __int64 v41; // [rsp+68h] [rbp-70h]
  __int64 v42; // [rsp+70h] [rbp-68h]
  __int64 v43; // [rsp+78h] [rbp-60h]
  _QWORD *v44; // [rsp+88h] [rbp-50h]
  __int64 v46; // [rsp+98h] [rbp-40h]

  v3 = a2;
  v44 = a2;
  v4 = *a1;
  v5 = a1[1];
  v6 = a1[2];
  v7 = a1[3];
  v8 = a1[4];
  v9 = a1[5];
  v10 = a1[6];
  v11 = a1[7];
  while ( 1 )
  {
    v28 = v4;
    v29 = v5;
    v30 = v6;
    v31 = v7;
    v32 = v8;
    v33 = v9;
    v34 = v10;
    v35 = v11;
    v36 = *v3 ^ v4;
    v37 = v3[1] ^ v5;
    v38 = v3[2] ^ v6;
    v39 = v3[3] ^ v7;
    v40 = v3[4] ^ v8;
    v41 = v3[5] ^ v9;
    v42 = v3[6] ^ v10;
    v43 = v3[7] ^ v11;
    v12 = 0;
    v46 = 0;
    while ( 1 )
    {
      v13 = qword_7FF91DCA8580[2 * (unsigned __int8)v35]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v34)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v33)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v32)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v31)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v30)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v29)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v28)] + 1);
      v14 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v35)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v34)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v33)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v32)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v31)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v30)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v29]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v28)] + 7);
      v15 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v35)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v34)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v33)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v32)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v31)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v30]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v29)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v28)] + 6);
      v16 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v35)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v34)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v33)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v32)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v31]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v30)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v29)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v28)] + 5);
      v17 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v35)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v34)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v33)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v32]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v31)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v30)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v29)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v28)] + 4);
      v18 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v35)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v34)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v33]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v32)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v31)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v30)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v29)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v28)] + 3);
      v19 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v35)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v34]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v33)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v32)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v31)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v30)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v29)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v28)] + 2);
      v28 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v35)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v34)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v33)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v32)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v31)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v30)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v29)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v28]
          ^ qword_7FF91DCA8580[v12 + 512];
      v29 = v14;
      v30 = v15;
      v31 = v16;
      v32 = v17;
      v33 = v18;
      v34 = v19;
      v35 = v13;
      v20 = qword_7FF91DCA8580[2 * (unsigned __int8)v43]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v42)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v41)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v40)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v39)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v38)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v37)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v36)] + 1)
          ^ v13;
      v21 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v43)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v42)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v41)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v40)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v39)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v38)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v37]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v36)] + 7)
          ^ v14;
      v22 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v43)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v42)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v41)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v40)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v39)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v38]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v37)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v36)] + 6)
          ^ v15;
      v23 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v43)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v42)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v41)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v40)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v39]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v38)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v37)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v36)] + 5)
          ^ v16;
      v24 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v43)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v42)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v41)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v40]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v39)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v38)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v37)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v36)] + 4)
          ^ v17;
      v25 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v43)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v42)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v41]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v40)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v39)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v38)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v37)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v36)] + 3)
          ^ v18;
      v26 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v43)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v42]
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v41)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v40)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v39)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v38)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v37)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v36)] + 2)
          ^ v19;
      v12 = v46 + 1;
      if ( v46 == 9 )
        break;
      ++v46;
      v36 = *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v43)] + 7)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v42)] + 6)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v41)] + 5)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v40)] + 4)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v39)] + 3)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v38)] + 2)
          ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v37)] + 1)
          ^ qword_7FF91DCA8580[2 * (unsigned __int8)v36]
          ^ v28;
      v37 = v21;
      v38 = v22;
      v39 = v23;
      v40 = v24;
      v41 = v25;
      v42 = v26;
      v43 = v20;
    }
    v4 = *a1
       ^ *v44
       ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE1(v43)] + 7)
       ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE2(v42)] + 6)
       ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE3(v41)] + 5)
       ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE4(v40)] + 4)
       ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE5(v39)] + 3)
       ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * BYTE6(v38)] + 2)
       ^ *(__int64 *)((char *)&qword_7FF91DCA8580[2 * HIBYTE(v37)] + 1)
       ^ qword_7FF91DCA8580[2 * (unsigned __int8)v36]
       ^ v28;
    v5 = a1[1] ^ v44[1] ^ v21;
    v6 = a1[2] ^ v44[2] ^ v22;
    v7 = a1[3] ^ v44[3] ^ v23;
    v8 = a1[4] ^ v44[4] ^ v24;
    v9 = a1[5] ^ v44[5] ^ v25;
    v10 = a1[6] ^ v44[6] ^ v26;
    v11 = a1[7] ^ v44[7] ^ v20;
    *a1 = v4;
    a1[1] = v5;
    a1[2] = v6;
    a1[3] = v7;
    a1[4] = v8;
    a1[5] = v9;
    a1[6] = v10;
    a1[7] = v11;
    v3 = v44 + 8;
    result = a3 - 1;
    if ( a3 == 1 )
      break;
    v44 += 8;
    --a3;
  }
  return result;
}


// ==== sub_7FF91DCA95D0 @ rva 0x495D0 ====
__int64 __fastcall sub_7FF91DCA95D0(__int64 a1, __int64 a2, _QWORD *a3, __int64 a4)
{
  unsigned __int64 v4; // kr00_8
  _QWORD *v5; // rax
  unsigned __int64 v6; // rbx
  __int64 v7; // rbp
  __int64 v8; // r12
  __int64 v9; // r13
  __int64 v10; // r14
  __int64 v11; // r15
  __int64 v12; // rdi
  __int64 v13; // rsi

  v4 = __readeflags();
  v5 = (_QWORD *)a3[15];
  v6 = a3[31];
  if ( v6 >= (unsigned __int64)&loc_7FF91DCA7CC5 )
  {
    v5 = (_QWORD *)a3[19];
    if ( v6 < (unsigned __int64)&loc_7FF91DCA856E )
    {
      v5 = (_QWORD *)(v5[20] + 48LL);
      v7 = *(v5 - 2);
      v8 = *(v5 - 3);
      v9 = *(v5 - 4);
      v10 = *(v5 - 5);
      v11 = *(v5 - 6);
      a3[18] = *(v5 - 1);
      a3[20] = v7;
      a3[27] = v8;
      a3[28] = v9;
      a3[29] = v10;
      a3[30] = v11;
    }
  }
  v12 = v5[1];
  v13 = v5[2];
  a3[19] = v5;
  a3[21] = v13;
  a3[22] = v12;
  qmemcpy(*(void **)(a4 + 40), a3, 0x4D0u);
  RtlVirtualUnwind(
    0,
    *(_QWORD *)(a4 + 8),
    *(_QWORD *)a4,
    *(PRUNTIME_FUNCTION *)(a4 + 16),
    *(PCONTEXT *)(a4 + 40),
    (PVOID *)(a4 + 56),
    (PULONG64)(a4 + 24),
    nullptr);
  __writeeflags(v4);
  return 1;
}


// ==== sub_7FF91DCA9700 @ rva 0x49700 ====
unsigned __int64 __fastcall sub_7FF91DCA9700(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v3; // rax
  unsigned __int64 v4; // rbp
  __int64 v5; // r9
  __int64 v6; // r12
  __int64 v7; // r11
  __int64 v8; // rax
  __int64 v9; // r14
  __int64 v10; // rsi
  unsigned __int64 v11; // rbp
  __int64 v12; // rdi
  __m128i v13; // xmm0
  __int64 v14; // rsi
  __int64 v15; // rcx
  __int64 v16; // rdi
  __int64 v17; // rax
  __m128i v18; // xmm1
  __int64 v19; // rsi
  __m128i v20; // xmm0
  __int64 v21; // rcx
  __int64 v22; // rdi
  __int64 v23; // rax
  __m128i v24; // xmm1
  __int64 v25; // rsi
  __m128i v26; // xmm0
  __int64 v27; // rcx
  __int64 v28; // rdi
  __int64 v29; // rax
  __m128i v30; // xmm1
  __int64 v31; // rsi
  __m128i v32; // xmm0
  __int64 v33; // rcx
  __int64 v34; // rdi
  __int64 v35; // rax
  __m128i v36; // xmm1
  __int64 v37; // rsi
  __int64 v38; // rcx
  __int64 v39; // rdi
  _QWORD v41[3]; // [rsp+0h] [rbp-88h] BYREF
  __int64 v42; // [rsp+18h] [rbp-70h]
  __int64 v43; // [rsp+20h] [rbp-68h]
  __int64 v44; // [rsp+28h] [rbp-60h]
  __int64 v45; // [rsp+30h] [rbp-58h]
  __int64 v46; // [rsp+38h] [rbp-50h]
  __int64 v47; // [rsp+40h] [rbp-48h]
  __int64 v48; // [rsp+48h] [rbp-40h]
  __int64 v49; // [rsp+50h] [rbp-38h]
  __int64 v50; // [rsp+58h] [rbp-30h]
  __int64 v51; // [rsp+60h] [rbp-28h]
  __int64 v52; // [rsp+68h] [rbp-20h]
  __int64 v53; // [rsp+70h] [rbp-18h]
  __int64 v54; // [rsp+78h] [rbp-10h]

  v5 = v3 & 0x1FFFFFFFFFFFFFFFLL;
  v6 = 8 * v3;
  v7 = 4 * (v3 & 0x1FFFFFFFFFFFFFFFLL);
  v8 = ((v4 & ((4 * v3) >> 63)) << 61) ^ ((v4 & ((2 * v3) >> 63)) << 62) ^ ((v4 & (v3 >> 63)) << 63);
  v41[0] = 0;
  v41[1] = v5;
  v41[2] = 2 * v5;
  v9 = v6 ^ (4 * v5);
  v42 = (2 * v5) ^ v5;
  v43 = v7;
  v44 = (4 * v5) ^ v5;
  v45 = (4 * v5) ^ (2 * v5);
  v46 = (4 * v5) ^ v42;
  v47 = v6;
  v48 = v9 ^ v44;
  v49 = v9 ^ v45;
  v50 = v9 ^ v46;
  v51 = v9;
  v52 = (4 * v5) ^ v9 ^ v44;
  v10 = v4 & a3;
  v53 = v7 ^ v9 ^ v45;
  v11 = v4 >> 4;
  v54 = v7 ^ v9 ^ v46;
  v12 = v11 & a3;
  v11 >>= 4;
  v13 = _mm_loadl_epi64((const __m128i *)&v41[v10]);
  v14 = v11 & a3;
  v11 >>= 4;
  v15 = v41[v12];
  v16 = v11 & a3;
  v17 = (16 * v15) ^ v8;
  v18 = _mm_slli_si128(_mm_loadl_epi64((const __m128i *)&v41[v14]), 1);
  v11 >>= 4;
  v19 = v11 & a3;
  v11 >>= 4;
  v20 = _mm_xor_si128(v13, v18);
  v21 = v41[v16];
  v22 = v11 & a3;
  v23 = (v21 << 12) ^ v17;
  v24 = _mm_slli_si128(_mm_loadl_epi64((const __m128i *)&v41[v19]), 2);
  v11 >>= 4;
  v25 = v11 & a3;
  v11 >>= 4;
  v26 = _mm_xor_si128(v20, v24);
  v27 = v41[v22];
  v28 = v11 & a3;
  v29 = (v27 << 20) ^ v23;
  v30 = _mm_slli_si128(_mm_loadl_epi64((const __m128i *)&v41[v25]), 3);
  v11 >>= 4;
  v31 = v11 & a3;
  v11 >>= 4;
  v32 = _mm_xor_si128(v26, v30);
  v33 = v41[v28];
  v34 = v11 & a3;
  v35 = (v33 << 28) ^ v29;
  v36 = _mm_slli_si128(_mm_loadl_epi64((const __m128i *)&v41[v31]), 4);
  v11 >>= 4;
  v37 = v11 & a3;
  v11 >>= 4;
  v38 = v41[v34];
  v39 = v11 & a3;
  v11 >>= 4;
  return _mm_xor_si128(
           _mm_xor_si128(
             _mm_xor_si128(_mm_xor_si128(v32, v36), _mm_slli_si128(_mm_loadl_epi64((const __m128i *)&v41[v37]), 5)),
             _mm_slli_si128(_mm_loadl_epi64((const __m128i *)&v41[v11 & a3]), 6)),
           _mm_slli_si128(_mm_loadl_epi64((const __m128i *)&v41[(v11 >> 8) & a3]), 7)).m128i_u64[0]
       ^ (v41[(v11 >> 12) & a3] << 60)
       ^ (v41[(v11 >> 4) & a3] << 52)
       ^ (v41[v39] << 44)
       ^ (v38 << 36)
       ^ v35;
}


// ==== sub_7FF91DCA99D0 @ rva 0x499D0 ====
__int64 __fastcall sub_7FF91DCA99D0(
        __m128i *a1,
        unsigned __int64 a2,
        unsigned __int64 a3,
        unsigned __int64 a4,
        __int64 a5)
{
  __int64 result; // rax
  __m128i v15; // xmm5

  result = qword_7FF91E91A5F0;
  if ( (qword_7FF91E91A5F0 & 0x200000000LL) == 0 )
    return sub_7FF91DCA9A40((_DWORD)a1, a2, a3, a4, a5);
  _XMM1 = a4;
  _XMM2 = a3;
  _XMM3 = _mm_loadl_epi64((const __m128i *)&a5);
  _XMM4 = a2;
  __asm { pclmulqdq xmm0, xmm1, 0 }
  _XMM4 = _mm_xor_si128((__m128i)a2, (__m128i)a3);
  _XMM5 = _mm_xor_si128((__m128i)a4, _XMM3);
  __asm
  {
    pclmulqdq xmm2, xmm3, 0
    pclmulqdq xmm4, xmm5, 0
  }
  v15 = (__m128i)_mm_xor_ps(_mm_xor_ps(_XMM4, _XMM0), _XMM2);
  *a1 = _mm_xor_si128((__m128i)_XMM2, _mm_slli_si128(v15, 8));
  a1[1] = _mm_xor_si128((__m128i)_XMM0, _mm_srli_si128(v15, 8));
  return result;
}


// ==== sub_7FF91DCA9A40 @ rva 0x49A40 ====
unsigned __int64 __fastcall sub_7FF91DCA9A40(_QWORD *a1, __int64 a2)
{
  __int64 v2; // rdx
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // rdx
  __int64 v6; // rcx
  __int64 v7; // r8
  unsigned __int64 v8; // rax
  __int64 v9; // rdx
  unsigned __int64 v10; // rax
  __int64 v11; // rdx
  unsigned __int64 result; // rax
  __int64 v13; // [rsp+0h] [rbp-88h]
  __int64 v14; // [rsp+8h] [rbp-80h]
  __int64 v15; // [rsp+10h] [rbp-78h]
  __int64 v16; // [rsp+18h] [rbp-70h]

  sub_7FF91DCA9700((__int64)a1, a2, 15);
  sub_7FF91DCA9700(v3, v2, v4);
  v8 = sub_7FF91DCA9700(v6, v5, v7);
  v10 = v9 ^ v8;
  *a1 = v13;
  a1[3] = v16;
  v11 = v16 ^ v15 ^ v14 ^ v9;
  result = v11 ^ v16 ^ v13 ^ v10;
  a1[2] = v11;
  a1[1] = result;
  return result;
}


// ==== sub_7FF91DCA9B90 @ rva 0x49B90 ====
__int64 __fastcall sub_7FF91DCA9B90(__int64 a1, __int64 a2, _QWORD *a3, __int64 a4)
{
  unsigned __int64 v4; // kr00_8
  _QWORD *v5; // rax
  __int64 v6; // r14
  __int64 v7; // r13
  __int64 v8; // r12
  __int64 v9; // rbp
  __int64 v10; // rdi
  __int64 v11; // rsi

  v4 = __readeflags();
  v5 = (_QWORD *)a3[19];
  if ( a3[31] >= (unsigned __int64)&loc_7FF91DCA9A76 )
  {
    v6 = v5[10];
    v7 = v5[11];
    v8 = v5[12];
    v9 = v5[13];
    v10 = v5[15];
    v11 = v5[16];
    a3[18] = v5[14];
    a3[20] = v9;
    a3[21] = v11;
    a3[22] = v10;
    a3[27] = v8;
    a3[28] = v7;
    a3[29] = v6;
  }
  a3[19] = v5 + 17;
  qmemcpy(*(void **)(a4 + 40), a3, 0x4D0u);
  RtlVirtualUnwind(
    0,
    *(_QWORD *)(a4 + 8),
    *(_QWORD *)a4,
    *(PRUNTIME_FUNCTION *)(a4 + 16),
    *(PCONTEXT *)(a4 + 40),
    (PVOID *)(a4 + 56),
    (PULONG64)(a4 + 24),
    nullptr);
  __writeeflags(v4);
  return 1;
}


// ==== sub_7FF91DCA9C80 @ rva 0x49C80 ====
int sub_7FF91DCA9C80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918848, "133783475");
  return atexit(sub_7FF91E5812D0);
}


// ==== sub_7FF91DCA9CB0 @ rva 0x49CB0 ====
// Hidden C++ exception states: #wind=2
int sub_7FF91DCA9CB0()
{
  __int64 v0; // rcx
  char *v1; // rcx

  sub_7FF91DD55780(&qword_7FF91E918820, 8);
  v0 = dword_7FF91E91882C++;
  v1 = (char *)qword_7FF91E918820 + 8 * v0;
  if ( v1 )
    sub_7FF91DD5DCD0(v1, "%L10N%USERNAME");
  return atexit(sub_7FF91E581300);
}


// ==== sub_7FF91DCA9D20 @ rva 0x49D20 ====
int sub_7FF91DCA9D20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187F8, "%L10N%HOTHNG");
  return atexit(sub_7FF91E581320);
}


// ==== sub_7FF91DCA9D50 @ rva 0x49D50 ====
int sub_7FF91DCA9D50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187A8, "%L10N%LOADINGSAMPLES");
  return atexit(sub_7FF91E581350);
}


// ==== sub_7FF91DCA9D80 @ rva 0x49D80 ====
int sub_7FF91DCA9D80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187B0, "%L10N%NOCONNECTION");
  return atexit(sub_7FF91E581380);
}


// ==== sub_7FF91DCA9DB0 @ rva 0x49DB0 ====
int sub_7FF91DCA9DB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918838, "%L10N%NHOTH");
  return atexit(sub_7FF91E5813B0);
}


// ==== sub_7FF91DCA9DE0 @ rva 0x49DE0 ====
int sub_7FF91DCA9DE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918788, "%L10N%XPRDHOTH");
  return atexit(sub_7FF91E5813E0);
}


// ==== sub_7FF91DCA9E10 @ rva 0x49E10 ====
int sub_7FF91DCA9E10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918760, "%L10N%HOTHED");
  return atexit(sub_7FF91E581410);
}


// ==== sub_7FF91DCA9E40 @ rva 0x49E40 ====
int sub_7FF91DCA9E40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187C8, "%L10N%HOTHOUTAGE");
  return atexit(sub_7FF91E581440);
}


// ==== sub_7FF91DCA9E70 @ rva 0x49E70 ====
int sub_7FF91DCA9E70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918870, "%L10N%HOTHRRR");
  return atexit(sub_7FF91E581470);
}


// ==== sub_7FF91DCA9EA0 @ rva 0x49EA0 ====
int sub_7FF91DCA9EA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918778, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E5814A0);
}


// ==== sub_7FF91DCA9ED0 @ rva 0x49ED0 ====
int sub_7FF91DCA9ED0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918878, "%L10N%INSTRUMENTNOTFOUND");
  return atexit(sub_7FF91E5814D0);
}


// ==== sub_7FF91DCA9F00 @ rva 0x49F00 ====
int sub_7FF91DCA9F00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918750, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E581500);
}


// ==== sub_7FF91DCA9F30 @ rva 0x49F30 ====
int sub_7FF91DCA9F30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187E0, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E581530);
}


// ==== sub_7FF91DCA9F60 @ rva 0x49F60 ====
int sub_7FF91DCA9F60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918790, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E581560);
}


// ==== sub_7FF91DCA9F90 @ rva 0x49F90 ====
int sub_7FF91DCA9F90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187D8, "%L10N%NOPERSPECTIVES");
  return atexit(sub_7FF91E581590);
}


// ==== sub_7FF91DCA9FC0 @ rva 0x49FC0 ====
int sub_7FF91DCA9FC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918920, "%L10N%LOADINGCANCELLED");
  return atexit(sub_7FF91E5815C0);
}


// ==== sub_7FF91DCA9FF0 @ rva 0x49FF0 ====
int sub_7FF91DCA9FF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918850, "%L10N%MISSINGPARAMETER");
  return atexit(sub_7FF91E5815F0);
}


// ==== sub_7FF91DCAA020 @ rva 0x4A020 ====
int sub_7FF91DCAA020()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188B8, "%L10N%PROGRAMMERERROR");
  return atexit(sub_7FF91E581620);
}


// ==== sub_7FF91DCAA050 @ rva 0x4A050 ====
int sub_7FF91DCAA050()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918758, "%L10N%CANNOTLOADANOTHER");
  return atexit(sub_7FF91E581650);
}


// ==== sub_7FF91DCAA080 @ rva 0x4A080 ====
int sub_7FF91DCAA080()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918880, "%L10N%VRSNCHCKRRR");
  return atexit(sub_7FF91E581680);
}


// ==== sub_7FF91DCAA0B0 @ rva 0x4A0B0 ====
int sub_7FF91DCAA0B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918888, "%L10N%VRSNCHCKRRRFTR");
  return atexit(sub_7FF91E5816B0);
}


// ==== sub_7FF91DCAA0E0 @ rva 0x4A0E0 ====
int sub_7FF91DCAA0E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918928, "%L10N%IHOTH");
  return atexit(sub_7FF91E5816E0);
}


// ==== sub_7FF91DCAA110 @ rva 0x4A110 ====
int sub_7FF91DCAA110()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187C0, "%L10N%HOTHUUIDNOTFOUND");
  return atexit(sub_7FF91E581710);
}


// ==== sub_7FF91DCAA140 @ rva 0x4A140 ====
int sub_7FF91DCAA140()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918730, "%L10N%HOTHGRACEDAY");
  return atexit(sub_7FF91E581740);
}


// ==== sub_7FF91DCAA170 @ rva 0x4A170 ====
int sub_7FF91DCAA170()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918910, "%L10N%HOTHGRACEDAYS");
  return atexit(sub_7FF91E581770);
}


// ==== sub_7FF91DCAA1A0 @ rva 0x4A1A0 ====
int sub_7FF91DCAA1A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918840, "%L10N%HOTHGRACEHOUR");
  return atexit(sub_7FF91E5817A0);
}


// ==== sub_7FF91DCAA1D0 @ rva 0x4A1D0 ====
int sub_7FF91DCAA1D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918898, "%L10N%HOTHGRACEHOURS");
  return atexit(sub_7FF91E5817D0);
}


// ==== sub_7FF91DCAA200 @ rva 0x4A200 ====
int sub_7FF91DCAA200()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918798, "%L10N%HOTHGRACEMINUTE");
  return atexit(sub_7FF91E581800);
}


// ==== sub_7FF91DCAA230 @ rva 0x4A230 ====
int sub_7FF91DCAA230()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918868, "%L10N%HOTHGRACEMINUTES");
  return atexit(sub_7FF91E581830);
}


// ==== sub_7FF91DCAA260 @ rva 0x4A260 ====
int sub_7FF91DCAA260()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188D8, "%L10N%NHOTH2");
  return atexit(sub_7FF91E581860);
}


// ==== sub_7FF91DCAA290 @ rva 0x4A290 ====
int sub_7FF91DCAA290()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918918, "%L10N%HOTHRRRTITLEBAR");
  return atexit(sub_7FF91E581890);
}


// ==== sub_7FF91DCAA2C0 @ rva 0x4A2C0 ====
int sub_7FF91DCAA2C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918780, "%L10N%RTRYHOTHBUTTON");
  return atexit(sub_7FF91E5818C0);
}


// ==== sub_7FF91DCAA2F0 @ rva 0x4A2F0 ====
int sub_7FF91DCAA2F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918720, "%L10N%ALERTWINDOWINSTRUMENTLOAD");
  return atexit(sub_7FF91E5818F0);
}


// ==== sub_7FF91DCAA320 @ rva 0x4A320 ====
int sub_7FF91DCAA320()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918808, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E581920);
}


// ==== sub_7FF91DCAA350 @ rva 0x4A350 ====
int sub_7FF91DCAA350()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187E8, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E581950);
}


// ==== sub_7FF91DCAA380 @ rva 0x4A380 ====
int sub_7FF91DCAA380()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187A0, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E581980);
}


// ==== sub_7FF91DCAA3B0 @ rva 0x4A3B0 ====
int sub_7FF91DCAA3B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188E0, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E5819B0);
}


// ==== sub_7FF91DCAA3E0 @ rva 0x4A3E0 ====
int sub_7FF91DCAA3E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918740, "%L10N%BUSASSIGNMENTTITLEBAR");
  return atexit(sub_7FF91E5819E0);
}


// ==== sub_7FF91DCAA410 @ rva 0x4A410 ====
int sub_7FF91DCAA410()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918930, "%L10N%BUSASSIGNMENTFAILED");
  return atexit(sub_7FF91E581A10);
}


// ==== sub_7FF91DCAA440 @ rva 0x4A440 ====
int sub_7FF91DCAA440()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918900, "%L10N%ARSEEMNOTFOUNDERROR");
  return atexit(sub_7FF91E581A40);
}


// ==== sub_7FF91DCAA470 @ rva 0x4A470 ====
int sub_7FF91DCAA470()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918748, "%L10N%ARSEEMSVCNOTRUNNINGERROR");
  return atexit(sub_7FF91E581A70);
}


// ==== sub_7FF91DCAA4A0 @ rva 0x4A4A0 ====
int sub_7FF91DCAA4A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188E8, "%L10N%ARSEEMSVCCANTSTARTERROR");
  return atexit(sub_7FF91E581AA0);
}


// ==== sub_7FF91DCAA4D0 @ rva 0x4A4D0 ====
int sub_7FF91DCAA4D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188F8, "%L10N%ARSEEMSVCNOTCONNECTEDERROR");
  return atexit(sub_7FF91E581AD0);
}


// ==== sub_7FF91DCAA500 @ rva 0x4A500 ====
int sub_7FF91DCAA500()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918818, "%L10N%ARSEEMSVCNOTLOGGEDINERROR");
  return atexit(sub_7FF91E581B00);
}


// ==== sub_7FF91DCAA530 @ rva 0x4A530 ====
int sub_7FF91DCAA530()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187F0, "%L10N%ARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E581B30);
}


// ==== sub_7FF91DCAA560 @ rva 0x4A560 ====
int sub_7FF91DCAA560()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918860, "%L10N%GTTNGTKN");
  return atexit(sub_7FF91E581B60);
}


// ==== sub_7FF91DCAA590 @ rva 0x4A590 ====
int sub_7FF91DCAA590()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918908, "%L10N%DVCLMTRCHD");
  return atexit(sub_7FF91E581B90);
}


// ==== sub_7FF91DCAA5C0 @ rva 0x4A5C0 ====
int sub_7FF91DCAA5C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188B0, "%L10N%CNTCTNGSRVC");
  return atexit(sub_7FF91E581BC0);
}


// ==== sub_7FF91DCAA5F0 @ rva 0x4A5F0 ====
int sub_7FF91DCAA5F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188C0, "%L10N%TTLDTLSNOCONNECTION");
  return atexit(sub_7FF91E581BF0);
}


// ==== sub_7FF91DCAA620 @ rva 0x4A620 ====
int sub_7FF91DCAA620()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188F0, "%L10N%TTLDTLSUNOTH");
  return atexit(sub_7FF91E581C20);
}


// ==== sub_7FF91DCAA650 @ rva 0x4A650 ====
int sub_7FF91DCAA650()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188C8, "%L10N%TTLDTLSEXPRD");
  return atexit(sub_7FF91E581C50);
}


// ==== sub_7FF91DCAA680 @ rva 0x4A680 ====
int sub_7FF91DCAA680()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187B8, "%L10N%TTLDTLSSRVRPRBLM");
  return atexit(sub_7FF91E581C80);
}


// ==== sub_7FF91DCAA6B0 @ rva 0x4A6B0 ====
int sub_7FF91DCAA6B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918728, "%L10N%TTLDTLSARSEEMNTFND");
  return atexit(sub_7FF91E581CB0);
}


// ==== sub_7FF91DCAA6E0 @ rva 0x4A6E0 ====
int sub_7FF91DCAA6E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918738, "%L10N%TTLDTLSARSEEMSNTRNG");
  return atexit(sub_7FF91E581CE0);
}


// ==== sub_7FF91DCAA710 @ rva 0x4A710 ====
int sub_7FF91DCAA710()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188A8, "%L10N%TTLDTLSARSEEMSNTCNTD");
  return atexit(sub_7FF91E581D10);
}


// ==== sub_7FF91DCAA740 @ rva 0x4A740 ====
int sub_7FF91DCAA740()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918800, "%L10N%TTLDTLSARSEEMSCNTSTRT");
  return atexit(sub_7FF91E581D40);
}


// ==== sub_7FF91DCAA770 @ rva 0x4A770 ====
int sub_7FF91DCAA770()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188D0, "%L10N%TTLDTLSARSEEMNTLGN");
  return atexit(sub_7FF91E581D70);
}


// ==== sub_7FF91DCAA7A0 @ rva 0x4A7A0 ====
int sub_7FF91DCAA7A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918768, "%L10N%TTLDTLSARSEEMGEN");
  return atexit(sub_7FF91E581DA0);
}


// ==== sub_7FF91DCAA7D0 @ rva 0x4A7D0 ====
int sub_7FF91DCAA7D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9188A0, "%L10N%ILGDINTRYAGN");
  return atexit(sub_7FF91E581DD0);
}


// ==== sub_7FF91DCAA800 @ rva 0x4A800 ====
int sub_7FF91DCAA800()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918770, "%L10N%TTLDTLARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E581E00);
}


// ==== sub_7FF91DCAA830 @ rva 0x4A830 ====
int sub_7FF91DCAA830()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9187D0, "%L10N%TTLDTGTTNGTKN");
  return atexit(sub_7FF91E581E30);
}


// ==== sub_7FF91DCAA860 @ rva 0x4A860 ====
int sub_7FF91DCAA860()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918718, "%L10N%TTLDTDVCLMTRCHD");
  return atexit(sub_7FF91E581E60);
}


// ==== sub_7FF91DCAA890 @ rva 0x4A890 ====
int sub_7FF91DCAA890()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918810, "%L10N%LGIN");
  return atexit(sub_7FF91E581E90);
}


// ==== sub_7FF91DCAA8C0 @ rva 0x4A8C0 ====
int sub_7FF91DCAA8C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918890, "rvssv");
  return atexit(sub_7FF91E581EC0);
}


// ==== sub_7FF91DCAA8F0 @ rva 0x4A8F0 ====
int sub_7FF91DCAA8F0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5CF0, "AUTHLIB.VERSION", 15);
  return atexit(sub_7FF91E581EF0);
}


// ==== sub_7FF91DCAA920 @ rva 0x4A920 ====
int sub_7FF91DCAA920()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5D10, "ENVIRONMENT.DATA", 16);
  return atexit(sub_7FF91E581F70);
}


// ==== sub_7FF91DCAA950 @ rva 0x4A950 ====
int sub_7FF91DCAA950()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5D50, "RCM.VERSION", 11);
  return atexit(sub_7FF91E581FF0);
}


// ==== sub_7FF91DCAA980 @ rva 0x4A980 ====
int sub_7FF91DCAA980()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5D30, "RCM.INSTALLATION.PATH", 21);
  return atexit(sub_7FF91E582070);
}


// ==== sub_7FF91DCAA9B0 @ rva 0x4A9B0 ====
int sub_7FF91DCAA9B0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5D70, "AUTHLIB.VERSION.STATUS", 22);
  return atexit(sub_7FF91E5820F0);
}


// ==== sub_7FF91DCAA9E0 @ rva 0x4A9E0 ====
int sub_7FF91DCAA9E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A98, "133783475");
  return atexit(sub_7FF91E582170);
}


// ==== sub_7FF91DCAAA10 @ rva 0x4AA10 ====
// Hidden C++ exception states: #wind=2
int sub_7FF91DCAAA10()
{
  __int64 v0; // rcx
  char *v1; // rcx

  sub_7FF91DD55780(&qword_7FF91E918A70, 8);
  v0 = dword_7FF91E918A7C++;
  v1 = (char *)qword_7FF91E918A70 + 8 * v0;
  if ( v1 )
    sub_7FF91DD5DCD0(v1, "%L10N%USERNAME");
  return atexit(sub_7FF91E5821A0);
}


// ==== sub_7FF91DCAAA80 @ rva 0x4AA80 ====
int sub_7FF91DCAAA80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A18, "%L10N%HOTHNG");
  return atexit(sub_7FF91E5821C0);
}


// ==== sub_7FF91DCAAAB0 @ rva 0x4AAB0 ====
int sub_7FF91DCAAAB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189C8, "%L10N%LOADINGSAMPLES");
  return atexit(sub_7FF91E5821F0);
}


// ==== sub_7FF91DCAAAE0 @ rva 0x4AAE0 ====
int sub_7FF91DCAAAE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189D0, "%L10N%NOCONNECTION");
  return atexit(sub_7FF91E582220);
}


// ==== sub_7FF91DCAAB10 @ rva 0x4AB10 ====
int sub_7FF91DCAAB10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A88, "%L10N%NHOTH");
  return atexit(sub_7FF91E582250);
}


// ==== sub_7FF91DCAAB40 @ rva 0x4AB40 ====
int sub_7FF91DCAAB40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189A8, "%L10N%XPRDHOTH");
  return atexit(sub_7FF91E582280);
}


// ==== sub_7FF91DCAAB70 @ rva 0x4AB70 ====
int sub_7FF91DCAAB70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918980, "%L10N%HOTHED");
  return atexit(sub_7FF91E5822B0);
}


// ==== sub_7FF91DCAABA0 @ rva 0x4ABA0 ====
int sub_7FF91DCAABA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189E8, "%L10N%HOTHOUTAGE");
  return atexit(sub_7FF91E5822E0);
}


// ==== sub_7FF91DCAABD0 @ rva 0x4ABD0 ====
int sub_7FF91DCAABD0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AB8, "%L10N%HOTHRRR");
  return atexit(sub_7FF91E582310);
}


// ==== sub_7FF91DCAAC00 @ rva 0x4AC00 ====
int sub_7FF91DCAAC00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918998, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E582340);
}


// ==== sub_7FF91DCAAC30 @ rva 0x4AC30 ====
int sub_7FF91DCAAC30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AC0, "%L10N%INSTRUMENTNOTFOUND");
  return atexit(sub_7FF91E582370);
}


// ==== sub_7FF91DCAAC60 @ rva 0x4AC60 ====
int sub_7FF91DCAAC60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918970, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E5823A0);
}


// ==== sub_7FF91DCAAC90 @ rva 0x4AC90 ====
int sub_7FF91DCAAC90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A00, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E5823D0);
}


// ==== sub_7FF91DCAACC0 @ rva 0x4ACC0 ====
int sub_7FF91DCAACC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189B0, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E582400);
}


// ==== sub_7FF91DCAACF0 @ rva 0x4ACF0 ====
int sub_7FF91DCAACF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189F8, "%L10N%NOPERSPECTIVES");
  return atexit(sub_7FF91E582430);
}


// ==== sub_7FF91DCAAD20 @ rva 0x4AD20 ====
int sub_7FF91DCAAD20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B68, "%L10N%LOADINGCANCELLED");
  return atexit(sub_7FF91E582460);
}


// ==== sub_7FF91DCAAD50 @ rva 0x4AD50 ====
int sub_7FF91DCAAD50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AA0, "%L10N%MISSINGPARAMETER");
  return atexit(sub_7FF91E582490);
}


// ==== sub_7FF91DCAAD80 @ rva 0x4AD80 ====
int sub_7FF91DCAAD80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B00, "%L10N%PROGRAMMERERROR");
  return atexit(sub_7FF91E5824C0);
}


// ==== sub_7FF91DCAADB0 @ rva 0x4ADB0 ====
int sub_7FF91DCAADB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918978, "%L10N%CANNOTLOADANOTHER");
  return atexit(sub_7FF91E5824F0);
}


// ==== sub_7FF91DCAADE0 @ rva 0x4ADE0 ====
int sub_7FF91DCAADE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AC8, "%L10N%VRSNCHCKRRR");
  return atexit(sub_7FF91E582520);
}


// ==== sub_7FF91DCAAE10 @ rva 0x4AE10 ====
int sub_7FF91DCAAE10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AD0, "%L10N%VRSNCHCKRRRFTR");
  return atexit(sub_7FF91E582550);
}


// ==== sub_7FF91DCAAE40 @ rva 0x4AE40 ====
int sub_7FF91DCAAE40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B70, "%L10N%IHOTH");
  return atexit(sub_7FF91E582580);
}


// ==== sub_7FF91DCAAE70 @ rva 0x4AE70 ====
int sub_7FF91DCAAE70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189E0, "%L10N%HOTHUUIDNOTFOUND");
  return atexit(sub_7FF91E5825B0);
}


// ==== sub_7FF91DCAAEA0 @ rva 0x4AEA0 ====
int sub_7FF91DCAAEA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918950, "%L10N%HOTHGRACEDAY");
  return atexit(sub_7FF91E5825E0);
}


// ==== sub_7FF91DCAAED0 @ rva 0x4AED0 ====
int sub_7FF91DCAAED0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B58, "%L10N%HOTHGRACEDAYS");
  return atexit(sub_7FF91E582610);
}


// ==== sub_7FF91DCAAF00 @ rva 0x4AF00 ====
int sub_7FF91DCAAF00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A90, "%L10N%HOTHGRACEHOUR");
  return atexit(sub_7FF91E582640);
}


// ==== sub_7FF91DCAAF30 @ rva 0x4AF30 ====
int sub_7FF91DCAAF30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AE0, "%L10N%HOTHGRACEHOURS");
  return atexit(sub_7FF91E582670);
}


// ==== sub_7FF91DCAAF60 @ rva 0x4AF60 ====
int sub_7FF91DCAAF60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189B8, "%L10N%HOTHGRACEMINUTE");
  return atexit(sub_7FF91E5826A0);
}


// ==== sub_7FF91DCAAF90 @ rva 0x4AF90 ====
int sub_7FF91DCAAF90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AB0, "%L10N%HOTHGRACEMINUTES");
  return atexit(sub_7FF91E5826D0);
}


// ==== sub_7FF91DCAAFC0 @ rva 0x4AFC0 ====
int sub_7FF91DCAAFC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B20, "%L10N%NHOTH2");
  return atexit(sub_7FF91E582700);
}


// ==== sub_7FF91DCAAFF0 @ rva 0x4AFF0 ====
int sub_7FF91DCAAFF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B60, "%L10N%HOTHRRRTITLEBAR");
  return atexit(sub_7FF91E582730);
}


// ==== sub_7FF91DCAB020 @ rva 0x4B020 ====
int sub_7FF91DCAB020()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189A0, "%L10N%RTRYHOTHBUTTON");
  return atexit(sub_7FF91E582760);
}


// ==== sub_7FF91DCAB050 @ rva 0x4B050 ====
int sub_7FF91DCAB050()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918940, "%L10N%ALERTWINDOWINSTRUMENTLOAD");
  return atexit(sub_7FF91E582790);
}


// ==== sub_7FF91DCAB080 @ rva 0x4B080 ====
int sub_7FF91DCAB080()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A58, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E5827C0);
}


// ==== sub_7FF91DCAB0B0 @ rva 0x4B0B0 ====
int sub_7FF91DCAB0B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A08, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E5827F0);
}


// ==== sub_7FF91DCAB0E0 @ rva 0x4B0E0 ====
int sub_7FF91DCAB0E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189C0, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E582820);
}


// ==== sub_7FF91DCAB110 @ rva 0x4B110 ====
int sub_7FF91DCAB110()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B28, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E582850);
}


// ==== sub_7FF91DCAB140 @ rva 0x4B140 ====
int sub_7FF91DCAB140()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918960, "%L10N%BUSASSIGNMENTTITLEBAR");
  return atexit(sub_7FF91E582880);
}


// ==== sub_7FF91DCAB170 @ rva 0x4B170 ====
int sub_7FF91DCAB170()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B78, "%L10N%BUSASSIGNMENTFAILED");
  return atexit(sub_7FF91E5828B0);
}


// ==== sub_7FF91DCAB1A0 @ rva 0x4B1A0 ====
int sub_7FF91DCAB1A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B48, "%L10N%ARSEEMNOTFOUNDERROR");
  return atexit(sub_7FF91E5828E0);
}


// ==== sub_7FF91DCAB1D0 @ rva 0x4B1D0 ====
int sub_7FF91DCAB1D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918968, "%L10N%ARSEEMSVCNOTRUNNINGERROR");
  return atexit(sub_7FF91E582910);
}


// ==== sub_7FF91DCAB200 @ rva 0x4B200 ====
int sub_7FF91DCAB200()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B30, "%L10N%ARSEEMSVCCANTSTARTERROR");
  return atexit(sub_7FF91E582940);
}


// ==== sub_7FF91DCAB230 @ rva 0x4B230 ====
int sub_7FF91DCAB230()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B40, "%L10N%ARSEEMSVCNOTCONNECTEDERROR");
  return atexit(sub_7FF91E582970);
}


// ==== sub_7FF91DCAB260 @ rva 0x4B260 ====
int sub_7FF91DCAB260()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A68, "%L10N%ARSEEMSVCNOTLOGGEDINERROR");
  return atexit(sub_7FF91E5829A0);
}


// ==== sub_7FF91DCAB290 @ rva 0x4B290 ====
int sub_7FF91DCAB290()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A10, "%L10N%ARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E5829D0);
}


// ==== sub_7FF91DCAB2C0 @ rva 0x4B2C0 ====
int sub_7FF91DCAB2C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AA8, "%L10N%GTTNGTKN");
  return atexit(sub_7FF91E582A00);
}


// ==== sub_7FF91DCAB2F0 @ rva 0x4B2F0 ====
int sub_7FF91DCAB2F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B50, "%L10N%DVCLMTRCHD");
  return atexit(sub_7FF91E582A30);
}


// ==== sub_7FF91DCAB320 @ rva 0x4B320 ====
int sub_7FF91DCAB320()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AF8, "%L10N%CNTCTNGSRVC");
  return atexit(sub_7FF91E582A60);
}


// ==== sub_7FF91DCAB350 @ rva 0x4B350 ====
int sub_7FF91DCAB350()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B08, "%L10N%TTLDTLSNOCONNECTION");
  return atexit(sub_7FF91E582A90);
}


// ==== sub_7FF91DCAB380 @ rva 0x4B380 ====
int sub_7FF91DCAB380()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B38, "%L10N%TTLDTLSUNOTH");
  return atexit(sub_7FF91E582AC0);
}


// ==== sub_7FF91DCAB3B0 @ rva 0x4B3B0 ====
int sub_7FF91DCAB3B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B10, "%L10N%TTLDTLSEXPRD");
  return atexit(sub_7FF91E582AF0);
}


// ==== sub_7FF91DCAB3E0 @ rva 0x4B3E0 ====
int sub_7FF91DCAB3E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189D8, "%L10N%TTLDTLSSRVRPRBLM");
  return atexit(sub_7FF91E582B20);
}


// ==== sub_7FF91DCAB410 @ rva 0x4B410 ====
int sub_7FF91DCAB410()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918948, "%L10N%TTLDTLSARSEEMNTFND");
  return atexit(sub_7FF91E582B50);
}


// ==== sub_7FF91DCAB440 @ rva 0x4B440 ====
int sub_7FF91DCAB440()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918958, "%L10N%TTLDTLSARSEEMSNTRNG");
  return atexit(sub_7FF91E582B80);
}


// ==== sub_7FF91DCAB470 @ rva 0x4B470 ====
int sub_7FF91DCAB470()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AF0, "%L10N%TTLDTLSARSEEMSNTCNTD");
  return atexit(sub_7FF91E582BB0);
}


// ==== sub_7FF91DCAB4A0 @ rva 0x4B4A0 ====
int sub_7FF91DCAB4A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A20, "%L10N%TTLDTLSARSEEMSCNTSTRT");
  return atexit(sub_7FF91E582BE0);
}


// ==== sub_7FF91DCAB4D0 @ rva 0x4B4D0 ====
int sub_7FF91DCAB4D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B18, "%L10N%TTLDTLSARSEEMNTLGN");
  return atexit(sub_7FF91E582C10);
}


// ==== sub_7FF91DCAB500 @ rva 0x4B500 ====
int sub_7FF91DCAB500()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918988, "%L10N%TTLDTLSARSEEMGEN");
  return atexit(sub_7FF91E582C40);
}


// ==== sub_7FF91DCAB530 @ rva 0x4B530 ====
int sub_7FF91DCAB530()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AE8, "%L10N%ILGDINTRYAGN");
  return atexit(sub_7FF91E582C70);
}


// ==== sub_7FF91DCAB560 @ rva 0x4B560 ====
int sub_7FF91DCAB560()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918990, "%L10N%TTLDTLARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E582CA0);
}


// ==== sub_7FF91DCAB590 @ rva 0x4B590 ====
int sub_7FF91DCAB590()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9189F0, "%L10N%TTLDTGTTNGTKN");
  return atexit(sub_7FF91E582CD0);
}


// ==== sub_7FF91DCAB5C0 @ rva 0x4B5C0 ====
int sub_7FF91DCAB5C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918938, "%L10N%TTLDTDVCLMTRCHD");
  return atexit(sub_7FF91E582D00);
}


// ==== sub_7FF91DCAB5F0 @ rva 0x4B5F0 ====
int sub_7FF91DCAB5F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918A60, "%L10N%LGIN");
  return atexit(sub_7FF91E582D30);
}


// ==== sub_7FF91DCAB620 @ rva 0x4B620 ====
int sub_7FF91DCAB620()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918AD8, "rvssv");
  return atexit(sub_7FF91E582D60);
}


// ==== sub_7FF91DCAB650 @ rva 0x4B650 ====
int sub_7FF91DCAB650()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5D90, "AUTHLIB.VERSION", 15);
  return atexit(sub_7FF91E582D90);
}


// ==== sub_7FF91DCAB680 @ rva 0x4B680 ====
int sub_7FF91DCAB680()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5DB0, "ENVIRONMENT.DATA", 16);
  return atexit(sub_7FF91E582E10);
}


// ==== sub_7FF91DCAB6B0 @ rva 0x4B6B0 ====
int sub_7FF91DCAB6B0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5DF0, "RCM.VERSION", 11);
  return atexit(sub_7FF91E582E90);
}


// ==== sub_7FF91DCAB6E0 @ rva 0x4B6E0 ====
int sub_7FF91DCAB6E0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5DD0, "RCM.INSTALLATION.PATH", 21);
  return atexit(sub_7FF91E582F10);
}


// ==== sub_7FF91DCAB710 @ rva 0x4B710 ====
int sub_7FF91DCAB710()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5E10, "AUTHLIB.VERSION.STATUS", 22);
  return atexit(sub_7FF91E582F90);
}


// ==== sub_7FF91DCAB740 @ rva 0x4B740 ====
int sub_7FF91DCAB740()
{
  InitializeCriticalSection(&CriticalSection);
  return atexit(sub_7FF91E583010);
}


// ==== sub_7FF91DCAB770 @ rva 0x4B770 ====
int sub_7FF91DCAB770()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918CF8, "133783475");
  return atexit(sub_7FF91E583020);
}


// ==== sub_7FF91DCAB7A0 @ rva 0x4B7A0 ====
// Hidden C++ exception states: #wind=2
int sub_7FF91DCAB7A0()
{
  __int64 v0; // rcx
  char *v1; // rcx

  sub_7FF91DD55780(&qword_7FF91E918CD0, 8);
  v0 = dword_7FF91E918CDC++;
  v1 = (char *)qword_7FF91E918CD0 + 8 * v0;
  if ( v1 )
    sub_7FF91DD5DCD0(v1, "%L10N%USERNAME");
  return atexit(sub_7FF91E583050);
}


// ==== sub_7FF91DCAB810 @ rva 0x4B810 ====
int sub_7FF91DCAB810()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C80, "%L10N%HOTHNG");
  return atexit(sub_7FF91E583070);
}


// ==== sub_7FF91DCAB840 @ rva 0x4B840 ====
int sub_7FF91DCAB840()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C10, "%L10N%LOADINGSAMPLES");
  return atexit(sub_7FF91E5830A0);
}


// ==== sub_7FF91DCAB870 @ rva 0x4B870 ====
int sub_7FF91DCAB870()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C18, "%L10N%NOCONNECTION");
  return atexit(sub_7FF91E5830D0);
}


// ==== sub_7FF91DCAB8A0 @ rva 0x4B8A0 ====
int sub_7FF91DCAB8A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918CE8, "%L10N%NHOTH");
  return atexit(sub_7FF91E583100);
}


// ==== sub_7FF91DCAB8D0 @ rva 0x4B8D0 ====
int sub_7FF91DCAB8D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BF0, "%L10N%XPRDHOTH");
  return atexit(sub_7FF91E583130);
}


// ==== sub_7FF91DCAB900 @ rva 0x4B900 ====
int sub_7FF91DCAB900()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BC8, "%L10N%HOTHED");
  return atexit(sub_7FF91E583160);
}


// ==== sub_7FF91DCAB930 @ rva 0x4B930 ====
int sub_7FF91DCAB930()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C48, "%L10N%HOTHOUTAGE");
  return atexit(sub_7FF91E583190);
}


// ==== sub_7FF91DCAB960 @ rva 0x4B960 ====
int sub_7FF91DCAB960()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D30, "%L10N%HOTHRRR");
  return atexit(sub_7FF91E5831C0);
}


// ==== sub_7FF91DCAB990 @ rva 0x4B990 ====
int sub_7FF91DCAB990()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BE0, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E5831F0);
}


// ==== sub_7FF91DCAB9C0 @ rva 0x4B9C0 ====
int sub_7FF91DCAB9C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D38, "%L10N%INSTRUMENTNOTFOUND");
  return atexit(sub_7FF91E583220);
}


// ==== sub_7FF91DCAB9F0 @ rva 0x4B9F0 ====
int sub_7FF91DCAB9F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BB8, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E583250);
}


// ==== sub_7FF91DCABA20 @ rva 0x4BA20 ====
int sub_7FF91DCABA20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C60, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E583280);
}


// ==== sub_7FF91DCABA50 @ rva 0x4BA50 ====
int sub_7FF91DCABA50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BF8, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E5832B0);
}


// ==== sub_7FF91DCABA80 @ rva 0x4BA80 ====
int sub_7FF91DCABA80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C58, "%L10N%NOPERSPECTIVES");
  return atexit(sub_7FF91E5832E0);
}


// ==== sub_7FF91DCABAB0 @ rva 0x4BAB0 ====
int sub_7FF91DCABAB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E00, "%L10N%LOADINGCANCELLED");
  return atexit(sub_7FF91E583310);
}


// ==== sub_7FF91DCABAE0 @ rva 0x4BAE0 ====
int sub_7FF91DCABAE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D08, "%L10N%MISSINGPARAMETER");
  return atexit(sub_7FF91E583340);
}


// ==== sub_7FF91DCABB10 @ rva 0x4BB10 ====
int sub_7FF91DCABB10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D80, "%L10N%PROGRAMMERERROR");
  return atexit(sub_7FF91E583370);
}


// ==== sub_7FF91DCABB40 @ rva 0x4BB40 ====
int sub_7FF91DCABB40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BC0, "%L10N%CANNOTLOADANOTHER");
  return atexit(sub_7FF91E5833A0);
}


// ==== sub_7FF91DCABB70 @ rva 0x4BB70 ====
int sub_7FF91DCABB70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D40, "%L10N%VRSNCHCKRRR");
  return atexit(sub_7FF91E5833D0);
}


// ==== sub_7FF91DCABBA0 @ rva 0x4BBA0 ====
int sub_7FF91DCABBA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D48, "%L10N%VRSNCHCKRRRFTR");
  return atexit(sub_7FF91E583400);
}


// ==== sub_7FF91DCABBD0 @ rva 0x4BBD0 ====
int sub_7FF91DCABBD0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E08, "%L10N%IHOTH");
  return atexit(sub_7FF91E583430);
}


// ==== sub_7FF91DCABC00 @ rva 0x4BC00 ====
int sub_7FF91DCABC00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C40, "%L10N%HOTHUUIDNOTFOUND");
  return atexit(sub_7FF91E583460);
}


// ==== sub_7FF91DCABC30 @ rva 0x4BC30 ====
int sub_7FF91DCABC30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B98, "%L10N%HOTHGRACEDAY");
  return atexit(sub_7FF91E583490);
}


// ==== sub_7FF91DCABC60 @ rva 0x4BC60 ====
int sub_7FF91DCABC60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DF0, "%L10N%HOTHGRACEDAYS");
  return atexit(sub_7FF91E5834C0);
}


// ==== sub_7FF91DCABC90 @ rva 0x4BC90 ====
int sub_7FF91DCABC90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918CF0, "%L10N%HOTHGRACEHOUR");
  return atexit(sub_7FF91E5834F0);
}


// ==== sub_7FF91DCABCC0 @ rva 0x4BCC0 ====
int sub_7FF91DCABCC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D58, "%L10N%HOTHGRACEHOURS");
  return atexit(sub_7FF91E583520);
}


// ==== sub_7FF91DCABCF0 @ rva 0x4BCF0 ====
int sub_7FF91DCABCF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C00, "%L10N%HOTHGRACEMINUTE");
  return atexit(sub_7FF91E583550);
}


// ==== sub_7FF91DCABD20 @ rva 0x4BD20 ====
int sub_7FF91DCABD20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D28, "%L10N%HOTHGRACEMINUTES");
  return atexit(sub_7FF91E583580);
}


// ==== sub_7FF91DCABD50 @ rva 0x4BD50 ====
int sub_7FF91DCABD50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DA8, "%L10N%NHOTH2");
  return atexit(sub_7FF91E5835B0);
}


// ==== sub_7FF91DCABD80 @ rva 0x4BD80 ====
int sub_7FF91DCABD80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DF8, "%L10N%HOTHRRRTITLEBAR");
  return atexit(sub_7FF91E5835E0);
}


// ==== sub_7FF91DCABDB0 @ rva 0x4BDB0 ====
int sub_7FF91DCABDB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BE8, "%L10N%RTRYHOTHBUTTON");
  return atexit(sub_7FF91E583610);
}


// ==== sub_7FF91DCABDE0 @ rva 0x4BDE0 ====
int sub_7FF91DCABDE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B88, "%L10N%ALERTWINDOWINSTRUMENTLOAD");
  return atexit(sub_7FF91E583640);
}


// ==== sub_7FF91DCABE10 @ rva 0x4BE10 ====
int sub_7FF91DCABE10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918CB0, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E583670);
}


// ==== sub_7FF91DCABE40 @ rva 0x4BE40 ====
int sub_7FF91DCABE40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C68, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E5836A0);
}


// ==== sub_7FF91DCABE70 @ rva 0x4BE70 ====
int sub_7FF91DCABE70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C08, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E5836D0);
}


// ==== sub_7FF91DCABEA0 @ rva 0x4BEA0 ====
int sub_7FF91DCABEA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DB0, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E583700);
}


// ==== sub_7FF91DCABED0 @ rva 0x4BED0 ====
int sub_7FF91DCABED0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BA8, "%L10N%BUSASSIGNMENTTITLEBAR");
  return atexit(sub_7FF91E583730);
}


// ==== sub_7FF91DCABF00 @ rva 0x4BF00 ====
int sub_7FF91DCABF00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E10, "%L10N%BUSASSIGNMENTFAILED");
  return atexit(sub_7FF91E583760);
}


// ==== sub_7FF91DCABF30 @ rva 0x4BF30 ====
int sub_7FF91DCABF30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DD8, "%L10N%ARSEEMNOTFOUNDERROR");
  return atexit(sub_7FF91E583790);
}


// ==== sub_7FF91DCABF60 @ rva 0x4BF60 ====
int sub_7FF91DCABF60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BB0, "%L10N%ARSEEMSVCNOTRUNNINGERROR");
  return atexit(sub_7FF91E5837C0);
}


// ==== sub_7FF91DCABF90 @ rva 0x4BF90 ====
int sub_7FF91DCABF90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DB8, "%L10N%ARSEEMSVCCANTSTARTERROR");
  return atexit(sub_7FF91E5837F0);
}


// ==== sub_7FF91DCABFC0 @ rva 0x4BFC0 ====
int sub_7FF91DCABFC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DC8, "%L10N%ARSEEMSVCNOTCONNECTEDERROR");
  return atexit(sub_7FF91E583820);
}


// ==== sub_7FF91DCABFF0 @ rva 0x4BFF0 ====
int sub_7FF91DCABFF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918CC8, "%L10N%ARSEEMSVCNOTLOGGEDINERROR");
  return atexit(sub_7FF91E583850);
}


// ==== sub_7FF91DCAC020 @ rva 0x4C020 ====
int sub_7FF91DCAC020()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C70, "%L10N%ARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E583880);
}


// ==== sub_7FF91DCAC050 @ rva 0x4C050 ====
int sub_7FF91DCAC050()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D20, "%L10N%GTTNGTKN");
  return atexit(sub_7FF91E5838B0);
}


// ==== sub_7FF91DCAC080 @ rva 0x4C080 ====
int sub_7FF91DCAC080()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DE0, "%L10N%DVCLMTRCHD");
  return atexit(sub_7FF91E5838E0);
}


// ==== sub_7FF91DCAC0B0 @ rva 0x4C0B0 ====
int sub_7FF91DCAC0B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D78, "%L10N%CNTCTNGSRVC");
  return atexit(sub_7FF91E583910);
}


// ==== sub_7FF91DCAC0E0 @ rva 0x4C0E0 ====
int sub_7FF91DCAC0E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D88, "%L10N%TTLDTLSNOCONNECTION");
  return atexit(sub_7FF91E583940);
}


// ==== sub_7FF91DCAC110 @ rva 0x4C110 ====
int sub_7FF91DCAC110()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DC0, "%L10N%TTLDTLSUNOTH");
  return atexit(sub_7FF91E583970);
}


// ==== sub_7FF91DCAC140 @ rva 0x4C140 ====
int sub_7FF91DCAC140()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D90, "%L10N%TTLDTLSEXPRD");
  return atexit(sub_7FF91E5839A0);
}


// ==== sub_7FF91DCAC170 @ rva 0x4C170 ====
int sub_7FF91DCAC170()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C20, "%L10N%TTLDTLSSRVRPRBLM");
  return atexit(sub_7FF91E5839D0);
}


// ==== sub_7FF91DCAC1A0 @ rva 0x4C1A0 ====
int sub_7FF91DCAC1A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B90, "%L10N%TTLDTLSARSEEMNTFND");
  return atexit(sub_7FF91E583A00);
}


// ==== sub_7FF91DCAC1D0 @ rva 0x4C1D0 ====
int sub_7FF91DCAC1D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BA0, "%L10N%TTLDTLSARSEEMSNTRNG");
  return atexit(sub_7FF91E583A30);
}


// ==== sub_7FF91DCAC200 @ rva 0x4C200 ====
int sub_7FF91DCAC200()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D70, "%L10N%TTLDTLSARSEEMSNTCNTD");
  return atexit(sub_7FF91E583A60);
}


// ==== sub_7FF91DCAC230 @ rva 0x4C230 ====
int sub_7FF91DCAC230()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C90, "%L10N%TTLDTLSARSEEMSCNTSTRT");
  return atexit(sub_7FF91E583A90);
}


// ==== sub_7FF91DCAC260 @ rva 0x4C260 ====
int sub_7FF91DCAC260()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DA0, "%L10N%TTLDTLSARSEEMNTLGN");
  return atexit(sub_7FF91E583AC0);
}


// ==== sub_7FF91DCAC290 @ rva 0x4C290 ====
int sub_7FF91DCAC290()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BD0, "%L10N%TTLDTLSARSEEMGEN");
  return atexit(sub_7FF91E583AF0);
}


// ==== sub_7FF91DCAC2C0 @ rva 0x4C2C0 ====
int sub_7FF91DCAC2C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D68, "%L10N%ILGDINTRYAGN");
  return atexit(sub_7FF91E583B20);
}


// ==== sub_7FF91DCAC2F0 @ rva 0x4C2F0 ====
int sub_7FF91DCAC2F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918BD8, "%L10N%TTLDTLARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E583B50);
}


// ==== sub_7FF91DCAC320 @ rva 0x4C320 ====
int sub_7FF91DCAC320()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C50, "%L10N%TTLDTGTTNGTKN");
  return atexit(sub_7FF91E583B80);
}


// ==== sub_7FF91DCAC350 @ rva 0x4C350 ====
int sub_7FF91DCAC350()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918B80, "%L10N%TTLDTDVCLMTRCHD");
  return atexit(sub_7FF91E583BB0);
}


// ==== sub_7FF91DCAC380 @ rva 0x4C380 ====
int sub_7FF91DCAC380()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918CB8, "%L10N%LGIN");
  return atexit(sub_7FF91E583BE0);
}


// ==== sub_7FF91DCAC3B0 @ rva 0x4C3B0 ====
int sub_7FF91DCAC3B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D50, "rvssv");
  return atexit(sub_7FF91E583C10);
}


// ==== sub_7FF91DCAC3E0 @ rva 0x4C3E0 ====
int sub_7FF91DCAC3E0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5E40, "AUTHLIB.VERSION", 15);
  return atexit(sub_7FF91E583C40);
}


// ==== sub_7FF91DCAC410 @ rva 0x4C410 ====
int sub_7FF91DCAC410()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5E60, "ENVIRONMENT.DATA", 16);
  return atexit(sub_7FF91E583CC0);
}


// ==== sub_7FF91DCAC440 @ rva 0x4C440 ====
int sub_7FF91DCAC440()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5EA0, "RCM.VERSION", 11);
  return atexit(sub_7FF91E583D40);
}


// ==== sub_7FF91DCAC470 @ rva 0x4C470 ====
int sub_7FF91DCAC470()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5E80, "RCM.INSTALLATION.PATH", 21);
  return atexit(sub_7FF91E583DC0);
}


// ==== sub_7FF91DCAC4A0 @ rva 0x4C4A0 ====
int sub_7FF91DCAC4A0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5EC0, "AUTHLIB.VERSION.STATUS", 22);
  return atexit(sub_7FF91E583E40);
}


// ==== sub_7FF91DCAC4D0 @ rva 0x4C4D0 ====
int sub_7FF91DCAC4D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D00, "133783475");
  return atexit(sub_7FF91E583EC0);
}


// ==== sub_7FF91DCAC500 @ rva 0x4C500 ====
int sub_7FF91DCAC500()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D98, "%L10N%0THAK");
  return atexit(sub_7FF91E583EF0);
}


// ==== sub_7FF91DCAC530 @ rva 0x4C530 ====
int sub_7FF91DCAC530()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C88, "%L10N%0THANCPTVRFRC");
  return atexit(sub_7FF91E583F20);
}


// ==== sub_7FF91DCAC560 @ rva 0x4C560 ====
int sub_7FF91DCAC560()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C78, "%L10N%0THANCPTVRFRCDSC");
  return atexit(sub_7FF91E583F50);
}


// ==== sub_7FF91DCAC590 @ rva 0x4C590 ====
int sub_7FF91DCAC590()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C38, "%L10N%0THACNTSTRC");
  return atexit(sub_7FF91E583F80);
}


// ==== sub_7FF91DCAC5C0 @ rva 0x4C5C0 ====
int sub_7FF91DCAC5C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C30, "%L10N%0THACNTSTRCDSC");
  return atexit(sub_7FF91E583FB0);
}


// ==== sub_7FF91DCAC5F0 @ rva 0x4C5F0 ====
int sub_7FF91DCAC5F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918D60, "%L10N%0THACMNTFND");
  return atexit(sub_7FF91E583FE0);
}


// ==== sub_7FF91DCAC620 @ rva 0x4C620 ====
int sub_7FF91DCAC620()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C98, "%L10N%0THACMNTFNDDSC");
  return atexit(sub_7FF91E584010);
}


// ==== sub_7FF91DCAC650 @ rva 0x4C650 ====
int sub_7FF91DCAC650()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DE8, "%L10N%OTHDVCLMTRCHD");
  return atexit(sub_7FF91E584040);
}


// ==== sub_7FF91DCAC680 @ rva 0x4C680 ====
int sub_7FF91DCAC680()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918CC0, "%L10N%OTHDVCLMTRCHDDSC");
  return atexit(sub_7FF91E584070);
}


// ==== sub_7FF91DCAC6B0 @ rva 0x4C6B0 ====
int sub_7FF91DCAC6B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918DD0, "%L10N%OTHRCMSVCNTCNCTD");
  return atexit(sub_7FF91E5840A0);
}


// ==== sub_7FF91DCAC6E0 @ rva 0x4C6E0 ====
int sub_7FF91DCAC6E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918C28, "%L10N%OTHRCMSVCNTCNCTDDSC");
  return atexit(sub_7FF91E5840D0);
}


// ==== sub_7FF91DCAC710 @ rva 0x4C710 ====
int sub_7FF91DCAC710()
{
  Block = (void *)sub_7FF91DD1C9D0();
  return atexit(sub_7FF91E584100);
}


// ==== sub_7FF91DCAC730 @ rva 0x4C730 ====
int sub_7FF91DCAC730()
{
  qword_7FF91E918D18 = CreateEventW(nullptr, 0, 0, nullptr);
  return atexit(sub_7FF91E584160);
}


// ==== sub_7FF91DCAC760 @ rva 0x4C760 ====
int sub_7FF91DCAC760()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F78, "133783475");
  return atexit(sub_7FF91E5841E0);
}


// ==== sub_7FF91DCAC790 @ rva 0x4C790 ====
// Hidden C++ exception states: #wind=2
int sub_7FF91DCAC790()
{
  __int64 v0; // rcx
  char *v1; // rcx

  sub_7FF91DD55780(&qword_7FF91E918F50, 8);
  v0 = dword_7FF91E918F5C++;
  v1 = (char *)qword_7FF91E918F50 + 8 * v0;
  if ( v1 )
    sub_7FF91DD5DCD0(v1, "%L10N%USERNAME");
  return atexit(sub_7FF91E584210);
}


// ==== sub_7FF91DCAC800 @ rva 0x4C800 ====
int sub_7FF91DCAC800()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F28, "%L10N%HOTHNG");
  return atexit(sub_7FF91E584230);
}


// ==== sub_7FF91DCAC830 @ rva 0x4C830 ====
int sub_7FF91DCAC830()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918ED8, "%L10N%LOADINGSAMPLES");
  return atexit(sub_7FF91E584260);
}


// ==== sub_7FF91DCAC860 @ rva 0x4C860 ====
int sub_7FF91DCAC860()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918EE0, "%L10N%NOCONNECTION");
  return atexit(sub_7FF91E584290);
}


// ==== sub_7FF91DCAC890 @ rva 0x4C890 ====
int sub_7FF91DCAC890()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F68, "%L10N%NHOTH");
  return atexit(sub_7FF91E5842C0);
}


// ==== sub_7FF91DCAC8C0 @ rva 0x4C8C0 ====
int sub_7FF91DCAC8C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918EB8, "%L10N%XPRDHOTH");
  return atexit(sub_7FF91E5842F0);
}


// ==== sub_7FF91DCAC8F0 @ rva 0x4C8F0 ====
int sub_7FF91DCAC8F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E90, "%L10N%HOTHED");
  return atexit(sub_7FF91E584320);
}


// ==== sub_7FF91DCAC920 @ rva 0x4C920 ====
int sub_7FF91DCAC920()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918EF8, "%L10N%HOTHOUTAGE");
  return atexit(sub_7FF91E584350);
}


// ==== sub_7FF91DCAC950 @ rva 0x4C950 ====
int sub_7FF91DCAC950()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F98, "%L10N%HOTHRRR");
  return atexit(sub_7FF91E584380);
}


// ==== sub_7FF91DCAC980 @ rva 0x4C980 ====
int sub_7FF91DCAC980()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918EA8, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E5843B0);
}


// ==== sub_7FF91DCAC9B0 @ rva 0x4C9B0 ====
int sub_7FF91DCAC9B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FA0, "%L10N%INSTRUMENTNOTFOUND");
  return atexit(sub_7FF91E5843E0);
}


// ==== sub_7FF91DCAC9E0 @ rva 0x4C9E0 ====
int sub_7FF91DCAC9E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E80, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E584410);
}


// ==== sub_7FF91DCACA10 @ rva 0x4CA10 ====
int sub_7FF91DCACA10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F10, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E584440);
}


// ==== sub_7FF91DCACA40 @ rva 0x4CA40 ====
int sub_7FF91DCACA40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918EC0, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E584470);
}


// ==== sub_7FF91DCACA70 @ rva 0x4CA70 ====
int sub_7FF91DCACA70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F08, "%L10N%NOPERSPECTIVES");
  return atexit(sub_7FF91E5844A0);
}


// ==== sub_7FF91DCACAA0 @ rva 0x4CAA0 ====
int sub_7FF91DCACAA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919050, "%L10N%LOADINGCANCELLED");
  return atexit(sub_7FF91E5844D0);
}


// ==== sub_7FF91DCACAD0 @ rva 0x4CAD0 ====
int sub_7FF91DCACAD0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F80, "%L10N%MISSINGPARAMETER");
  return atexit(sub_7FF91E584500);
}


// ==== sub_7FF91DCACB00 @ rva 0x4CB00 ====
int sub_7FF91DCACB00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FE0, "%L10N%PROGRAMMERERROR");
  return atexit(sub_7FF91E584530);
}


// ==== sub_7FF91DCACB30 @ rva 0x4CB30 ====
int sub_7FF91DCACB30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E88, "%L10N%CANNOTLOADANOTHER");
  return atexit(sub_7FF91E584560);
}


// ==== sub_7FF91DCACB60 @ rva 0x4CB60 ====
int sub_7FF91DCACB60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FA8, "%L10N%VRSNCHCKRRR");
  return atexit(sub_7FF91E584590);
}


// ==== sub_7FF91DCACB90 @ rva 0x4CB90 ====
int sub_7FF91DCACB90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FB0, "%L10N%VRSNCHCKRRRFTR");
  return atexit(sub_7FF91E5845C0);
}


// ==== sub_7FF91DCACBC0 @ rva 0x4CBC0 ====
int sub_7FF91DCACBC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919058, "%L10N%IHOTH");
  return atexit(sub_7FF91E5845F0);
}


// ==== sub_7FF91DCACBF0 @ rva 0x4CBF0 ====
int sub_7FF91DCACBF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918EF0, "%L10N%HOTHUUIDNOTFOUND");
  return atexit(sub_7FF91E584620);
}


// ==== sub_7FF91DCACC20 @ rva 0x4CC20 ====
int sub_7FF91DCACC20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E60, "%L10N%HOTHGRACEDAY");
  return atexit(sub_7FF91E584650);
}


// ==== sub_7FF91DCACC50 @ rva 0x4CC50 ====
int sub_7FF91DCACC50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919040, "%L10N%HOTHGRACEDAYS");
  return atexit(sub_7FF91E584680);
}


// ==== sub_7FF91DCACC80 @ rva 0x4CC80 ====
int sub_7FF91DCACC80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F70, "%L10N%HOTHGRACEHOUR");
  return atexit(sub_7FF91E5846B0);
}


// ==== sub_7FF91DCACCB0 @ rva 0x4CCB0 ====
int sub_7FF91DCACCB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FC0, "%L10N%HOTHGRACEHOURS");
  return atexit(sub_7FF91E5846E0);
}


// ==== sub_7FF91DCACCE0 @ rva 0x4CCE0 ====
int sub_7FF91DCACCE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918EC8, "%L10N%HOTHGRACEMINUTE");
  return atexit(sub_7FF91E584710);
}


// ==== sub_7FF91DCACD10 @ rva 0x4CD10 ====
int sub_7FF91DCACD10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F90, "%L10N%HOTHGRACEMINUTES");
  return atexit(sub_7FF91E584740);
}


// ==== sub_7FF91DCACD40 @ rva 0x4CD40 ====
int sub_7FF91DCACD40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919000, "%L10N%NHOTH2");
  return atexit(sub_7FF91E584770);
}


// ==== sub_7FF91DCACD70 @ rva 0x4CD70 ====
int sub_7FF91DCACD70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919048, "%L10N%HOTHRRRTITLEBAR");
  return atexit(sub_7FF91E5847A0);
}


// ==== sub_7FF91DCACDA0 @ rva 0x4CDA0 ====
int sub_7FF91DCACDA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918EB0, "%L10N%RTRYHOTHBUTTON");
  return atexit(sub_7FF91E5847D0);
}


// ==== sub_7FF91DCACDD0 @ rva 0x4CDD0 ====
int sub_7FF91DCACDD0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E50, "%L10N%ALERTWINDOWINSTRUMENTLOAD");
  return atexit(sub_7FF91E584800);
}


// ==== sub_7FF91DCACE00 @ rva 0x4CE00 ====
int sub_7FF91DCACE00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F38, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E584830);
}


// ==== sub_7FF91DCACE30 @ rva 0x4CE30 ====
int sub_7FF91DCACE30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F18, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E584860);
}


// ==== sub_7FF91DCACE60 @ rva 0x4CE60 ====
int sub_7FF91DCACE60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918ED0, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E584890);
}


// ==== sub_7FF91DCACE90 @ rva 0x4CE90 ====
int sub_7FF91DCACE90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919008, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E5848C0);
}


// ==== sub_7FF91DCACEC0 @ rva 0x4CEC0 ====
int sub_7FF91DCACEC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E70, "%L10N%BUSASSIGNMENTTITLEBAR");
  return atexit(sub_7FF91E5848F0);
}


// ==== sub_7FF91DCACEF0 @ rva 0x4CEF0 ====
int sub_7FF91DCACEF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919060, "%L10N%BUSASSIGNMENTFAILED");
  return atexit(sub_7FF91E584920);
}


// ==== sub_7FF91DCACF20 @ rva 0x4CF20 ====
int sub_7FF91DCACF20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919030, "%L10N%ARSEEMNOTFOUNDERROR");
  return atexit(sub_7FF91E584950);
}


// ==== sub_7FF91DCACF50 @ rva 0x4CF50 ====
int sub_7FF91DCACF50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E78, "%L10N%ARSEEMSVCNOTRUNNINGERROR");
  return atexit(sub_7FF91E584980);
}


// ==== sub_7FF91DCACF80 @ rva 0x4CF80 ====
int sub_7FF91DCACF80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919010, "%L10N%ARSEEMSVCCANTSTARTERROR");
  return atexit(sub_7FF91E5849B0);
}


// ==== sub_7FF91DCACFB0 @ rva 0x4CFB0 ====
int sub_7FF91DCACFB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919028, "%L10N%ARSEEMSVCNOTCONNECTEDERROR");
  return atexit(sub_7FF91E5849E0);
}


// ==== sub_7FF91DCACFE0 @ rva 0x4CFE0 ====
int sub_7FF91DCACFE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F48, "%L10N%ARSEEMSVCNOTLOGGEDINERROR");
  return atexit(sub_7FF91E584A10);
}


// ==== sub_7FF91DCAD010 @ rva 0x4D010 ====
int sub_7FF91DCAD010()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F20, "%L10N%ARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E584A40);
}


// ==== sub_7FF91DCAD040 @ rva 0x4D040 ====
int sub_7FF91DCAD040()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F88, "%L10N%GTTNGTKN");
  return atexit(sub_7FF91E584A70);
}


// ==== sub_7FF91DCAD070 @ rva 0x4D070 ====
int sub_7FF91DCAD070()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919038, "%L10N%DVCLMTRCHD");
  return atexit(sub_7FF91E584AA0);
}


// ==== sub_7FF91DCAD0A0 @ rva 0x4D0A0 ====
int sub_7FF91DCAD0A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FD8, "%L10N%CNTCTNGSRVC");
  return atexit(sub_7FF91E584AD0);
}


// ==== sub_7FF91DCAD0D0 @ rva 0x4D0D0 ====
int sub_7FF91DCAD0D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FE8, "%L10N%TTLDTLSNOCONNECTION");
  return atexit(sub_7FF91E584B00);
}


// ==== sub_7FF91DCAD100 @ rva 0x4D100 ====
int sub_7FF91DCAD100()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919018, "%L10N%TTLDTLSUNOTH");
  return atexit(sub_7FF91E584B30);
}


// ==== sub_7FF91DCAD130 @ rva 0x4D130 ====
int sub_7FF91DCAD130()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FF0, "%L10N%TTLDTLSEXPRD");
  return atexit(sub_7FF91E584B60);
}


// ==== sub_7FF91DCAD160 @ rva 0x4D160 ====
int sub_7FF91DCAD160()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918EE8, "%L10N%TTLDTLSSRVRPRBLM");
  return atexit(sub_7FF91E584B90);
}


// ==== sub_7FF91DCAD190 @ rva 0x4D190 ====
int sub_7FF91DCAD190()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E58, "%L10N%TTLDTLSARSEEMNTFND");
  return atexit(sub_7FF91E584BC0);
}


// ==== sub_7FF91DCAD1C0 @ rva 0x4D1C0 ====
int sub_7FF91DCAD1C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E68, "%L10N%TTLDTLSARSEEMSNTRNG");
  return atexit(sub_7FF91E584BF0);
}


// ==== sub_7FF91DCAD1F0 @ rva 0x4D1F0 ====
int sub_7FF91DCAD1F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FD0, "%L10N%TTLDTLSARSEEMSNTCNTD");
  return atexit(sub_7FF91E584C20);
}


// ==== sub_7FF91DCAD220 @ rva 0x4D220 ====
int sub_7FF91DCAD220()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F30, "%L10N%TTLDTLSARSEEMSCNTSTRT");
  return atexit(sub_7FF91E584C50);
}


// ==== sub_7FF91DCAD250 @ rva 0x4D250 ====
int sub_7FF91DCAD250()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FF8, "%L10N%TTLDTLSARSEEMNTLGN");
  return atexit(sub_7FF91E584C80);
}


// ==== sub_7FF91DCAD280 @ rva 0x4D280 ====
int sub_7FF91DCAD280()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E98, "%L10N%TTLDTLSARSEEMGEN");
  return atexit(sub_7FF91E584CB0);
}


// ==== sub_7FF91DCAD2B0 @ rva 0x4D2B0 ====
int sub_7FF91DCAD2B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FC8, "%L10N%ILGDINTRYAGN");
  return atexit(sub_7FF91E584CE0);
}


// ==== sub_7FF91DCAD2E0 @ rva 0x4D2E0 ====
int sub_7FF91DCAD2E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918EA0, "%L10N%TTLDTLARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E584D10);
}


// ==== sub_7FF91DCAD310 @ rva 0x4D310 ====
int sub_7FF91DCAD310()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F00, "%L10N%TTLDTGTTNGTKN");
  return atexit(sub_7FF91E584D40);
}


// ==== sub_7FF91DCAD340 @ rva 0x4D340 ====
int sub_7FF91DCAD340()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918E48, "%L10N%TTLDTDVCLMTRCHD");
  return atexit(sub_7FF91E584D70);
}


// ==== sub_7FF91DCAD370 @ rva 0x4D370 ====
int sub_7FF91DCAD370()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918F40, "%L10N%LGIN");
  return atexit(sub_7FF91E584DA0);
}


// ==== sub_7FF91DCAD3A0 @ rva 0x4D3A0 ====
int sub_7FF91DCAD3A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E918FB8, "rvssv");
  return atexit(sub_7FF91E584DD0);
}


// ==== sub_7FF91DCAD3D0 @ rva 0x4D3D0 ====
int sub_7FF91DCAD3D0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5EF0, "AUTHLIB.VERSION", 15);
  return atexit(sub_7FF91E584E00);
}


// ==== sub_7FF91DCAD400 @ rva 0x4D400 ====
int sub_7FF91DCAD400()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5F10, "ENVIRONMENT.DATA", 16);
  return atexit(sub_7FF91E584E80);
}


// ==== sub_7FF91DCAD430 @ rva 0x4D430 ====
int sub_7FF91DCAD430()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5F50, "RCM.VERSION", 11);
  return atexit(sub_7FF91E584F00);
}


// ==== sub_7FF91DCAD460 @ rva 0x4D460 ====
int sub_7FF91DCAD460()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5F30, "RCM.INSTALLATION.PATH", 21);
  return atexit(sub_7FF91E584F80);
}


// ==== sub_7FF91DCAD490 @ rva 0x4D490 ====
int sub_7FF91DCAD490()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5F70, "AUTHLIB.VERSION.STATUS", 22);
  return atexit(sub_7FF91E585000);
}


// ==== sub_7FF91DCAD4C0 @ rva 0x4D4C0 ====
int sub_7FF91DCAD4C0()
{
  return atexit((void (__cdecl *)())nullsub_109);
}


// ==== sub_7FF91DCAD4D0 @ rva 0x4D4D0 ====
int sub_7FF91DCAD4D0()
{
  InitializeCriticalSection(&stru_7FF91E918E18);
  return atexit(sub_7FF91E585090);
}


// ==== sub_7FF91DCAD500 @ rva 0x4D500 ====
int sub_7FF91DCAD500()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919198, "133783475");
  return atexit(sub_7FF91E5850A0);
}


// ==== sub_7FF91DCAD530 @ rva 0x4D530 ====
// Hidden C++ exception states: #wind=2
int sub_7FF91DCAD530()
{
  __int64 v0; // rcx
  char *v1; // rcx

  sub_7FF91DD55780(&qword_7FF91E919170, 8);
  v0 = dword_7FF91E91917C++;
  v1 = (char *)qword_7FF91E919170 + 8 * v0;
  if ( v1 )
    sub_7FF91DD5DCD0(v1, "%L10N%USERNAME");
  return atexit(sub_7FF91E5850D0);
}


// ==== sub_7FF91DCAD5A0 @ rva 0x4D5A0 ====
int sub_7FF91DCAD5A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919148, "%L10N%HOTHNG");
  return atexit(sub_7FF91E5850F0);
}


// ==== sub_7FF91DCAD5D0 @ rva 0x4D5D0 ====
int sub_7FF91DCAD5D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190F8, "%L10N%LOADINGSAMPLES");
  return atexit(sub_7FF91E585120);
}


// ==== sub_7FF91DCAD600 @ rva 0x4D600 ====
int sub_7FF91DCAD600()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919100, "%L10N%NOCONNECTION");
  return atexit(sub_7FF91E585150);
}


// ==== sub_7FF91DCAD630 @ rva 0x4D630 ====
int sub_7FF91DCAD630()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919188, "%L10N%NHOTH");
  return atexit(sub_7FF91E585180);
}


// ==== sub_7FF91DCAD660 @ rva 0x4D660 ====
int sub_7FF91DCAD660()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190D8, "%L10N%XPRDHOTH");
  return atexit(sub_7FF91E5851B0);
}


// ==== sub_7FF91DCAD690 @ rva 0x4D690 ====
int sub_7FF91DCAD690()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190B0, "%L10N%HOTHED");
  return atexit(sub_7FF91E5851E0);
}


// ==== sub_7FF91DCAD6C0 @ rva 0x4D6C0 ====
int sub_7FF91DCAD6C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919118, "%L10N%HOTHOUTAGE");
  return atexit(sub_7FF91E585210);
}


// ==== sub_7FF91DCAD6F0 @ rva 0x4D6F0 ====
int sub_7FF91DCAD6F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191B8, "%L10N%HOTHRRR");
  return atexit(sub_7FF91E585240);
}


// ==== sub_7FF91DCAD720 @ rva 0x4D720 ====
int sub_7FF91DCAD720()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190C8, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E585270);
}


// ==== sub_7FF91DCAD750 @ rva 0x4D750 ====
int sub_7FF91DCAD750()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191C0, "%L10N%INSTRUMENTNOTFOUND");
  return atexit(sub_7FF91E5852A0);
}


// ==== sub_7FF91DCAD780 @ rva 0x4D780 ====
int sub_7FF91DCAD780()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190A0, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E5852D0);
}


// ==== sub_7FF91DCAD7B0 @ rva 0x4D7B0 ====
int sub_7FF91DCAD7B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919130, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E585300);
}


// ==== sub_7FF91DCAD7E0 @ rva 0x4D7E0 ====
int sub_7FF91DCAD7E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190E0, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E585330);
}


// ==== sub_7FF91DCAD810 @ rva 0x4D810 ====
int sub_7FF91DCAD810()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919128, "%L10N%NOPERSPECTIVES");
  return atexit(sub_7FF91E585360);
}


// ==== sub_7FF91DCAD840 @ rva 0x4D840 ====
int sub_7FF91DCAD840()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919270, "%L10N%LOADINGCANCELLED");
  return atexit(sub_7FF91E585390);
}


// ==== sub_7FF91DCAD870 @ rva 0x4D870 ====
int sub_7FF91DCAD870()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191A0, "%L10N%MISSINGPARAMETER");
  return atexit(sub_7FF91E5853C0);
}


// ==== sub_7FF91DCAD8A0 @ rva 0x4D8A0 ====
int sub_7FF91DCAD8A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919208, "%L10N%PROGRAMMERERROR");
  return atexit(sub_7FF91E5853F0);
}


// ==== sub_7FF91DCAD8D0 @ rva 0x4D8D0 ====
int sub_7FF91DCAD8D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190A8, "%L10N%CANNOTLOADANOTHER");
  return atexit(sub_7FF91E585420);
}


// ==== sub_7FF91DCAD900 @ rva 0x4D900 ====
int sub_7FF91DCAD900()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191C8, "%L10N%VRSNCHCKRRR");
  return atexit(sub_7FF91E585450);
}


// ==== sub_7FF91DCAD930 @ rva 0x4D930 ====
int sub_7FF91DCAD930()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191D0, "%L10N%VRSNCHCKRRRFTR");
  return atexit(sub_7FF91E585480);
}


// ==== sub_7FF91DCAD960 @ rva 0x4D960 ====
int sub_7FF91DCAD960()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919278, "%L10N%IHOTH");
  return atexit(sub_7FF91E5854B0);
}


// ==== sub_7FF91DCAD990 @ rva 0x4D990 ====
int sub_7FF91DCAD990()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919110, "%L10N%HOTHUUIDNOTFOUND");
  return atexit(sub_7FF91E5854E0);
}


// ==== sub_7FF91DCAD9C0 @ rva 0x4D9C0 ====
int sub_7FF91DCAD9C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919080, "%L10N%HOTHGRACEDAY");
  return atexit(sub_7FF91E585510);
}


// ==== sub_7FF91DCAD9F0 @ rva 0x4D9F0 ====
int sub_7FF91DCAD9F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919260, "%L10N%HOTHGRACEDAYS");
  return atexit(sub_7FF91E585540);
}


// ==== sub_7FF91DCADA20 @ rva 0x4DA20 ====
int sub_7FF91DCADA20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919190, "%L10N%HOTHGRACEHOUR");
  return atexit(sub_7FF91E585570);
}


// ==== sub_7FF91DCADA50 @ rva 0x4DA50 ====
int sub_7FF91DCADA50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191E0, "%L10N%HOTHGRACEHOURS");
  return atexit(sub_7FF91E5855A0);
}


// ==== sub_7FF91DCADA80 @ rva 0x4DA80 ====
int sub_7FF91DCADA80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190E8, "%L10N%HOTHGRACEMINUTE");
  return atexit(sub_7FF91E5855D0);
}


// ==== sub_7FF91DCADAB0 @ rva 0x4DAB0 ====
int sub_7FF91DCADAB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191B0, "%L10N%HOTHGRACEMINUTES");
  return atexit(sub_7FF91E585600);
}


// ==== sub_7FF91DCADAE0 @ rva 0x4DAE0 ====
int sub_7FF91DCADAE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919228, "%L10N%NHOTH2");
  return atexit(sub_7FF91E585630);
}


// ==== sub_7FF91DCADB10 @ rva 0x4DB10 ====
int sub_7FF91DCADB10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919268, "%L10N%HOTHRRRTITLEBAR");
  return atexit(sub_7FF91E585660);
}


// ==== sub_7FF91DCADB40 @ rva 0x4DB40 ====
int sub_7FF91DCADB40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190D0, "%L10N%RTRYHOTHBUTTON");
  return atexit(sub_7FF91E585690);
}


// ==== sub_7FF91DCADB70 @ rva 0x4DB70 ====
int sub_7FF91DCADB70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919070, "%L10N%ALERTWINDOWINSTRUMENTLOAD");
  return atexit(sub_7FF91E5856C0);
}


// ==== sub_7FF91DCADBA0 @ rva 0x4DBA0 ====
int sub_7FF91DCADBA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919158, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E5856F0);
}


// ==== sub_7FF91DCADBD0 @ rva 0x4DBD0 ====
int sub_7FF91DCADBD0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919138, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E585720);
}


// ==== sub_7FF91DCADC00 @ rva 0x4DC00 ====
int sub_7FF91DCADC00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190F0, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E585750);
}


// ==== sub_7FF91DCADC30 @ rva 0x4DC30 ====
int sub_7FF91DCADC30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919230, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E585780);
}


// ==== sub_7FF91DCADC60 @ rva 0x4DC60 ====
int sub_7FF91DCADC60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919090, "%L10N%BUSASSIGNMENTTITLEBAR");
  return atexit(sub_7FF91E5857B0);
}


// ==== sub_7FF91DCADC90 @ rva 0x4DC90 ====
int sub_7FF91DCADC90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919280, "%L10N%BUSASSIGNMENTFAILED");
  return atexit(sub_7FF91E5857E0);
}


// ==== sub_7FF91DCADCC0 @ rva 0x4DCC0 ====
int sub_7FF91DCADCC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919250, "%L10N%ARSEEMNOTFOUNDERROR");
  return atexit(sub_7FF91E585810);
}


// ==== sub_7FF91DCADCF0 @ rva 0x4DCF0 ====
int sub_7FF91DCADCF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919098, "%L10N%ARSEEMSVCNOTRUNNINGERROR");
  return atexit(sub_7FF91E585840);
}


// ==== sub_7FF91DCADD20 @ rva 0x4DD20 ====
int sub_7FF91DCADD20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919238, "%L10N%ARSEEMSVCCANTSTARTERROR");
  return atexit(sub_7FF91E585870);
}


// ==== sub_7FF91DCADD50 @ rva 0x4DD50 ====
int sub_7FF91DCADD50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919248, "%L10N%ARSEEMSVCNOTCONNECTEDERROR");
  return atexit(sub_7FF91E5858A0);
}


// ==== sub_7FF91DCADD80 @ rva 0x4DD80 ====
int sub_7FF91DCADD80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919168, "%L10N%ARSEEMSVCNOTLOGGEDINERROR");
  return atexit(sub_7FF91E5858D0);
}


// ==== sub_7FF91DCADDB0 @ rva 0x4DDB0 ====
int sub_7FF91DCADDB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919140, "%L10N%ARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E585900);
}


// ==== sub_7FF91DCADDE0 @ rva 0x4DDE0 ====
int sub_7FF91DCADDE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191A8, "%L10N%GTTNGTKN");
  return atexit(sub_7FF91E585930);
}


// ==== sub_7FF91DCADE10 @ rva 0x4DE10 ====
int sub_7FF91DCADE10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919258, "%L10N%DVCLMTRCHD");
  return atexit(sub_7FF91E585960);
}


// ==== sub_7FF91DCADE40 @ rva 0x4DE40 ====
int sub_7FF91DCADE40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919200, "%L10N%CNTCTNGSRVC");
  return atexit(sub_7FF91E585990);
}


// ==== sub_7FF91DCADE70 @ rva 0x4DE70 ====
int sub_7FF91DCADE70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919210, "%L10N%TTLDTLSNOCONNECTION");
  return atexit(sub_7FF91E5859C0);
}


// ==== sub_7FF91DCADEA0 @ rva 0x4DEA0 ====
int sub_7FF91DCADEA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919240, "%L10N%TTLDTLSUNOTH");
  return atexit(sub_7FF91E5859F0);
}


// ==== sub_7FF91DCADED0 @ rva 0x4DED0 ====
int sub_7FF91DCADED0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919218, "%L10N%TTLDTLSEXPRD");
  return atexit(sub_7FF91E585A20);
}


// ==== sub_7FF91DCADF00 @ rva 0x4DF00 ====
int sub_7FF91DCADF00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919108, "%L10N%TTLDTLSSRVRPRBLM");
  return atexit(sub_7FF91E585A50);
}


// ==== sub_7FF91DCADF30 @ rva 0x4DF30 ====
int sub_7FF91DCADF30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919078, "%L10N%TTLDTLSARSEEMNTFND");
  return atexit(sub_7FF91E585A80);
}


// ==== sub_7FF91DCADF60 @ rva 0x4DF60 ====
int sub_7FF91DCADF60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919088, "%L10N%TTLDTLSARSEEMSNTRNG");
  return atexit(sub_7FF91E585AB0);
}


// ==== sub_7FF91DCADF90 @ rva 0x4DF90 ====
int sub_7FF91DCADF90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191F8, "%L10N%TTLDTLSARSEEMSNTCNTD");
  return atexit(sub_7FF91E585AE0);
}


// ==== sub_7FF91DCADFC0 @ rva 0x4DFC0 ====
int sub_7FF91DCADFC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919150, "%L10N%TTLDTLSARSEEMSCNTSTRT");
  return atexit(sub_7FF91E585B10);
}


// ==== sub_7FF91DCADFF0 @ rva 0x4DFF0 ====
int sub_7FF91DCADFF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919220, "%L10N%TTLDTLSARSEEMNTLGN");
  return atexit(sub_7FF91E585B40);
}


// ==== sub_7FF91DCAE020 @ rva 0x4E020 ====
int sub_7FF91DCAE020()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190B8, "%L10N%TTLDTLSARSEEMGEN");
  return atexit(sub_7FF91E585B70);
}


// ==== sub_7FF91DCAE050 @ rva 0x4E050 ====
int sub_7FF91DCAE050()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191F0, "%L10N%ILGDINTRYAGN");
  return atexit(sub_7FF91E585BA0);
}


// ==== sub_7FF91DCAE080 @ rva 0x4E080 ====
int sub_7FF91DCAE080()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9190C0, "%L10N%TTLDTLARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E585BD0);
}


// ==== sub_7FF91DCAE0B0 @ rva 0x4E0B0 ====
int sub_7FF91DCAE0B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919120, "%L10N%TTLDTGTTNGTKN");
  return atexit(sub_7FF91E585C00);
}


// ==== sub_7FF91DCAE0E0 @ rva 0x4E0E0 ====
int sub_7FF91DCAE0E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919068, "%L10N%TTLDTDVCLMTRCHD");
  return atexit(sub_7FF91E585C30);
}


// ==== sub_7FF91DCAE110 @ rva 0x4E110 ====
int sub_7FF91DCAE110()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919160, "%L10N%LGIN");
  return atexit(sub_7FF91E585C60);
}


// ==== sub_7FF91DCAE140 @ rva 0x4E140 ====
int sub_7FF91DCAE140()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9191D8, "rvssv");
  return atexit(sub_7FF91E585C90);
}


// ==== sub_7FF91DCAE170 @ rva 0x4E170 ====
int sub_7FF91DCAE170()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5F90, "AUTHLIB.VERSION", 15);
  return atexit(sub_7FF91E585CC0);
}


// ==== sub_7FF91DCAE1A0 @ rva 0x4E1A0 ====
int sub_7FF91DCAE1A0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5FB0, "ENVIRONMENT.DATA", 16);
  return atexit(sub_7FF91E585D40);
}


// ==== sub_7FF91DCAE1D0 @ rva 0x4E1D0 ====
int sub_7FF91DCAE1D0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6010, "RCM.VERSION", 11);
  return atexit(sub_7FF91E585DC0);
}


// ==== sub_7FF91DCAE200 @ rva 0x4E200 ====
int sub_7FF91DCAE200()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5FF0, "RCM.INSTALLATION.PATH", 21);
  return atexit(sub_7FF91E585E40);
}


// ==== sub_7FF91DCAE230 @ rva 0x4E230 ====
int sub_7FF91DCAE230()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6030, "AUTHLIB.VERSION.STATUS", 22);
  return atexit(sub_7FF91E585EC0);
}


// ==== sub_7FF91DCAE260 @ rva 0x4E260 ====
int sub_7FF91DCAE260()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F5FD0, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", 64);
  return atexit(sub_7FF91E585F40);
}


// ==== sub_7FF91DCAE290 @ rva 0x4E290 ====
int sub_7FF91DCAE290()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193B8, "133783475");
  return atexit(sub_7FF91E585FC0);
}


// ==== sub_7FF91DCAE2C0 @ rva 0x4E2C0 ====
// Hidden C++ exception states: #wind=2
int sub_7FF91DCAE2C0()
{
  __int64 v0; // rcx
  char *v1; // rcx

  sub_7FF91DD55780(&qword_7FF91E919390, 8);
  v0 = dword_7FF91E91939C++;
  v1 = (char *)qword_7FF91E919390 + 8 * v0;
  if ( v1 )
    sub_7FF91DD5DCD0(v1, "%L10N%USERNAME");
  return atexit(sub_7FF91E585FF0);
}


// ==== sub_7FF91DCAE330 @ rva 0x4E330 ====
int sub_7FF91DCAE330()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919368, "%L10N%HOTHNG");
  return atexit(sub_7FF91E586010);
}


// ==== sub_7FF91DCAE360 @ rva 0x4E360 ====
int sub_7FF91DCAE360()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919318, "%L10N%LOADINGSAMPLES");
  return atexit(sub_7FF91E586040);
}


// ==== sub_7FF91DCAE390 @ rva 0x4E390 ====
int sub_7FF91DCAE390()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919320, "%L10N%NOCONNECTION");
  return atexit(sub_7FF91E586070);
}


// ==== sub_7FF91DCAE3C0 @ rva 0x4E3C0 ====
int sub_7FF91DCAE3C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193A8, "%L10N%NHOTH");
  return atexit(sub_7FF91E5860A0);
}


// ==== sub_7FF91DCAE3F0 @ rva 0x4E3F0 ====
int sub_7FF91DCAE3F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192F8, "%L10N%XPRDHOTH");
  return atexit(sub_7FF91E5860D0);
}


// ==== sub_7FF91DCAE420 @ rva 0x4E420 ====
int sub_7FF91DCAE420()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192D0, "%L10N%HOTHED");
  return atexit(sub_7FF91E586100);
}


// ==== sub_7FF91DCAE450 @ rva 0x4E450 ====
int sub_7FF91DCAE450()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919338, "%L10N%HOTHOUTAGE");
  return atexit(sub_7FF91E586130);
}


// ==== sub_7FF91DCAE480 @ rva 0x4E480 ====
int sub_7FF91DCAE480()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193D8, "%L10N%HOTHRRR");
  return atexit(sub_7FF91E586160);
}


// ==== sub_7FF91DCAE4B0 @ rva 0x4E4B0 ====
int sub_7FF91DCAE4B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192E8, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E586190);
}


// ==== sub_7FF91DCAE4E0 @ rva 0x4E4E0 ====
int sub_7FF91DCAE4E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193E0, "%L10N%INSTRUMENTNOTFOUND");
  return atexit(sub_7FF91E5861C0);
}


// ==== sub_7FF91DCAE510 @ rva 0x4E510 ====
int sub_7FF91DCAE510()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192C0, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E5861F0);
}


// ==== sub_7FF91DCAE540 @ rva 0x4E540 ====
int sub_7FF91DCAE540()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919350, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E586220);
}


// ==== sub_7FF91DCAE570 @ rva 0x4E570 ====
int sub_7FF91DCAE570()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919300, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E586250);
}


// ==== sub_7FF91DCAE5A0 @ rva 0x4E5A0 ====
int sub_7FF91DCAE5A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919348, "%L10N%NOPERSPECTIVES");
  return atexit(sub_7FF91E586280);
}


// ==== sub_7FF91DCAE5D0 @ rva 0x4E5D0 ====
int sub_7FF91DCAE5D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919488, "%L10N%LOADINGCANCELLED");
  return atexit(sub_7FF91E5862B0);
}


// ==== sub_7FF91DCAE600 @ rva 0x4E600 ====
int sub_7FF91DCAE600()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193C0, "%L10N%MISSINGPARAMETER");
  return atexit(sub_7FF91E5862E0);
}


// ==== sub_7FF91DCAE630 @ rva 0x4E630 ====
int sub_7FF91DCAE630()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919420, "%L10N%PROGRAMMERERROR");
  return atexit(sub_7FF91E586310);
}


// ==== sub_7FF91DCAE660 @ rva 0x4E660 ====
int sub_7FF91DCAE660()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192C8, "%L10N%CANNOTLOADANOTHER");
  return atexit(sub_7FF91E586340);
}


// ==== sub_7FF91DCAE690 @ rva 0x4E690 ====
int sub_7FF91DCAE690()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193E8, "%L10N%VRSNCHCKRRR");
  return atexit(sub_7FF91E586370);
}


// ==== sub_7FF91DCAE6C0 @ rva 0x4E6C0 ====
int sub_7FF91DCAE6C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193F0, "%L10N%VRSNCHCKRRRFTR");
  return atexit(sub_7FF91E5863A0);
}


// ==== sub_7FF91DCAE6F0 @ rva 0x4E6F0 ====
int sub_7FF91DCAE6F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919490, "%L10N%IHOTH");
  return atexit(sub_7FF91E5863D0);
}


// ==== sub_7FF91DCAE720 @ rva 0x4E720 ====
int sub_7FF91DCAE720()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919330, "%L10N%HOTHUUIDNOTFOUND");
  return atexit(sub_7FF91E586400);
}


// ==== sub_7FF91DCAE750 @ rva 0x4E750 ====
int sub_7FF91DCAE750()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192A0, "%L10N%HOTHGRACEDAY");
  return atexit(sub_7FF91E586430);
}


// ==== sub_7FF91DCAE780 @ rva 0x4E780 ====
int sub_7FF91DCAE780()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919478, "%L10N%HOTHGRACEDAYS");
  return atexit(sub_7FF91E586460);
}


// ==== sub_7FF91DCAE7B0 @ rva 0x4E7B0 ====
int sub_7FF91DCAE7B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193B0, "%L10N%HOTHGRACEHOUR");
  return atexit(sub_7FF91E586490);
}


// ==== sub_7FF91DCAE7E0 @ rva 0x4E7E0 ====
int sub_7FF91DCAE7E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919400, "%L10N%HOTHGRACEHOURS");
  return atexit(sub_7FF91E5864C0);
}


// ==== sub_7FF91DCAE810 @ rva 0x4E810 ====
int sub_7FF91DCAE810()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919308, "%L10N%HOTHGRACEMINUTE");
  return atexit(sub_7FF91E5864F0);
}


// ==== sub_7FF91DCAE840 @ rva 0x4E840 ====
int sub_7FF91DCAE840()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193D0, "%L10N%HOTHGRACEMINUTES");
  return atexit(sub_7FF91E586520);
}


// ==== sub_7FF91DCAE870 @ rva 0x4E870 ====
int sub_7FF91DCAE870()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919440, "%L10N%NHOTH2");
  return atexit(sub_7FF91E586550);
}


// ==== sub_7FF91DCAE8A0 @ rva 0x4E8A0 ====
int sub_7FF91DCAE8A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919480, "%L10N%HOTHRRRTITLEBAR");
  return atexit(sub_7FF91E586580);
}


// ==== sub_7FF91DCAE8D0 @ rva 0x4E8D0 ====
int sub_7FF91DCAE8D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192F0, "%L10N%RTRYHOTHBUTTON");
  return atexit(sub_7FF91E5865B0);
}


// ==== sub_7FF91DCAE900 @ rva 0x4E900 ====
int sub_7FF91DCAE900()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919290, "%L10N%ALERTWINDOWINSTRUMENTLOAD");
  return atexit(sub_7FF91E5865E0);
}


// ==== sub_7FF91DCAE930 @ rva 0x4E930 ====
int sub_7FF91DCAE930()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919378, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E586610);
}


// ==== sub_7FF91DCAE960 @ rva 0x4E960 ====
int sub_7FF91DCAE960()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919358, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E586640);
}


// ==== sub_7FF91DCAE990 @ rva 0x4E990 ====
int sub_7FF91DCAE990()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919310, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E586670);
}


// ==== sub_7FF91DCAE9C0 @ rva 0x4E9C0 ====
int sub_7FF91DCAE9C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919448, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E5866A0);
}


// ==== sub_7FF91DCAE9F0 @ rva 0x4E9F0 ====
int sub_7FF91DCAE9F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192B0, "%L10N%BUSASSIGNMENTTITLEBAR");
  return atexit(sub_7FF91E5866D0);
}


// ==== sub_7FF91DCAEA20 @ rva 0x4EA20 ====
int sub_7FF91DCAEA20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919498, "%L10N%BUSASSIGNMENTFAILED");
  return atexit(sub_7FF91E586700);
}


// ==== sub_7FF91DCAEA50 @ rva 0x4EA50 ====
int sub_7FF91DCAEA50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919468, "%L10N%ARSEEMNOTFOUNDERROR");
  return atexit(sub_7FF91E586730);
}


// ==== sub_7FF91DCAEA80 @ rva 0x4EA80 ====
int sub_7FF91DCAEA80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192B8, "%L10N%ARSEEMSVCNOTRUNNINGERROR");
  return atexit(sub_7FF91E586760);
}


// ==== sub_7FF91DCAEAB0 @ rva 0x4EAB0 ====
int sub_7FF91DCAEAB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919450, "%L10N%ARSEEMSVCCANTSTARTERROR");
  return atexit(sub_7FF91E586790);
}


// ==== sub_7FF91DCAEAE0 @ rva 0x4EAE0 ====
int sub_7FF91DCAEAE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919460, "%L10N%ARSEEMSVCNOTCONNECTEDERROR");
  return atexit(sub_7FF91E5867C0);
}


// ==== sub_7FF91DCAEB10 @ rva 0x4EB10 ====
int sub_7FF91DCAEB10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919388, "%L10N%ARSEEMSVCNOTLOGGEDINERROR");
  return atexit(sub_7FF91E5867F0);
}


// ==== sub_7FF91DCAEB40 @ rva 0x4EB40 ====
int sub_7FF91DCAEB40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919360, "%L10N%ARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E586820);
}


// ==== sub_7FF91DCAEB70 @ rva 0x4EB70 ====
int sub_7FF91DCAEB70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193C8, "%L10N%GTTNGTKN");
  return atexit(sub_7FF91E586850);
}


// ==== sub_7FF91DCAEBA0 @ rva 0x4EBA0 ====
int sub_7FF91DCAEBA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919470, "%L10N%DVCLMTRCHD");
  return atexit(sub_7FF91E586880);
}


// ==== sub_7FF91DCAEBD0 @ rva 0x4EBD0 ====
int sub_7FF91DCAEBD0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919418, "%L10N%CNTCTNGSRVC");
  return atexit(sub_7FF91E5868B0);
}


// ==== sub_7FF91DCAEC00 @ rva 0x4EC00 ====
int sub_7FF91DCAEC00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919428, "%L10N%TTLDTLSNOCONNECTION");
  return atexit(sub_7FF91E5868E0);
}


// ==== sub_7FF91DCAEC30 @ rva 0x4EC30 ====
int sub_7FF91DCAEC30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919458, "%L10N%TTLDTLSUNOTH");
  return atexit(sub_7FF91E586910);
}


// ==== sub_7FF91DCAEC60 @ rva 0x4EC60 ====
int sub_7FF91DCAEC60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919430, "%L10N%TTLDTLSEXPRD");
  return atexit(sub_7FF91E586940);
}


// ==== sub_7FF91DCAEC90 @ rva 0x4EC90 ====
int sub_7FF91DCAEC90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919328, "%L10N%TTLDTLSSRVRPRBLM");
  return atexit(sub_7FF91E586970);
}


// ==== sub_7FF91DCAECC0 @ rva 0x4ECC0 ====
int sub_7FF91DCAECC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919298, "%L10N%TTLDTLSARSEEMNTFND");
  return atexit(sub_7FF91E5869A0);
}


// ==== sub_7FF91DCAECF0 @ rva 0x4ECF0 ====
int sub_7FF91DCAECF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192A8, "%L10N%TTLDTLSARSEEMSNTRNG");
  return atexit(sub_7FF91E5869D0);
}


// ==== sub_7FF91DCAED20 @ rva 0x4ED20 ====
int sub_7FF91DCAED20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919410, "%L10N%TTLDTLSARSEEMSNTCNTD");
  return atexit(sub_7FF91E586A00);
}


// ==== sub_7FF91DCAED50 @ rva 0x4ED50 ====
int sub_7FF91DCAED50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919370, "%L10N%TTLDTLSARSEEMSCNTSTRT");
  return atexit(sub_7FF91E586A30);
}


// ==== sub_7FF91DCAED80 @ rva 0x4ED80 ====
int sub_7FF91DCAED80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919438, "%L10N%TTLDTLSARSEEMNTLGN");
  return atexit(sub_7FF91E586A60);
}


// ==== sub_7FF91DCAEDB0 @ rva 0x4EDB0 ====
int sub_7FF91DCAEDB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192D8, "%L10N%TTLDTLSARSEEMGEN");
  return atexit(sub_7FF91E586A90);
}


// ==== sub_7FF91DCAEDE0 @ rva 0x4EDE0 ====
int sub_7FF91DCAEDE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919408, "%L10N%ILGDINTRYAGN");
  return atexit(sub_7FF91E586AC0);
}


// ==== sub_7FF91DCAEE10 @ rva 0x4EE10 ====
int sub_7FF91DCAEE10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9192E0, "%L10N%TTLDTLARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E586AF0);
}


// ==== sub_7FF91DCAEE40 @ rva 0x4EE40 ====
int sub_7FF91DCAEE40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919340, "%L10N%TTLDTGTTNGTKN");
  return atexit(sub_7FF91E586B20);
}


// ==== sub_7FF91DCAEE70 @ rva 0x4EE70 ====
int sub_7FF91DCAEE70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919288, "%L10N%TTLDTDVCLMTRCHD");
  return atexit(sub_7FF91E586B50);
}


// ==== sub_7FF91DCAEEA0 @ rva 0x4EEA0 ====
int sub_7FF91DCAEEA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919380, "%L10N%LGIN");
  return atexit(sub_7FF91E586B80);
}


// ==== sub_7FF91DCAEED0 @ rva 0x4EED0 ====
int sub_7FF91DCAEED0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9193F8, "rvssv");
  return atexit(sub_7FF91E586BB0);
}


// ==== sub_7FF91DCAEF00 @ rva 0x4EF00 ====
int sub_7FF91DCAEF00()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6050, "AUTHLIB.VERSION", 15);
  return atexit(sub_7FF91E586BE0);
}


// ==== sub_7FF91DCAEF30 @ rva 0x4EF30 ====
int sub_7FF91DCAEF30()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6070, "ENVIRONMENT.DATA", 16);
  return atexit(sub_7FF91E586C60);
}


// ==== sub_7FF91DCAEF60 @ rva 0x4EF60 ====
int sub_7FF91DCAEF60()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F60D0, "RCM.VERSION", 11);
  return atexit(sub_7FF91E586CE0);
}


// ==== sub_7FF91DCAEF90 @ rva 0x4EF90 ====
int sub_7FF91DCAEF90()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F60B0, "RCM.INSTALLATION.PATH", 21);
  return atexit(sub_7FF91E586D60);
}


// ==== sub_7FF91DCAEFC0 @ rva 0x4EFC0 ====
int sub_7FF91DCAEFC0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F60F0, "AUTHLIB.VERSION.STATUS", 22);
  return atexit(sub_7FF91E586DE0);
}


// ==== sub_7FF91DCAEFF0 @ rva 0x4EFF0 ====
int sub_7FF91DCAEFF0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6090, "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", 64);
  return atexit(sub_7FF91E586E60);
}


// ==== sub_7FF91DCAF020 @ rva 0x4F020 ====
int sub_7FF91DCAF020()
{
  return atexit((void (__cdecl *)())sub_7FF91E586F10);
}


// ==== sub_7FF91DCAF030 @ rva 0x4F030 ====
int sub_7FF91DCAF030()
{
  return atexit((void (__cdecl *)())nullsub_110);
}


// ==== sub_7FF91DCAF040 @ rva 0x4F040 ====
int sub_7FF91DCAF040()
{
  return atexit((void (__cdecl *)())sub_7FF91E586F50);
}


// ==== sub_7FF91DCAF050 @ rva 0x4F050 ====
int sub_7FF91DCAF050()
{
  return atexit((void (__cdecl *)())nullsub_111);
}


// ==== sub_7FF91DCAF060 @ rva 0x4F060 ====
int sub_7FF91DCAF060()
{
  return atexit((void (__cdecl *)())sub_7FF91E587070);
}


// ==== sub_7FF91DCAF070 @ rva 0x4F070 ====
int sub_7FF91DCAF070()
{
  return atexit((void (__cdecl *)())sub_7FF91E587080);
}


// ==== sub_7FF91DCAF080 @ rva 0x4F080 ====
int sub_7FF91DCAF080()
{
  return atexit((void (__cdecl *)())sub_7FF91E587090);
}


// ==== sub_7FF91DCAF090 @ rva 0x4F090 ====
int sub_7FF91DCAF090()
{
  return atexit((void (__cdecl *)())sub_7FF91E5870A0);
}


// ==== sub_7FF91DCAF0A0 @ rva 0x4F0A0 ====
int sub_7FF91DCAF0A0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5870B0);
}


// ==== sub_7FF91DCAF0B0 @ rva 0x4F0B0 ====
int sub_7FF91DCAF0B0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5870C0);
}


// ==== sub_7FF91DCAF0C0 @ rva 0x4F0C0 ====
int sub_7FF91DCAF0C0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5870D0);
}


// ==== sub_7FF91DCAF0D0 @ rva 0x4F0D0 ====
int sub_7FF91DCAF0D0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5870E0);
}


// ==== sub_7FF91DCAF0E0 @ rva 0x4F0E0 ====
int sub_7FF91DCAF0E0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5870F0);
}


// ==== sub_7FF91DCAF0F0 @ rva 0x4F0F0 ====
int sub_7FF91DCAF0F0()
{
  return atexit((void (__cdecl *)())sub_7FF91E587100);
}


// ==== sub_7FF91DCAF100 @ rva 0x4F100 ====
int sub_7FF91DCAF100()
{
  return atexit((void (__cdecl *)())sub_7FF91E587110);
}


// ==== sub_7FF91DCAF110 @ rva 0x4F110 ====
int sub_7FF91DCAF110()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9194A8, "text");
  return atexit(sub_7FF91E587300);
}


// ==== sub_7FF91DCAF140 @ rva 0x4F140 ====
LARGE_INTEGER sub_7FF91DCAF140()
{
  LARGE_INTEGER Frequency; // [rsp+30h] [rbp+8h] BYREF

  timeBeginPeriod(1u);
  QueryPerformanceFrequency(&Frequency);
  qword_7FF91E9194B8 = Frequency.QuadPart;
  *(double *)&qword_7FF91E9194C8 = 1000.0 / (double)(int)Frequency.LowPart;
  return Frequency;
}


// ==== sub_7FF91DCAF190 @ rva 0x4F190 ====
int sub_7FF91DCAF190()
{
  hHandle = CreateEventW(nullptr, 0, 0, nullptr);
  return atexit(heap_term_0);
}


// ==== sub_7FF91DCAF1C0 @ rva 0x4F1C0 ====
int sub_7FF91DCAF1C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919600, "133783475");
  return atexit(sub_7FF91E587370);
}


// ==== sub_7FF91DCAF1F0 @ rva 0x4F1F0 ====
// Hidden C++ exception states: #wind=2
int sub_7FF91DCAF1F0()
{
  __int64 v0; // rcx
  char *v1; // rcx

  sub_7FF91DD55780(&qword_7FF91E9195E0, 8);
  v0 = dword_7FF91E9195EC++;
  v1 = (char *)qword_7FF91E9195E0 + 8 * v0;
  if ( v1 )
    sub_7FF91DD5DCD0(v1, "%L10N%USERNAME");
  return atexit(sub_7FF91E5873A0);
}


// ==== sub_7FF91DCAF260 @ rva 0x4F260 ====
int sub_7FF91DCAF260()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9195B0, "%L10N%HOTHNG");
  return atexit(sub_7FF91E5873C0);
}


// ==== sub_7FF91DCAF290 @ rva 0x4F290 ====
int sub_7FF91DCAF290()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919560, "%L10N%LOADINGSAMPLES");
  return atexit(sub_7FF91E5873F0);
}


// ==== sub_7FF91DCAF2C0 @ rva 0x4F2C0 ====
int sub_7FF91DCAF2C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919568, "%L10N%NOCONNECTION");
  return atexit(sub_7FF91E587420);
}


// ==== sub_7FF91DCAF2F0 @ rva 0x4F2F0 ====
int sub_7FF91DCAF2F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9195F0, "%L10N%NHOTH");
  return atexit(sub_7FF91E587450);
}


// ==== sub_7FF91DCAF320 @ rva 0x4F320 ====
int sub_7FF91DCAF320()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919540, "%L10N%XPRDHOTH");
  return atexit(sub_7FF91E587480);
}


// ==== sub_7FF91DCAF350 @ rva 0x4F350 ====
int sub_7FF91DCAF350()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919518, "%L10N%HOTHED");
  return atexit(sub_7FF91E5874B0);
}


// ==== sub_7FF91DCAF380 @ rva 0x4F380 ====
int sub_7FF91DCAF380()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919580, "%L10N%HOTHOUTAGE");
  return atexit(sub_7FF91E5874E0);
}


// ==== sub_7FF91DCAF3B0 @ rva 0x4F3B0 ====
int sub_7FF91DCAF3B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919628, "%L10N%HOTHRRR");
  return atexit(sub_7FF91E587510);
}


// ==== sub_7FF91DCAF3E0 @ rva 0x4F3E0 ====
int sub_7FF91DCAF3E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919530, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E587540);
}


// ==== sub_7FF91DCAF410 @ rva 0x4F410 ====
int sub_7FF91DCAF410()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919630, "%L10N%INSTRUMENTNOTFOUND");
  return atexit(sub_7FF91E587570);
}


// ==== sub_7FF91DCAF440 @ rva 0x4F440 ====
int sub_7FF91DCAF440()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919508, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E5875A0);
}


// ==== sub_7FF91DCAF470 @ rva 0x4F470 ====
int sub_7FF91DCAF470()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919598, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E5875D0);
}


// ==== sub_7FF91DCAF4A0 @ rva 0x4F4A0 ====
int sub_7FF91DCAF4A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919548, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E587600);
}


// ==== sub_7FF91DCAF4D0 @ rva 0x4F4D0 ====
int sub_7FF91DCAF4D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919590, "%L10N%NOPERSPECTIVES");
  return atexit(sub_7FF91E587630);
}


// ==== sub_7FF91DCAF500 @ rva 0x4F500 ====
int sub_7FF91DCAF500()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919708, "%L10N%LOADINGCANCELLED");
  return atexit(sub_7FF91E587660);
}


// ==== sub_7FF91DCAF530 @ rva 0x4F530 ====
int sub_7FF91DCAF530()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919608, "%L10N%MISSINGPARAMETER");
  return atexit(sub_7FF91E587690);
}


// ==== sub_7FF91DCAF560 @ rva 0x4F560 ====
int sub_7FF91DCAF560()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196A0, "%L10N%PROGRAMMERERROR");
  return atexit(sub_7FF91E5876C0);
}


// ==== sub_7FF91DCAF590 @ rva 0x4F590 ====
int sub_7FF91DCAF590()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919510, "%L10N%CANNOTLOADANOTHER");
  return atexit(sub_7FF91E5876F0);
}


// ==== sub_7FF91DCAF5C0 @ rva 0x4F5C0 ====
int sub_7FF91DCAF5C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919638, "%L10N%VRSNCHCKRRR");
  return atexit(sub_7FF91E587720);
}


// ==== sub_7FF91DCAF5F0 @ rva 0x4F5F0 ====
int sub_7FF91DCAF5F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919640, "%L10N%VRSNCHCKRRRFTR");
  return atexit(sub_7FF91E587750);
}


// ==== sub_7FF91DCAF620 @ rva 0x4F620 ====
int sub_7FF91DCAF620()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919710, "%L10N%IHOTH");
  return atexit(sub_7FF91E587780);
}


// ==== sub_7FF91DCAF650 @ rva 0x4F650 ====
int sub_7FF91DCAF650()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919578, "%L10N%HOTHUUIDNOTFOUND");
  return atexit(sub_7FF91E5877B0);
}


// ==== sub_7FF91DCAF680 @ rva 0x4F680 ====
int sub_7FF91DCAF680()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9194E8, "%L10N%HOTHGRACEDAY");
  return atexit(sub_7FF91E5877E0);
}


// ==== sub_7FF91DCAF6B0 @ rva 0x4F6B0 ====
int sub_7FF91DCAF6B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196F8, "%L10N%HOTHGRACEDAYS");
  return atexit(sub_7FF91E587810);
}


// ==== sub_7FF91DCAF6E0 @ rva 0x4F6E0 ====
int sub_7FF91DCAF6E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9195F8, "%L10N%HOTHGRACEHOUR");
  return atexit(sub_7FF91E587840);
}


// ==== sub_7FF91DCAF710 @ rva 0x4F710 ====
int sub_7FF91DCAF710()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919680, "%L10N%HOTHGRACEHOURS");
  return atexit(sub_7FF91E587870);
}


// ==== sub_7FF91DCAF740 @ rva 0x4F740 ====
int sub_7FF91DCAF740()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919550, "%L10N%HOTHGRACEMINUTE");
  return atexit(sub_7FF91E5878A0);
}


// ==== sub_7FF91DCAF770 @ rva 0x4F770 ====
int sub_7FF91DCAF770()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919620, "%L10N%HOTHGRACEMINUTES");
  return atexit(sub_7FF91E5878D0);
}


// ==== sub_7FF91DCAF7A0 @ rva 0x4F7A0 ====
int sub_7FF91DCAF7A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196C0, "%L10N%NHOTH2");
  return atexit(sub_7FF91E587900);
}


// ==== sub_7FF91DCAF7D0 @ rva 0x4F7D0 ====
int sub_7FF91DCAF7D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919700, "%L10N%HOTHRRRTITLEBAR");
  return atexit(sub_7FF91E587930);
}


// ==== sub_7FF91DCAF800 @ rva 0x4F800 ====
int sub_7FF91DCAF800()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919538, "%L10N%RTRYHOTHBUTTON");
  return atexit(sub_7FF91E587960);
}


// ==== sub_7FF91DCAF830 @ rva 0x4F830 ====
int sub_7FF91DCAF830()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9194D8, "%L10N%ALERTWINDOWINSTRUMENTLOAD");
  return atexit(sub_7FF91E587990);
}


// ==== sub_7FF91DCAF860 @ rva 0x4F860 ====
int sub_7FF91DCAF860()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9195C0, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E5879C0);
}


// ==== sub_7FF91DCAF890 @ rva 0x4F890 ====
int sub_7FF91DCAF890()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9195A0, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E5879F0);
}


// ==== sub_7FF91DCAF8C0 @ rva 0x4F8C0 ====
int sub_7FF91DCAF8C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919558, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E587A20);
}


// ==== sub_7FF91DCAF8F0 @ rva 0x4F8F0 ====
int sub_7FF91DCAF8F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196C8, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E587A50);
}


// ==== sub_7FF91DCAF920 @ rva 0x4F920 ====
int sub_7FF91DCAF920()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9194F8, "%L10N%BUSASSIGNMENTTITLEBAR");
  return atexit(sub_7FF91E587A80);
}


// ==== sub_7FF91DCAF950 @ rva 0x4F950 ====
int sub_7FF91DCAF950()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919718, "%L10N%BUSASSIGNMENTFAILED");
  return atexit(sub_7FF91E587AB0);
}


// ==== sub_7FF91DCAF980 @ rva 0x4F980 ====
int sub_7FF91DCAF980()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196E8, "%L10N%ARSEEMNOTFOUNDERROR");
  return atexit(sub_7FF91E587AE0);
}


// ==== sub_7FF91DCAF9B0 @ rva 0x4F9B0 ====
int sub_7FF91DCAF9B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919500, "%L10N%ARSEEMSVCNOTRUNNINGERROR");
  return atexit(sub_7FF91E587B10);
}


// ==== sub_7FF91DCAF9E0 @ rva 0x4F9E0 ====
int sub_7FF91DCAF9E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196D0, "%L10N%ARSEEMSVCCANTSTARTERROR");
  return atexit(sub_7FF91E587B40);
}


// ==== sub_7FF91DCAFA10 @ rva 0x4FA10 ====
int sub_7FF91DCAFA10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196E0, "%L10N%ARSEEMSVCNOTCONNECTEDERROR");
  return atexit(sub_7FF91E587B70);
}


// ==== sub_7FF91DCAFA40 @ rva 0x4FA40 ====
int sub_7FF91DCAFA40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9195D0, "%L10N%ARSEEMSVCNOTLOGGEDINERROR");
  return atexit(sub_7FF91E587BA0);
}


// ==== sub_7FF91DCAFA70 @ rva 0x4FA70 ====
int sub_7FF91DCAFA70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9195A8, "%L10N%ARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E587BD0);
}


// ==== sub_7FF91DCAFAA0 @ rva 0x4FAA0 ====
int sub_7FF91DCAFAA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919618, "%L10N%GTTNGTKN");
  return atexit(sub_7FF91E587C00);
}


// ==== sub_7FF91DCAFAD0 @ rva 0x4FAD0 ====
int sub_7FF91DCAFAD0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196F0, "%L10N%DVCLMTRCHD");
  return atexit(sub_7FF91E587C30);
}


// ==== sub_7FF91DCAFB00 @ rva 0x4FB00 ====
int sub_7FF91DCAFB00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919698, "%L10N%CNTCTNGSRVC");
  return atexit(sub_7FF91E587C60);
}


// ==== sub_7FF91DCAFB30 @ rva 0x4FB30 ====
int sub_7FF91DCAFB30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196A8, "%L10N%TTLDTLSNOCONNECTION");
  return atexit(sub_7FF91E587C90);
}


// ==== sub_7FF91DCAFB60 @ rva 0x4FB60 ====
int sub_7FF91DCAFB60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196D8, "%L10N%TTLDTLSUNOTH");
  return atexit(sub_7FF91E587CC0);
}


// ==== sub_7FF91DCAFB90 @ rva 0x4FB90 ====
int sub_7FF91DCAFB90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196B0, "%L10N%TTLDTLSEXPRD");
  return atexit(sub_7FF91E587CF0);
}


// ==== sub_7FF91DCAFBC0 @ rva 0x4FBC0 ====
int sub_7FF91DCAFBC0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919570, "%L10N%TTLDTLSSRVRPRBLM");
  return atexit(sub_7FF91E587D20);
}


// ==== sub_7FF91DCAFBF0 @ rva 0x4FBF0 ====
int sub_7FF91DCAFBF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9194E0, "%L10N%TTLDTLSARSEEMNTFND");
  return atexit(sub_7FF91E587D50);
}


// ==== sub_7FF91DCAFC20 @ rva 0x4FC20 ====
int sub_7FF91DCAFC20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9194F0, "%L10N%TTLDTLSARSEEMSNTRNG");
  return atexit(sub_7FF91E587D80);
}


// ==== sub_7FF91DCAFC50 @ rva 0x4FC50 ====
int sub_7FF91DCAFC50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919690, "%L10N%TTLDTLSARSEEMSNTCNTD");
  return atexit(sub_7FF91E587DB0);
}


// ==== sub_7FF91DCAFC80 @ rva 0x4FC80 ====
int sub_7FF91DCAFC80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9195B8, "%L10N%TTLDTLSARSEEMSCNTSTRT");
  return atexit(sub_7FF91E587DE0);
}


// ==== sub_7FF91DCAFCB0 @ rva 0x4FCB0 ====
int sub_7FF91DCAFCB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9196B8, "%L10N%TTLDTLSARSEEMNTLGN");
  return atexit(sub_7FF91E587E10);
}


// ==== sub_7FF91DCAFCE0 @ rva 0x4FCE0 ====
int sub_7FF91DCAFCE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919520, "%L10N%TTLDTLSARSEEMGEN");
  return atexit(sub_7FF91E587E40);
}


// ==== sub_7FF91DCAFD10 @ rva 0x4FD10 ====
int sub_7FF91DCAFD10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919688, "%L10N%ILGDINTRYAGN");
  return atexit(sub_7FF91E587E70);
}


// ==== sub_7FF91DCAFD40 @ rva 0x4FD40 ====
int sub_7FF91DCAFD40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919528, "%L10N%TTLDTLARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E587EA0);
}


// ==== sub_7FF91DCAFD70 @ rva 0x4FD70 ====
int sub_7FF91DCAFD70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919588, "%L10N%TTLDTGTTNGTKN");
  return atexit(sub_7FF91E587ED0);
}


// ==== sub_7FF91DCAFDA0 @ rva 0x4FDA0 ====
int sub_7FF91DCAFDA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9194D0, "%L10N%TTLDTDVCLMTRCHD");
  return atexit(sub_7FF91E587F00);
}


// ==== sub_7FF91DCAFDD0 @ rva 0x4FDD0 ====
int sub_7FF91DCAFDD0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9195C8, "%L10N%LGIN");
  return atexit(sub_7FF91E587F30);
}


// ==== sub_7FF91DCAFE00 @ rva 0x4FE00 ====
int sub_7FF91DCAFE00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919678, "rvssv");
  return atexit(sub_7FF91E587F60);
}


// ==== sub_7FF91DCAFE30 @ rva 0x4FE30 ====
int sub_7FF91DCAFE30()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F61D0, "AUTHLIB.VERSION", 15);
  return atexit(sub_7FF91E587F90);
}


// ==== sub_7FF91DCAFE60 @ rva 0x4FE60 ====
int sub_7FF91DCAFE60()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F61F0, "ENVIRONMENT.DATA", 16);
  return atexit(sub_7FF91E588010);
}


// ==== sub_7FF91DCAFE90 @ rva 0x4FE90 ====
int sub_7FF91DCAFE90()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6230, "RCM.VERSION", 11);
  return atexit(sub_7FF91E588090);
}


// ==== sub_7FF91DCAFEC0 @ rva 0x4FEC0 ====
int sub_7FF91DCAFEC0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6210, "RCM.INSTALLATION.PATH", 21);
  return atexit(sub_7FF91E588110);
}


// ==== sub_7FF91DCAFEF0 @ rva 0x4FEF0 ====
int sub_7FF91DCAFEF0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6250, "AUTHLIB.VERSION.STATUS", 22);
  return atexit(sub_7FF91E588190);
}


// ==== sub_7FF91DCAFF20 @ rva 0x4FF20 ====
int sub_7FF91DCAFF20()
{
  InitializeCriticalSection(&stru_7FF91E919648);
  return atexit(sub_7FF91E588210);
}


// ==== sub_7FF91DCAFF50 @ rva 0x4FF50 ====
int sub_7FF91DCAFF50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919888, "133783475");
  return atexit(sub_7FF91E588220);
}


// ==== sub_7FF91DCAFF80 @ rva 0x4FF80 ====
// Hidden C++ exception states: #wind=2
int sub_7FF91DCAFF80()
{
  __int64 v0; // rcx
  char *v1; // rcx

  sub_7FF91DD55780(&qword_7FF91E919860, 8);
  v0 = dword_7FF91E91986C++;
  v1 = (char *)qword_7FF91E919860 + 8 * v0;
  if ( v1 )
    sub_7FF91DD5DCD0(v1, "%L10N%USERNAME");
  return atexit(sub_7FF91E588250);
}


// ==== sub_7FF91DCAFFF0 @ rva 0x4FFF0 ====
int sub_7FF91DCAFFF0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919800, "%L10N%HOTHNG");
  return atexit(sub_7FF91E588270);
}


// ==== sub_7FF91DCB0020 @ rva 0x50020 ====
int sub_7FF91DCB0020()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197B0, "%L10N%LOADINGSAMPLES");
  return atexit(sub_7FF91E5882A0);
}


// ==== sub_7FF91DCB0050 @ rva 0x50050 ====
int sub_7FF91DCB0050()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197B8, "%L10N%NOCONNECTION");
  return atexit(sub_7FF91E5882D0);
}


// ==== sub_7FF91DCB0080 @ rva 0x50080 ====
int sub_7FF91DCB0080()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919878, "%L10N%NHOTH");
  return atexit(sub_7FF91E588300);
}


// ==== sub_7FF91DCB00B0 @ rva 0x500B0 ====
int sub_7FF91DCB00B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919790, "%L10N%XPRDHOTH");
  return atexit(sub_7FF91E588330);
}


// ==== sub_7FF91DCB00E0 @ rva 0x500E0 ====
int sub_7FF91DCB00E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919768, "%L10N%HOTHED");
  return atexit(sub_7FF91E588360);
}


// ==== sub_7FF91DCB0110 @ rva 0x50110 ====
int sub_7FF91DCB0110()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197D0, "%L10N%HOTHOUTAGE");
  return atexit(sub_7FF91E588390);
}


// ==== sub_7FF91DCB0140 @ rva 0x50140 ====
int sub_7FF91DCB0140()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198A8, "%L10N%HOTHRRR");
  return atexit(sub_7FF91E5883C0);
}


// ==== sub_7FF91DCB0170 @ rva 0x50170 ====
int sub_7FF91DCB0170()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919780, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E5883F0);
}


// ==== sub_7FF91DCB01A0 @ rva 0x501A0 ====
int sub_7FF91DCB01A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198B0, "%L10N%INSTRUMENTNOTFOUND");
  return atexit(sub_7FF91E588420);
}


// ==== sub_7FF91DCB01D0 @ rva 0x501D0 ====
int sub_7FF91DCB01D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919758, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E588450);
}


// ==== sub_7FF91DCB0200 @ rva 0x50200 ====
int sub_7FF91DCB0200()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197E8, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E588480);
}


// ==== sub_7FF91DCB0230 @ rva 0x50230 ====
int sub_7FF91DCB0230()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919798, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E5884B0);
}


// ==== sub_7FF91DCB0260 @ rva 0x50260 ====
int sub_7FF91DCB0260()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197E0, "%L10N%NOPERSPECTIVES");
  return atexit(sub_7FF91E5884E0);
}


// ==== sub_7FF91DCB0290 @ rva 0x50290 ====
int sub_7FF91DCB0290()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919958, "%L10N%LOADINGCANCELLED");
  return atexit(sub_7FF91E588510);
}


// ==== sub_7FF91DCB02C0 @ rva 0x502C0 ====
int sub_7FF91DCB02C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919890, "%L10N%MISSINGPARAMETER");
  return atexit(sub_7FF91E588540);
}


// ==== sub_7FF91DCB02F0 @ rva 0x502F0 ====
int sub_7FF91DCB02F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198F0, "%L10N%PROGRAMMERERROR");
  return atexit(sub_7FF91E588570);
}


// ==== sub_7FF91DCB0320 @ rva 0x50320 ====
int sub_7FF91DCB0320()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919760, "%L10N%CANNOTLOADANOTHER");
  return atexit(sub_7FF91E5885A0);
}


// ==== sub_7FF91DCB0350 @ rva 0x50350 ====
int sub_7FF91DCB0350()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198B8, "%L10N%VRSNCHCKRRR");
  return atexit(sub_7FF91E5885D0);
}


// ==== sub_7FF91DCB0380 @ rva 0x50380 ====
int sub_7FF91DCB0380()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198C0, "%L10N%VRSNCHCKRRRFTR");
  return atexit(sub_7FF91E588600);
}


// ==== sub_7FF91DCB03B0 @ rva 0x503B0 ====
int sub_7FF91DCB03B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919960, "%L10N%IHOTH");
  return atexit(sub_7FF91E588630);
}


// ==== sub_7FF91DCB03E0 @ rva 0x503E0 ====
int sub_7FF91DCB03E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197C8, "%L10N%HOTHUUIDNOTFOUND");
  return atexit(sub_7FF91E588660);
}


// ==== sub_7FF91DCB0410 @ rva 0x50410 ====
int sub_7FF91DCB0410()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919738, "%L10N%HOTHGRACEDAY");
  return atexit(sub_7FF91E588690);
}


// ==== sub_7FF91DCB0440 @ rva 0x50440 ====
int sub_7FF91DCB0440()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919948, "%L10N%HOTHGRACEDAYS");
  return atexit(sub_7FF91E5886C0);
}


// ==== sub_7FF91DCB0470 @ rva 0x50470 ====
int sub_7FF91DCB0470()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919880, "%L10N%HOTHGRACEHOUR");
  return atexit(sub_7FF91E5886F0);
}


// ==== sub_7FF91DCB04A0 @ rva 0x504A0 ====
int sub_7FF91DCB04A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198D0, "%L10N%HOTHGRACEHOURS");
  return atexit(sub_7FF91E588720);
}


// ==== sub_7FF91DCB04D0 @ rva 0x504D0 ====
int sub_7FF91DCB04D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197A0, "%L10N%HOTHGRACEMINUTE");
  return atexit(sub_7FF91E588750);
}


// ==== sub_7FF91DCB0500 @ rva 0x50500 ====
int sub_7FF91DCB0500()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198A0, "%L10N%HOTHGRACEMINUTES");
  return atexit(sub_7FF91E588780);
}


// ==== sub_7FF91DCB0530 @ rva 0x50530 ====
int sub_7FF91DCB0530()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919910, "%L10N%NHOTH2");
  return atexit(sub_7FF91E5887B0);
}


// ==== sub_7FF91DCB0560 @ rva 0x50560 ====
int sub_7FF91DCB0560()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919950, "%L10N%HOTHRRRTITLEBAR");
  return atexit(sub_7FF91E5887E0);
}


// ==== sub_7FF91DCB0590 @ rva 0x50590 ====
int sub_7FF91DCB0590()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919788, "%L10N%RTRYHOTHBUTTON");
  return atexit(sub_7FF91E588810);
}


// ==== sub_7FF91DCB05C0 @ rva 0x505C0 ====
int sub_7FF91DCB05C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919728, "%L10N%ALERTWINDOWINSTRUMENTLOAD");
  return atexit(sub_7FF91E588840);
}


// ==== sub_7FF91DCB05F0 @ rva 0x505F0 ====
int sub_7FF91DCB05F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919810, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E588870);
}


// ==== sub_7FF91DCB0620 @ rva 0x50620 ====
int sub_7FF91DCB0620()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197F0, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E5888A0);
}


// ==== sub_7FF91DCB0650 @ rva 0x50650 ====
int sub_7FF91DCB0650()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197A8, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E5888D0);
}


// ==== sub_7FF91DCB0680 @ rva 0x50680 ====
int sub_7FF91DCB0680()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919918, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E588900);
}


// ==== sub_7FF91DCB06B0 @ rva 0x506B0 ====
int sub_7FF91DCB06B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919748, "%L10N%BUSASSIGNMENTTITLEBAR");
  return atexit(sub_7FF91E588930);
}


// ==== sub_7FF91DCB06E0 @ rva 0x506E0 ====
int sub_7FF91DCB06E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919968, "%L10N%BUSASSIGNMENTFAILED");
  return atexit(sub_7FF91E588960);
}


// ==== sub_7FF91DCB0710 @ rva 0x50710 ====
int sub_7FF91DCB0710()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919938, "%L10N%ARSEEMNOTFOUNDERROR");
  return atexit(sub_7FF91E588990);
}


// ==== sub_7FF91DCB0740 @ rva 0x50740 ====
int sub_7FF91DCB0740()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919750, "%L10N%ARSEEMSVCNOTRUNNINGERROR");
  return atexit(sub_7FF91E5889C0);
}


// ==== sub_7FF91DCB0770 @ rva 0x50770 ====
int sub_7FF91DCB0770()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919920, "%L10N%ARSEEMSVCCANTSTARTERROR");
  return atexit(sub_7FF91E5889F0);
}


// ==== sub_7FF91DCB07A0 @ rva 0x507A0 ====
int sub_7FF91DCB07A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919930, "%L10N%ARSEEMSVCNOTCONNECTEDERROR");
  return atexit(sub_7FF91E588A20);
}


// ==== sub_7FF91DCB07D0 @ rva 0x507D0 ====
int sub_7FF91DCB07D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919820, "%L10N%ARSEEMSVCNOTLOGGEDINERROR");
  return atexit(sub_7FF91E588A50);
}


// ==== sub_7FF91DCB0800 @ rva 0x50800 ====
int sub_7FF91DCB0800()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197F8, "%L10N%ARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E588A80);
}


// ==== sub_7FF91DCB0830 @ rva 0x50830 ====
int sub_7FF91DCB0830()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919898, "%L10N%GTTNGTKN");
  return atexit(sub_7FF91E588AB0);
}


// ==== sub_7FF91DCB0860 @ rva 0x50860 ====
int sub_7FF91DCB0860()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919940, "%L10N%DVCLMTRCHD");
  return atexit(sub_7FF91E588AE0);
}


// ==== sub_7FF91DCB0890 @ rva 0x50890 ====
int sub_7FF91DCB0890()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198E8, "%L10N%CNTCTNGSRVC");
  return atexit(sub_7FF91E588B10);
}


// ==== sub_7FF91DCB08C0 @ rva 0x508C0 ====
int sub_7FF91DCB08C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198F8, "%L10N%TTLDTLSNOCONNECTION");
  return atexit(sub_7FF91E588B40);
}


// ==== sub_7FF91DCB08F0 @ rva 0x508F0 ====
int sub_7FF91DCB08F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919928, "%L10N%TTLDTLSUNOTH");
  return atexit(sub_7FF91E588B70);
}


// ==== sub_7FF91DCB0920 @ rva 0x50920 ====
int sub_7FF91DCB0920()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919900, "%L10N%TTLDTLSEXPRD");
  return atexit(sub_7FF91E588BA0);
}


// ==== sub_7FF91DCB0950 @ rva 0x50950 ====
int sub_7FF91DCB0950()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197C0, "%L10N%TTLDTLSSRVRPRBLM");
  return atexit(sub_7FF91E588BD0);
}


// ==== sub_7FF91DCB0980 @ rva 0x50980 ====
int sub_7FF91DCB0980()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919730, "%L10N%TTLDTLSARSEEMNTFND");
  return atexit(sub_7FF91E588C00);
}


// ==== sub_7FF91DCB09B0 @ rva 0x509B0 ====
int sub_7FF91DCB09B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919740, "%L10N%TTLDTLSARSEEMSNTRNG");
  return atexit(sub_7FF91E588C30);
}


// ==== sub_7FF91DCB09E0 @ rva 0x509E0 ====
int sub_7FF91DCB09E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198E0, "%L10N%TTLDTLSARSEEMSNTCNTD");
  return atexit(sub_7FF91E588C60);
}


// ==== sub_7FF91DCB0A10 @ rva 0x50A10 ====
int sub_7FF91DCB0A10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919808, "%L10N%TTLDTLSARSEEMSCNTSTRT");
  return atexit(sub_7FF91E588C90);
}


// ==== sub_7FF91DCB0A40 @ rva 0x50A40 ====
int sub_7FF91DCB0A40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919908, "%L10N%TTLDTLSARSEEMNTLGN");
  return atexit(sub_7FF91E588CC0);
}


// ==== sub_7FF91DCB0A70 @ rva 0x50A70 ====
int sub_7FF91DCB0A70()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919770, "%L10N%TTLDTLSARSEEMGEN");
  return atexit(sub_7FF91E588CF0);
}


// ==== sub_7FF91DCB0AA0 @ rva 0x50AA0 ====
int sub_7FF91DCB0AA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198D8, "%L10N%ILGDINTRYAGN");
  return atexit(sub_7FF91E588D20);
}


// ==== sub_7FF91DCB0AD0 @ rva 0x50AD0 ====
int sub_7FF91DCB0AD0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919778, "%L10N%TTLDTLARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E588D50);
}


// ==== sub_7FF91DCB0B00 @ rva 0x50B00 ====
int sub_7FF91DCB0B00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9197D8, "%L10N%TTLDTGTTNGTKN");
  return atexit(sub_7FF91E588D80);
}


// ==== sub_7FF91DCB0B30 @ rva 0x50B30 ====
int sub_7FF91DCB0B30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919720, "%L10N%TTLDTDVCLMTRCHD");
  return atexit(sub_7FF91E588DB0);
}


// ==== sub_7FF91DCB0B60 @ rva 0x50B60 ====
int sub_7FF91DCB0B60()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919818, "%L10N%LGIN");
  return atexit(sub_7FF91E588DE0);
}


// ==== sub_7FF91DCB0B90 @ rva 0x50B90 ====
int sub_7FF91DCB0B90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9198C8, "rvssv");
  return atexit(sub_7FF91E588E10);
}


// ==== sub_7FF91DCB0BC0 @ rva 0x50BC0 ====
int sub_7FF91DCB0BC0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6270, "AUTHLIB.VERSION", 15);
  return atexit(sub_7FF91E588E40);
}


// ==== sub_7FF91DCB0BF0 @ rva 0x50BF0 ====
int sub_7FF91DCB0BF0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6290, "ENVIRONMENT.DATA", 16);
  return atexit(sub_7FF91E588EC0);
}


// ==== sub_7FF91DCB0C20 @ rva 0x50C20 ====
int sub_7FF91DCB0C20()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F62D0, "RCM.VERSION", 11);
  return atexit(sub_7FF91E588F40);
}


// ==== sub_7FF91DCB0C50 @ rva 0x50C50 ====
int sub_7FF91DCB0C50()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F62B0, "RCM.INSTALLATION.PATH", 21);
  return atexit(sub_7FF91E588FC0);
}


// ==== sub_7FF91DCB0C80 @ rva 0x50C80 ====
int sub_7FF91DCB0C80()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F62F0, "AUTHLIB.VERSION.STATUS", 22);
  return atexit(sub_7FF91E589040);
}


// ==== sub_7FF91DCB0CB0 @ rva 0x50CB0 ====
int sub_7FF91DCB0CB0()
{
  InitializeCriticalSection(&stru_7FF91E919828);
  qword_7FF91E919858 = 0;
  return atexit(sub_7FF91E5890C0);
}


// ==== sub_7FF91DCB0CE0 @ rva 0x50CE0 ====
int sub_7FF91DCB0CE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919980, "rvssv");
  return atexit(sub_7FF91E5890D0);
}


// ==== sub_7FF91DCB0D10 @ rva 0x50D10 ====
int sub_7FF91DCB0D10()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6310, "AUTHLIB.VERSION", 15);
  return atexit(sub_7FF91E589100);
}


// ==== sub_7FF91DCB0D40 @ rva 0x50D40 ====
int sub_7FF91DCB0D40()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6330, "ENVIRONMENT.DATA", 16);
  return atexit(sub_7FF91E589180);
}


// ==== sub_7FF91DCB0D70 @ rva 0x50D70 ====
int sub_7FF91DCB0D70()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6380, "RCM.VERSION", 11);
  return atexit(sub_7FF91E589200);
}


// ==== sub_7FF91DCB0DA0 @ rva 0x50DA0 ====
int sub_7FF91DCB0DA0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6360, "RCM.INSTALLATION.PATH", 21);
  return atexit(sub_7FF91E589280);
}


// ==== sub_7FF91DCB0DD0 @ rva 0x50DD0 ====
int sub_7FF91DCB0DD0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F63A0, "AUTHLIB.VERSION.STATUS", 22);
  return atexit(sub_7FF91E589300);
}


// ==== sub_7FF91DCB0E00 @ rva 0x50E00 ====
int sub_7FF91DCB0E00()
{
  InitializeCriticalSection(&stru_7FF91E919988);
  return atexit(sub_7FF91E589380);
}


// ==== sub_7FF91DCB0E30 @ rva 0x50E30 ====
int sub_7FF91DCB0E30()
{
  InitializeCriticalSection(&stru_7FF91E9199B8);
  return atexit(sub_7FF91E589390);
}


// ==== sub_7FF91DCB0E60 @ rva 0x50E60 ====
int sub_7FF91DCB0E60()
{
  return atexit((void (__cdecl *)())sub_7FF91E5893A0);
}


// ==== sub_7FF91DCB0E70 @ rva 0x50E70 ====
int sub_7FF91DCB0E70()
{
  void *v0; // rcx
  __int64 v2; // [rsp+30h] [rbp+8h] BYREF

  sub_7FF91DD5DCD0(&v2, "PropLock");
  qword_7FF91E9199F0 = nullptr;
  InitializeCriticalSection(&stru_7FF91E9199F8);
  qword_7FF91E919A28 = v2;
  if ( (*(_DWORD *)(v2 - 16) & 0x30000000) == 0 )
    _InterlockedExchangeAdd((volatile signed __int32 *)(v2 - 16), 1u);
  v0 = (void *)(v2 - 16);
  if ( (*(_DWORD *)(v2 - 16) & 0x30000000) == 0 && !_InterlockedExchangeAdd((volatile signed __int32 *)v0, 0xFFFFFFFF) )
    j_j_free_0(v0);
  return atexit(sub_7FF91E5893D0);
}


// ==== sub_7FF91DCB0F00 @ rva 0x50F00 ====
int sub_7FF91DCB0F00()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B58, "133783475");
  return atexit(sub_7FF91E5894B0);
}


// ==== sub_7FF91DCB0F30 @ rva 0x50F30 ====
// Hidden C++ exception states: #wind=2
int sub_7FF91DCB0F30()
{
  __int64 v0; // rcx
  char *v1; // rcx

  sub_7FF91DD55780(&qword_7FF91E919B30, 8);
  v0 = dword_7FF91E919B3C++;
  v1 = (char *)qword_7FF91E919B30 + 8 * v0;
  if ( v1 )
    sub_7FF91DD5DCD0(v1, "%L10N%USERNAME");
  return atexit(sub_7FF91E5894E0);
}


// ==== sub_7FF91DCB0FA0 @ rva 0x50FA0 ====
int sub_7FF91DCB0FA0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B08, "%L10N%HOTHNG");
  return atexit(sub_7FF91E589500);
}


// ==== sub_7FF91DCB0FD0 @ rva 0x50FD0 ====
int sub_7FF91DCB0FD0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AB8, "%L10N%LOADINGSAMPLES");
  return atexit(sub_7FF91E589530);
}


// ==== sub_7FF91DCB1000 @ rva 0x51000 ====
int sub_7FF91DCB1000()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AC0, "%L10N%NOCONNECTION");
  return atexit(sub_7FF91E589560);
}


// ==== sub_7FF91DCB1030 @ rva 0x51030 ====
int sub_7FF91DCB1030()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B48, "%L10N%NHOTH");
  return atexit(sub_7FF91E589590);
}


// ==== sub_7FF91DCB1060 @ rva 0x51060 ====
int sub_7FF91DCB1060()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A98, "%L10N%XPRDHOTH");
  return atexit(sub_7FF91E5895C0);
}


// ==== sub_7FF91DCB1090 @ rva 0x51090 ====
int sub_7FF91DCB1090()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A70, "%L10N%HOTHED");
  return atexit(sub_7FF91E5895F0);
}


// ==== sub_7FF91DCB10C0 @ rva 0x510C0 ====
int sub_7FF91DCB10C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AD8, "%L10N%HOTHOUTAGE");
  return atexit(sub_7FF91E589620);
}


// ==== sub_7FF91DCB10F0 @ rva 0x510F0 ====
int sub_7FF91DCB10F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B78, "%L10N%HOTHRRR");
  return atexit(sub_7FF91E589650);
}


// ==== sub_7FF91DCB1120 @ rva 0x51120 ====
int sub_7FF91DCB1120()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A88, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E589680);
}


// ==== sub_7FF91DCB1150 @ rva 0x51150 ====
int sub_7FF91DCB1150()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B80, "%L10N%INSTRUMENTNOTFOUND");
  return atexit(sub_7FF91E5896B0);
}


// ==== sub_7FF91DCB1180 @ rva 0x51180 ====
int sub_7FF91DCB1180()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A60, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E5896E0);
}


// ==== sub_7FF91DCB11B0 @ rva 0x511B0 ====
int sub_7FF91DCB11B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AF0, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E589710);
}


// ==== sub_7FF91DCB11E0 @ rva 0x511E0 ====
int sub_7FF91DCB11E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AA0, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E589740);
}


// ==== sub_7FF91DCB1210 @ rva 0x51210 ====
int sub_7FF91DCB1210()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AE8, "%L10N%NOPERSPECTIVES");
  return atexit(sub_7FF91E589770);
}


// ==== sub_7FF91DCB1240 @ rva 0x51240 ====
int sub_7FF91DCB1240()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919C28, "%L10N%LOADINGCANCELLED");
  return atexit(sub_7FF91E5897A0);
}


// ==== sub_7FF91DCB1270 @ rva 0x51270 ====
int sub_7FF91DCB1270()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B60, "%L10N%MISSINGPARAMETER");
  return atexit(sub_7FF91E5897D0);
}


// ==== sub_7FF91DCB12A0 @ rva 0x512A0 ====
int sub_7FF91DCB12A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BC0, "%L10N%PROGRAMMERERROR");
  return atexit(sub_7FF91E589800);
}


// ==== sub_7FF91DCB12D0 @ rva 0x512D0 ====
int sub_7FF91DCB12D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A68, "%L10N%CANNOTLOADANOTHER");
  return atexit(sub_7FF91E589830);
}


// ==== sub_7FF91DCB1300 @ rva 0x51300 ====
int sub_7FF91DCB1300()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B88, "%L10N%VRSNCHCKRRR");
  return atexit(sub_7FF91E589860);
}


// ==== sub_7FF91DCB1330 @ rva 0x51330 ====
int sub_7FF91DCB1330()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B90, "%L10N%VRSNCHCKRRRFTR");
  return atexit(sub_7FF91E589890);
}


// ==== sub_7FF91DCB1360 @ rva 0x51360 ====
int sub_7FF91DCB1360()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919C30, "%L10N%IHOTH");
  return atexit(sub_7FF91E5898C0);
}


// ==== sub_7FF91DCB1390 @ rva 0x51390 ====
int sub_7FF91DCB1390()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AD0, "%L10N%HOTHUUIDNOTFOUND");
  return atexit(sub_7FF91E5898F0);
}


// ==== sub_7FF91DCB13C0 @ rva 0x513C0 ====
int sub_7FF91DCB13C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A40, "%L10N%HOTHGRACEDAY");
  return atexit(sub_7FF91E589920);
}


// ==== sub_7FF91DCB13F0 @ rva 0x513F0 ====
int sub_7FF91DCB13F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919C18, "%L10N%HOTHGRACEDAYS");
  return atexit(sub_7FF91E589950);
}


// ==== sub_7FF91DCB1420 @ rva 0x51420 ====
int sub_7FF91DCB1420()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B50, "%L10N%HOTHGRACEHOUR");
  return atexit(sub_7FF91E589980);
}


// ==== sub_7FF91DCB1450 @ rva 0x51450 ====
int sub_7FF91DCB1450()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BA0, "%L10N%HOTHGRACEHOURS");
  return atexit(sub_7FF91E5899B0);
}


// ==== sub_7FF91DCB1480 @ rva 0x51480 ====
int sub_7FF91DCB1480()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AA8, "%L10N%HOTHGRACEMINUTE");
  return atexit(sub_7FF91E5899E0);
}


// ==== sub_7FF91DCB14B0 @ rva 0x514B0 ====
int sub_7FF91DCB14B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B70, "%L10N%HOTHGRACEMINUTES");
  return atexit(sub_7FF91E589A10);
}


// ==== sub_7FF91DCB14E0 @ rva 0x514E0 ====
int sub_7FF91DCB14E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BE0, "%L10N%NHOTH2");
  return atexit(sub_7FF91E589A40);
}


// ==== sub_7FF91DCB1510 @ rva 0x51510 ====
int sub_7FF91DCB1510()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919C20, "%L10N%HOTHRRRTITLEBAR");
  return atexit(sub_7FF91E589A70);
}


// ==== sub_7FF91DCB1540 @ rva 0x51540 ====
int sub_7FF91DCB1540()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A90, "%L10N%RTRYHOTHBUTTON");
  return atexit(sub_7FF91E589AA0);
}


// ==== sub_7FF91DCB1570 @ rva 0x51570 ====
int sub_7FF91DCB1570()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A30, "%L10N%ALERTWINDOWINSTRUMENTLOAD");
  return atexit(sub_7FF91E589AD0);
}


// ==== sub_7FF91DCB15A0 @ rva 0x515A0 ====
int sub_7FF91DCB15A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B18, "%L10N%LOADINGFAILED");
  return atexit(sub_7FF91E589B00);
}


// ==== sub_7FF91DCB15D0 @ rva 0x515D0 ====
int sub_7FF91DCB15D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AF8, "%L10N%INSTRUMENTARCHIVEREADFAIL");
  return atexit(sub_7FF91E589B30);
}


// ==== sub_7FF91DCB1600 @ rva 0x51600 ====
int sub_7FF91DCB1600()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AB0, "%L10N%INSTRUMENTOPENFAILED");
  return atexit(sub_7FF91E589B60);
}


// ==== sub_7FF91DCB1630 @ rva 0x51630 ====
int sub_7FF91DCB1630()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BE8, "%L10N%INSTRUMENTPARSEFAIL");
  return atexit(sub_7FF91E589B90);
}


// ==== sub_7FF91DCB1660 @ rva 0x51660 ====
int sub_7FF91DCB1660()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A50, "%L10N%BUSASSIGNMENTTITLEBAR");
  return atexit(sub_7FF91E589BC0);
}


// ==== sub_7FF91DCB1690 @ rva 0x51690 ====
int sub_7FF91DCB1690()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919C38, "%L10N%BUSASSIGNMENTFAILED");
  return atexit(sub_7FF91E589BF0);
}


// ==== sub_7FF91DCB16C0 @ rva 0x516C0 ====
int sub_7FF91DCB16C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919C08, "%L10N%ARSEEMNOTFOUNDERROR");
  return atexit(sub_7FF91E589C20);
}


// ==== sub_7FF91DCB16F0 @ rva 0x516F0 ====
int sub_7FF91DCB16F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A58, "%L10N%ARSEEMSVCNOTRUNNINGERROR");
  return atexit(sub_7FF91E589C50);
}


// ==== sub_7FF91DCB1720 @ rva 0x51720 ====
int sub_7FF91DCB1720()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BF0, "%L10N%ARSEEMSVCCANTSTARTERROR");
  return atexit(sub_7FF91E589C80);
}


// ==== sub_7FF91DCB1750 @ rva 0x51750 ====
int sub_7FF91DCB1750()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919C00, "%L10N%ARSEEMSVCNOTCONNECTEDERROR");
  return atexit(sub_7FF91E589CB0);
}


// ==== sub_7FF91DCB1780 @ rva 0x51780 ====
int sub_7FF91DCB1780()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B28, "%L10N%ARSEEMSVCNOTLOGGEDINERROR");
  return atexit(sub_7FF91E589CE0);
}


// ==== sub_7FF91DCB17B0 @ rva 0x517B0 ====
int sub_7FF91DCB17B0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B00, "%L10N%ARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E589D10);
}


// ==== sub_7FF91DCB17E0 @ rva 0x517E0 ====
int sub_7FF91DCB17E0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B68, "%L10N%GTTNGTKN");
  return atexit(sub_7FF91E589D40);
}


// ==== sub_7FF91DCB1810 @ rva 0x51810 ====
int sub_7FF91DCB1810()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919C10, "%L10N%DVCLMTRCHD");
  return atexit(sub_7FF91E589D70);
}


// ==== sub_7FF91DCB1840 @ rva 0x51840 ====
int sub_7FF91DCB1840()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BB8, "%L10N%CNTCTNGSRVC");
  return atexit(sub_7FF91E589DA0);
}


// ==== sub_7FF91DCB1870 @ rva 0x51870 ====
int sub_7FF91DCB1870()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BC8, "%L10N%TTLDTLSNOCONNECTION");
  return atexit(sub_7FF91E589DD0);
}


// ==== sub_7FF91DCB18A0 @ rva 0x518A0 ====
int sub_7FF91DCB18A0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BF8, "%L10N%TTLDTLSUNOTH");
  return atexit(sub_7FF91E589E00);
}


// ==== sub_7FF91DCB18D0 @ rva 0x518D0 ====
int sub_7FF91DCB18D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BD0, "%L10N%TTLDTLSEXPRD");
  return atexit(sub_7FF91E589E30);
}


// ==== sub_7FF91DCB1900 @ rva 0x51900 ====
int sub_7FF91DCB1900()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AC8, "%L10N%TTLDTLSSRVRPRBLM");
  return atexit(sub_7FF91E589E60);
}


// ==== sub_7FF91DCB1930 @ rva 0x51930 ====
int sub_7FF91DCB1930()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A38, "%L10N%TTLDTLSARSEEMNTFND");
  return atexit(sub_7FF91E589E90);
}


// ==== sub_7FF91DCB1960 @ rva 0x51960 ====
int sub_7FF91DCB1960()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A48, "%L10N%TTLDTLSARSEEMSNTRNG");
  return atexit(sub_7FF91E589EC0);
}


// ==== sub_7FF91DCB1990 @ rva 0x51990 ====
int sub_7FF91DCB1990()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BB0, "%L10N%TTLDTLSARSEEMSNTCNTD");
  return atexit(sub_7FF91E589EF0);
}


// ==== sub_7FF91DCB19C0 @ rva 0x519C0 ====
int sub_7FF91DCB19C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B10, "%L10N%TTLDTLSARSEEMSCNTSTRT");
  return atexit(sub_7FF91E589F20);
}


// ==== sub_7FF91DCB19F0 @ rva 0x519F0 ====
int sub_7FF91DCB19F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BD8, "%L10N%TTLDTLSARSEEMNTLGN");
  return atexit(sub_7FF91E589F50);
}


// ==== sub_7FF91DCB1A20 @ rva 0x51A20 ====
int sub_7FF91DCB1A20()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A78, "%L10N%TTLDTLSARSEEMGEN");
  return atexit(sub_7FF91E589F80);
}


// ==== sub_7FF91DCB1A50 @ rva 0x51A50 ====
int sub_7FF91DCB1A50()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919BA8, "%L10N%ILGDINTRYAGN");
  return atexit(sub_7FF91E589FB0);
}


// ==== sub_7FF91DCB1A80 @ rva 0x51A80 ====
int sub_7FF91DCB1A80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919A80, "%L10N%TTLDTLARSEEMNCMPTBLVER");
  return atexit(sub_7FF91E589FE0);
}


// ==== sub_7FF91DCB1AB0 @ rva 0x51AB0 ====
int sub_7FF91DCB1AB0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919AE0, "%L10N%TTLDTGTTNGTKN");
  return atexit(sub_7FF91E58A010);
}


// ==== sub_7FF91DCB1AE0 @ rva 0x51AE0 ====
int sub_7FF91DCB1AE0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E9199E8, "%L10N%TTLDTDVCLMTRCHD");
  return atexit(sub_7FF91E58A040);
}


// ==== sub_7FF91DCB1B10 @ rva 0x51B10 ====
int sub_7FF91DCB1B10()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B20, "%L10N%LGIN");
  return atexit(sub_7FF91E58A070);
}


// ==== sub_7FF91DCB1B40 @ rva 0x51B40 ====
int sub_7FF91DCB1B40()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919B98, "rvssv");
  return atexit(sub_7FF91E58A0A0);
}


// ==== sub_7FF91DCB1B70 @ rva 0x51B70 ====
// attributes: thunk
__int64 sub_7FF91DCB1B70()
{
  return sub_7FF91E3F8FC0();
}


// ==== sub_7FF91DCB1B80 @ rva 0x51B80 ====
int sub_7FF91DCB1B80()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919C48, "rvssv");
  return atexit(sub_7FF91E58A0D0);
}


// ==== sub_7FF91DCB1BB0 @ rva 0x51BB0 ====
int sub_7FF91DCB1BB0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F63C8, "AUTHLIB.VERSION", 15);
  return atexit(sub_7FF91E58A100);
}


// ==== sub_7FF91DCB1BE0 @ rva 0x51BE0 ====
int sub_7FF91DCB1BE0()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F63E8, "ENVIRONMENT.DATA", 16);
  return atexit(sub_7FF91E58A180);
}


// ==== sub_7FF91DCB1C10 @ rva 0x51C10 ====
int sub_7FF91DCB1C10()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6428, "RCM.VERSION", 11);
  return atexit(sub_7FF91E58A200);
}


// ==== sub_7FF91DCB1C40 @ rva 0x51C40 ====
int sub_7FF91DCB1C40()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6408, "RCM.INSTALLATION.PATH", 21);
  return atexit(sub_7FF91E58A280);
}


// ==== sub_7FF91DCB1C70 @ rva 0x51C70 ====
int sub_7FF91DCB1C70()
{
  sub_7FF91DD17EC0(&qword_7FF91E8F6448, "AUTHLIB.VERSION.STATUS", 22);
  return atexit(sub_7FF91E58A300);
}


// ==== sub_7FF91DCB1CA0 @ rva 0x51CA0 ====
int __fastcall sub_7FF91DCB1CA0(__int64 a1)
{
  xmmword_7FF91E919C50 = (void *)sub_7FF91DD7B810(a1, 0, 0);
  return atexit(sub_7FF91E58A380);
}


// ==== sub_7FF91DCB1CD0 @ rva 0x51CD0 ====
int sub_7FF91DCB1CD0()
{
  return atexit((void (__cdecl *)())nullsub_107);
}


// ==== sub_7FF91DCB1CE0 @ rva 0x51CE0 ====
int sub_7FF91DCB1CE0()
{
  InitializeCriticalSection(&stru_7FF91E919C68);
  return atexit(sub_7FF91E58A430);
}


// ==== sub_7FF91DCB1D10 @ rva 0x51D10 ====
int sub_7FF91DCB1D10()
{
  return atexit((void (__cdecl *)())sub_7FF91E58A440);
}


// ==== sub_7FF91DCB1D20 @ rva 0x51D20 ====
// attributes: thunk
__int64 sub_7FF91DCB1D20()
{
  return sub_7FF91E4129A0();
}


// ==== sub_7FF91DCB1D30 @ rva 0x51D30 ====
int sub_7FF91DCB1D30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919CD8, "rvssv");
  return atexit(sub_7FF91E58A4A0);
}


// ==== sub_7FF91DCB1D60 @ rva 0x51D60 ====
int sub_7FF91DCB1D60()
{
  InitializeCriticalSection(&stru_7FF91E919CA8);
  return atexit(sub_7FF91E58A4D0);
}


// ==== sub_7FF91DCB1D90 @ rva 0x51D90 ====
int sub_7FF91DCB1D90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919CE8, "rvssv");
  return atexit(sub_7FF91E58A4E0);
}


// ==== sub_7FF91DCB1DC0 @ rva 0x51DC0 ====
int sub_7FF91DCB1DC0()
{
  InitializeCriticalSection(&stru_7FF91E919CF8);
  return atexit(sub_7FF91E58A510);
}


// ==== sub_7FF91DCB1DF0 @ rva 0x51DF0 ====
int sub_7FF91DCB1DF0()
{
  InitializeCriticalSection(&stru_7FF91E919D28);
  qword_7FF91E919D58 = 0;
  return atexit(sub_7FF91E58A540);
}


// ==== sub_7FF91DCB1E20 @ rva 0x51E20 ====
int sub_7FF91DCB1E20()
{
  return atexit((void (__cdecl *)())sub_7FF91E58A550);
}


// ==== sub_7FF91DCB1E30 @ rva 0x51E30 ====
int sub_7FF91DCB1E30()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919DC8, "rvssv");
  return atexit(sub_7FF91E58A570);
}


// ==== ??__E_Task_cv_mutex@?A0xf199a13b@details@Concurrency@@YAXXZ @ rva 0x51E60 ====
int Concurrency::details::`anonymous namespace'::`dynamic initializer for '_Task_cv_mutex''()
{
  Mtx_init_in_situ((_Mtx_t)&unk_7FF91E919D70, 2);
  return atexit(sub_7FF91E58A5A0);
}


// ==== sub_7FF91DCB1E90 @ rva 0x51E90 ====
int sub_7FF91DCB1E90()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919DD8, "rvssv");
  return atexit(sub_7FF91E58A5B0);
}


// ==== ??__E_Task_cv_mutex@?A0xf199a13b@details@Concurrency@@YAXXZ_0 @ rva 0x51EC0 ====
int Concurrency::details::`anonymous namespace'::`dynamic initializer for '_Task_cv_mutex''()
{
  Mtx_init_in_situ((_Mtx_t)&unk_7FF91E919DE0, 2);
  return atexit(sub_7FF91E58A5E0);
}


// ==== sub_7FF91DCB1EF0 @ rva 0x51EF0 ====
int sub_7FF91DCB1EF0()
{
  return atexit((void (__cdecl *)())nullsub_112);
}


// ==== sub_7FF91DCB1F00 @ rva 0x51F00 ====
int sub_7FF91DCB1F00()
{
  return atexit((void (__cdecl *)())sub_7FF91E58A6B0);
}


// ==== sub_7FF91DCB1F10 @ rva 0x51F10 ====
int sub_7FF91DCB1F10()
{
  return atexit((void (__cdecl *)())sub_7FF91E58A6E0);
}


// ==== sub_7FF91DCB1F20 @ rva 0x51F20 ====
int sub_7FF91DCB1F20()
{
  InitializeCriticalSection(&stru_7FF91E919E38);
  qword_7FF91E919E68 = 0;
  return atexit(sub_7FF91E58A710);
}


// ==== sub_7FF91DCB1F50 @ rva 0x51F50 ====
// attributes: thunk
__int64 sub_7FF91DCB1F50()
{
  return sub_7FF91E432430();
}


// ==== sub_7FF91DCB1F60 @ rva 0x51F60 ====
int sub_7FF91DCB1F60()
{
  __int64 v0; // rax

  v0 = sub_7FF91E3BBB00();
  sub_7FF91E3BBF60(v0, &qword_7FF91E919FA0, "_jexfo");
  return atexit(sub_7FF91E58A860);
}


// ==== sub_7FF91DCB1F90 @ rva 0x51F90 ====
int sub_7FF91DCB1F90()
{
  return atexit((void (__cdecl *)())nullsub_113);
}


// ==== sub_7FF91DCB1FA0 @ rva 0x51FA0 ====
int sub_7FF91DCB1FA0()
{
  return atexit((void (__cdecl *)())nullsub_114);
}


// ==== sub_7FF91DCB1FB0 @ rva 0x51FB0 ====
int sub_7FF91DCB1FB0()
{
  InitializeCriticalSection(&stru_7FF91E919EA8);
  qword_7FF91E919ED8 = 0;
  return atexit(sub_7FF91E58A8B0);
}


// ==== sub_7FF91DCB1FE0 @ rva 0x51FE0 ====
int sub_7FF91DCB1FE0()
{
  __int64 v0; // rax

  v0 = sub_7FF91E3BBB00();
  sub_7FF91E3BBF60(v0, &qword_7FF91E919FA8, "id");
  return atexit(sub_7FF91E58A8C0);
}


// ==== sub_7FF91DCB2010 @ rva 0x52010 ====
int sub_7FF91DCB2010()
{
  __int64 v0; // rax

  v0 = sub_7FF91E3BBB00();
  sub_7FF91E3BBF60(v0, &qword_7FF91E919E78, "deleteByTabComp_");
  return atexit(sub_7FF91E58A8F0);
}


// ==== sub_7FF91DCB2040 @ rva 0x52040 ====
int sub_7FF91DCB2040()
{
  __int64 v0; // rax

  v0 = sub_7FF91E3BBB00();
  sub_7FF91E3BBF60(v0, &qword_7FF91E919F48, "Marker");
  return atexit(sub_7FF91E58A940);
}


// ==== sub_7FF91DCB2070 @ rva 0x52070 ====
int sub_7FF91DCB2070()
{
  __int64 v0; // rax

  v0 = sub_7FF91E3BBB00();
  sub_7FF91E3BBF60(v0, &qword_7FF91E919E80, "name");
  return atexit(sub_7FF91E58A970);
}


// ==== sub_7FF91DCB20A0 @ rva 0x520A0 ====
int sub_7FF91DCB20A0()
{
  __int64 v0; // rax

  v0 = sub_7FF91E3BBB00();
  sub_7FF91E3BBF60(v0, &qword_7FF91E919F40, "position");
  return atexit(sub_7FF91E58A9A0);
}


// ==== sub_7FF91DCB20D0 @ rva 0x520D0 ====
int sub_7FF91DCB20D0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919F88, "parent");
  return atexit(sub_7FF91E58A9D0);
}


// ==== sub_7FF91DCB2100 @ rva 0x52100 ====
int sub_7FF91DCB2100()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919EE0, "left");
  return atexit(sub_7FF91E58AA00);
}


// ==== sub_7FF91DCB2130 @ rva 0x52130 ====
int sub_7FF91DCB2130()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919F70, "right");
  return atexit(sub_7FF91E58AA30);
}


// ==== sub_7FF91DCB2160 @ rva 0x52160 ====
int sub_7FF91DCB2160()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919F90, "top");
  return atexit(sub_7FF91E58AA60);
}


// ==== sub_7FF91DCB2190 @ rva 0x52190 ====
int sub_7FF91DCB2190()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919F68, "bottom");
  return atexit(sub_7FF91E58AA90);
}


// ==== sub_7FF91DCB21C0 @ rva 0x521C0 ====
int sub_7FF91DCB21C0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919F80, "x");
  return atexit(sub_7FF91E58AAC0);
}


// ==== sub_7FF91DCB21F0 @ rva 0x521F0 ====
int sub_7FF91DCB21F0()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919F60, "y");
  return atexit(sub_7FF91E58AAF0);
}


// ==== sub_7FF91DCB2220 @ rva 0x52220 ====
int sub_7FF91DCB2220()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919F50, "width");
  return atexit(sub_7FF91E58AB20);
}


// ==== sub_7FF91DCB2250 @ rva 0x52250 ====
int sub_7FF91DCB2250()
{
  sub_7FF91DD5DCD0(&qword_7FF91E919F78, "height");
  return atexit(sub_7FF91E58AB50);
}


// ==== sub_7FF91DCB2280 @ rva 0x52280 ====
int sub_7FF91DCB2280()
{
  return atexit((void (__cdecl *)())sub_7FF91E58AB80);
}


// ==== sub_7FF91DCB2290 @ rva 0x52290 ====
int sub_7FF91DCB2290()
{
  return atexit((void (__cdecl *)())nullsub_115);
}


// ==== sub_7FF91DCB22A0 @ rva 0x522A0 ====
int sub_7FF91DCB22A0()
{
  return atexit((void (__cdecl *)())nullsub_116);
}


// ==== sub_7FF91DCB22B0 @ rva 0x522B0 ====
int sub_7FF91DCB22B0()
{
  return atexit((void (__cdecl *)())nullsub_117);
}


// ==== sub_7FF91DCB22C0 @ rva 0x522C0 ====
int sub_7FF91DCB22C0()
{
  return atexit((void (__cdecl *)())sub_7FF91E58ABF0);
}


// ==== sub_7FF91DCB22D0 @ rva 0x522D0 ====
int sub_7FF91DCB22D0()
{
  return atexit((void (__cdecl *)())nullsub_118);
}


// ==== sub_7FF91DCB22E0 @ rva 0x522E0 ====
int sub_7FF91DCB22E0()
{
  return atexit((void (__cdecl *)())sub_7FF91E58AC20);
}


// ==== sub_7FF91DCB22F0 @ rva 0x522F0 ====
int sub_7FF91DCB22F0()
{
  return atexit((void (__cdecl *)())nullsub_119);
}


// ==== sub_7FF91DCB2300 @ rva 0x52300 ====
int sub_7FF91DCB2300()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58BFF0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58BFF0);
  }
}


// ==== sub_7FF91DCB23C0 @ rva 0x523C0 ====
int sub_7FF91DCB23C0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58C080);
}


// ==== sub_7FF91DCB2460 @ rva 0x52460 ====
int sub_7FF91DCB2460()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58C160);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58C160);
  }
}


// ==== sub_7FF91DCB2520 @ rva 0x52520 ====
int sub_7FF91DCB2520()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58C1F0);
}


// ==== sub_7FF91DCB25C0 @ rva 0x525C0 ====
int sub_7FF91DCB25C0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58C310);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58C310);
  }
}


// ==== sub_7FF91DCB2680 @ rva 0x52680 ====
int sub_7FF91DCB2680()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58C3A0);
}


// ==== sub_7FF91DCB2720 @ rva 0x52720 ====
int sub_7FF91DCB2720()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58C5B0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58C5B0);
  }
}


// ==== sub_7FF91DCB27E0 @ rva 0x527E0 ====
int sub_7FF91DCB27E0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58C640);
}


// ==== sub_7FF91DCB2880 @ rva 0x52880 ====
int sub_7FF91DCB2880()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58C790);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58C790);
  }
}


// ==== sub_7FF91DCB2940 @ rva 0x52940 ====
int sub_7FF91DCB2940()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58C820);
}


// ==== sub_7FF91DCB29E0 @ rva 0x529E0 ====
__int64 sub_7FF91DCB29E0()
{
  struct _SYSTEM_INFO SystemInfo; // [rsp+20h] [rbp-38h] BYREF

  GetSystemInfo(&SystemInfo);
  qword_7FF91E9100C8 = SystemInfo.dwAllocationGranularity;
  return SystemInfo.dwAllocationGranularity;
}


// ==== sub_7FF91DCB2A00 @ rva 0x52A00 ====
int sub_7FF91DCB2A00()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58C970);
}


// ==== sub_7FF91DCB2A20 @ rva 0x52A20 ====
int sub_7FF91DCB2A20()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58C9D0);
}


// ==== sub_7FF91DCB2A40 @ rva 0x52A40 ====
int sub_7FF91DCB2A40()
{
  return atexit(nullsub_79);
}


// ==== sub_7FF91DCB2A50 @ rva 0x52A50 ====
__int64 sub_7FF91DCB2A50()
{
  struct _SYSTEM_INFO SystemInfo; // [rsp+20h] [rbp-38h] BYREF

  GetSystemInfo(&SystemInfo);
  dword_7FF91E9100C0 = SystemInfo.dwNumberOfProcessors;
  return SystemInfo.dwNumberOfProcessors;
}


// ==== sub_7FF91DCB2A70 @ rva 0x52A70 ====
BOOL sub_7FF91DCB2A70()
{
  BOOL result; // eax

  result = InitializeSecurityDescriptor(&unk_7FF91E90FE88, 1u);
  if ( result )
  {
    result = SetSecurityDescriptorDacl(&unk_7FF91E90FE88, 1, nullptr, 0);
    if ( result )
    {
      qword_7FF91E90FE78 = (__int64)&unk_7FF91E90FE88;
      dword_7FF91E90FE70 = 24;
      dword_7FF91E90FE80 = 0;
      byte_7FF91E90FEB0 = 0;
    }
  }
  return result;
}


// ==== sub_7FF91DCB2AD0 @ rva 0x52AD0 ====
__int64 sub_7FF91DCB2AD0()
{
  qword_7FF91E90FDC8 = qword_7FF91E8A3588;
  return qword_7FF91E8A3588;
}


// ==== sub_7FF91DCB2AE0 @ rva 0x52AE0 ====
int sub_7FF91DCB2AE0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58CC20);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58CC20);
  }
}


// ==== sub_7FF91DCB2BA0 @ rva 0x52BA0 ====
int sub_7FF91DCB2BA0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58CCB0);
}


// ==== sub_7FF91DCB2C40 @ rva 0x52C40 ====
int sub_7FF91DCB2C40()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58CD90);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58CD90);
  }
}


// ==== sub_7FF91DCB2D00 @ rva 0x52D00 ====
int sub_7FF91DCB2D00()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58CE20);
}


// ==== sub_7FF91DCB2DA0 @ rva 0x52DA0 ====
int sub_7FF91DCB2DA0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58CF00);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58CF00);
  }
}


// ==== sub_7FF91DCB2E60 @ rva 0x52E60 ====
int sub_7FF91DCB2E60()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58CF90);
}


// ==== sub_7FF91DCB2F00 @ rva 0x52F00 ====
int sub_7FF91DCB2F00()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58D080);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58D080);
  }
}


// ==== sub_7FF91DCB2FC0 @ rva 0x52FC0 ====
int sub_7FF91DCB2FC0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58D110);
}


// ==== sub_7FF91DCB3060 @ rva 0x53060 ====
int sub_7FF91DCB3060()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58D280);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58D280);
  }
}


// ==== sub_7FF91DCB3120 @ rva 0x53120 ====
int sub_7FF91DCB3120()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58D310);
}


// ==== sub_7FF91DCB31C0 @ rva 0x531C0 ====
int sub_7FF91DCB31C0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58D3F0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58D3F0);
  }
}


// ==== sub_7FF91DCB3280 @ rva 0x53280 ====
int sub_7FF91DCB3280()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58D480);
}


// ==== sub_7FF91DCB3320 @ rva 0x53320 ====
int sub_7FF91DCB3320()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58D570);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58D570);
  }
}


// ==== sub_7FF91DCB33E0 @ rva 0x533E0 ====
int sub_7FF91DCB33E0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58D600);
}


// ==== sub_7FF91DCB3480 @ rva 0x53480 ====
int sub_7FF91DCB3480()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58D750);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58D750);
  }
}


// ==== sub_7FF91DCB3540 @ rva 0x53540 ====
int sub_7FF91DCB3540()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58D7E0);
}


// ==== sub_7FF91DCB35E0 @ rva 0x535E0 ====
int sub_7FF91DCB35E0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58D910);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58D910);
  }
}


// ==== sub_7FF91DCB36A0 @ rva 0x536A0 ====
int sub_7FF91DCB36A0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58D9A0);
}


// ==== sub_7FF91DCB3740 @ rva 0x53740 ====
int sub_7FF91DCB3740()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58DAA0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58DAA0);
  }
}


// ==== sub_7FF91DCB3800 @ rva 0x53800 ====
int sub_7FF91DCB3800()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58DB30);
}


// ==== sub_7FF91DCB38A0 @ rva 0x538A0 ====
int sub_7FF91DCB38A0()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58DC80);
}


// ==== sub_7FF91DCB38C0 @ rva 0x538C0 ====
int sub_7FF91DCB38C0()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58DCE0);
}


// ==== sub_7FF91DCB38E0 @ rva 0x538E0 ====
int sub_7FF91DCB38E0()
{
  qword_7FF91E9104E0 = (void *)sub_7FF91DF7AA50(&qword_7FF91E9104E0);
  return atexit(sub_7FF91E58DD40);
}


// ==== sub_7FF91DCB3910 @ rva 0x53910 ====
int sub_7FF91DCB3910()
{
  qword_7FF91E9104F8 = (void *)sub_7FF91DF7AA50(&qword_7FF91E9104F8);
  return atexit(sub_7FF91E58DD80);
}


// ==== sub_7FF91DCB3940 @ rva 0x53940 ====
int sub_7FF91DCB3940()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58DE80);
}


// ==== sub_7FF91DCB3960 @ rva 0x53960 ====
int sub_7FF91DCB3960()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58DEE0);
}


// ==== sub_7FF91DCB3980 @ rva 0x53980 ====
int sub_7FF91DCB3980()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58E000);
}


// ==== sub_7FF91DCB39A0 @ rva 0x539A0 ====
int sub_7FF91DCB39A0()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58E060);
}


// ==== sub_7FF91DCB39C0 @ rva 0x539C0 ====
int sub_7FF91DCB39C0()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58E180);
}


// ==== sub_7FF91DCB39E0 @ rva 0x539E0 ====
int sub_7FF91DCB39E0()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58E1E0);
}


// ==== sub_7FF91DCB3A00 @ rva 0x53A00 ====
int sub_7FF91DCB3A00()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58E370);
}


// ==== sub_7FF91DCB3A20 @ rva 0x53A20 ====
int sub_7FF91DCB3A20()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58E3D0);
}


// ==== sub_7FF91DCB3A40 @ rva 0x53A40 ====
int sub_7FF91DCB3A40()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58E4F0);
}


// ==== sub_7FF91DCB3A60 @ rva 0x53A60 ====
int sub_7FF91DCB3A60()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58E550);
}


// ==== sub_7FF91DCB3A80 @ rva 0x53A80 ====
int sub_7FF91DCB3A80()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58E6B0);
}


// ==== sub_7FF91DCB3AA0 @ rva 0x53AA0 ====
int sub_7FF91DCB3AA0()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58E710);
}


// ==== sub_7FF91DCB3AC0 @ rva 0x53AC0 ====
int sub_7FF91DCB3AC0()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58E8A0);
}


// ==== sub_7FF91DCB3AE0 @ rva 0x53AE0 ====
int sub_7FF91DCB3AE0()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58E900);
}


// ==== sub_7FF91DCB3B00 @ rva 0x53B00 ====
int sub_7FF91DCB3B00()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58EA90);
}


// ==== sub_7FF91DCB3B20 @ rva 0x53B20 ====
int sub_7FF91DCB3B20()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58EAF0);
}


// ==== sub_7FF91DCB3B40 @ rva 0x53B40 ====
int sub_7FF91DCB3B40()
{
  char v1; // [rsp+30h] [rbp+8h] BYREF

  sub_7FF91DF8BC70(&qword_7FF91E9105B8, 1, &v1);
  return atexit(sub_7FF91E58EC10);
}


// ==== sub_7FF91DCB3B70 @ rva 0x53B70 ====
int sub_7FF91DCB3B70()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58EC80);
}


// ==== sub_7FF91DCB3B90 @ rva 0x53B90 ====
int sub_7FF91DCB3B90()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58ECE0);
}


// ==== sub_7FF91DCB3BB0 @ rva 0x53BB0 ====
int sub_7FF91DCB3BB0()
{
  unsigned __int8 v1; // [rsp+20h] [rbp-E0h]
  _OWORD v2[1142]; // [rsp+30h] [rbp-D0h] BYREF
  __int64 v3; // [rsp+4790h] [rbp+4690h] BYREF

  v2[0] = xmmword_7FF91E5C35D0;
  v2[1] = xmmword_7FF91E5C35C0;
  v2[2] = xmmword_7FF91E5C35B0;
  v2[3] = xmmword_7FF91E5C35A0;
  v2[4] = xmmword_7FF91E5C3590;
  v2[5] = xmmword_7FF91E5C3580;
  v2[6] = xmmword_7FF91E5C3570;
  v2[7] = xmmword_7FF91E5C3560;
  v2[8] = xmmword_7FF91E5C3540;
  v2[9] = xmmword_7FF91E5C3530;
  v2[10] = xmmword_7FF91E5C3520;
  v2[11] = xmmword_7FF91E5C3510;
  v2[12] = xmmword_7FF91E5C3500;
  v2[13] = xmmword_7FF91E5C34F0;
  v2[14] = xmmword_7FF91E5C34E0;
  v2[15] = xmmword_7FF91E5C34D0;
  v2[16] = xmmword_7FF91E5C34C0;
  v2[17] = xmmword_7FF91E5C34B0;
  v2[18] = xmmword_7FF91E5C34A0;
  v2[19] = xmmword_7FF91E5C3490;
  v2[20] = xmmword_7FF91E5C3480;
  v2[21] = xmmword_7FF91E5C3470;
  v2[22] = xmmword_7FF91E5C3460;
  v2[23] = xmmword_7FF91E5C3450;
  v2[24] = xmmword_7FF91E5C3440;
  v2[25] = xmmword_7FF91E5C3430;
  v2[26] = xmmword_7FF91E5C3420;
  v2[27] = xmmword_7FF91E5C3410;
  v2[28] = xmmword_7FF91E5C3400;
  v2[29] = xmmword_7FF91E5C33F0;
  v2[30] = xmmword_7FF91E5C33E0;
  v2[31] = xmmword_7FF91E5C33C0;
  v2[32] = xmmword_7FF91E5C33B0;
  v2[33] = xmmword_7FF91E5C33A0;
  v2[34] = xmmword_7FF91E5C3390;
  v2[35] = xmmword_7FF91E5C3380;
  v2[36] = xmmword_7FF91E5C3370;
  v2[37] = xmmword_7FF91E5C3360;
  v2[38] = xmmword_7FF91E5C3350;
  v2[39] = xmmword_7FF91E5C3340;
  v2[40] = xmmword_7FF91E5C3330;
  v2[42] = xmmword_7FF91E5C3310;
  v2[41] = xmmword_7FF91E5C3320;
  v2[44] = xmmword_7FF91E5C32E0;
  v2[43] = xmmword_7FF91E5C32F0;
  v2[46] = xmmword_7FF91E5C32C0;
  v2[45] = xmmword_7FF91E5C32D0;
  v2[48] = xmmword_7FF91E5C32A0;
  v2[47] = xmmword_7FF91E5C32B0;
  v2[50] = xmmword_7FF91E5C3280;
  v2[49] = xmmword_7FF91E5C3290;
  v2[52] = xmmword_7FF91E5C3250;
  v2[51] = xmmword_7FF91E5C3270;
  v2[54] = xmmword_7FF91E5C3220;
  v2[53] = xmmword_7FF91E5C3240;
  v2[56] = xmmword_7FF91E5C3200;
  v2[55] = xmmword_7FF91E5C3210;
  v2[58] = xmmword_7FF91E5C31E0;
  v2[57] = xmmword_7FF91E5C31F0;
  v2[60] = xmmword_7FF91E5C31C0;
  v2[59] = xmmword_7FF91E5C31D0;
  v2[62] = xmmword_7FF91E5C31A0;
  v2[61] = xmmword_7FF91E5C31B0;
  v2[64] = xmmword_7FF91E5C3170;
  v2[63] = xmmword_7FF91E5C3180;
  v2[66] = xmmword_7FF91E5C3150;
  v2[65] = xmmword_7FF91E5C3160;
  v2[68] = xmmword_7FF91E5C3130;
  v2[67] = xmmword_7FF91E5C3140;
  v2[70] = xmmword_7FF91E5C3100;
  v2[69] = xmmword_7FF91E5C3110;
  v2[72] = xmmword_7FF91E5C30C0;
  v2[71] = xmmword_7FF91E5C30E0;
  v2[74] = xmmword_7FF91E5C30A0;
  v2[73] = xmmword_7FF91E5C30B0;
  v2[76] = xmmword_7FF91E5C3080;
  v2[75] = xmmword_7FF91E5C3090;
  v2[78] = xmmword_7FF91E5C3060;
  v2[77] = xmmword_7FF91E5C3070;
  v2[80] = xmmword_7FF91E5C3020;
  v2[79] = xmmword_7FF91E5C3040;
  v2[81] = xmmword_7FF91E5C3010;
  v2[82] = xmmword_7FF91E5C3000;
  v2[83] = xmmword_7FF91E5C2FF0;
  v2[84] = xmmword_7FF91E5C2FE0;
  v2[85] = xmmword_7FF91E5C2FC0;
  v2[86] = xmmword_7FF91E5C2FB0;
  v2[87] = xmmword_7FF91E5C2F30;
  v2[88] = xmmword_7FF91E5C2ED0;
  v2[89] = xmmword_7FF91E5C2EA0;
  v2[90] = xmmword_7FF91E5C2E70;
  v2[91] = xmmword_7FF91E5C2E50;
  v2[92] = xmmword_7FF91E5C2E30;
  v2[93] = xmmword_7FF91E5C2E00;
  v2[94] = xmmword_7FF91E5C2DE0;
  v2[95] = xmmword_7FF91E5C2DB0;
  v2[96] = xmmword_7FF91E5C2D90;
  v2[97] = xmmword_7FF91E5C2D60;
  v2[98] = xmmword_7FF91E5C2D50;
  v2[99] = xmmword_7FF91E5C2D20;
  v2[100] = xmmword_7FF91E5C2D10;
  v2[101] = xmmword_7FF91E5C2CE0;
  v2[102] = xmmword_7FF91E5C2CB0;
  v2[103] = xmmword_7FF91E5C2C80;
  v2[104] = xmmword_7FF91E5C2C50;
  v2[105] = xmmword_7FF91E5C2C20;
  v2[106] = xmmword_7FF91E5C2B80;
  v2[107] = xmmword_7FF91E5C2970;
  v2[108] = xmmword_7FF91E5C2800;
  v2[109] = xmmword_7FF91E5C2700;
  v2[110] = xmmword_7FF91E5C2610;
  v2[111] = xmmword_7FF91E5C2540;
  v2[112] = xmmword_7FF91E5C2490;
  v2[113] = xmmword_7FF91E5C23E0;
  v2[114] = xmmword_7FF91E5C2150;
  v2[115] = xmmword_7FF91E5C1DE0;
  v2[116] = xmmword_7FF91E5C1B80;
  v2[117] = xmmword_7FF91E5C1750;
  v2[118] = xmmword_7FF91E5C0F80;
  v2[119] = xmmword_7FF91E5C4460;
  v2[120] = xmmword_7FF91E5C4BA0;
  v2[121] = xmmword_7FF91E5C5060;
  v2[123] = xmmword_7FF91E5C5560;
  v2[122] = xmmword_7FF91E5C5400;
  v2[125] = xmmword_7FF91E5C57C0;
  v2[124] = xmmword_7FF91E5C5680;
  v2[127] = xmmword_7FF91E5C5B90;
  v2[126] = xmmword_7FF91E5C5920;
  v2[129] = xmmword_7FF91E5C5D30;
  v2[128] = xmmword_7FF91E5C5CF0;
  v2[131] = xmmword_7FF91E5C5DB0;
  v2[130] = xmmword_7FF91E5C5D70;
  v2[133] = xmmword_7FF91E5C5E30;
  v2[132] = xmmword_7FF91E5C5DE0;
  v2[135] = xmmword_7FF91E5C5EA0;
  v2[134] = xmmword_7FF91E5C5E50;
  v2[137] = xmmword_7FF91E5C5EF0;
  v2[136] = xmmword_7FF91E5C5EC0;
  v2[139] = xmmword_7FF91E5C5F70;
  v2[138] = xmmword_7FF91E5C5F30;
  v2[141] = xmmword_7FF91E5C5FF0;
  v2[140] = xmmword_7FF91E5C5FB0;
  v2[143] = xmmword_7FF91E5C6060;
  v2[142] = xmmword_7FF91E5C6010;
  v2[145] = xmmword_7FF91E5C60B0;
  v2[144] = xmmword_7FF91E5C6080;
  v2[147] = xmmword_7FF91E5C6120;
  v2[146] = xmmword_7FF91E5C60E0;
  v2[149] = xmmword_7FF91E5C6180;
  v2[148] = xmmword_7FF91E5C6160;
  v2[151] = xmmword_7FF91E5C61E0;
  v2[150] = xmmword_7FF91E5C61C0;
  v2[153] = xmmword_7FF91E5C6250;
  v2[152] = xmmword_7FF91E5C6230;
  v2[155] = xmmword_7FF91E5C62C0;
  v2[154] = xmmword_7FF91E5C6290;
  v2[157] = xmmword_7FF91E5C6350;
  v2[156] = xmmword_7FF91E5C6300;
  v2[159] = xmmword_7FF91E5C63A0;
  v2[158] = xmmword_7FF91E5C6370;
  v2[161] = xmmword_7FF91E5C63E0;
  v2[160] = xmmword_7FF91E5C63C0;
  v2[162] = xmmword_7FF91E5C6400;
  v2[163] = xmmword_7FF91E5C6420;
  v2[164] = xmmword_7FF91E5C6460;
  v2[165] = xmmword_7FF91E5C6490;
  v2[166] = xmmword_7FF91E5C64B0;
  v2[167] = xmmword_7FF91E5C64D0;
  v2[168] = xmmword_7FF91E5C64F0;
  v2[169] = xmmword_7FF91E5C6500;
  v2[170] = xmmword_7FF91E5C64E0;
  v2[171] = xmmword_7FF91E5C64C0;
  v2[172] = xmmword_7FF91E5C64A0;
  v2[173] = xmmword_7FF91E5C6480;
  v2[174] = xmmword_7FF91E5C6440;
  v2[175] = xmmword_7FF91E5C6410;
  v2[176] = xmmword_7FF91E5C63F0;
  v2[177] = xmmword_7FF91E5C63D0;
  v2[178] = xmmword_7FF91E5C63B0;
  v2[179] = xmmword_7FF91E5C6390;
  v2[180] = xmmword_7FF91E5C6380;
  v2[181] = xmmword_7FF91E5C6360;
  v2[182] = xmmword_7FF91E5C6320;
  v2[183] = xmmword_7FF91E5C62E0;
  v2[184] = xmmword_7FF91E5C62A0;
  v2[185] = xmmword_7FF91E5C6280;
  v2[186] = xmmword_7FF91E5C6240;
  v2[187] = xmmword_7FF91E5C6220;
  v2[188] = xmmword_7FF91E5C61F0;
  v2[189] = xmmword_7FF91E5C61D0;
  v2[190] = xmmword_7FF91E5C61A0;
  v2[191] = xmmword_7FF91E5C6170;
  v2[192] = xmmword_7FF91E5C6150;
  v2[193] = xmmword_7FF91E5C6110;
  v2[194] = xmmword_7FF91E5C60F0;
  v2[195] = xmmword_7FF91E5C60D0;
  v2[196] = xmmword_7FF91E5C6090;
  v2[197] = xmmword_7FF91E5C6070;
  v2[198] = xmmword_7FF91E5C6050;
  v2[199] = xmmword_7FF91E5C6020;
  v2[200] = xmmword_7FF91E5C6000;
  v2[201] = xmmword_7FF91E5C5FD0;
  v2[202] = xmmword_7FF91E5C5FA0;
  v2[204] = xmmword_7FF91E5C5F50;
  v2[203] = xmmword_7FF91E5C5F80;
  v2[206] = xmmword_7FF91E5C5F00;
  v2[205] = xmmword_7FF91E5C5F20;
  v2[208] = xmmword_7FF91E5C5EB0;
  v2[207] = xmmword_7FF91E5C5ED0;
  v2[210] = xmmword_7FF91E5C5E60;
  v2[209] = xmmword_7FF91E5C5E90;
  v2[212] = xmmword_7FF91E5C5E20;
  v2[211] = xmmword_7FF91E5C5E40;
  v2[214] = xmmword_7FF91E5C5DC0;
  v2[213] = xmmword_7FF91E5C5E00;
  v2[216] = xmmword_7FF91E5C5D80;
  v2[215] = xmmword_7FF91E5C5DA0;
  v2[218] = xmmword_7FF91E5C5D40;
  v2[217] = xmmword_7FF91E5C5D60;
  v2[220] = xmmword_7FF91E5C5CB0;
  v2[219] = xmmword_7FF91E5C5D10;
  v2[222] = xmmword_7FF91E5C5A70;
  v2[221] = xmmword_7FF91E5C5C40;
  v2[224] = xmmword_7FF91E5C5860;
  v2[223] = xmmword_7FF91E5C5940;
  v2[226] = xmmword_7FF91E5C56F0;
  v2[225] = xmmword_7FF91E5C57A0;
  v2[228] = xmmword_7FF91E5C55A0;
  v2[227] = xmmword_7FF91E5C5650;
  v2[230] = xmmword_7FF91E5C5440;
  v2[229] = xmmword_7FF91E5C5510;
  v2[232] = xmmword_7FF91E5C5130;
  v2[231] = xmmword_7FF91E5C53A0;
  v2[234] = xmmword_7FF91E5C4C50;
  v2[233] = xmmword_7FF91E5C4E70;
  v2[236] = xmmword_7FF91E5C46F0;
  v2[235] = xmmword_7FF91E5C4A60;
  v2[238] = xmmword_7FF91E5C08E0;
  v2[237] = xmmword_7FF91E5C40E0;
  v2[240] = xmmword_7FF91E5C14B0;
  v2[239] = xmmword_7FF91E5C10B0;
  v2[242] = xmmword_7FF91E5C1A70;
  v2[241] = xmmword_7FF91E5C17E0;
  v2[243] = xmmword_7FF91E5C1B20;
  v2[244] = xmmword_7FF91E5C1C30;
  v2[245] = xmmword_7FF91E5C1D10;
  v2[246] = xmmword_7FF91E5C1E30;
  v2[247] = xmmword_7FF91E5C1F50;
  v2[248] = xmmword_7FF91E5C20A0;
  v2[249] = xmmword_7FF91E5C2350;
  v2[250] = xmmword_7FF91E5C23A0;
  v2[251] = xmmword_7FF91E5C23D0;
  v2[252] = xmmword_7FF91E5C2410;
  v2[253] = xmmword_7FF91E5C2450;
  v2[254] = xmmword_7FF91E5C2480;
  v2[255] = xmmword_7FF91E5C24B0;
  v2[256] = xmmword_7FF91E5C24F0;
  v2[257] = xmmword_7FF91E5C2520;
  v2[258] = xmmword_7FF91E5C2550;
  v2[259] = xmmword_7FF91E5C2590;
  v2[260] = xmmword_7FF91E5C25C0;
  v2[261] = xmmword_7FF91E5C2600;
  v2[262] = xmmword_7FF91E5C2650;
  v2[263] = xmmword_7FF91E5C2680;
  v2[264] = xmmword_7FF91E5C26C0;
  v2[265] = xmmword_7FF91E5C26E0;
  v2[266] = xmmword_7FF91E5C2710;
  v2[267] = xmmword_7FF91E5C2740;
  v2[268] = xmmword_7FF91E5C2770;
  v2[269] = xmmword_7FF91E5C27A0;
  v2[270] = xmmword_7FF91E5C27E0;
  v2[271] = xmmword_7FF91E5C2810;
  v2[272] = xmmword_7FF91E5C2850;
  v2[273] = xmmword_7FF91E5C2870;
  v2[274] = xmmword_7FF91E5C28A0;
  v2[275] = xmmword_7FF91E5C28D0;
  v2[276] = xmmword_7FF91E5C2910;
  v2[277] = xmmword_7FF91E5C2930;
  v2[278] = xmmword_7FF91E5C2960;
  v2[279] = xmmword_7FF91E5C2990;
  v2[280] = xmmword_7FF91E5C29B0;
  v2[281] = xmmword_7FF91E5C29F0;
  v2[282] = xmmword_7FF91E5C2A10;
  v2[283] = xmmword_7FF91E5C2A40;
  v2[285] = xmmword_7FF91E5C2A80;
  v2[284] = xmmword_7FF91E5C2A60;
  v2[287] = xmmword_7FF91E5C2AC0;
  v2[286] = xmmword_7FF91E5C2AA0;
  v2[289] = xmmword_7FF91E5C2B00;
  v2[288] = xmmword_7FF91E5C2AE0;
  v2[291] = xmmword_7FF91E5C2B30;
  v2[290] = xmmword_7FF91E5C2B20;
  v2[293] = xmmword_7FF91E5C2AF0;
  v2[292] = xmmword_7FF91E5C2B10;
  v2[295] = xmmword_7FF91E5C2AB0;
  v2[294] = xmmword_7FF91E5C2AD0;
  v2[297] = xmmword_7FF91E5C2A70;
  v2[296] = xmmword_7FF91E5C2A90;
  v2[299] = xmmword_7FF91E5C2A20;
  v2[298] = xmmword_7FF91E5C2A50;
  v2[301] = xmmword_7FF91E5C29D0;
  v2[300] = xmmword_7FF91E5C2A00;
  v2[303] = xmmword_7FF91E5C2980;
  v2[302] = xmmword_7FF91E5C29A0;
  v2[305] = xmmword_7FF91E5C2920;
  v2[304] = xmmword_7FF91E5C2950;
  v2[307] = xmmword_7FF91E5C28E0;
  v2[306] = xmmword_7FF91E5C2900;
  v2[309] = xmmword_7FF91E5C2880;
  v2[308] = xmmword_7FF91E5C28C0;
  v2[311] = xmmword_7FF91E5C2840;
  v2[310] = xmmword_7FF91E5C2860;
  v2[313] = xmmword_7FF91E5C27C0;
  v2[312] = xmmword_7FF91E5C27F0;
  v2[315] = xmmword_7FF91E5C2780;
  v2[314] = xmmword_7FF91E5C2790;
  v2[317] = xmmword_7FF91E5C2720;
  v2[316] = xmmword_7FF91E5C2750;
  v2[319] = xmmword_7FF91E5C26D0;
  v2[318] = xmmword_7FF91E5C26F0;
  v2[321] = xmmword_7FF91E5C2670;
  v2[320] = xmmword_7FF91E5C26B0;
  v2[323] = xmmword_7FF91E5C2630;
  v2[322] = xmmword_7FF91E5C2660;
  v2[324] = xmmword_7FF91E5C25E0;
  v2[325] = xmmword_7FF91E5C25B0;
  v2[326] = xmmword_7FF91E5C2580;
  v2[327] = xmmword_7FF91E5C2570;
  v2[328] = xmmword_7FF91E5C2530;
  v2[329] = xmmword_7FF91E5C2500;
  v2[330] = xmmword_7FF91E5C24E0;
  v2[331] = xmmword_7FF91E5C24C0;
  v2[332] = xmmword_7FF91E5C24A0;
  v2[333] = xmmword_7FF91E5C2470;
  v2[334] = xmmword_7FF91E5C2430;
  v2[335] = xmmword_7FF91E5C2420;
  v2[336] = xmmword_7FF91E5C23F0;
  v2[337] = xmmword_7FF91E5C23C0;
  v2[338] = xmmword_7FF91E5C2370;
  v2[339] = xmmword_7FF91E5C2360;
  v2[340] = xmmword_7FF91E5C2170;
  v2[341] = xmmword_7FF91E5C2040;
  v2[342] = xmmword_7FF91E5C1F70;
  v2[343] = xmmword_7FF91E5C1EA0;
  v2[344] = xmmword_7FF91E5C1DC0;
  v2[345] = xmmword_7FF91E5C1D20;
  v2[346] = xmmword_7FF91E5C1C80;
  v2[347] = xmmword_7FF91E5C1BE0;
  v2[348] = xmmword_7FF91E5C1B30;
  v2[349] = xmmword_7FF91E5C1AB0;
  v2[350] = xmmword_7FF91E5C1A40;
  v2[351] = xmmword_7FF91E5C18B0;
  v2[352] = xmmword_7FF91E5C1640;
  v2[353] = xmmword_7FF91E5C13F0;
  v2[354] = xmmword_7FF91E5C11B0;
  v2[355] = xmmword_7FF91E5C0FE0;
  v2[356] = xmmword_7FF91E5C0A10;
  v2[357] = xmmword_7FF91E5C39F0;
  v2[358] = xmmword_7FF91E5C4160;
  v2[359] = xmmword_7FF91E5C4480;
  v2[360] = xmmword_7FF91E5C4900;
  v2[361] = xmmword_7FF91E5C49E0;
  v2[362] = xmmword_7FF91E5C4AF0;
  v2[363] = xmmword_7FF91E5C4BE0;
  v2[364] = xmmword_7FF91E5C4D00;
  v2[366] = xmmword_7FF91E5C4F30;
  v2[365] = xmmword_7FF91E5C4E00;
  v2[368] = xmmword_7FF91E5C5210;
  v2[367] = xmmword_7FF91E5C50B0;
  v2[370] = xmmword_7FF91E5C53D0;
  v2[369] = xmmword_7FF91E5C5370;
  v2[372] = xmmword_7FF91E5C5460;
  v2[371] = xmmword_7FF91E5C5410;
  v2[374] = xmmword_7FF91E5C5500;
  v2[373] = xmmword_7FF91E5C54A0;
  v2[376] = xmmword_7FF91E5C5580;
  v2[375] = xmmword_7FF91E5C5530;
  v2[378] = xmmword_7FF91E5C5600;
  v2[377] = xmmword_7FF91E5C55C0;
  v2[380] = xmmword_7FF91E5C5670;
  v2[379] = xmmword_7FF91E5C5620;
  v2[382] = xmmword_7FF91E5C56E0;
  v2[381] = xmmword_7FF91E5C56B0;
  v2[384] = xmmword_7FF91E5C5740;
  v2[383] = xmmword_7FF91E5C5710;
  v2[386] = xmmword_7FF91E5C57D0;
  v2[385] = xmmword_7FF91E5C5790;
  v2[388] = xmmword_7FF91E5C5820;
  v2[387] = xmmword_7FF91E5C5800;
  v2[390] = xmmword_7FF91E5C5890;
  v2[389] = xmmword_7FF91E5C5870;
  v2[392] = xmmword_7FF91E5C58F0;
  v2[391] = xmmword_7FF91E5C58B0;
  v2[394] = xmmword_7FF91E5C5960;
  v2[393] = xmmword_7FF91E5C5930;
  v2[396] = xmmword_7FF91E5C59D0;
  v2[395] = xmmword_7FF91E5C5980;
  v2[398] = xmmword_7FF91E5C5A20;
  v2[397] = xmmword_7FF91E5C5A00;
  v2[400] = xmmword_7FF91E5C5A80;
  v2[399] = xmmword_7FF91E5C5A40;
  v2[402] = xmmword_7FF91E5C5AC0;
  v2[401] = xmmword_7FF91E5C5AA0;
  v2[404] = xmmword_7FF91E5C5B20;
  v2[403] = xmmword_7FF91E5C5AF0;
  v2[405] = xmmword_7FF91E5C5B40;
  v2[406] = xmmword_7FF91E5C5B70;
  v2[407] = xmmword_7FF91E5C5BA0;
  v2[408] = xmmword_7FF91E5C5BD0;
  v2[409] = xmmword_7FF91E5C5BF0;
  v2[410] = xmmword_7FF91E5C5C10;
  v2[411] = xmmword_7FF91E5C5C00;
  v2[412] = xmmword_7FF91E5C5BE0;
  v2[413] = xmmword_7FF91E5C5BC0;
  v2[414] = xmmword_7FF91E5C5BB0;
  v2[415] = xmmword_7FF91E5C5B80;
  v2[416] = xmmword_7FF91E5C5B50;
  v2[417] = xmmword_7FF91E5C5B30;
  v2[418] = xmmword_7FF91E5C5B00;
  v2[419] = xmmword_7FF91E5C5AE0;
  v2[420] = xmmword_7FF91E5C5AB0;
  v2[421] = xmmword_7FF91E5C5A90;
  v2[422] = xmmword_7FF91E5C5A50;
  v2[423] = xmmword_7FF91E5C5A30;
  v2[424] = xmmword_7FF91E5C5A10;
  v2[425] = xmmword_7FF91E5C59E0;
  v2[426] = xmmword_7FF91E5C59C0;
  v2[427] = xmmword_7FF91E5C5970;
  v2[428] = xmmword_7FF91E5C5950;
  v2[429] = xmmword_7FF91E5C5910;
  v2[430] = xmmword_7FF91E5C58E0;
  v2[431] = xmmword_7FF91E5C58C0;
  v2[432] = xmmword_7FF91E5C58A0;
  v2[433] = xmmword_7FF91E5C5880;
  v2[434] = xmmword_7FF91E5C5850;
  v2[435] = xmmword_7FF91E5C5810;
  v2[436] = xmmword_7FF91E5C57F0;
  v2[437] = xmmword_7FF91E5C57B0;
  v2[438] = xmmword_7FF91E5C5780;
  v2[439] = xmmword_7FF91E5C5750;
  v2[440] = xmmword_7FF91E5C5720;
  v2[441] = xmmword_7FF91E5C5700;
  v2[442] = xmmword_7FF91E5C56C0;
  v2[443] = xmmword_7FF91E5C5690;
  v2[444] = xmmword_7FF91E5C5660;
  v2[445] = xmmword_7FF91E5C5630;
  v2[447] = xmmword_7FF91E5C55F0;
  v2[446] = xmmword_7FF91E5C5610;
  v2[449] = xmmword_7FF91E5C5570;
  v2[448] = xmmword_7FF91E5C55B0;
  v2[451] = xmmword_7FF91E5C5520;
  v2[450] = xmmword_7FF91E5C5540;
  v2[453] = xmmword_7FF91E5C5490;
  v2[452] = xmmword_7FF91E5C54C0;
  v2[455] = xmmword_7FF91E5C5420;
  v2[454] = xmmword_7FF91E5C5470;
  v2[457] = xmmword_7FF91E5C53B0;
  v2[456] = xmmword_7FF91E5C53E0;
  v2[459] = xmmword_7FF91E5C52A0;
  v2[458] = xmmword_7FF91E5C5380;
  v2[461] = xmmword_7FF91E5C5080;
  v2[460] = xmmword_7FF91E5C5160;
  v2[463] = xmmword_7FF91E5C4E60;
  v2[462] = xmmword_7FF91E5C4F40;
  v2[465] = xmmword_7FF91E5C4CF0;
  v2[464] = xmmword_7FF91E5C4DB0;
  v2[467] = xmmword_7FF91E5C4B70;
  v2[466] = xmmword_7FF91E5C4C10;
  v2[469] = xmmword_7FF91E5C4A30;
  v2[468] = xmmword_7FF91E5C4AC0;
  v2[471] = xmmword_7FF91E5C48F0;
  v2[470] = xmmword_7FF91E5C49A0;
  v2[473] = xmmword_7FF91E5C4390;
  v2[472] = xmmword_7FF91E5C4580;
  v2[475] = xmmword_7FF91E5C3EF0;
  v2[474] = xmmword_7FF91E5C4200;
  v2[477] = xmmword_7FF91E5C08A0;
  v2[476] = xmmword_7FF91E5C38C0;
  v2[479] = xmmword_7FF91E5C0FC0;
  v2[478] = xmmword_7FF91E5C0CD0;
  v2[481] = xmmword_7FF91E5C11F0;
  v2[480] = xmmword_7FF91E5C10E0;
  v2[483] = xmmword_7FF91E5C14C0;
  v2[482] = xmmword_7FF91E5C1310;
  v2[485] = xmmword_7FF91E5C16C0;
  v2[484] = xmmword_7FF91E5C15D0;
  v2[486] = xmmword_7FF91E5C1810;
  v2[487] = xmmword_7FF91E5C19E0;
  v2[488] = xmmword_7FF91E5C1A10;
  v2[489] = xmmword_7FF91E5C1A60;
  v2[490] = xmmword_7FF91E5C1AA0;
  v2[491] = xmmword_7FF91E5C1AE0;
  v2[492] = xmmword_7FF91E5C1B00;
  v2[493] = xmmword_7FF91E5C1B70;
  v2[494] = xmmword_7FF91E5C1BB0;
  v2[495] = xmmword_7FF91E5C1C00;
  v2[496] = xmmword_7FF91E5C1C50;
  v2[497] = xmmword_7FF91E5C1C70;
  v2[498] = xmmword_7FF91E5C1CB0;
  v2[499] = xmmword_7FF91E5C1CE0;
  v2[500] = xmmword_7FF91E5C1D30;
  v2[501] = xmmword_7FF91E5C1D60;
  v2[502] = xmmword_7FF91E5C1D80;
  v2[503] = xmmword_7FF91E5C1E00;
  v2[504] = xmmword_7FF91E5C1E40;
  v2[505] = xmmword_7FF91E5C1E70;
  v2[506] = xmmword_7FF91E5C1EC0;
  v2[507] = xmmword_7FF91E5C1EE0;
  v2[508] = xmmword_7FF91E5C1F20;
  v2[509] = xmmword_7FF91E5C1F60;
  v2[510] = xmmword_7FF91E5C1FA0;
  v2[511] = xmmword_7FF91E5C1FC0;
  v2[512] = xmmword_7FF91E5C1FF0;
  v2[513] = xmmword_7FF91E5C2020;
  v2[514] = xmmword_7FF91E5C2060;
  v2[515] = xmmword_7FF91E5C2090;
  v2[516] = xmmword_7FF91E5C20E0;
  v2[517] = xmmword_7FF91E5C2100;
  v2[518] = xmmword_7FF91E5C2140;
  v2[519] = xmmword_7FF91E5C2180;
  v2[520] = xmmword_7FF91E5C21A0;
  v2[521] = xmmword_7FF91E5C21E0;
  v2[522] = xmmword_7FF91E5C2200;
  v2[523] = xmmword_7FF91E5C2220;
  v2[524] = xmmword_7FF91E5C2260;
  v2[525] = xmmword_7FF91E5C2280;
  v2[526] = xmmword_7FF91E5C22A0;
  v2[528] = xmmword_7FF91E5C2300;
  v2[527] = xmmword_7FF91E5C22E0;
  v2[530] = xmmword_7FF91E5C2330;
  v2[529] = xmmword_7FF91E5C2320;
  v2[532] = xmmword_7FF91E5C22F0;
  v2[531] = xmmword_7FF91E5C2310;
  v2[534] = xmmword_7FF91E5C2290;
  v2[533] = xmmword_7FF91E5C22B0;
  v2[536] = xmmword_7FF91E5C2230;
  v2[535] = xmmword_7FF91E5C2270;
  v2[538] = xmmword_7FF91E5C21F0;
  v2[537] = xmmword_7FF91E5C2210;
  v2[540] = xmmword_7FF91E5C2190;
  v2[539] = xmmword_7FF91E5C21C0;
  v2[542] = xmmword_7FF91E5C2120;
  v2[541] = xmmword_7FF91E5C2160;
  v2[544] = xmmword_7FF91E5C20D0;
  v2[543] = xmmword_7FF91E5C20F0;
  v2[546] = xmmword_7FF91E5C2050;
  v2[545] = xmmword_7FF91E5C2080;
  v2[548] = xmmword_7FF91E5C2000;
  v2[547] = xmmword_7FF91E5C2030;
  v2[550] = xmmword_7FF91E5C1FB0;
  v2[549] = xmmword_7FF91E5C1FD0;
  v2[552] = xmmword_7FF91E5C1F40;
  v2[551] = xmmword_7FF91E5C1F80;
  v2[554] = xmmword_7FF91E5C1ED0;
  v2[553] = xmmword_7FF91E5C1F10;
  v2[556] = xmmword_7FF91E5C1E80;
  v2[555] = xmmword_7FF91E5C1EB0;
  v2[558] = xmmword_7FF91E5C1E10;
  v2[557] = xmmword_7FF91E5C1E50;
  v2[560] = xmmword_7FF91E5C1D70;
  v2[559] = xmmword_7FF91E5C1DD0;
  v2[562] = xmmword_7FF91E5C1D40;
  v2[561] = xmmword_7FF91E5C1D50;
  v2[564] = xmmword_7FF91E5C1CC0;
  v2[563] = xmmword_7FF91E5C1CF0;
  v2[566] = xmmword_7FF91E5C1C60;
  v2[565] = xmmword_7FF91E5C1CA0;
  v2[567] = xmmword_7FF91E5C1C40;
  v2[568] = xmmword_7FF91E5C1C10;
  v2[569] = xmmword_7FF91E5C1BD0;
  v2[570] = xmmword_7FF91E5C1B90;
  v2[571] = xmmword_7FF91E5C1B60;
  v2[572] = xmmword_7FF91E5C1B10;
  v2[573] = xmmword_7FF91E5C1AF0;
  v2[574] = xmmword_7FF91E5C1AD0;
  v2[575] = xmmword_7FF91E5C1A90;
  v2[576] = xmmword_7FF91E5C1A50;
  v2[577] = xmmword_7FF91E5C1A30;
  v2[578] = xmmword_7FF91E5C1A00;
  v2[579] = xmmword_7FF91E5C19D0;
  v2[580] = xmmword_7FF91E5C1840;
  v2[581] = xmmword_7FF91E5C1720;
  v2[582] = xmmword_7FF91E5C1670;
  v2[583] = xmmword_7FF91E5C15B0;
  v2[584] = xmmword_7FF91E5C1500;
  v2[585] = xmmword_7FF91E5C13E0;
  v2[586] = xmmword_7FF91E5C1300;
  v2[587] = xmmword_7FF91E5C1250;
  v2[588] = xmmword_7FF91E5C1180;
  v2[589] = xmmword_7FF91E5C10A0;
  v2[590] = xmmword_7FF91E5C1010;
  v2[591] = xmmword_7FF91E5C0F50;
  v2[592] = xmmword_7FF91E5C0CB0;
  v2[593] = xmmword_7FF91E5C0A00;
  v2[594] = xmmword_7FF91E5C07B0;
  v2[595] = xmmword_7FF91E5C05A0;
  v2[596] = xmmword_7FF91E5C3AD0;
  v2[597] = xmmword_7FF91E5C3F20;
  v2[598] = xmmword_7FF91E5C4070;
  v2[599] = xmmword_7FF91E5C4240;
  v2[600] = xmmword_7FF91E5C4340;
  v2[601] = xmmword_7FF91E5C4420;
  v2[602] = xmmword_7FF91E5C4530;
  v2[603] = xmmword_7FF91E5C4690;
  v2[604] = xmmword_7FF91E5C48E0;
  v2[605] = xmmword_7FF91E5C4940;
  v2[606] = xmmword_7FF91E5C49B0;
  v2[607] = xmmword_7FF91E5C49D0;
  v2[609] = xmmword_7FF91E5C4A70;
  v2[608] = xmmword_7FF91E5C4A40;
  v2[611] = xmmword_7FF91E5C4B20;
  v2[610] = xmmword_7FF91E5C4AA0;
  v2[613] = xmmword_7FF91E5C4BC0;
  v2[612] = xmmword_7FF91E5C4B60;
  v2[615] = xmmword_7FF91E5C4C40;
  v2[614] = xmmword_7FF91E5C4C00;
  v2[617] = xmmword_7FF91E5C4CD0;
  v2[616] = xmmword_7FF91E5C4C90;
  v2[619] = xmmword_7FF91E5C4D80;
  v2[618] = xmmword_7FF91E5C4D30;
  v2[621] = xmmword_7FF91E5C4DF0;
  v2[620] = xmmword_7FF91E5C4DC0;
  v2[623] = xmmword_7FF91E5C4E90;
  v2[622] = xmmword_7FF91E5C4E50;
  v2[625] = xmmword_7FF91E5C4F00;
  v2[624] = xmmword_7FF91E5C4ED0;
  v2[627] = xmmword_7FF91E5C4F90;
  v2[626] = xmmword_7FF91E5C4F50;
  v2[629] = xmmword_7FF91E5C5050;
  v2[628] = xmmword_7FF91E5C4FF0;
  v2[631] = xmmword_7FF91E5C50C0;
  v2[630] = xmmword_7FF91E5C5090;
  v2[633] = xmmword_7FF91E5C5110;
  v2[632] = xmmword_7FF91E5C50F0;
  v2[635] = xmmword_7FF91E5C5170;
  v2[634] = xmmword_7FF91E5C5140;
  v2[637] = xmmword_7FF91E5C51C0;
  v2[636] = xmmword_7FF91E5C5190;
  v2[639] = xmmword_7FF91E5C5200;
  v2[638] = xmmword_7FF91E5C51E0;
  v2[641] = xmmword_7FF91E5C5250;
  v2[640] = xmmword_7FF91E5C5230;
  v2[643] = xmmword_7FF91E5C5290;
  v2[642] = xmmword_7FF91E5C5270;
  v2[645] = xmmword_7FF91E5C52E0;
  v2[644] = xmmword_7FF91E5C52C0;
  v2[647] = xmmword_7FF91E5C5320;
  v2[646] = xmmword_7FF91E5C5300;
  v2[648] = xmmword_7FF91E5C5340;
  v2[649] = xmmword_7FF91E5C5330;
  v2[650] = xmmword_7FF91E5C5310;
  v2[651] = xmmword_7FF91E5C52F0;
  v2[652] = xmmword_7FF91E5C52D0;
  v2[653] = xmmword_7FF91E5C52B0;
  v2[654] = xmmword_7FF91E5C5280;
  v2[655] = xmmword_7FF91E5C5260;
  v2[656] = xmmword_7FF91E5C5240;
  v2[657] = xmmword_7FF91E5C5220;
  v2[658] = xmmword_7FF91E5C51F0;
  v2[659] = xmmword_7FF91E5C51D0;
  v2[660] = xmmword_7FF91E5C51B0;
  v2[661] = xmmword_7FF91E5C51A0;
  v2[662] = xmmword_7FF91E5C5180;
  v2[663] = xmmword_7FF91E5C5150;
  v2[664] = xmmword_7FF91E5C5120;
  v2[665] = xmmword_7FF91E5C5100;
  v2[666] = xmmword_7FF91E5C50D0;
  v2[667] = xmmword_7FF91E5C50A0;
  v2[668] = xmmword_7FF91E5C5070;
  v2[669] = xmmword_7FF91E5C5040;
  v2[670] = xmmword_7FF91E5C4FD0;
  v2[671] = xmmword_7FF91E5C4FA0;
  v2[672] = xmmword_7FF91E5C4F70;
  v2[673] = xmmword_7FF91E5C4F20;
  v2[674] = xmmword_7FF91E5C4EE0;
  v2[675] = xmmword_7FF91E5C4EC0;
  v2[676] = xmmword_7FF91E5C4E80;
  v2[677] = xmmword_7FF91E5C4E40;
  v2[678] = xmmword_7FF91E5C4E10;
  v2[679] = xmmword_7FF91E5C4DE0;
  v2[680] = xmmword_7FF91E5C4D90;
  v2[681] = xmmword_7FF91E5C4D60;
  v2[682] = xmmword_7FF91E5C4D20;
  v2[683] = xmmword_7FF91E5C4CE0;
  v2[684] = xmmword_7FF91E5C4CA0;
  v2[685] = xmmword_7FF91E5C4C70;
  v2[686] = xmmword_7FF91E5C4C20;
  v2[687] = xmmword_7FF91E5C4BF0;
  v2[688] = xmmword_7FF91E5C4BD0;
  v2[690] = xmmword_7FF91E5C4B50;
  v2[689] = xmmword_7FF91E5C4B80;
  v2[692] = xmmword_7FF91E5C4AB0;
  v2[691] = xmmword_7FF91E5C4B10;
  v2[694] = xmmword_7FF91E5C4A50;
  v2[693] = xmmword_7FF91E5C4A80;
  v2[696] = xmmword_7FF91E5C49F0;
  v2[695] = xmmword_7FF91E5C4A20;
  v2[698] = xmmword_7FF91E5C4980;
  v2[697] = xmmword_7FF91E5C49C0;
  v2[700] = xmmword_7FF91E5C4930;
  v2[699] = xmmword_7FF91E5C4950;
  v2[702] = xmmword_7FF91E5C4670;
  v2[701] = xmmword_7FF91E5C4790;
  v2[704] = xmmword_7FF91E5C44E0;
  v2[703] = xmmword_7FF91E5C45A0;
  v2[706] = xmmword_7FF91E5C4380;
  v2[705] = xmmword_7FF91E5C4410;
  v2[708] = xmmword_7FF91E5C4270;
  v2[707] = xmmword_7FF91E5C42E0;
  v2[710] = xmmword_7FF91E5C4020;
  v2[709] = xmmword_7FF91E5C4140;
  v2[712] = xmmword_7FF91E5C3EA0;
  v2[711] = xmmword_7FF91E5C3F70;
  v2[714] = xmmword_7FF91E5C3950;
  v2[713] = xmmword_7FF91E5C3AF0;
  v2[716] = xmmword_7FF91E5C0710;
  v2[715] = xmmword_7FF91E5C05F0;
  v2[718] = xmmword_7FF91E5C0990;
  v2[717] = xmmword_7FF91E5C0860;
  v2[720] = xmmword_7FF91E5C0C40;
  v2[719] = xmmword_7FF91E5C0AF0;
  v2[722] = xmmword_7FF91E5C0F40;
  v2[721] = xmmword_7FF91E5C0EF0;
  v2[724] = xmmword_7FF91E5C1000;
  v2[723] = xmmword_7FF91E5C0FA0;
  v2[726] = xmmword_7FF91E5C1090;
  v2[725] = xmmword_7FF91E5C1050;
  v2[728] = xmmword_7FF91E5C1150;
  v2[727] = xmmword_7FF91E5C10F0;
  v2[729] = xmmword_7FF91E5C11A0;
  v2[730] = xmmword_7FF91E5C1210;
  v2[731] = xmmword_7FF91E5C1260;
  v2[732] = xmmword_7FF91E5C12A0;
  v2[733] = xmmword_7FF91E5C12F0;
  v2[734] = xmmword_7FF91E5C1360;
  v2[735] = xmmword_7FF91E5C13A0;
  v2[736] = xmmword_7FF91E5C1420;
  v2[737] = xmmword_7FF91E5C14A0;
  v2[738] = xmmword_7FF91E5C14E0;
  v2[739] = xmmword_7FF91E5C1510;
  v2[740] = xmmword_7FF91E5C1550;
  v2[741] = xmmword_7FF91E5C1590;
  v2[742] = xmmword_7FF91E5C15C0;
  v2[743] = xmmword_7FF91E5C1600;
  v2[744] = xmmword_7FF91E5C1620;
  v2[745] = xmmword_7FF91E5C1660;
  v2[746] = xmmword_7FF91E5C1690;
  v2[747] = xmmword_7FF91E5C16B0;
  v2[748] = xmmword_7FF91E5C16E0;
  v2[749] = xmmword_7FF91E5C1700;
  v2[750] = xmmword_7FF91E5C1730;
  v2[751] = xmmword_7FF91E5C1760;
  v2[752] = xmmword_7FF91E5C1790;
  v2[753] = xmmword_7FF91E5C17B0;
  v2[754] = xmmword_7FF91E5C17D0;
  v2[755] = xmmword_7FF91E5C1800;
  v2[756] = xmmword_7FF91E5C1850;
  v2[757] = xmmword_7FF91E5C1870;
  v2[758] = xmmword_7FF91E5C1890;
  v2[759] = xmmword_7FF91E5C18C0;
  v2[760] = xmmword_7FF91E5C18E0;
  v2[761] = xmmword_7FF91E5C1900;
  v2[762] = xmmword_7FF91E5C1920;
  v2[763] = xmmword_7FF91E5C1940;
  v2[764] = xmmword_7FF91E5C1960;
  v2[765] = xmmword_7FF91E5C1990;
  v2[766] = xmmword_7FF91E5C19B0;
  v2[767] = xmmword_7FF91E5C19C0;
  v2[768] = xmmword_7FF91E5C19A0;
  v2[769] = xmmword_7FF91E5C1970;
  v2[771] = xmmword_7FF91E5C1930;
  v2[770] = xmmword_7FF91E5C1950;
  v2[773] = xmmword_7FF91E5C18F0;
  v2[772] = xmmword_7FF91E5C1910;
  v2[775] = xmmword_7FF91E5C18A0;
  v2[774] = xmmword_7FF91E5C18D0;
  v2[777] = xmmword_7FF91E5C1860;
  v2[776] = xmmword_7FF91E5C1880;
  v2[779] = xmmword_7FF91E5C17F0;
  v2[778] = xmmword_7FF91E5C1820;
  v2[781] = xmmword_7FF91E5C17A0;
  v2[780] = xmmword_7FF91E5C17C0;
  v2[783] = xmmword_7FF91E5C1770;
  v2[782] = xmmword_7FF91E5C1780;
  v2[785] = xmmword_7FF91E5C1710;
  v2[784] = xmmword_7FF91E5C1740;
  v2[787] = xmmword_7FF91E5C16D0;
  v2[786] = xmmword_7FF91E5C16F0;
  v2[789] = xmmword_7FF91E5C1680;
  v2[788] = xmmword_7FF91E5C16A0;
  v2[791] = xmmword_7FF91E5C1630;
  v2[790] = xmmword_7FF91E5C1650;
  v2[793] = xmmword_7FF91E5C15F0;
  v2[792] = xmmword_7FF91E5C1610;
  v2[795] = xmmword_7FF91E5C1580;
  v2[794] = xmmword_7FF91E5C15A0;
  v2[797] = xmmword_7FF91E5C1520;
  v2[796] = xmmword_7FF91E5C1540;
  v2[799] = xmmword_7FF91E5C14D0;
  v2[798] = xmmword_7FF91E5C14F0;
  v2[801] = xmmword_7FF91E5C1410;
  v2[800] = xmmword_7FF91E5C1490;
  v2[803] = xmmword_7FF91E5C1370;
  v2[802] = xmmword_7FF91E5C13B0;
  v2[805] = xmmword_7FF91E5C12E0;
  v2[804] = xmmword_7FF91E5C1330;
  v2[807] = xmmword_7FF91E5C1280;
  v2[806] = xmmword_7FF91E5C12B0;
  v2[809] = xmmword_7FF91E5C1200;
  v2[808] = xmmword_7FF91E5C1240;
  v2[810] = xmmword_7FF91E5C11C0;
  v2[811] = xmmword_7FF91E5C1190;
  v2[812] = xmmword_7FF91E5C1140;
  v2[813] = xmmword_7FF91E5C1110;
  v2[814] = xmmword_7FF91E5C10C0;
  v2[815] = xmmword_7FF91E5C1070;
  v2[816] = xmmword_7FF91E5C1060;
  v2[817] = xmmword_7FF91E5C1020;
  v2[818] = xmmword_7FF91E5C0FF0;
  v2[819] = xmmword_7FF91E5C0FB0;
  v2[820] = xmmword_7FF91E5C0F70;
  v2[821] = xmmword_7FF91E5C0F30;
  v2[822] = xmmword_7FF91E5C0F10;
  v2[823] = xmmword_7FF91E5C0D50;
  v2[824] = xmmword_7FF91E5C0C10;
  v2[825] = xmmword_7FF91E5C0B40;
  v2[826] = xmmword_7FF91E5C0A80;
  v2[827] = xmmword_7FF91E5C09B0;
  v2[828] = xmmword_7FF91E5C08F0;
  v2[829] = xmmword_7FF91E5C0830;
  v2[830] = xmmword_7FF91E5C0780;
  v2[831] = xmmword_7FF91E5C06C0;
  v2[832] = xmmword_7FF91E5C0640;
  v2[833] = xmmword_7FF91E5C0590;
  v2[834] = xmmword_7FF91E5C3920;
  v2[835] = xmmword_7FF91E5C39D0;
  v2[836] = xmmword_7FF91E5C3AA0;
  v2[837] = xmmword_7FF91E5C3CE0;
  v2[838] = xmmword_7FF91E5C3E70;
  v2[839] = xmmword_7FF91E5C3ED0;
  v2[840] = xmmword_7FF91E5C3F50;
  v2[841] = xmmword_7FF91E5C3FA0;
  v2[842] = xmmword_7FF91E5C3FD0;
  v2[843] = xmmword_7FF91E5C4050;
  v2[844] = xmmword_7FF91E5C40F0;
  v2[845] = xmmword_7FF91E5C4180;
  v2[846] = xmmword_7FF91E5C4220;
  v2[847] = xmmword_7FF91E5C4250;
  v2[848] = xmmword_7FF91E5C4290;
  v2[849] = xmmword_7FF91E5C42B0;
  v2[850] = xmmword_7FF91E5C4310;
  v2[852] = xmmword_7FF91E5C4370;
  v2[851] = xmmword_7FF91E5C4330;
  v2[854] = xmmword_7FF91E5C43D0;
  v2[853] = xmmword_7FF91E5C43B0;
  v2[856] = xmmword_7FF91E5C4450;
  v2[855] = xmmword_7FF91E5C4400;
  v2[858] = xmmword_7FF91E5C44C0;
  v2[857] = xmmword_7FF91E5C4490;
  v2[860] = xmmword_7FF91E5C4510;
  v2[859] = xmmword_7FF91E5C44F0;
  v2[862] = xmmword_7FF91E5C4570;
  v2[861] = xmmword_7FF91E5C4540;
  v2[864] = xmmword_7FF91E5C45E0;
  v2[863] = xmmword_7FF91E5C45B0;
  v2[866] = xmmword_7FF91E5C4630;
  v2[865] = xmmword_7FF91E5C4610;
  v2[868] = xmmword_7FF91E5C46A0;
  v2[867] = xmmword_7FF91E5C4660;
  v2[870] = xmmword_7FF91E5C46E0;
  v2[869] = xmmword_7FF91E5C46C0;
  v2[872] = xmmword_7FF91E5C4730;
  v2[871] = xmmword_7FF91E5C4710;
  v2[874] = xmmword_7FF91E5C4770;
  v2[873] = xmmword_7FF91E5C4750;
  v2[876] = xmmword_7FF91E5C47D0;
  v2[875] = xmmword_7FF91E5C47A0;
  v2[878] = xmmword_7FF91E5C4810;
  v2[877] = xmmword_7FF91E5C47F0;
  v2[880] = xmmword_7FF91E5C4850;
  v2[879] = xmmword_7FF91E5C4830;
  v2[882] = xmmword_7FF91E5C4890;
  v2[881] = xmmword_7FF91E5C4870;
  v2[884] = xmmword_7FF91E5C48D0;
  v2[883] = xmmword_7FF91E5C48B0;
  v2[886] = xmmword_7FF91E5C48A0;
  v2[885] = xmmword_7FF91E5C48C0;
  v2[888] = xmmword_7FF91E5C4860;
  v2[887] = xmmword_7FF91E5C4880;
  v2[890] = xmmword_7FF91E5C4820;
  v2[889] = xmmword_7FF91E5C4840;
  v2[891] = xmmword_7FF91E5C4800;
  v2[892] = xmmword_7FF91E5C47E0;
  v2[893] = xmmword_7FF91E5C47C0;
  v2[894] = xmmword_7FF91E5C47B0;
  v2[895] = xmmword_7FF91E5C4780;
  v2[896] = xmmword_7FF91E5C4760;
  v2[897] = xmmword_7FF91E5C4740;
  v2[898] = xmmword_7FF91E5C4720;
  v2[899] = xmmword_7FF91E5C4700;
  v2[900] = xmmword_7FF91E5C46D0;
  v2[901] = xmmword_7FF91E5C46B0;
  v2[902] = xmmword_7FF91E5C4680;
  v2[903] = xmmword_7FF91E5C4650;
  v2[904] = xmmword_7FF91E5C4640;
  v2[905] = xmmword_7FF91E5C4620;
  v2[906] = xmmword_7FF91E5C45F0;
  v2[907] = xmmword_7FF91E5C45D0;
  v2[908] = xmmword_7FF91E5C4590;
  v2[909] = xmmword_7FF91E5C4560;
  v2[910] = xmmword_7FF91E5C4550;
  v2[911] = xmmword_7FF91E5C4520;
  v2[912] = xmmword_7FF91E5C4500;
  v2[913] = xmmword_7FF91E5C44D0;
  v2[914] = xmmword_7FF91E5C44B0;
  v2[915] = xmmword_7FF91E5C44A0;
  v2[916] = xmmword_7FF91E5C4470;
  v2[917] = xmmword_7FF91E5C4430;
  v2[918] = xmmword_7FF91E5C43F0;
  v2[919] = xmmword_7FF91E5C43E0;
  v2[920] = xmmword_7FF91E5C43C0;
  v2[921] = xmmword_7FF91E5C43A0;
  v2[922] = xmmword_7FF91E5C4360;
  v2[923] = xmmword_7FF91E5C4350;
  v2[924] = xmmword_7FF91E5C4320;
  v2[925] = xmmword_7FF91E5C4300;
  v2[926] = xmmword_7FF91E5C42D0;
  v2[927] = xmmword_7FF91E5C42A0;
  v2[928] = xmmword_7FF91E5C4280;
  v2[929] = xmmword_7FF91E5C4260;
  v2[930] = xmmword_7FF91E5C4230;
  v2[931] = xmmword_7FF91E5C4210;
  v2[933] = xmmword_7FF91E5C4120;
  v2[932] = xmmword_7FF91E5C41B0;
  v2[935] = xmmword_7FF91E5C4090;
  v2[934] = xmmword_7FF91E5C40D0;
  v2[937] = xmmword_7FF91E5C3FE0;
  v2[936] = xmmword_7FF91E5C4030;
  v2[939] = xmmword_7FF91E5C3F90;
  v2[938] = xmmword_7FF91E5C3FB0;
  v2[941] = xmmword_7FF91E5C3F30;
  v2[940] = xmmword_7FF91E5C3F60;
  v2[943] = xmmword_7FF91E5C3EC0;
  v2[942] = xmmword_7FF91E5C3EE0;
  v2[945] = xmmword_7FF91E5C3E60;
  v2[944] = xmmword_7FF91E5C3E80;
  v2[947] = xmmword_7FF91E5C3B40;
  v2[946] = xmmword_7FF91E5C3CA0;
  v2[949] = xmmword_7FF91E5C3A30;
  v2[948] = xmmword_7FF91E5C3A80;
  v2[951] = xmmword_7FF91E5C3970;
  v2[950] = xmmword_7FF91E5C39B0;
  v2[953] = xmmword_7FF91E5C0540;
  v2[952] = xmmword_7FF91E5C3900;
  v2[955] = xmmword_7FF91E5C05D0;
  v2[954] = xmmword_7FF91E5C0580;
  v2[957] = xmmword_7FF91E5C0670;
  v2[956] = xmmword_7FF91E5C0630;
  v2[959] = xmmword_7FF91E5C06E0;
  v2[958] = xmmword_7FF91E5C06A0;
  v2[961] = xmmword_7FF91E5C0770;
  v2[960] = xmmword_7FF91E5C0730;
  v2[963] = xmmword_7FF91E5C0800;
  v2[962] = xmmword_7FF91E5C07D0;
  v2[965] = xmmword_7FF91E5C0880;
  v2[964] = xmmword_7FF91E5C0840;
  v2[967] = xmmword_7FF91E5C0900;
  v2[966] = xmmword_7FF91E5C08C0;
  v2[969] = xmmword_7FF91E5C0970;
  v2[968] = xmmword_7FF91E5C0930;
  v2[971] = xmmword_7FF91E5C09E0;
  v2[970] = xmmword_7FF91E5C09C0;
  v2[972] = xmmword_7FF91E5C0A30;
  v2[973] = xmmword_7FF91E5C0A60;
  v2[974] = xmmword_7FF91E5C0AA0;
  v2[975] = xmmword_7FF91E5C0AC0;
  v2[976] = xmmword_7FF91E5C0B10;
  v2[977] = xmmword_7FF91E5C0B30;
  v2[978] = xmmword_7FF91E5C0B60;
  v2[979] = xmmword_7FF91E5C0B90;
  v2[980] = xmmword_7FF91E5C0BB0;
  v2[981] = xmmword_7FF91E5C0BD0;
  v2[982] = xmmword_7FF91E5C0BF0;
  v2[983] = xmmword_7FF91E5C0C30;
  v2[984] = xmmword_7FF91E5C0C70;
  v2[985] = xmmword_7FF91E5C0C90;
  v2[986] = xmmword_7FF91E5C0CC0;
  v2[987] = xmmword_7FF91E5C0CF0;
  v2[988] = xmmword_7FF91E5C0D10;
  v2[989] = xmmword_7FF91E5C0D40;
  v2[990] = xmmword_7FF91E5C0D70;
  v2[991] = xmmword_7FF91E5C0D90;
  v2[992] = xmmword_7FF91E5C0DB0;
  v2[993] = xmmword_7FF91E5C0DD0;
  v2[994] = xmmword_7FF91E5C0E00;
  v2[995] = xmmword_7FF91E5C0E20;
  v2[996] = xmmword_7FF91E5C0E40;
  v2[997] = xmmword_7FF91E5C0E60;
  v2[998] = xmmword_7FF91E5C0E80;
  v2[999] = xmmword_7FF91E5C0EA0;
  v2[1000] = xmmword_7FF91E5C0EC0;
  v2[1001] = xmmword_7FF91E5C0EE0;
  v2[1002] = xmmword_7FF91E5C0ED0;
  v2[1003] = xmmword_7FF91E5C0EB0;
  v2[1004] = xmmword_7FF91E5C0E90;
  v2[1005] = xmmword_7FF91E5C0E70;
  v2[1006] = xmmword_7FF91E5C0E50;
  v2[1007] = xmmword_7FF91E5C0E30;
  v2[1008] = xmmword_7FF91E5C0E10;
  v2[1009] = xmmword_7FF91E5C0DF0;
  v2[1010] = xmmword_7FF91E5C0DC0;
  v2[1011] = xmmword_7FF91E5C0DA0;
  v2[1012] = xmmword_7FF91E5C0D80;
  v2[1014] = xmmword_7FF91E5C0D30;
  v2[1013] = xmmword_7FF91E5C0D60;
  v2[1016] = xmmword_7FF91E5C0D00;
  v2[1015] = xmmword_7FF91E5C0D20;
  v2[1018] = xmmword_7FF91E5C0CA0;
  v2[1017] = xmmword_7FF91E5C0CE0;
  v2[1020] = xmmword_7FF91E5C0C60;
  v2[1019] = xmmword_7FF91E5C0C80;
  v2[1022] = xmmword_7FF91E5C0C00;
  v2[1021] = xmmword_7FF91E5C0C20;
  v2[1024] = xmmword_7FF91E5C0BC0;
  v2[1023] = xmmword_7FF91E5C0BE0;
  v2[1026] = xmmword_7FF91E5C0B80;
  v2[1025] = xmmword_7FF91E5C0BA0;
  v2[1028] = xmmword_7FF91E5C0B50;
  v2[1027] = xmmword_7FF91E5C0B70;
  v2[1030] = xmmword_7FF91E5C0B00;
  v2[1029] = xmmword_7FF91E5C0B20;
  v2[1032] = xmmword_7FF91E5C0AB0;
  v2[1031] = xmmword_7FF91E5C0AE0;
  v2[1034] = xmmword_7FF91E5C0A70;
  v2[1033] = xmmword_7FF91E5C0A90;
  v2[1036] = xmmword_7FF91E5C0A20;
  v2[1035] = xmmword_7FF91E5C0A40;
  v2[1038] = xmmword_7FF91E5C09D0;
  v2[1037] = xmmword_7FF91E5C09F0;
  v2[1040] = xmmword_7FF91E5C0980;
  v2[1039] = xmmword_7FF91E5C09A0;
  v2[1042] = xmmword_7FF91E5C0920;
  v2[1041] = xmmword_7FF91E5C0950;
  v2[1044] = xmmword_7FF91E5C08D0;
  v2[1043] = xmmword_7FF91E5C0910;
  v2[1046] = xmmword_7FF91E5C0890;
  v2[1045] = xmmword_7FF91E5C08B0;
  v2[1048] = xmmword_7FF91E5C0850;
  v2[1047] = xmmword_7FF91E5C0870;
  v2[1050] = xmmword_7FF91E5C07F0;
  v2[1049] = xmmword_7FF91E5C0810;
  v2[1052] = xmmword_7FF91E5C07C0;
  v2[1051] = xmmword_7FF91E5C07E0;
  v2[1053] = xmmword_7FF91E5C0790;
  v2[1054] = xmmword_7FF91E5C0760;
  v2[1055] = xmmword_7FF91E5C0750;
  v2[1056] = xmmword_7FF91E5C0720;
  v2[1057] = xmmword_7FF91E5C06F0;
  v2[1058] = xmmword_7FF91E5C06D0;
  v2[1059] = xmmword_7FF91E5C06B0;
  v2[1060] = xmmword_7FF91E5C0690;
  v2[1061] = xmmword_7FF91E5C0680;
  v2[1062] = xmmword_7FF91E5C0660;
  v2[1063] = xmmword_7FF91E5C0650;
  v2[1064] = xmmword_7FF91E5C0620;
  v2[1065] = xmmword_7FF91E5C0600;
  v2[1066] = xmmword_7FF91E5C05E0;
  v2[1067] = xmmword_7FF91E5C05C0;
  v2[1068] = xmmword_7FF91E5C05B0;
  v2[1069] = xmmword_7FF91E5C0570;
  v2[1070] = xmmword_7FF91E5C0560;
  v2[1071] = xmmword_7FF91E5C0550;
  v2[1072] = xmmword_7FF91E5C38B0;
  v2[1073] = xmmword_7FF91E5C38D0;
  v2[1074] = xmmword_7FF91E5C38F0;
  v2[1075] = xmmword_7FF91E5C3930;
  v2[1076] = xmmword_7FF91E5C3940;
  v2[1077] = xmmword_7FF91E5C3960;
  v2[1078] = xmmword_7FF91E5C3980;
  v2[1079] = xmmword_7FF91E5C3990;
  v2[1080] = xmmword_7FF91E5C39A0;
  v2[1081] = xmmword_7FF91E5C39C0;
  v2[1082] = xmmword_7FF91E5C39E0;
  v2[1083] = xmmword_7FF91E5C3A00;
  v2[1084] = xmmword_7FF91E5C3A20;
  v2[1085] = xmmword_7FF91E5C3A40;
  v2[1086] = xmmword_7FF91E5C3A50;
  v2[1087] = xmmword_7FF91E5C3A60;
  v2[1088] = xmmword_7FF91E5C3A70;
  v2[1089] = xmmword_7FF91E5C3A90;
  v2[1090] = xmmword_7FF91E5C3AB0;
  v2[1091] = xmmword_7FF91E5C3AC0;
  v2[1092] = xmmword_7FF91E5C3AE0;
  v2[1093] = xmmword_7FF91E5C3B10;
  v2[1095] = xmmword_7FF91E5C3B70;
  v2[1094] = xmmword_7FF91E5C3B30;
  v2[1097] = xmmword_7FF91E5C3BC0;
  v2[1096] = xmmword_7FF91E5C3B90;
  v2[1099] = xmmword_7FF91E5C3C20;
  v2[1098] = xmmword_7FF91E5C3BF0;
  v2[1101] = xmmword_7FF91E5C3C70;
  v2[1100] = xmmword_7FF91E5C3C40;
  v2[1103] = xmmword_7FF91E5C3CC0;
  v2[1102] = xmmword_7FF91E5C3C90;
  v2[1105] = xmmword_7FF91E5C3D10;
  v2[1104] = xmmword_7FF91E5C3CF0;
  v2[1107] = xmmword_7FF91E5C3D60;
  v2[1106] = xmmword_7FF91E5C3D40;
  v2[1109] = xmmword_7FF91E5C3DA0;
  v2[1108] = xmmword_7FF91E5C3D80;
  v2[1111] = xmmword_7FF91E5C3DE0;
  v2[1110] = xmmword_7FF91E5C3DC0;
  v2[1113] = xmmword_7FF91E5C3E20;
  v2[1112] = xmmword_7FF91E5C3E00;
  v2[1115] = xmmword_7FF91E5C3E50;
  v2[1114] = xmmword_7FF91E5C3E40;
  v2[1117] = xmmword_7FF91E5C3E10;
  v2[1116] = xmmword_7FF91E5C3E30;
  v2[1119] = xmmword_7FF91E5C3DD0;
  v2[1118] = xmmword_7FF91E5C3DF0;
  v2[1121] = xmmword_7FF91E5C3D90;
  v2[1120] = xmmword_7FF91E5C3DB0;
  v2[1123] = xmmword_7FF91E5C3D50;
  v2[1122] = xmmword_7FF91E5C3D70;
  v2[1125] = xmmword_7FF91E5C3D20;
  v2[1124] = xmmword_7FF91E5C3D30;
  v2[1127] = xmmword_7FF91E5C3CD0;
  v2[1126] = xmmword_7FF91E5C3D00;
  v2[1129] = xmmword_7FF91E5C3C80;
  v2[1128] = xmmword_7FF91E5C3CB0;
  v2[1131] = xmmword_7FF91E5C3C50;
  v2[1130] = xmmword_7FF91E5C3C60;
  v2[1133] = xmmword_7FF91E5C3C00;
  v2[1132] = xmmword_7FF91E5C3C30;
  v2[1134] = xmmword_7FF91E5C3BE0;
  v2[1135] = xmmword_7FF91E5C3BD0;
  v2[1136] = xmmword_7FF91E5C3BA0;
  v2[1137] = xmmword_7FF91E5C3B80;
  v2[1138] = xmmword_7FF91E5C3B60;
  v2[1139] = xmmword_7FF91E5C3B50;
  v2[1140] = xmmword_7FF91E5C3B20;
  v2[1141] = xmmword_7FF91E5C3B00;
  sub_7FF91DFA3780(&xmmword_7FF91E910658, v2, &v3, v1);
  return atexit(sub_7FF91E58EE00);
}


// ==== sub_7FF91DCB7A60 @ rva 0x57A60 ====
int sub_7FF91DCB7A60()
{
  unsigned __int8 v1; // [rsp+20h] [rbp-E0h]
  _OWORD v2[381]; // [rsp+30h] [rbp-D0h] BYREF
  __int64 v3; // [rsp+1800h] [rbp+1700h] BYREF

  v2[0] = xmmword_7FF91E5C37F0;
  v2[1] = xmmword_7FF91E5C37E0;
  v2[2] = xmmword_7FF91E5C37D0;
  v2[3] = xmmword_7FF91E5C37C0;
  v2[4] = xmmword_7FF91E5C37B0;
  v2[5] = xmmword_7FF91E5C37A0;
  v2[6] = xmmword_7FF91E5C3780;
  v2[7] = xmmword_7FF91E5C3770;
  v2[8] = xmmword_7FF91E5C3760;
  v2[9] = xmmword_7FF91E5C3750;
  v2[10] = xmmword_7FF91E5C3740;
  v2[11] = xmmword_7FF91E5C3730;
  v2[12] = xmmword_7FF91E5C3720;
  v2[13] = xmmword_7FF91E5C3710;
  v2[14] = xmmword_7FF91E5C3700;
  v2[15] = xmmword_7FF91E5C36F0;
  v2[16] = xmmword_7FF91E5C36E0;
  v2[17] = xmmword_7FF91E5C36C0;
  v2[18] = xmmword_7FF91E5C36B0;
  v2[19] = xmmword_7FF91E5C36A0;
  v2[20] = xmmword_7FF91E5C3690;
  v2[21] = xmmword_7FF91E5C3680;
  v2[22] = xmmword_7FF91E5C3670;
  v2[23] = xmmword_7FF91E5C3660;
  v2[24] = xmmword_7FF91E5C3650;
  v2[25] = xmmword_7FF91E5C3630;
  v2[26] = xmmword_7FF91E5C3610;
  v2[27] = xmmword_7FF91E5C35E0;
  v2[28] = xmmword_7FF91E5C3550;
  v2[29] = xmmword_7FF91E5C33D0;
  v2[30] = xmmword_7FF91E5C3300;
  v2[31] = xmmword_7FF91E5C3230;
  v2[32] = xmmword_7FF91E5C3190;
  v2[33] = xmmword_7FF91E5C30F0;
  v2[34] = xmmword_7FF91E5C3050;
  v2[35] = xmmword_7FF91E5C2F60;
  v2[36] = xmmword_7FF91E5C2DD0;
  v2[37] = xmmword_7FF91E5C2CC0;
  v2[38] = xmmword_7FF91E5C2620;
  v2[39] = xmmword_7FF91E5C3F40;
  v2[40] = xmmword_7FF91E5C5D00;
  v2[42] = xmmword_7FF91E5C6450;
  v2[41] = xmmword_7FF91E5C5FC0;
  v2[44] = xmmword_7FF91E5C6570;
  v2[43] = xmmword_7FF91E5C6540;
  v2[46] = xmmword_7FF91E5C65E0;
  v2[45] = xmmword_7FF91E5C65B0;
  v2[48] = xmmword_7FF91E5C6650;
  v2[47] = xmmword_7FF91E5C6610;
  v2[50] = xmmword_7FF91E5C66B0;
  v2[49] = xmmword_7FF91E5C6680;
  v2[52] = xmmword_7FF91E5C66F0;
  v2[51] = xmmword_7FF91E5C66D0;
  v2[54] = xmmword_7FF91E5C6730;
  v2[53] = xmmword_7FF91E5C6710;
  v2[56] = xmmword_7FF91E5C6760;
  v2[55] = xmmword_7FF91E5C6750;
  v2[58] = xmmword_7FF91E5C6720;
  v2[57] = xmmword_7FF91E5C6740;
  v2[60] = xmmword_7FF91E5C66E0;
  v2[59] = xmmword_7FF91E5C6700;
  v2[62] = xmmword_7FF91E5C66A0;
  v2[61] = xmmword_7FF91E5C66C0;
  v2[64] = xmmword_7FF91E5C6660;
  v2[63] = xmmword_7FF91E5C6690;
  v2[66] = xmmword_7FF91E5C6600;
  v2[65] = xmmword_7FF91E5C6630;
  v2[68] = xmmword_7FF91E5C65C0;
  v2[67] = xmmword_7FF91E5C65F0;
  v2[70] = xmmword_7FF91E5C6560;
  v2[69] = xmmword_7FF91E5C65A0;
  v2[72] = xmmword_7FF91E5C6530;
  v2[71] = xmmword_7FF91E5C6550;
  v2[74] = xmmword_7FF91E5C6100;
  v2[73] = xmmword_7FF91E5C6470;
  v2[76] = xmmword_7FF91E5C5DD0;
  v2[75] = xmmword_7FF91E5C5F40;
  v2[78] = xmmword_7FF91E5C5350;
  v2[77] = xmmword_7FF91E5C5990;
  v2[80] = xmmword_7FF91E5C2380;
  v2[79] = xmmword_7FF91E5C1570;
  v2[81] = xmmword_7FF91E5C2640;
  v2[82] = xmmword_7FF91E5C29E0;
  v2[83] = xmmword_7FF91E5C2C60;
  v2[84] = xmmword_7FF91E5C2CD0;
  v2[85] = xmmword_7FF91E5C2D30;
  v2[86] = xmmword_7FF91E5C2D80;
  v2[87] = xmmword_7FF91E5C2DC0;
  v2[88] = xmmword_7FF91E5C2E10;
  v2[89] = xmmword_7FF91E5C2E40;
  v2[90] = xmmword_7FF91E5C2E80;
  v2[91] = xmmword_7FF91E5C2EB0;
  v2[92] = xmmword_7FF91E5C2EF0;
  v2[93] = xmmword_7FF91E5C2F20;
  v2[94] = xmmword_7FF91E5C2F50;
  v2[95] = xmmword_7FF91E5C2F80;
  v2[96] = xmmword_7FF91E5C2FA0;
  v2[97] = xmmword_7FF91E5C2F90;
  v2[98] = xmmword_7FF91E5C2F70;
  v2[99] = xmmword_7FF91E5C2F40;
  v2[100] = xmmword_7FF91E5C2F10;
  v2[101] = xmmword_7FF91E5C2EE0;
  v2[102] = xmmword_7FF91E5C2EC0;
  v2[103] = xmmword_7FF91E5C2E90;
  v2[104] = xmmword_7FF91E5C2E60;
  v2[105] = xmmword_7FF91E5C2E20;
  v2[106] = xmmword_7FF91E5C2DF0;
  v2[107] = xmmword_7FF91E5C2DA0;
  v2[108] = xmmword_7FF91E5C2D70;
  v2[109] = xmmword_7FF91E5C2D40;
  v2[110] = xmmword_7FF91E5C2CF0;
  v2[111] = xmmword_7FF91E5C2CA0;
  v2[112] = xmmword_7FF91E5C2C40;
  v2[113] = xmmword_7FF91E5C2B70;
  v2[114] = xmmword_7FF91E5C27B0;
  v2[115] = xmmword_7FF91E5C25A0;
  v2[116] = xmmword_7FF91E5C2400;
  v2[117] = xmmword_7FF91E5C1DB0;
  v2[118] = xmmword_7FF91E5C1470;
  v2[119] = xmmword_7FF91E5C4AD0;
  v2[120] = xmmword_7FF91E5C5450;
  v2[121] = xmmword_7FF91E5C5730;
  v2[123] = xmmword_7FF91E5C5D50;
  v2[122] = xmmword_7FF91E5C5C20;
  v2[125] = xmmword_7FF91E5C5E80;
  v2[124] = xmmword_7FF91E5C5DF0;
  v2[127] = xmmword_7FF91E5C5F90;
  v2[126] = xmmword_7FF91E5C5F10;
  v2[129] = xmmword_7FF91E5C60A0;
  v2[128] = xmmword_7FF91E5C6030;
  v2[131] = xmmword_7FF91E5C61B0;
  v2[130] = xmmword_7FF91E5C6130;
  v2[133] = xmmword_7FF91E5C6270;
  v2[132] = xmmword_7FF91E5C6210;
  v2[135] = xmmword_7FF91E5C6310;
  v2[134] = xmmword_7FF91E5C62D0;
  v2[137] = xmmword_7FF91E5C6330;
  v2[136] = xmmword_7FF91E5C6340;
  v2[139] = xmmword_7FF91E5C62B0;
  v2[138] = xmmword_7FF91E5C62F0;
  v2[141] = xmmword_7FF91E5C6200;
  v2[140] = xmmword_7FF91E5C6260;
  v2[143] = xmmword_7FF91E5C6140;
  v2[142] = xmmword_7FF91E5C6190;
  v2[145] = xmmword_7FF91E5C6040;
  v2[144] = xmmword_7FF91E5C60C0;
  v2[147] = xmmword_7FF91E5C5F60;
  v2[146] = xmmword_7FF91E5C5FE0;
  v2[149] = xmmword_7FF91E5C5E70;
  v2[148] = xmmword_7FF91E5C5EE0;
  v2[151] = xmmword_7FF91E5C5D90;
  v2[150] = xmmword_7FF91E5C5E10;
  v2[153] = xmmword_7FF91E5C5B10;
  v2[152] = xmmword_7FF91E5C5D20;
  v2[155] = xmmword_7FF91E5C55D0;
  v2[154] = xmmword_7FF91E5C57E0;
  v2[157] = xmmword_7FF91E5C4C80;
  v2[156] = xmmword_7FF91E5C53C0;
  v2[159] = xmmword_7FF91E5C1560;
  v2[158] = xmmword_7FF91E5C4000;
  v2[161] = xmmword_7FF91E5C1F00;
  v2[160] = xmmword_7FF91E5C1BA0;
  v2[162] = xmmword_7FF91E5C2390;
  v2[163] = xmmword_7FF91E5C2460;
  v2[164] = xmmword_7FF91E5C2510;
  v2[165] = xmmword_7FF91E5C25D0;
  v2[166] = xmmword_7FF91E5C2690;
  v2[167] = xmmword_7FF91E5C2760;
  v2[168] = xmmword_7FF91E5C2820;
  v2[169] = xmmword_7FF91E5C28F0;
  v2[170] = xmmword_7FF91E5C29C0;
  v2[171] = xmmword_7FF91E5C2B40;
  v2[172] = xmmword_7FF91E5C2B90;
  v2[173] = xmmword_7FF91E5C2BB0;
  v2[174] = xmmword_7FF91E5C2BD0;
  v2[175] = xmmword_7FF91E5C2BF0;
  v2[176] = xmmword_7FF91E5C2C10;
  v2[177] = xmmword_7FF91E5C2C00;
  v2[178] = xmmword_7FF91E5C2BE0;
  v2[179] = xmmword_7FF91E5C2BC0;
  v2[180] = xmmword_7FF91E5C2BA0;
  v2[181] = xmmword_7FF91E5C2B50;
  v2[182] = xmmword_7FF91E5C2A30;
  v2[183] = xmmword_7FF91E5C2940;
  v2[184] = xmmword_7FF91E5C2890;
  v2[185] = xmmword_7FF91E5C27D0;
  v2[186] = xmmword_7FF91E5C2730;
  v2[187] = xmmword_7FF91E5C26A0;
  v2[188] = xmmword_7FF91E5C25F0;
  v2[189] = xmmword_7FF91E5C2560;
  v2[190] = xmmword_7FF91E5C24D0;
  v2[191] = xmmword_7FF91E5C2440;
  v2[192] = xmmword_7FF91E5C23B0;
  v2[193] = xmmword_7FF91E5C20C0;
  v2[194] = xmmword_7FF91E5C1DF0;
  v2[195] = xmmword_7FF91E5C1BC0;
  v2[196] = xmmword_7FF91E5C19F0;
  v2[197] = xmmword_7FF91E5C1220;
  v2[198] = xmmword_7FF91E5C3BB0;
  v2[199] = xmmword_7FF91E5C4970;
  v2[200] = xmmword_7FF91E5C4CB0;
  v2[201] = xmmword_7FF91E5C50E0;
  v2[202] = xmmword_7FF91E5C53F0;
  v2[204] = xmmword_7FF91E5C55E0;
  v2[203] = xmmword_7FF91E5C54F0;
  v2[206] = xmmword_7FF91E5C5760;
  v2[205] = xmmword_7FF91E5C56A0;
  v2[208] = xmmword_7FF91E5C5900;
  v2[207] = xmmword_7FF91E5C5840;
  v2[210] = xmmword_7FF91E5C5AD0;
  v2[209] = xmmword_7FF91E5C59F0;
  v2[212] = xmmword_7FF91E5C5C60;
  v2[211] = xmmword_7FF91E5C5C30;
  v2[214] = xmmword_7FF91E5C5CA0;
  v2[213] = xmmword_7FF91E5C5C80;
  v2[216] = xmmword_7FF91E5C5CE0;
  v2[215] = xmmword_7FF91E5C5CD0;
  v2[218] = xmmword_7FF91E5C5C90;
  v2[217] = xmmword_7FF91E5C5CC0;
  v2[220] = xmmword_7FF91E5C5C50;
  v2[219] = xmmword_7FF91E5C5C70;
  v2[222] = xmmword_7FF91E5C5A60;
  v2[221] = xmmword_7FF91E5C5B60;
  v2[224] = xmmword_7FF91E5C58D0;
  v2[223] = xmmword_7FF91E5C59A0;
  v2[226] = xmmword_7FF91E5C5770;
  v2[225] = xmmword_7FF91E5C5830;
  v2[228] = xmmword_7FF91E5C5640;
  v2[227] = xmmword_7FF91E5C56D0;
  v2[230] = xmmword_7FF91E5C54E0;
  v2[229] = xmmword_7FF91E5C5590;
  v2[232] = xmmword_7FF91E5C5360;
  v2[231] = xmmword_7FF91E5C5430;
  v2[234] = xmmword_7FF91E5C4D40;
  v2[233] = xmmword_7FF91E5C5030;
  v2[236] = xmmword_7FF91E5C4920;
  v2[235] = xmmword_7FF91E5C4B00;
  v2[238] = xmmword_7FF91E5C0940;
  v2[237] = xmmword_7FF91E5C41C0;
  v2[240] = xmmword_7FF91E5C1530;
  v2[239] = xmmword_7FF91E5C1130;
  v2[242] = xmmword_7FF91E5C1A80;
  v2[241] = xmmword_7FF91E5C1980;
  v2[243] = xmmword_7FF91E5C1B50;
  v2[244] = xmmword_7FF91E5C1C20;
  v2[245] = xmmword_7FF91E5C1CD0;
  v2[246] = xmmword_7FF91E5C1D90;
  v2[247] = xmmword_7FF91E5C1E90;
  v2[248] = xmmword_7FF91E5C1F30;
  v2[249] = xmmword_7FF91E5C1FE0;
  v2[250] = xmmword_7FF91E5C2070;
  v2[251] = xmmword_7FF91E5C2110;
  v2[252] = xmmword_7FF91E5C21B0;
  v2[253] = xmmword_7FF91E5C2240;
  v2[254] = xmmword_7FF91E5C22C0;
  v2[255] = xmmword_7FF91E5C2340;
  v2[256] = xmmword_7FF91E5C22D0;
  v2[257] = xmmword_7FF91E5C2250;
  v2[258] = xmmword_7FF91E5C21D0;
  v2[259] = xmmword_7FF91E5C2130;
  v2[260] = xmmword_7FF91E5C20B0;
  v2[261] = xmmword_7FF91E5C2010;
  v2[262] = xmmword_7FF91E5C1F90;
  v2[263] = xmmword_7FF91E5C1EF0;
  v2[264] = xmmword_7FF91E5C1E60;
  v2[265] = xmmword_7FF91E5C1DA0;
  v2[266] = xmmword_7FF91E5C1D00;
  v2[267] = xmmword_7FF91E5C1C90;
  v2[268] = xmmword_7FF91E5C1BF0;
  v2[269] = xmmword_7FF91E5C1B40;
  v2[270] = xmmword_7FF91E5C1AC0;
  v2[271] = xmmword_7FF91E5C1A20;
  v2[272] = xmmword_7FF91E5C1830;
  v2[273] = xmmword_7FF91E5C15E0;
  v2[274] = xmmword_7FF91E5C1350;
  v2[275] = xmmword_7FF91E5C1120;
  v2[276] = xmmword_7FF91E5C0F20;
  v2[277] = xmmword_7FF91E5C0740;
  v2[278] = xmmword_7FF91E5C3F10;
  v2[279] = xmmword_7FF91E5C42F0;
  v2[280] = xmmword_7FF91E5C45C0;
  v2[281] = xmmword_7FF91E5C4960;
  v2[282] = xmmword_7FF91E5C4A10;
  v2[283] = xmmword_7FF91E5C4AE0;
  v2[285] = xmmword_7FF91E5C4C60;
  v2[284] = xmmword_7FF91E5C4B90;
  v2[287] = xmmword_7FF91E5C4DA0;
  v2[286] = xmmword_7FF91E5C4D10;
  v2[289] = xmmword_7FF91E5C4EB0;
  v2[288] = xmmword_7FF91E5C4E20;
  v2[291] = xmmword_7FF91E5C4F80;
  v2[290] = xmmword_7FF91E5C4F10;
  v2[293] = xmmword_7FF91E5C5000;
  v2[292] = xmmword_7FF91E5C4FC0;
  v2[295] = xmmword_7FF91E5C5010;
  v2[294] = xmmword_7FF91E5C5020;
  v2[297] = xmmword_7FF91E5C4FB0;
  v2[296] = xmmword_7FF91E5C4FE0;
  v2[299] = xmmword_7FF91E5C4EF0;
  v2[298] = xmmword_7FF91E5C4F60;
  v2[301] = xmmword_7FF91E5C4E30;
  v2[300] = xmmword_7FF91E5C4EA0;
  v2[303] = xmmword_7FF91E5C4D50;
  v2[302] = xmmword_7FF91E5C4DD0;
  v2[305] = xmmword_7FF91E5C4C30;
  v2[304] = xmmword_7FF91E5C4CC0;
  v2[307] = xmmword_7FF91E5C4B40;
  v2[306] = xmmword_7FF91E5C4BB0;
  v2[309] = xmmword_7FF91E5C4A00;
  v2[308] = xmmword_7FF91E5C4A90;
  v2[311] = xmmword_7FF91E5C4910;
  v2[310] = xmmword_7FF91E5C4990;
  v2[313] = xmmword_7FF91E5C4440;
  v2[312] = xmmword_7FF91E5C4600;
  v2[315] = xmmword_7FF91E5C40A0;
  v2[314] = xmmword_7FF91E5C42C0;
  v2[317] = xmmword_7FF91E5C3910;
  v2[316] = xmmword_7FF91E5C3EB0;
  v2[319] = xmmword_7FF91E5C0A50;
  v2[318] = xmmword_7FF91E5C07A0;
  v2[321] = xmmword_7FF91E5C0F90;
  v2[320] = xmmword_7FF91E5C0DE0;
  v2[323] = xmmword_7FF91E5C10D0;
  v2[322] = xmmword_7FF91E5C1040;
  v2[324] = xmmword_7FF91E5C1170;
  v2[325] = xmmword_7FF91E5C11E0;
  v2[326] = xmmword_7FF91E5C1270;
  v2[327] = xmmword_7FF91E5C12C0;
  v2[328] = xmmword_7FF91E5C1340;
  v2[329] = xmmword_7FF91E5C1390;
  v2[330] = xmmword_7FF91E5C13D0;
  v2[331] = xmmword_7FF91E5C1430;
  v2[332] = xmmword_7FF91E5C1450;
  v2[333] = xmmword_7FF91E5C1480;
  v2[334] = xmmword_7FF91E5C1460;
  v2[335] = xmmword_7FF91E5C1440;
  v2[336] = xmmword_7FF91E5C1400;
  v2[337] = xmmword_7FF91E5C13C0;
  v2[338] = xmmword_7FF91E5C1380;
  v2[339] = xmmword_7FF91E5C1320;
  v2[340] = xmmword_7FF91E5C12D0;
  v2[341] = xmmword_7FF91E5C1290;
  v2[342] = xmmword_7FF91E5C1230;
  v2[343] = xmmword_7FF91E5C11D0;
  v2[344] = xmmword_7FF91E5C1160;
  v2[345] = xmmword_7FF91E5C1100;
  v2[346] = xmmword_7FF91E5C1080;
  v2[347] = xmmword_7FF91E5C1030;
  v2[348] = xmmword_7FF91E5C0FD0;
  v2[349] = xmmword_7FF91E5C0F60;
  v2[350] = xmmword_7FF91E5C0F00;
  v2[351] = xmmword_7FF91E5C0C50;
  v2[352] = xmmword_7FF91E5C0AD0;
  v2[353] = xmmword_7FF91E5C0960;
  v2[354] = xmmword_7FF91E5C0820;
  v2[355] = xmmword_7FF91E5C0700;
  v2[356] = xmmword_7FF91E5C0610;
  v2[357] = xmmword_7FF91E5C38E0;
  v2[358] = xmmword_7FF91E5C3A10;
  v2[359] = xmmword_7FF91E5C3C10;
  v2[360] = xmmword_7FF91E5C3E90;
  v2[361] = xmmword_7FF91E5C3F00;
  v2[362] = xmmword_7FF91E5C3F80;
  v2[363] = xmmword_7FF91E5C3FC0;
  v2[364] = xmmword_7FF91E5C4010;
  v2[366] = xmmword_7FF91E5C40C0;
  v2[365] = xmmword_7FF91E5C4060;
  v2[368] = xmmword_7FF91E5C4150;
  v2[367] = xmmword_7FF91E5C4110;
  v2[370] = xmmword_7FF91E5C41D0;
  v2[369] = xmmword_7FF91E5C4190;
  v2[372] = xmmword_7FF91E5C41E0;
  v2[371] = xmmword_7FF91E5C41F0;
  v2[374] = xmmword_7FF91E5C4170;
  v2[373] = xmmword_7FF91E5C41A0;
  v2[376] = xmmword_7FF91E5C4100;
  v2[375] = xmmword_7FF91E5C4130;
  v2[378] = xmmword_7FF91E5C4080;
  v2[377] = xmmword_7FF91E5C40B0;
  v2[380] = xmmword_7FF91E5C3FF0;
  v2[379] = xmmword_7FF91E5C4040;
  sub_7FF91DFA3780(&xmmword_7FF91E910638, v2, &v3, v1);
  return atexit(sub_7FF91E58EE70);
}


// ==== sub_7FF91DCB8F70 @ rva 0x58F70 ====
int sub_7FF91DCB8F70()
{
  unsigned __int8 v1; // [rsp+20h] [rbp-E0h]
  _OWORD v2[31]; // [rsp+30h] [rbp-D0h] BYREF
  int v3; // [rsp+220h] [rbp+120h]
  int v4; // [rsp+224h] [rbp+124h]
  _BYTE v5[8]; // [rsp+228h] [rbp+128h] BYREF

  v2[0] = xmmword_7FF91E5C3880;
  v2[2] = xmmword_7FF91E5C3840;
  v2[1] = xmmword_7FF91E5C3870;
  v2[4] = xmmword_7FF91E5C6820;
  v2[3] = xmmword_7FF91E5C67F0;
  v2[6] = xmmword_7FF91E5C3620;
  v2[5] = xmmword_7FF91E5C67E0;
  v2[8] = xmmword_7FF91E5C3790;
  v2[7] = xmmword_7FF91E5C3800;
  v2[10] = xmmword_7FF91E5C67B0;
  v2[9] = xmmword_7FF91E5C59B0;
  v2[12] = xmmword_7FF91E5C65D0;
  v2[11] = xmmword_7FF91E5C67A0;
  v2[14] = xmmword_7FF91E5C3640;
  v2[13] = xmmword_7FF91E5C35F0;
  v2[16] = xmmword_7FF91E5C6670;
  v2[15] = xmmword_7FF91E5C3120;
  v2[18] = xmmword_7FF91E5C6620;
  v2[17] = xmmword_7FF91E5C6770;
  v2[20] = xmmword_7FF91E5C30D0;
  v2[19] = xmmword_7FF91E5C2D00;
  v2[22] = xmmword_7FF91E5C4D70;
  v2[21] = xmmword_7FF91E5C2FD0;
  v2[24] = xmmword_7FF91E5C6430;
  v2[23] = xmmword_7FF91E5C6520;
  v2[26] = xmmword_7FF91E5C2830;
  v2[25] = xmmword_7FF91E5C54D0;
  v2[28] = xmmword_7FF91E5C1E20;
  v2[27] = xmmword_7FF91E5C28B0;
  v2[30] = xmmword_7FF91E5C54B0;
  v2[29] = xmmword_7FF91E5C5390;
  v4 = -1203349217;
  v3 = -1200343762;
  sub_7FF91DFA3780(&xmmword_7FF91E910670, v2, v5, v1);
  return atexit(sub_7FF91E58EEE0);
}


// ==== sub_7FF91DCB9170 @ rva 0x59170 ====
int sub_7FF91DCB9170()
{
  unsigned __int8 v1; // [rsp+20h] [rbp-E0h]
  _OWORD v2[21]; // [rsp+30h] [rbp-D0h] BYREF
  __int64 v3; // [rsp+180h] [rbp+80h] BYREF

  v2[0] = xmmword_7FF91E5C38A0;
  v2[2] = xmmword_7FF91E5C6830;
  v2[1] = xmmword_7FF91E5C3860;
  v2[4] = xmmword_7FF91E5C3810;
  v2[3] = xmmword_7FF91E5C6800;
  v2[6] = xmmword_7FF91E5C6790;
  v2[5] = xmmword_7FF91E5C3830;
  v2[8] = xmmword_7FF91E5C3030;
  v2[7] = xmmword_7FF91E5C67D0;
  v2[10] = xmmword_7FF91E5C2C90;
  v2[9] = xmmword_7FF91E5C36D0;
  v2[12] = xmmword_7FF91E5C6580;
  v2[11] = xmmword_7FF91E5C6780;
  v2[14] = xmmword_7FF91E5C2F00;
  v2[13] = xmmword_7FF91E5C3260;
  v2[16] = xmmword_7FF91E5C6510;
  v2[15] = xmmword_7FF91E5C6590;
  v2[18] = xmmword_7FF91E5C2B60;
  v2[17] = xmmword_7FF91E5C2C30;
  v2[20] = xmmword_7FF91E5C5550;
  v2[19] = xmmword_7FF91E5C5480;
  sub_7FF91DFA3780(&xmmword_7FF91E9106A0, v2, &v3, v1);
  return atexit(sub_7FF91E58EF50);
}


// ==== sub_7FF91DCB92C0 @ rva 0x592C0 ====
int sub_7FF91DCB92C0()
{
  unsigned __int8 v1; // [rsp+20h] [rbp-D8h]
  _OWORD v2[10]; // [rsp+30h] [rbp-C8h] BYREF
  int v3; // [rsp+D0h] [rbp-28h]
  int v4; // [rsp+D4h] [rbp-24h]
  int v5; // [rsp+D8h] [rbp-20h]
  int v6; // [rsp+DCh] [rbp-1Ch] BYREF

  v2[0] = xmmword_7FF91E5C3890;
  v2[1] = xmmword_7FF91E5C6840;
  v2[2] = xmmword_7FF91E5C3850;
  v2[3] = xmmword_7FF91E5C6810;
  v2[4] = xmmword_7FF91E5C3820;
  v2[5] = xmmword_7FF91E5C67C0;
  v2[6] = xmmword_7FF91E5C3600;
  v2[7] = xmmword_7FF91E5C6640;
  v2[8] = xmmword_7FF91E5C2C70;
  v2[9] = xmmword_7FF91E5C4B30;
  v3 = -1184649527;
  v4 = -1184230352;
  v5 = -1191282077;
  sub_7FF91DFA3780(&xmmword_7FF91E910620, v2, &v6, v1);
  return atexit(sub_7FF91E58EFC0);
}


// ==== sub_7FF91DCB93C0 @ rva 0x593C0 ====
// None
