// ==== sub_7FF91DFE0190 @ rva 0x380190 ====
__int64 __fastcall sub_7FF91DFE0190(__int64 a1, _DWORD **a2)
{
  float v2; // xmm4_4
  float v5; // xmm0_4
  float v6; // xmm1_4
  float v7; // xmm2_4
  int v8; // edx
  int v9; // edx
  int v10; // eax
  float v11; // xmm3_4
  float v12; // xmm6_4
  int v13; // eax
  float v14; // xmm8_4
  int v15; // ecx
  float v16; // xmm7_4
  signed int v17; // edx
  float v18; // xmm1_4
  double v19; // xmm10_8
  float v20; // xmm0_4
  float v21; // xmm0_4
  float v22; // xmm1_4
  float v23; // xmm2_4
  float v24; // xmm1_4
  float v25; // xmm0_4
  float v26; // xmm2_4
  float v27; // xmm1_4
  float v28; // xmm6_4
  float v29; // xmm3_4
  float v30; // xmm1_4
  float v31; // xmm3_4
  double v32; // xmm0_8
  float v33; // xmm15_4
  float v34; // xmm5_4
  float v35; // xmm0_4
  float v36; // xmm5_4
  float v37; // xmm2_4
  float v38; // xmm1_4
  int v39; // eax
  float v40; // xmm4_4
  float v41; // xmm3_4
  double v42; // xmm12_8
  float v43; // xmm5_4
  float v44; // xmm0_4
  float v45; // xmm5_4
  float v46; // xmm1_4
  float v47; // xmm2_4
  float v48; // xmm2_4
  float v49; // xmm1_4
  float v50; // xmm2_4
  float v51; // xmm2_4
  float v52; // xmm2_4
  float v53; // xmm1_4
  double v54; // xmm0_8
  float v55; // xmm1_4
  float v56; // xmm1_4
  float v57; // xmm7_4
  float v58; // xmm0_4
  float v59; // xmm2_4
  int v60; // xmm9_4
  float v61; // xmm7_4
  int v62; // xmm8_4
  int v63; // eax
  float v64; // xmm7_4
  float v65; // xmm1_4
  int v66; // eax
  float v67; // xmm0_4
  float v68; // xmm2_4
  float v69; // xmm1_4
  float v70; // xmm2_4
  double v71; // xmm0_8
  float v72; // xmm1_4
  double v73; // xmm0_8
  float v74; // xmm6_4
  float v75; // xmm0_4
  float v76; // xmm1_4
  float v77; // xmm0_4
  float v78; // xmm3_4
  float v79; // xmm7_4
  float v80; // xmm2_4
  float v81; // xmm4_4
  int v82; // eax
  float v83; // xmm1_4
  float v84; // xmm0_4
  float v85; // xmm7_4
  float v86; // xmm7_4
  float v87; // xmm6_4
  float v88; // xmm6_4
  float v89; // xmm0_4
  float v90; // xmm0_4
  float v91; // xmm6_4
  float v92; // xmm2_4
  float v93; // xmm6_4
  float v94; // xmm1_4
  float v95; // xmm11_4
  float v96; // xmm0_4
  float v97; // xmm0_4
  float v98; // xmm6_4
  double v99; // xmm1_8
  float v100; // xmm0_4
  float v101; // xmm7_4
  float v102; // xmm7_4
  float v103; // xmm8_4
  float v104; // xmm0_4
  float v105; // xmm8_4
  float v106; // xmm0_4
  float v107; // xmm8_4
  float v108; // xmm7_4
  float v109; // xmm0_4
  float v110; // xmm7_4
  float v111; // xmm0_4
  float v112; // xmm6_4
  float v113; // xmm7_4
  float v114; // xmm6_4
  float v115; // xmm4_4
  float v116; // xmm3_4
  float v117; // xmm6_4
  float v118; // xmm4_4
  float v119; // xmm2_4
  float v120; // xmm3_4
  float v121; // xmm4_4
  int v122; // xmm0_4
  float v123; // xmm0_4
  float v124; // xmm1_4
  float v125; // xmm8_4
  float v126; // xmm5_4
  float v127; // xmm7_4
  float v128; // xmm4_4
  float v129; // xmm7_4
  float v130; // xmm6_4
  float v131; // xmm2_4
  float v132; // xmm3_4
  float v133; // xmm4_4
  float v134; // xmm3_4
  float v135; // xmm5_4
  float v136; // xmm7_4
  float v137; // xmm4_4
  float v138; // xmm0_4
  float v139; // xmm3_4
  float v140; // xmm5_4
  float v141; // xmm2_4
  float v142; // xmm3_4
  float v143; // xmm3_4
  float v144; // xmm0_4
  float v145; // xmm0_4
  float v146; // xmm1_4
  float v147; // xmm8_4
  float v148; // xmm5_4
  float v149; // xmm6_4
  float v150; // xmm4_4
  float v151; // xmm6_4
  float v152; // xmm7_4
  float v153; // xmm0_4
  float v154; // xmm2_4
  float v155; // xmm4_4
  float v156; // xmm3_4
  float v157; // xmm5_4
  float v158; // xmm6_4
  float v159; // xmm4_4
  float v160; // xmm0_4
  float v161; // xmm3_4
  float v162; // xmm5_4
  float v163; // xmm2_4
  float v164; // xmm3_4
  float v165; // xmm3_4
  float v166; // xmm0_4
  float v167; // xmm0_4
  float v168; // xmm8_4
  float v169; // xmm8_4
  float v170; // xmm7_4
  int v171; // xmm1_4
  int v172; // xmm2_4
  int v173; // xmm0_4
  float v174; // xmm4_4
  float v175; // xmm5_4
  float v176; // xmm7_4
  float v177; // xmm4_4
  float v178; // xmm2_4
  float v179; // xmm3_4
  float v180; // xmm7_4
  float v181; // xmm6_4
  float v182; // xmm5_4
  float v183; // xmm0_4
  float v184; // xmm3_4
  float v185; // xmm6_4
  float v186; // xmm3_4
  int v187; // xmm0_4
  float v188; // xmm2_4
  int v189; // xmm0_4
  float v190; // xmm4_4
  float v191; // xmm2_4
  float v192; // xmm3_4
  float v193; // xmm0_4
  float v194; // xmm3_4
  float v195; // xmm4_4
  float v196; // xmm1_4
  float v197; // xmm1_4
  float v198; // xmm1_4
  float v199; // xmm0_4
  float v200; // xmm4_4
  float v201; // xmm0_4
  double v202; // xmm0_8
  float v203; // xmm1_4
  float v204; // xmm0_4
  float v205; // xmm1_4
  float v206; // xmm0_4
  float v207; // xmm1_4
  float v208; // xmm0_4
  float v209; // xmm3_4
  float v210; // xmm2_4
  float v211; // xmm3_4
  float v212; // xmm0_4
  float v213; // xmm3_4
  float v214; // xmm1_4
  float v215; // xmm0_4
  float v216; // xmm0_4
  float v217; // xmm7_4
  float v218; // xmm7_4
  float v219; // xmm1_4
  float v220; // xmm0_4
  float v221; // xmm7_4
  float v222; // xmm4_4
  float v223; // xmm5_4
  float v224; // xmm6_4
  float v225; // xmm0_4
  float v226; // xmm3_4
  __m128 v227; // xmm9
  float v228; // xmm7_4
  float v229; // xmm8_4
  float v230; // xmm0_4
  float v231; // xmm6_4
  float v232; // xmm6_4
  float v233; // xmm2_4
  float v234; // xmm1_4
  int v235; // ecx
  float v236; // xmm9_4
  float v237; // xmm6_4
  float v238; // xmm4_4
  float v239; // xmm3_4
  float v240; // xmm8_4
  float v241; // xmm8_4
  float v242; // xmm1_4
  float v243; // xmm9_4
  float v244; // xmm0_4
  float v245; // xmm6_4
  float v246; // xmm6_4
  float v247; // xmm3_4
  float v248; // xmm1_4
  float v249; // xmm5_4
  float v250; // xmm5_4
  float v251; // xmm2_4
  float v252; // xmm1_4
  float v253; // xmm0_4
  float v254; // xmm5_4
  float v255; // xmm5_4
  float v256; // xmm5_4
  float v257; // xmm3_4
  float v258; // xmm4_4
  float v259; // xmm1_4
  float v260; // xmm3_4
  float v261; // xmm4_4
  float v262; // xmm3_4
  float v263; // xmm5_4
  float v264; // xmm2_4
  float v265; // xmm5_4
  float v266; // xmm4_4
  float v267; // xmm2_4
  float v268; // xmm5_4
  float v269; // xmm0_4
  float v270; // xmm5_4
  float v271; // xmm5_4
  float v272; // xmm5_4
  float v273; // xmm5_4
  float v274; // xmm1_4
  float v275; // xmm3_4
  float v276; // xmm4_4
  float v277; // xmm1_4
  float v278; // xmm3_4
  float v279; // xmm4_4
  float v280; // xmm3_4
  float v281; // xmm5_4
  float v282; // xmm2_4
  float v283; // xmm5_4
  float v284; // xmm1_4
  float v285; // xmm4_4
  float v286; // xmm2_4
  float v287; // xmm5_4
  float v288; // xmm0_4
  float v289; // xmm5_4
  float v290; // xmm5_4
  float v291; // xmm5_4
  float v292; // xmm5_4
  float v293; // xmm1_4
  float v294; // xmm3_4
  float v295; // xmm4_4
  float v296; // xmm1_4
  float v297; // xmm3_4
  float v298; // xmm4_4
  float v299; // xmm3_4
  float v300; // xmm5_4
  float v301; // xmm2_4
  float v302; // xmm5_4
  float v303; // xmm3_4
  float v304; // xmm1_4
  float v305; // xmm5_4
  float v306; // xmm0_4
  float v307; // xmm5_4
  float v308; // xmm5_4
  float v309; // xmm5_4
  float v310; // xmm5_4
  float v311; // xmm3_4
  float v312; // xmm4_4
  float v313; // xmm1_4
  float v314; // xmm3_4
  float v315; // xmm4_4
  float v316; // xmm3_4
  float v317; // xmm5_4
  float v318; // xmm2_4
  float v319; // xmm5_4
  float v320; // xmm8_4
  float v321; // xmm3_4
  float v322; // xmm4_4
  float v323; // xmm5_4
  float v324; // xmm5_4
  float v325; // xmm0_4
  float v326; // xmm4_4
  int v327; // xmm0_4
  float v328; // xmm2_4
  float v329; // xmm0_4
  float v330; // xmm2_4
  float v331; // xmm2_4
  float v332; // xmm1_4
  float v333; // xmm3_4
  double v334; // xmm0_8
  float v335; // xmm0_4
  float v336; // xmm1_4
  float v337; // xmm2_4
  float v338; // xmm3_4
  double v339; // xmm0_8
  float v340; // xmm0_4
  float v341; // xmm5_4
  float v342; // xmm6_4
  float v343; // xmm4_4
  float v344; // xmm3_4
  float v345; // xmm4_4
  float v346; // xmm2_4
  float v347; // xmm0_4
  float v348; // xmm7_4
  float v349; // xmm6_4
  float v350; // xmm3_4
  int v351; // xmm0_4
  int v352; // xmm1_4
  float v353; // xmm4_4
  float v354; // xmm2_4
  float v355; // xmm3_4
  float v356; // xmm1_4
  float v357; // xmm6_4
  float v358; // xmm4_4
  float v359; // xmm3_4
  float v360; // xmm1_4
  float v361; // xmm6_4
  float v362; // xmm1_4
  float v363; // xmm7_4
  double v364; // xmm0_8
  float v365; // xmm4_4
  float v366; // xmm5_4
  float v367; // xmm5_4
  float v368; // xmm6_4
  float v369; // xmm2_4
  float v370; // xmm3_4
  float v371; // xmm4_4
  float v372; // xmm0_4
  float v373; // xmm1_4
  float v374; // xmm4_4
  float v375; // xmm2_4
  float v376; // xmm6_4
  float v377; // xmm5_4
  float v378; // xmm4_4
  double v379; // xmm0_8
  float v380; // xmm3_4
  float v381; // xmm3_4
  float v382; // xmm1_4
  float v383; // xmm2_4
  float v384; // xmm2_4
  double v385; // xmm12_8
  double v386; // xmm2_8
  double *v387; // rax
  double v388; // xmm4_8
  double v389; // xmm8_8
  double v390; // xmm10_8
  float v391; // xmm3_4
  float v392; // xmm5_4
  int v393; // xmm0_4
  int v394; // xmm1_4
  float v395; // xmm5_4
  float v396; // xmm3_4
  float v397; // xmm0_4
  float v398; // xmm2_4
  float v399; // xmm5_4
  double v400; // xmm0_8
  float v401; // xmm6_4
  int v402; // xmm1_4
  float v403; // xmm6_4
  float v404; // xmm7_4
  double v405; // xmm0_8
  float v406; // xmm5_4
  float v407; // xmm5_4
  float v408; // xmm5_4
  float v409; // xmm0_4
  float v410; // xmm3_4
  float v411; // xmm4_4
  float v412; // xmm0_4
  float v413; // xmm6_4
  float v414; // xmm8_4
  float v415; // xmm6_4
  double v416; // xmm0_8
  float v417; // xmm4_4
  float v418; // xmm0_4
  float v419; // xmm7_4
  float v420; // xmm4_4
  float v421; // xmm4_4
  float v422; // xmm4_4
  float v423; // xmm7_4
  float v424; // xmm9_4
  double v425; // xmm0_8
  float v426; // xmm7_4
  float v427; // xmm8_4
  float v428; // xmm8_4
  float v429; // xmm8_4
  float v430; // xmm6_4
  int v431; // xmm5_4
  float v432; // xmm6_4
  float v433; // xmm7_4
  double v434; // xmm0_8
  float v435; // xmm5_4
  float v436; // xmm5_4
  float v437; // xmm5_4
  float v438; // xmm0_4
  float v439; // xmm3_4
  float v440; // xmm4_4
  float v441; // xmm0_4
  float v442; // xmm6_4
  float v443; // xmm8_4
  float v444; // xmm6_4
  double v445; // xmm0_8
  float v446; // xmm4_4
  float v447; // xmm0_4
  float v448; // xmm7_4
  float v449; // xmm4_4
  float v450; // xmm4_4
  float v451; // xmm4_4
  float v452; // xmm7_4
  float v453; // xmm9_4
  double v454; // xmm0_8
  float v455; // xmm7_4
  float v456; // xmm8_4
  float v457; // xmm8_4
  float v458; // xmm8_4
  float v459; // xmm6_4
  int v460; // xmm5_4
  float v461; // xmm6_4
  float v462; // xmm7_4
  double v463; // xmm0_8
  float v464; // xmm5_4
  float v465; // xmm5_4
  float v466; // xmm5_4
  float v467; // xmm0_4
  float v468; // xmm3_4
  float v469; // xmm4_4
  float v470; // xmm0_4
  float v471; // xmm6_4
  float v472; // xmm8_4
  float v473; // xmm6_4
  double v474; // xmm0_8
  float v475; // xmm4_4
  float v476; // xmm0_4
  float v477; // xmm7_4
  float v478; // xmm4_4
  float v479; // xmm4_4
  float v480; // xmm4_4
  float v481; // xmm7_4
  float v482; // xmm9_4
  double v483; // xmm0_8
  float v484; // xmm7_4
  float v485; // xmm8_4
  float v486; // xmm8_4
  float v487; // xmm8_4
  float v488; // xmm6_4
  int v489; // xmm5_4
  float v490; // xmm6_4
  float v491; // xmm7_4
  double v492; // xmm0_8
  float v493; // xmm5_4
  float v494; // xmm5_4
  float v495; // xmm5_4
  float v496; // xmm0_4
  float v497; // xmm3_4
  float v498; // xmm4_4
  float v499; // xmm0_4
  float v500; // xmm6_4
  float v501; // xmm8_4
  float v502; // xmm6_4
  double v503; // xmm0_8
  float v504; // xmm4_4
  float v505; // xmm0_4
  float v506; // xmm7_4
  float v507; // xmm4_4
  float v508; // xmm4_4
  float v509; // xmm4_4
  float v510; // xmm7_4
  float v511; // xmm8_4
  float v512; // xmm0_4
  float v513; // xmm7_4
  float v514; // xmm0_4
  float v515; // xmm15_4
  int v516; // xmm5_4
  int v517; // xmm6_4
  float v518; // xmm2_4
  float v519; // xmm5_4
  float v520; // xmm2_4
  float v521; // xmm4_4
  float v522; // xmm5_4
  float v523; // xmm1_4
  float v524; // xmm5_4
  float v525; // xmm3_4
  float v526; // xmm4_4
  __int64 result; // rax
  int v528; // [rsp+D0h] [rbp+8h]
  float v529; // [rsp+E0h] [rbp+18h]

  v2 = *(float *)(a1 + 63392);
  v528 = 0;
  if ( *(float *)(a1 + 101696) == 1.0 )
  {
    v528 = *(_DWORD *)(a1 + 63392);
    v2 = 0.0;
    *(_DWORD *)(a1 + 63392) = 0;
  }
  v5 = *(float *)(a1 + 84336);
  v6 = *(float *)(a1 + 84272);
  v7 = *(float *)(a1 + 84304);
  *(float *)(a1 + 84352) = v5;
  *(float *)(a1 + 84288) = v6;
  *(float *)(a1 + 84320) = v7;
  v8 = (int)(float)(v5 * -16777216.0);
  if ( !v8 )
  {
    v9 = 1;
    goto LABEL_11;
  }
  v10 = v8 & 0x200000;
  if ( (v8 & 0x800000) != 0 )
  {
    if ( !v10 )
    {
      v9 = 2 * v8;
      goto LABEL_11;
    }
  }
  else if ( v10 )
  {
    v9 = 2 * v8;
    goto LABEL_11;
  }
  v9 = 2 * v8 + 1;
LABEL_11:
  v11 = *(float *)(a1 + 63280);
  v12 = *(float *)(a1 + 63248);
  v13 = v9 & 0xFFFFFF;
  v14 = *(float *)(a1 + 63440);
  v15 = v9;
  v16 = *(float *)(a1 + 63456);
  v17 = v9 | 0xFF000000;
  v18 = v6 * v7;
  *(_DWORD *)(a1 + 63504) = 0;
  *(float *)(a1 + 63296) = v11;
  v19 = 0.0;
  if ( (v15 & 0x1000000) == 0 )
    v17 = v13;
  *(float *)(a1 + 63264) = v12;
  *(_DWORD *)(a1 + 84384) = *(_DWORD *)(a1 + 84368);
  *(_DWORD *)(a1 + 63584) = *(_DWORD *)(a1 + 63568);
  *(float *)(a1 + 63424) = v2;
  v20 = (float)v17 * 0.000000059604645;
  *(float *)(a1 + 63472) = v14;
  *(float *)(a1 + 63488) = v16;
  *(float *)(a1 + 84336) = v20;
  v21 = (float)(v20 * *(float *)(a1 + 84400)) + *(float *)(a1 + 84416);
  *(float *)(a1 + 84368) = v21;
  v22 = v18 - (float)(v7 * v21);
  v23 = *(float *)(a1 + 63344);
  *(float *)(a1 + 63360) = v23;
  v24 = v22 + v21;
  v25 = *(float *)(a1 + 63312);
  v26 = v23 * v25;
  *(float *)(a1 + 63328) = v25;
  *(float *)(a1 + 84432) = v24;
  v27 = *(float *)(a1 + 63376);
  *(float *)(a1 + 63408) = v27;
  *(float *)(a1 + 63520) = v26;
  v28 = (float)((float)(v12 * v26) - (float)(v26 * v27)) + v27;
  v29 = (float)((float)(v11 * v26) - (float)(v2 * v26)) + v2;
  *(float *)(a1 + 63536) = v28;
  *(float *)(a1 + 63552) = v29;
  v30 = v29;
  v31 = v29 + *(float *)(a1 + 63616);
  if ( v31 < 0.0 )
    v32 = v31;
  else
    v32 = 0.0;
  v33 = -1.0;
  if ( v30 == 0.0 )
    v34 = -1.0;
  else
    v34 = v32;
  *(float *)(a1 + 63568) = v34;
  if ( v34 >= 0.0 )
  {
    if ( v34 > 0.0 )
      v34 = 1.0;
  }
  else
  {
    v34 = -1.0;
  }
  v35 = *(float *)(a1 + 63680);
  v36 = v34 + 1.0;
  v37 = *(float *)(a1 + 63840);
  v38 = *(float *)(a1 + 63696);
  v39 = *(_DWORD *)(a1 + 63632);
  v40 = *(float *)(a1 + 63776);
  v41 = v38 + *(float *)(a1 + 63856);
  v42 = 1.0;
  *(float *)(a1 + 63600) = v36;
  *(float *)(a1 + 63632) = v36;
  *(_DWORD *)(a1 + 63648) = v39;
  *(float *)(a1 + 63792) = v40;
  v43 = (float)(v36 * v35) - v35;
  v44 = *(float *)(a1 + 63888);
  v45 = (float)(v43 + 1.0) * *(float *)(a1 + 63664);
  v46 = (float)(*(float *)(a1 + 63744) / (float)((float)(v37 * v38) + *(float *)(a1 + 63872))) * v37;
  v47 = *(float *)(a1 + 63728);
  *(float *)(a1 + 63808) = v45;
  v48 = v47 - v46;
  v49 = *(float *)(a1 + 63760);
  v50 = (float)(v48 + v28) - v40;
  *(float *)(a1 + 63728) = v50;
  v51 = v50 * v41;
  *(float *)(a1 + 63744) = v51;
  v52 = v51 + v40;
  if ( (float)(v44 - fabs(v40 - v28)) < 0.0 )
  {
    v53 = 0.0;
LABEL_25:
    v54 = v53;
    goto LABEL_26;
  }
  v53 = v49 + *(float *)(a1 + 63904);
  if ( v53 < 1.0 )
    goto LABEL_25;
  v54 = 1.0;
LABEL_26:
  v55 = v54;
  *(float *)(a1 + 63760) = v55;
  v56 = (float)((float)(v55 * v28) - (float)(v55 * v52)) + v52;
  if ( v45 == 0.0 )
    v56 = v28;
  v57 = v16 * *(float *)(a1 + 63936);
  *(_DWORD *)(a1 + 63968) = *(_DWORD *)(a1 + 63952);
  v58 = *(float *)(a1 + 64240);
  v59 = *(float *)(a1 + 63984);
  v60 = *(_DWORD *)(a1 + 64080);
  v61 = v57 + (float)(v14 * *(float *)(a1 + 63920));
  v62 = *(_DWORD *)(a1 + 64048);
  v63 = (int)v58;
  *(float *)(a1 + 63952) = v61;
  v64 = *(float *)(a1 + 64016);
  *(float *)(a1 + 63776) = v56;
  *(float *)(a1 + 63824) = v56;
  v65 = *(float *)(a1 + 64176);
  *(float *)(a1 + 64032) = v64;
  *(float *)(a1 + 64000) = v59;
  *(_DWORD *)(a1 + 64064) = v62;
  *(_DWORD *)(a1 + 64096) = v60;
  *(float *)(a1 + 64192) = v65;
  if ( (int)v58 < -32 )
  {
    v59 = v59 * 2.3283064e-10;
    goto LABEL_38;
  }
  if ( v63 > 32 )
  {
    v63 = 32;
LABEL_37:
    v59 = v59 * dword_7FF91E5EAD3C[v63];
    goto LABEL_38;
  }
  if ( v63 < 0 )
  {
    v59 = v59 * dword_7FF91E5EACC0[~v63];
    goto LABEL_38;
  }
  if ( v63 > 0 )
    goto LABEL_37;
LABEL_38:
  v66 = (int)(float)-v58;
  if ( v66 < -32 )
  {
    v59 = v59 * 2.3283064e-10;
    goto LABEL_46;
  }
  if ( v66 > 32 )
  {
    v66 = 32;
LABEL_45:
    v59 = v59 * dword_7FF91E5EAD3C[v66];
    goto LABEL_46;
  }
  if ( v66 < 0 )
  {
    v59 = v59 * dword_7FF91E5EACC0[~v66];
    goto LABEL_46;
  }
  if ( v66 > 0 )
    goto LABEL_45;
LABEL_46:
  v67 = *(float *)(a1 + 64112);
  v68 = (float)((float)(v59 - v65) * *(float *)(a1 + 64224)) + v65;
  v69 = *(float *)(a1 + 64160);
  *(float *)(a1 + 64176) = v68;
  v70 = (float)((float)(v68 * v67) - (float)(v67 * v69)) + v69;
  if ( v70 <= 0.0 )
    v71 = 0.0;
  else
    v71 = v70;
  v72 = v71;
  if ( v72 < 1.0 )
    v73 = v72;
  else
    v73 = 1.0;
  v74 = *(float *)(a1 + 64128);
  v75 = expf((float)v73 * *(float *)(a1 + 64272)) * *(float *)(a1 + 64256);
  v76 = v74 * *(float *)(a1 + 64144);
  *(_DWORD *)(a1 + 64656) = *(_DWORD *)(a1 + 64640);
  v77 = v75 + *(float *)(a1 + 64288);
  v78 = *(float *)(a1 + 64576);
  v79 = v64 * *(float *)(a1 + 64976);
  *(_DWORD *)(a1 + 64688) = *(_DWORD *)(a1 + 64672);
  v80 = *(float *)(a1 + 64560);
  v81 = *(float *)(a1 + 64608);
  *(_DWORD *)(a1 + 64720) = *(_DWORD *)(a1 + 64704);
  v82 = *(_DWORD *)(a1 + 84432);
  *(float *)(a1 + 64592) = v78;
  *(float *)(a1 + 64576) = v80;
  *(float *)(a1 + 64624) = v81;
  *(_DWORD *)(a1 + 64512) = v62;
  *(_DWORD *)(a1 + 64528) = v60;
  *(_DWORD *)(a1 + 64496) = v82;
  v83 = (float)(v76 - (float)(v74 * v77)) + v77;
  v84 = *(float *)(a1 + 64928);
  v85 = v79 + v84;
  *(float *)(a1 + 64912) = v84;
  *(float *)(a1 + 64208) = v83;
  if ( v85 >= -1.0 )
    v86 = fminf(v85, 1.0);
  else
    v86 = -1.0;
  v87 = *(float *)(a1 + 65200);
  *(float *)(a1 + 64560) = v86;
  v88 = fminf(v87, v83 * 0.000015258789);
  v89 = (float)((float)(1.0 - v78) * *(float *)(a1 + 64992)) + v78;
  if ( v89 >= -1.0 )
    v90 = fminf(v89, 1.0);
  else
    v90 = -1.0;
  v91 = v88 * *(float *)(a1 + 65216);
  v92 = v80 - v86;
  *(float *)(a1 + 64736) = v91;
  v93 = v91 + v81;
  if ( v92 < 0.0 )
    v90 = 0.0;
  v94 = *(float *)(a1 + 64944);
  v95 = *(float *)(a1 + 64496);
  *(float *)(a1 + 64576) = v90;
  v96 = v90 + *(float *)(a1 + 65344);
  if ( v92 >= 0.0 )
    v94 = 1.0;
  v97 = v96 * *(float *)(a1 + 65328);
  v98 = (float)(v93 * v94) * *(float *)(a1 + 64960);
  if ( v97 <= 0.0 )
    v99 = 0.0;
  else
    v99 = v97;
  v100 = v99;
  v101 = (float)((float)(v95 - *(float *)(a1 + 64656)) * *(float *)(a1 + 0x10000)) + *(float *)(a1 + 64656);
  *(float *)(a1 + 64640) = v101;
  *(float *)(a1 + 64544) = v100;
  v529 = *(float *)(a1 + 64624);
  v102 = (float)((float)((float)(v101 * *(float *)(a1 + 65520)) * *(float *)(a1 + 65136))
               - (float)(v95 * *(float *)(a1 + 65136)))
       + v95;
  if ( v98 <= 1.0 )
  {
    if ( v98 < -1.0 )
      v98 = fmodf(v98 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v98 = fmodf(v98 + 1.0, 2.0) - 1.0;
  }
  v103 = *(float *)(a1 + 64688);
  *(float *)(a1 + 64608) = v98;
  v104 = v98 + *(float *)(a1 + 65360);
  *(float *)(a1 + 64480) = v102 * *(float *)(a1 + 65504);
  if ( v529 < 0.0 && v98 > 0.0 )
    v103 = v95;
  if ( v104 <= 1.0 )
  {
    if ( v104 < -1.0 )
      v104 = fmodf(v104 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v104 = fmodf(v104 + 1.0, 2.0) - 1.0;
  }
  *(float *)(a1 + 64672) = v103;
  v105 = v103 * *(float *)(a1 + 65488);
  v106 = (float)(v104 * *(float *)(a1 + 65424)) + *(float *)(a1 + 65552);
  *(float *)(a1 + 64752) = v106;
  *(float *)(a1 + 64832) = v105;
  v107 = v98 + *(float *)(a1 + 65392);
  *(float *)(a1 + 64768) = -v106;
  if ( v107 <= 1.0 )
  {
    if ( v107 < -1.0 )
      fmodf(v107 - 1.0, 2.0);
  }
  else
  {
    fmodf(v107 + 1.0, 2.0);
  }
  v108 = v98 + *(float *)(a1 + 65376);
  if ( v108 <= 1.0 )
  {
    if ( v108 < -1.0 )
      v108 = fmodf(v108 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v108 = fmodf(v108 + 1.0, 2.0) - 1.0;
  }
  v109 = sub_7FF91DFC8FC0();
  v110 = v108 + *(float *)(a1 + 65568);
  v111 = v109 * *(float *)(a1 + 65456);
  if ( v110 >= 0.0 )
  {
    if ( v110 > 0.0 )
      v110 = 1.0;
  }
  else
  {
    v110 = -1.0;
  }
  v112 = v98 + *(float *)(a1 + 65408);
  *(float *)(a1 + 64800) = v111;
  *(float *)(a1 + 64896) = v110;
  v113 = (float)(v110 * *(float *)(a1 + 65440)) + *(float *)(a1 + 65584);
  if ( v112 <= 1.0 )
  {
    if ( v112 < -1.0 )
      v112 = fmodf(v112 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v112 = fmodf(v112 + 1.0, 2.0) - 1.0;
  }
  v114 = fabs(v112);
  *(float *)(a1 + 64784) = v113;
  v115 = *(float *)(a1 + 65040);
  v116 = (float)((float)(*(float *)(a1 + 65104) * *(float *)(a1 + 64832))
               + (float)(*(float *)(a1 + 65072) * *(float *)(a1 + 64752)))
       + (float)(*(float *)(a1 + 65088) * *(float *)(a1 + 64768));
  v117 = (float)((float)((float)((float)(v114 * (float)((float)(v114 * v114) * v114)) * *(float *)(a1 + 65296))
                       + (float)((float)((float)((float)(v114 * v114) * v114) * *(float *)(a1 + 65280))
                               + (float)((float)((float)(v114 * *(float *)(a1 + 65248)) + *(float *)(a1 + 65232))
                                       + (float)((float)(v114 * v114) * *(float *)(a1 + 65264)))))
               + *(float *)(a1 + 65312))
       * *(float *)(a1 + 65472);
  *(float *)(a1 + 64816) = v117;
  v118 = (float)(v115 * *(float *)(a1 + 64800)) + v116;
  v119 = *(float *)(a1 + 65152);
  v120 = (float)((float)(*(float *)(a1 + 65008) * *(float *)(a1 + 64544)) - *(float *)(a1 + 65008)) + 1.0;
  v121 = (float)((float)(v118 + (float)(*(float *)(a1 + 65056) * *(float *)(a1 + 64784)))
               + (float)(v117 * *(float *)(a1 + 65024)))
       + (float)(*(float *)(a1 + 65120) * *(float *)(a1 + 64480));
  *(float *)(a1 + 64848) = v120;
  *(float *)(a1 + 64880) = v121;
  *(float *)(a1 + 64864) = (float)((float)(*(float *)(a1 + 65184) * *(float *)(a1 + 64528))
                                 + (float)(*(float *)(a1 + 65168) * *(float *)(a1 + 64512)))
                         + (float)((float)(v119 * v120) * v121);
  v122 = *(_DWORD *)(a1 + 64880);
  *(_DWORD *)(a1 + 65600) = *(_DWORD *)(a1 + 64896);
  *(_DWORD *)(a1 + 65616) = v122;
  if ( *(float *)(a1 + 64896) <= 0.0 )
    v123 = 0.0;
  else
    v123 = 1.0;
  if ( *(float *)(a1 + 65632) == 0.0 )
    v123 = 1.0;
  v124 = *(float *)(a1 + 63632) * v123;
  *(float *)(a1 + 65648) = v124;
  *(_DWORD *)(a1 + 65680) = *(_DWORD *)(a1 + 65664);
  *(_DWORD *)(a1 + 65728) = *(_DWORD *)(a1 + 65712);
  *(_DWORD *)(a1 + 65712) = *(_DWORD *)(a1 + 65696);
  *(_DWORD *)(a1 + 65760) = *(_DWORD *)(a1 + 65744);
  *(_DWORD *)(a1 + 65808) = *(_DWORD *)(a1 + 65792);
  if ( (float)(v124 + *(float *)(a1 + 65936)) >= 0.0 )
    v125 = 0.0;
  else
    v125 = 1.0;
  v126 = 1.0 - v125;
  v127 = (float)(1.0 - v125)
       * (float)((float)(*(float *)(a1 + 65968) * *(float *)(a1 + 65728)) + *(float *)(a1 + 65680));
  *(float *)(a1 + 65696) = v127;
  v128 = v127 + *(float *)(a1 + 65952);
  v129 = v127 - *(float *)(a1 + 65712);
  *(float *)(a1 + 65776) = (float)((float)(*(float *)(a1 + 65920) * *(float *)(a1 + 66032))
                                 - (float)(*(float *)(a1 + 66000) * *(float *)(a1 + 65920)))
                         + *(float *)(a1 + 66000);
  if ( v128 < 0.0 )
    v130 = 0.0;
  else
    v130 = 1.0;
  if ( v129 < 0.0 )
    v130 = 1.0 - v125;
  v131 = *(float *)(a1 + 65856);
  v132 = v126 * (float)(*(float *)(a1 + 65872) * *(float *)(a1 + 66000));
  *(float *)(a1 + 65712) = v130;
  v133 = *(float *)(a1 + 65760);
  v134 = (float)(v132 - (float)(*(float *)(a1 + 66016) * v126)) + *(float *)(a1 + 66016);
  v135 = v126 * (float)(1.0 - v130);
  v136 = (float)((float)(*(float *)(a1 + 65888) * 0.00390625) * v130) + (float)((float)(v131 * 0.00390625) * v135);
  if ( (float)(v134 - v133) > 0.0 )
    v134 = v133 + *(float *)(a1 + 65776);
  v137 = *(float *)(a1 + 65680);
  v138 = fminf(*(float *)(a1 + 66000), v134);
  *(float *)(a1 + 65744) = v138;
  v139 = *(float *)(a1 + 65904);
  v140 = (float)((float)(v135 * *(float *)(a1 + 65984)) + (float)(v130 * v138)) - v137;
  v141 = (float)((float)(*(float *)(a1 + 66048) * v136) - (float)(*(float *)(a1 + 66048) * *(float *)(a1 + 65808)))
       + *(float *)(a1 + 65808);
  *(float *)(a1 + 65792) = v141;
  v142 = (float)((float)((float)((float)((float)(v139 * 0.00390625) * v125) - (float)(v125 * v141)) + v141) * v140)
       + v137;
  *(float *)(a1 + 65664) = v142;
  v143 = (float)(v142 * *(float *)(a1 + 66064)) * *(float *)(a1 + 66080);
  v144 = v143 * *(float *)(a1 + 66096);
  *(float *)(a1 + 65824) = v143;
  *(float *)(a1 + 65840) = v144;
  if ( *(float *)(a1 + 64896) <= 0.0 )
    v145 = 0.0;
  else
    v145 = 1.0;
  if ( *(float *)(a1 + 66112) == 0.0 )
    v145 = 1.0;
  v146 = *(float *)(a1 + 63632) * v145;
  *(float *)(a1 + 66128) = v146;
  *(_DWORD *)(a1 + 66160) = *(_DWORD *)(a1 + 66144);
  *(_DWORD *)(a1 + 66208) = *(_DWORD *)(a1 + 66192);
  *(_DWORD *)(a1 + 66192) = *(_DWORD *)(a1 + 66176);
  *(_DWORD *)(a1 + 66240) = *(_DWORD *)(a1 + 66224);
  *(_DWORD *)(a1 + 66288) = *(_DWORD *)(a1 + 66272);
  if ( (float)(v146 + *(float *)(a1 + 66416)) >= 0.0 )
    v147 = 0.0;
  else
    v147 = 1.0;
  v148 = 1.0 - v147;
  v149 = (float)(1.0 - v147)
       * (float)((float)(*(float *)(a1 + 66448) * *(float *)(a1 + 66208)) + *(float *)(a1 + 66160));
  *(float *)(a1 + 66176) = v149;
  v150 = v149 + *(float *)(a1 + 66432);
  v151 = v149 - *(float *)(a1 + 66192);
  *(float *)(a1 + 66256) = (float)((float)(*(float *)(a1 + 66400) * *(float *)(a1 + 66512))
                                 - (float)(*(float *)(a1 + 66480) * *(float *)(a1 + 66400)))
                         + *(float *)(a1 + 66480);
  if ( v150 < 0.0 )
    v152 = 0.0;
  else
    v152 = 1.0;
  if ( v151 < 0.0 )
    v152 = 1.0 - v147;
  v153 = *(float *)(a1 + 66352) * *(float *)(a1 + 66480);
  v154 = *(float *)(a1 + 66336);
  *(float *)(a1 + 66192) = v152;
  v155 = *(float *)(a1 + 66240);
  v156 = (float)((float)(v148 * v153) - (float)(*(float *)(a1 + 66496) * v148)) + *(float *)(a1 + 66496);
  v157 = v148 * (float)(1.0 - v152);
  v158 = (float)((float)(*(float *)(a1 + 66368) * 0.00390625) * v152) + (float)((float)(v154 * 0.00390625) * v157);
  if ( (float)(v156 - v155) > 0.0 )
    v156 = v155 + *(float *)(a1 + 66256);
  v159 = *(float *)(a1 + 66160);
  v160 = fminf(*(float *)(a1 + 66480), v156);
  *(float *)(a1 + 66224) = v160;
  v161 = (float)(*(float *)(a1 + 66384) * 0.00390625) * v147;
  v162 = (float)((float)(v157 * *(float *)(a1 + 66464)) + (float)(v152 * v160)) - v159;
  v163 = (float)((float)(*(float *)(a1 + 66528) * v158) - (float)(*(float *)(a1 + 66528) * *(float *)(a1 + 66288)))
       + *(float *)(a1 + 66288);
  *(float *)(a1 + 66272) = v163;
  v164 = (float)((float)((float)(v161 - (float)(v147 * v163)) + v163) * v162) + v159;
  *(float *)(a1 + 66144) = v164;
  v165 = (float)(v164 * *(float *)(a1 + 66544)) * *(float *)(a1 + 66560);
  v166 = v165 * *(float *)(a1 + 66576);
  *(float *)(a1 + 66304) = v165;
  *(float *)(a1 + 66320) = v166;
  *(_DWORD *)(a1 + 66608) = *(_DWORD *)(a1 + 66592);
  *(_DWORD *)(a1 + 66640) = *(_DWORD *)(a1 + 66624);
  v167 = *(float *)(a1 + 63824);
  v168 = *(float *)(a1 + 63952);
  *(_DWORD *)(a1 + 66704) = *(_DWORD *)(a1 + 66688);
  v169 = (float)(v168 * *(float *)(a1 + 66672)) + (float)(v167 * *(float *)(a1 + 66656));
  *(float *)(a1 + 66688) = v169;
  v170 = *(float *)(a1 + 64864);
  v171 = *(_DWORD *)(a1 + 65824);
  v172 = *(_DWORD *)(a1 + 66304);
  v173 = *(_DWORD *)(a1 + 63824);
  *(_DWORD *)(a1 + 66752) = *(_DWORD *)(a1 + 66624);
  *(_DWORD *)(a1 + 66768) = v173;
  v174 = *(float *)(a1 + 67088);
  *(_DWORD *)(a1 + 66720) = v171;
  *(_DWORD *)(a1 + 66736) = v172;
  v175 = *(float *)(a1 + 67056);
  v176 = v170 * v174;
  v177 = v174 * *(float *)(a1 + 64880);
  *(float *)(a1 + 66784) = v177;
  v178 = *(float *)(a1 + 67184);
  v179 = *(float *)(a1 + 66928);
  v180 = v176 * *(float *)(a1 + 67104);
  v181 = *(float *)(a1 + 67120);
  v182 = (float)(v175 * v177) * *(float *)(a1 + 67072);
  *(float *)(a1 + 66816) = v182;
  v183 = *(float *)(a1 + 66944);
  v184 = (float)((float)((float)(v179 * *(float *)(a1 + 66752)) - (float)(v178 * v179)) + v178) * *(float *)(a1 + 67200);
  *(float *)(a1 + 66832) = v184;
  v185 = (float)((float)(v181 * v180) + v182) + (float)(v183 * v184);
  v186 = *(float *)(a1 + 66784);
  v187 = *(_DWORD *)(a1 + 66912);
  *(float *)(a1 + 66848) = (float)((float)((float)((float)((float)((float)(*(float *)(a1 + 67152)
                                                                         * *(float *)(a1 + 66736))
                                                                 + (float)(*(float *)(a1 + 67136)
                                                                         * *(float *)(a1 + 66720)))
                                                         * *(float *)(a1 + 67168))
                                                 + v185)
                                         + v169)
                                 + *(float *)(a1 + 67024))
                         + *(float *)(a1 + 67040);
  *(_DWORD *)(a1 + 66864) = v187;
  v188 = (float)(*(float *)(a1 + 66816) + *(float *)(a1 + 66768)) + *(float *)(a1 + 66832);
  *(float *)(a1 + 66880) = (float)((float)((float)((float)((float)((float)(v186 * *(float *)(a1 + 67232))
                                                                 + *(float *)(a1 + 67248))
                                                         * *(float *)(a1 + 66960))
                                                 + (float)(*(float *)(a1 + 66976) * *(float *)(a1 + 66720)))
                                         + (float)(*(float *)(a1 + 66992) * *(float *)(a1 + 66736)))
                                 + *(float *)(a1 + 67008))
                         * *(float *)(a1 + 67216);
  *(float *)(a1 + 66896) = v188;
  v189 = *(_DWORD *)(a1 + 67280);
  *(_DWORD *)(a1 + 67312) = *(_DWORD *)(a1 + 67264);
  *(_DWORD *)(a1 + 67328) = v189;
  *(_DWORD *)(a1 + 67344) = *(_DWORD *)(a1 + 67296);
  v190 = *(float *)(a1 + 84432);
  *(_DWORD *)(a1 + 67392) = *(_DWORD *)(a1 + 67376);
  v191 = *(float *)(a1 + 67360);
  *(float *)(a1 + 67376) = v191;
  v192 = (float)(v191 * *(float *)(a1 + 67408)) + *(float *)(a1 + 67392);
  *(float *)(a1 + 67376) = v192;
  v193 = (float)(v191 * *(float *)(a1 + 67424)) + v192;
  v194 = v192 * *(float *)(a1 + 67472);
  v195 = v190 - v193;
  v196 = (float)(v195 * *(float *)(a1 + 67408)) + v191;
  *(float *)(a1 + 67360) = v196;
  *(float *)(a1 + 67392) = (float)((float)(v195 * *(float *)(a1 + 67440)) + v194)
                         + (float)(v196 * *(float *)(a1 + 67456));
  *(_DWORD *)(a1 + 69504) = *(_DWORD *)(a1 + 69488);
  v197 = *(float *)(a1 + 69520);
  *(float *)(a1 + 69536) = v197;
  v198 = v197 * *(float *)(a1 + 66608);
  v199 = *(float *)(a1 + 69504) * *(float *)(a1 + 67392);
  *(float *)(a1 + 69552) = v198;
  *(float *)(a1 + 69568) = v199;
  *(_DWORD *)(a1 + 69632) = *(_DWORD *)(a1 + 69616);
  *(float *)(a1 + 69616) = (float)(v199 * *(float *)(a1 + 69600)) + (float)(v198 * *(float *)(a1 + 69584));
  *(_DWORD *)(a1 + 69664) = *(_DWORD *)(a1 + 69648);
  *(_DWORD *)(a1 + 69696) = *(_DWORD *)(a1 + 69680);
  *(_DWORD *)(a1 + 69728) = *(_DWORD *)(a1 + 69712);
  *(_DWORD *)(a1 + 69760) = *(_DWORD *)(a1 + 69744);
  v200 = (float)((float)(*(float *)(a1 + 69792) * *(float *)(a1 + 69648))
               - (float)(*(float *)(a1 + 69808) * *(float *)(a1 + 69792)))
       + *(float *)(a1 + 69808);
  v201 = (float)((float)((float)((float)(v200 * v200) * v200) * v200) * *(float *)(a1 + 69888))
       + (float)((float)((float)((float)(v200 * v200) * v200) * *(float *)(a1 + 69872))
               + (float)((float)((float)(v200 * *(float *)(a1 + 69840)) + *(float *)(a1 + 69824))
                       + (float)((float)(v200 * v200) * *(float *)(a1 + 69856))));
  if ( v201 <= 0.0 )
    v202 = 0.0;
  else
    v202 = v201;
  v203 = v202;
  if ( v203 < 1.0 )
    v42 = v203;
  v204 = v42;
  *(float *)(a1 + 69776) = v204;
  *(_DWORD *)(a1 + 69920) = *(_DWORD *)(a1 + 69904);
  v205 = *(float *)(a1 + 69936);
  *(float *)(a1 + 69952) = v205;
  v206 = *(float *)(a1 + 69968);
  *(float *)(a1 + 69984) = v206;
  *(float *)(a1 + 69968) = (float)((float)(v205 - v206) * *(float *)(a1 + 70000)) + v206;
  v207 = *(float *)(a1 + 63824);
  v208 = *(float *)(a1 + 63952);
  *(_DWORD *)(a1 + 70064) = *(_DWORD *)(a1 + 70048);
  *(float *)(a1 + 70048) = (float)(v208 * *(float *)(a1 + 70032)) + (float)(v207 * *(float *)(a1 + 70016));
  *(_DWORD *)(a1 + 70112) = *(_DWORD *)(a1 + 70080);
  v209 = *(float *)(a1 + 70096);
  *(float *)(a1 + 70128) = v209;
  v210 = *(float *)(a1 + 65824)
       + (float)((float)(*(float *)(a1 + 70112) * *(float *)(a1 + 66304))
               - (float)(*(float *)(a1 + 70112) * *(float *)(a1 + 65824)));
  *(float *)(a1 + 70144) = (float)((float)(v209 * *(float *)(a1 + 69712)) - (float)(v209 * v210)) + v210;
  v211 = *(float *)(a1 + 64864);
  v212 = *(float *)(a1 + 70160);
  *(float *)(a1 + 70176) = v212;
  v213 = v211 - v212;
  v214 = (float)(v213 * *(float *)(a1 + 70192)) + v212;
  v215 = *(float *)(a1 + 70224);
  *(float *)(a1 + 70160) = v214;
  *(float *)(a1 + 70176) = (float)(v213 * *(float *)(a1 + 70208)) + (float)(v215 * v214);
  v216 = *(float *)(a1 + 70240);
  v217 = *(float *)(a1 + 64880);
  *(float *)(a1 + 70256) = v216;
  v218 = v217 - v216;
  v219 = (float)(v218 * *(float *)(a1 + 70272)) + v216;
  v220 = *(float *)(a1 + 70304);
  *(float *)(a1 + 70240) = v219;
  v221 = (float)(v218 * *(float *)(a1 + 70288)) + (float)(v220 * v219);
  *(float *)(a1 + 70256) = v221;
  v222 = *(float *)(a1 + 70176);
  v223 = *(float *)(a1 + 70144);
  v224 = *(float *)(a1 + 70048);
  v227 = (__m128)*(unsigned int *)(a1 + 69680);
  *(_DWORD *)(a1 + 70320) = *(_DWORD *)(a1 + 69968);
  *(_DWORD *)(a1 + 70336) = v227.m128_i32[0];
  v225 = *(float *)(a1 + 70368);
  v226 = *(float *)(a1 + 70384) * *(float *)(a1 + 69744);
  v227.m128_f32[0] = (float)((float)((float)((float)((float)(v227.m128_f32[0] * *(float *)(a1 + 70400))
                                                   - (float)(*(float *)(a1 + 70528) * *(float *)(a1 + 70400)))
                                           + *(float *)(a1 + 70528))
                                   * *(float *)(a1 + 70544))
                           + (float)((float)((float)(*(float *)(a1 + 70512) + *(float *)(a1 + 70320))
                                           * *(float *)(a1 + 70576))
                                   * *(float *)(a1 + 70496)))
                   + (float)((float)((float)((float)((float)((float)(v226
                                                                   - (float)(*(float *)(a1 + 70384)
                                                                           * (float)(v221 * v225)))
                                                           + (float)(v221 * v225))
                                                   * *(float *)(a1 + 70432))
                                           * *(float *)(a1 + 70448))
                                   + (float)((float)((float)(v226
                                                           - (float)(*(float *)(a1 + 70384) * (float)(v222 * v225)))
                                                   + (float)(v222 * v225))
                                           * *(float *)(a1 + 70416)))
                           + (float)((float)((float)(v224 + *(float *)(a1 + 70560)) * *(float *)(a1 + 70480))
                                   + (float)(v223 * *(float *)(a1 + 70464))));
  *(_DWORD *)(a1 + 70352) = v227.m128_i32[0];
  v228 = *(float *)(a1 + 69776);
  v229 = *(float *)(a1 + 69920);
  *(_DWORD *)(a1 + 70656) = *(_DWORD *)(a1 + 70640);
  v230 = *(float *)(a1 + 70624);
  *(float *)(a1 + 70640) = v230;
  if ( *(float *)(a1 + 70704) == 1.0 )
  {
    v231 = *(float *)(a1 + 70656)
         + (float)((float)(*(float *)(a1 + 70784) * v230) - (float)(*(float *)(a1 + 70784) * *(float *)(a1 + 70656)));
    *(float *)(a1 + 70640) = v231;
    v232 = (float)(v231 * *(float *)(a1 + 70768)) + *(float *)(a1 + 70672);
    *(float *)(a1 + 70624) = sub_7FF91DFC8D60();
    v233 = (float)(1.0 - v229) * *(float *)(a1 + 70800);
    *(float *)(a1 + 70608) = (float)(v229 * *(float *)(a1 + 70864)) + *(float *)(a1 + 70688);
    v227.m128_f32[0] = (float)(fmaxf(
                                 fminf(
                                   (float)((float)((float)((float)(v227.m128_f32[0] * *(float *)(a1 + 70752))
                                                         + (float)(v228 * *(float *)(a1 + 70720)))
                                                 + v232)
                                         + fminf(*(float *)(a1 + 70816), v233))
                                 + *(float *)(a1 + 70736),
                                   *(float *)(a1 + 70832)),
                                 *(float *)(a1 + 70848))
                             * *(float *)(a1 + 70896))
                     + *(float *)(a1 + 70912);
    v234 = v227.m128_f32[0];
    v235 = (int)v227.m128_f32[0];
    if ( (int)v227.m128_f32[0] != 0x80000000 && (float)v235 != v227.m128_f32[0] )
      v234 = (float)(v235 - (_mm_movemask_ps(_mm_unpacklo_ps(v227, v227)) & 1));
    v236 = v227.m128_f32[0] - v234;
    v237 = (float)(v236 * v236) * 0.25;
    v238 = (float)(expf(v234)
                 * (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v236 * *(float *)(a1 + 71104)) + *(float *)(a1 + 71088)) * v237) + (float)(v236 * *(float *)(a1 + 71072))) + *(float *)(a1 + 71056)) * v237) + (float)(v236 * *(float *)(a1 + 71040)))
                                                                                                 + *(float *)(a1 + 71024))
                                                                                         * v237)
                                                                                 + (float)(v236 * *(float *)(a1 + 71008)))
                                                                         + *(float *)(a1 + 70992))
                                                                 * v237)
                                                         + (float)(v236 * *(float *)(a1 + 70976)))
                                                 + *(float *)(a1 + 70960))
                                         * v237)
                                 + (float)(v236 * *(float *)(a1 + 70944)))
                         + 1.0))
         * *(float *)(a1 + 70928);
    v239 = v238 * v238;
    v240 = (float)((float)((float)((float)((float)((float)((float)((float)(v238 * v238) * *(float *)(a1 + 71264))
                                                         + *(float *)(a1 + 71232))
                                                 * (float)(v239 * v239))
                                         + (float)((float)((float)(v238 * v238) * *(float *)(a1 + 71200))
                                                 + *(float *)(a1 + 71168)))
                                 * (float)((float)((float)(v238 * v238) * v238) * (float)(v238 * v238)))
                         + (float)((float)((float)(v238 * v238) * v238) * *(float *)(a1 + 71136)))
                 + v238)
         / (float)((float)((float)((float)((float)((float)((float)((float)((float)(v238 * v238) * *(float *)(a1 + 71248))
                                                                 + *(float *)(a1 + 71216))
                                                         * (float)(v239 * v239))
                                                 + (float)((float)(v238 * v238) * *(float *)(a1 + 71184)))
                                         + *(float *)(a1 + 71152))
                                 * (float)(v239 * v239))
                         + (float)((float)(v238 * v238) * *(float *)(a1 + 71120)))
                 + 1.0);
    v241 = v240 / (float)(v240 + 1.0);
    *(float *)(a1 + 70592) = v241;
  }
  else
  {
    v241 = *(float *)(a1 + 70592);
  }
  v242 = *(float *)(a1 + 69616);
  v243 = *(float *)(a1 + 70608);
  *(_DWORD *)(a1 + 71392) = *(_DWORD *)(a1 + 71376);
  *(_DWORD *)(a1 + 71376) = *(_DWORD *)(a1 + 71360);
  *(_DWORD *)(a1 + 71360) = *(_DWORD *)(a1 + 71344);
  *(_DWORD *)(a1 + 71344) = *(_DWORD *)(a1 + 71328);
  *(_DWORD *)(a1 + 71328) = *(_DWORD *)(a1 + 71312);
  *(_DWORD *)(a1 + 71312) = *(_DWORD *)(a1 + 71296);
  *(_DWORD *)(a1 + 71296) = *(_DWORD *)(a1 + 71280);
  *(_DWORD *)(a1 + 71616) = *(_DWORD *)(a1 + 71600);
  *(_DWORD *)(a1 + 71600) = *(_DWORD *)(a1 + 71584);
  *(_DWORD *)(a1 + 71584) = *(_DWORD *)(a1 + 71568);
  *(_DWORD *)(a1 + 71568) = *(_DWORD *)(a1 + 71552);
  *(_DWORD *)(a1 + 71552) = *(_DWORD *)(a1 + 71536);
  *(_DWORD *)(a1 + 71536) = *(_DWORD *)(a1 + 71520);
  *(_DWORD *)(a1 + 71520) = *(_DWORD *)(a1 + 71504);
  *(_DWORD *)(a1 + 71744) = *(_DWORD *)(a1 + 71728);
  *(_DWORD *)(a1 + 71728) = *(_DWORD *)(a1 + 71712);
  *(_DWORD *)(a1 + 71712) = *(_DWORD *)(a1 + 71696);
  *(_DWORD *)(a1 + 71696) = *(_DWORD *)(a1 + 71680);
  *(_DWORD *)(a1 + 71680) = *(_DWORD *)(a1 + 71664);
  *(_DWORD *)(a1 + 71664) = *(_DWORD *)(a1 + 71648);
  *(_DWORD *)(a1 + 71648) = *(_DWORD *)(a1 + 71632);
  *(_DWORD *)(a1 + 71872) = *(_DWORD *)(a1 + 71856);
  *(_DWORD *)(a1 + 71856) = *(_DWORD *)(a1 + 71840);
  *(_DWORD *)(a1 + 71840) = *(_DWORD *)(a1 + 71824);
  *(_DWORD *)(a1 + 71824) = *(_DWORD *)(a1 + 71808);
  *(_DWORD *)(a1 + 71808) = *(_DWORD *)(a1 + 71792);
  *(_DWORD *)(a1 + 71792) = *(_DWORD *)(a1 + 71776);
  *(_DWORD *)(a1 + 71776) = *(_DWORD *)(a1 + 71760);
  *(_DWORD *)(a1 + 72000) = *(_DWORD *)(a1 + 71984);
  *(_DWORD *)(a1 + 71984) = *(_DWORD *)(a1 + 71968);
  *(_DWORD *)(a1 + 71968) = *(_DWORD *)(a1 + 71952);
  *(_DWORD *)(a1 + 71952) = *(_DWORD *)(a1 + 71936);
  *(_DWORD *)(a1 + 71936) = *(_DWORD *)(a1 + 71920);
  *(_DWORD *)(a1 + 71920) = *(_DWORD *)(a1 + 71904);
  *(_DWORD *)(a1 + 71904) = *(_DWORD *)(a1 + 71888);
  *(_DWORD *)(a1 + 72032) = *(_DWORD *)(a1 + 72016);
  v244 = *(float *)(a1 + 72048);
  *(float *)(a1 + 72064) = v244;
  if ( *(float *)(a1 + 72128) == 1.0 )
  {
    v245 = (float)((float)((float)(v243 * *(float *)(a1 + 72240)) + 1.0) * (float)(v242 * *(float *)(a1 + 72208)))
         + (float)((float)-v244 * *(float *)(a1 + 72192));
    *(float *)(a1 + 72048) = sub_7FF91DFC8D60();
    *(float *)(a1 + 72016) = v245;
    v246 = 1.0 - (float)(v241 + v241);
    v247 = 1.0 / (float)((float)((float)((float)(v241 * v241) * (float)(v241 * v241)) * v243) + 1.0);
    *(float *)(a1 + 72096) = v247;
    v248 = *(float *)(a1 + 72016);
    v249 = *(float *)(a1 + 72032);
    *(float *)(a1 + 72080) = v247 * v243;
    v250 = v249 * *(float *)(a1 + 72288);
    v251 = *(float *)(a1 + 71376);
    v252 = v248 * *(float *)(a1 + 72304);
    v253 = *(float *)(a1 + 71392);
    *(float *)(a1 + 71488) = v251;
    v254 = (float)((float)(v250 + v252) * v247)
         - (float)((float)((float)(v251 * *(float *)(a1 + 72592)) + (float)(v253 * *(float *)(a1 + 72608)))
                 * (float)(v247 * v243));
    if ( v254 >= -1.0 )
      v255 = fminf(v254, 1.0);
    else
      v255 = -1.0;
    v256 = v255 + (float)((float)((float)((float)(v255 * v255) * v255) * v255) * (float)(v255 * *(float *)(a1 + 72256)));
    *(float *)(a1 + 71408) = v256;
    v257 = *(float *)(a1 + 71312);
    v258 = (float)(v241 * (float)(v256 + *(float *)(a1 + 71296))) + (float)(v257 * v246);
    *(float *)(a1 + 71424) = v258;
    v259 = *(float *)(a1 + 71328);
    v260 = v241 * (float)(v258 + v257);
    v261 = v241 * (float)((float)((float)(v241 * v256) + (float)(v246 * v258)) + v258);
    v262 = v260 + (float)(v259 * v246);
    *(float *)(a1 + 71440) = v262;
    v263 = *(float *)(a1 + 71344);
    v264 = (float)(v241 * (float)(v262 + v259)) + (float)(v263 * v246);
    *(float *)(a1 + 71456) = v264;
    v265 = (float)((float)(v263 + v264) * v241) + (float)(v246 * *(float *)(a1 + 71360));
    *(float *)(a1 + 71472) = v265;
    v266 = (float)(v241
                 * (float)((float)((float)(v241 * (float)((float)(v261 + (float)(v246 * v262)) + v262))
                                 + (float)(v246 * v264))
                         + v264))
         + (float)(v246 * v265);
    v267 = (float)(*(float *)(a1 + 71456) * *(float *)(a1 + 72160)) + (float)(v265 * *(float *)(a1 + 72176));
    v268 = *(float *)(a1 + 72032);
    *(float *)(a1 + 71888) = v267 + (float)(*(float *)(a1 + 72144) * *(float *)(a1 + 71440));
    v269 = *(float *)(a1 + 71488);
    v270 = (float)((float)(v268 + *(float *)(a1 + 72016)) * *(float *)(a1 + 72320)) * *(float *)(a1 + 72096);
    *(float *)(a1 + 71488) = v266;
    v271 = v270
         - (float)((float)((float)(v266 * *(float *)(a1 + 72592)) + (float)(v269 * *(float *)(a1 + 72608)))
                 * *(float *)(a1 + 72080));
    if ( v271 >= -1.0 )
      v272 = fminf(v271, 1.0);
    else
      v272 = -1.0;
    v273 = v272 + (float)((float)((float)((float)(v272 * v272) * v272) * v272) * (float)(v272 * *(float *)(a1 + 72256)));
    v274 = *(float *)(a1 + 71408);
    *(float *)(a1 + 71408) = v273;
    v275 = *(float *)(a1 + 71424);
    v276 = (float)(v241 * (float)(v273 + v274)) + (float)(v275 * v246);
    *(float *)(a1 + 71424) = v276;
    v277 = *(float *)(a1 + 71440);
    v278 = v241 * (float)(v276 + v275);
    v279 = v241 * (float)((float)((float)(v241 * v273) + (float)(v246 * v276)) + v276);
    v280 = v278 + (float)(v277 * v246);
    *(float *)(a1 + 71440) = v280;
    v281 = *(float *)(a1 + 71456);
    v282 = (float)(v241 * (float)(v280 + v277)) + (float)(v281 * v246);
    *(float *)(a1 + 71456) = v282;
    v283 = (float)((float)(v281 + v282) * v241) + (float)(v246 * *(float *)(a1 + 71472));
    *(float *)(a1 + 71472) = v283;
    v284 = *(float *)(a1 + 72016);
    v285 = (float)(v241
                 * (float)((float)((float)(v241 * (float)((float)(v279 + (float)(v246 * v280)) + v280))
                                 + (float)(v246 * v282))
                         + v282))
         + (float)(v246 * v283);
    v286 = (float)(*(float *)(a1 + 71456) * *(float *)(a1 + 72160)) + (float)(v283 * *(float *)(a1 + 72176));
    v287 = *(float *)(a1 + 72032);
    *(float *)(a1 + 71760) = v286 + (float)(*(float *)(a1 + 72144) * *(float *)(a1 + 71440));
    v288 = *(float *)(a1 + 71488);
    v289 = (float)((float)(v287 * *(float *)(a1 + 72304)) + (float)(v284 * *(float *)(a1 + 72288)))
         * *(float *)(a1 + 72096);
    *(float *)(a1 + 71488) = v285;
    v290 = v289
         - (float)((float)((float)(v285 * *(float *)(a1 + 72592)) + (float)(v288 * *(float *)(a1 + 72608)))
                 * *(float *)(a1 + 72080));
    if ( v290 >= -1.0 )
      v291 = fminf(v290, 1.0);
    else
      v291 = -1.0;
    v292 = v291 + (float)((float)((float)((float)(v291 * v291) * v291) * v291) * (float)(v291 * *(float *)(a1 + 72256)));
    v293 = *(float *)(a1 + 71408);
    *(float *)(a1 + 71408) = v292;
    v294 = *(float *)(a1 + 71424);
    v295 = (float)(v241 * (float)(v292 + v293)) + (float)(v294 * v246);
    *(float *)(a1 + 71424) = v295;
    v296 = *(float *)(a1 + 71440);
    v297 = v241 * (float)(v295 + v294);
    v298 = v241 * (float)((float)((float)(v241 * v292) + (float)(v246 * v295)) + v295);
    v299 = v297 + (float)(v296 * v246);
    *(float *)(a1 + 71440) = v299;
    v300 = *(float *)(a1 + 71456);
    v301 = (float)(v241 * (float)(v299 + v296)) + (float)(v300 * v246);
    *(float *)(a1 + 71456) = v301;
    v302 = (float)((float)(v300 + v301) * v241) + (float)(v246 * *(float *)(a1 + 71472));
    *(float *)(a1 + 71472) = v302;
    v303 = (float)(v241
                 * (float)((float)((float)(v241 * (float)((float)(v298 + (float)(v246 * v299)) + v299))
                                 + (float)(v246 * v301))
                         + v301))
         + (float)(v246 * v302);
    v304 = (float)(*(float *)(a1 + 71456) * *(float *)(a1 + 72160)) + (float)(v302 * *(float *)(a1 + 72176));
    v305 = *(float *)(a1 + 72016);
    *(float *)(a1 + 71632) = v304 + (float)(*(float *)(a1 + 72144) * *(float *)(a1 + 71440));
    v306 = *(float *)(a1 + 71488);
    v307 = (float)(v305 * *(float *)(a1 + 72272)) * *(float *)(a1 + 72096);
    *(float *)(a1 + 71376) = v303;
    v308 = v307
         - (float)((float)((float)(v303 * *(float *)(a1 + 72592)) + (float)(v306 * *(float *)(a1 + 72608)))
                 * *(float *)(a1 + 72080));
    if ( v308 >= -1.0 )
      v309 = fminf(v308, 1.0);
    else
      v309 = -1.0;
    v310 = v309 + (float)((float)((float)((float)(v309 * v309) * v309) * v309) * (float)(v309 * *(float *)(a1 + 72256)));
    *(float *)(a1 + 71280) = v310;
    v311 = *(float *)(a1 + 71424);
    v312 = (float)(v241 * (float)(v310 + *(float *)(a1 + 71408))) + (float)(v311 * v246);
    *(float *)(a1 + 71296) = v312;
    v313 = *(float *)(a1 + 71440);
    v314 = v241 * (float)(v312 + v311);
    v315 = v241 * (float)((float)((float)(v241 * v310) + (float)(v246 * v312)) + v312);
    v316 = v314 + (float)(v313 * v246);
    *(float *)(a1 + 71312) = v316;
    v317 = *(float *)(a1 + 71456);
    v318 = (float)(v241 * (float)(v316 + v313)) + (float)(v317 * v246);
    *(float *)(a1 + 71328) = v318;
    v319 = (float)((float)(v317 + v318) * v241) + (float)(v246 * *(float *)(a1 + 71472));
    v320 = v241
         * (float)((float)((float)(v241 * (float)((float)(v315 + (float)(v246 * v316)) + v316)) + (float)(v246 * v318))
                 + v318);
    *(float *)(a1 + 71344) = v319;
    v321 = *(float *)(a1 + 71312);
    *(float *)(a1 + 71360) = v320 + (float)(v246 * v319);
    v322 = *(float *)(a1 + 71568);
    v323 = (float)((float)(v319 * *(float *)(a1 + 72176)) + (float)(*(float *)(a1 + 72160) * *(float *)(a1 + 71328)))
         + (float)(v321 * *(float *)(a1 + 72144));
    *(float *)(a1 + 71504) = v323;
    v324 = (float)(v323 + *(float *)(a1 + 72000)) * *(float *)(a1 + 72336);
    v325 = (float)(*(float *)(a1 + 71760) + *(float *)(a1 + 71744)) * *(float *)(a1 + 72368);
    v326 = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v322 + *(float *)(a1 + 71936)) * *(float *)(a1 + 72576)) + (float)((float)(*(float *)(a1 + 71696) + *(float *)(a1 + 71808)) * *(float *)(a1 + 72560))) + (float)((float)(*(float *)(a1 + 71824) + *(float *)(a1 + 71680)) * *(float *)(a1 + 72544))) + (float)((float)(*(float *)(a1 + 71552) + *(float *)(a1 + 71952)) * *(float *)(a1 + 72528))) + (float)((float)(*(float *)(a1 + 71920) + *(float *)(a1 + 71584)) * *(float *)(a1 + 72512)))
                                                                                                 + (float)((float)(*(float *)(a1 + 71792) + *(float *)(a1 + 71712)) * *(float *)(a1 + 72496)))
                                                                                         + (float)((float)(*(float *)(a1 + 71840) + *(float *)(a1 + 71664))
                                                                                                 * *(float *)(a1 + 72480)))
                                                                                 + (float)((float)(*(float *)(a1 + 71968)
                                                                                                 + *(float *)(a1 + 71536))
                                                                                         * *(float *)(a1 + 72464)))
                                                                         + (float)((float)(*(float *)(a1 + 71904)
                                                                                         + *(float *)(a1 + 71600))
                                                                                 * *(float *)(a1 + 72448)))
                                                                 + (float)((float)(*(float *)(a1 + 71776)
                                                                                 + *(float *)(a1 + 71728))
                                                                         * *(float *)(a1 + 72432)))
                                                         + (float)((float)(*(float *)(a1 + 71856)
                                                                         + *(float *)(a1 + 71648))
                                                                 * *(float *)(a1 + 72416)))
                                                 + (float)((float)(*(float *)(a1 + 71984) + *(float *)(a1 + 71520))
                                                         * *(float *)(a1 + 72400)))
                                         + (float)((float)(*(float *)(a1 + 71888) + *(float *)(a1 + 71616))
                                                 * *(float *)(a1 + 72384)))
                                 + v325)
                         + (float)((float)(*(float *)(a1 + 71872) + *(float *)(a1 + 71632)) * *(float *)(a1 + 72352)))
                 + v324)
         * *(float *)(a1 + 72224);
    *(float *)(a1 + 72112) = v326;
  }
  *(_DWORD *)(a1 + 72640) = *(_DWORD *)(a1 + 72624);
  v327 = *(_DWORD *)(a1 + 72672);
  *(_DWORD *)(a1 + 72704) = *(_DWORD *)(a1 + 72656);
  *(_DWORD *)(a1 + 72720) = v327;
  *(_DWORD *)(a1 + 72736) = *(_DWORD *)(a1 + 72688);
  v328 = *(float *)(a1 + 72752);
  *(float *)(a1 + 72768) = v328;
  v329 = *(float *)(a1 + 72784);
  *(float *)(a1 + 72800) = v329;
  v330 = (float)((float)(v328 - v329) * *(float *)(a1 + 72816)) + v329;
  *(float *)(a1 + 72784) = v330;
  v331 = (float)((float)(v330 * *(float *)(a1 + 72720)) - (float)(*(float *)(a1 + 72720) * *(float *)(a1 + 72736)))
       + *(float *)(a1 + 72736);
  *(float *)(a1 + 72832) = v331;
  v332 = *(float *)(a1 + 72848);
  *(float *)(a1 + 72864) = v332;
  v333 = (float)((float)(*(float *)(a1 + 72880) * v331) - (float)(*(float *)(a1 + 72880) * v332)) + v332;
  if ( v333 <= 0.0 )
    v334 = 0.0;
  else
    v334 = v333;
  v335 = v334;
  *(float *)(a1 + 72848) = v335;
  v336 = *(float *)(a1 + 72896);
  *(float *)(a1 + 72912) = v336;
  v337 = *(float *)(a1 + 72928);
  *(float *)(a1 + 72944) = v337;
  v338 = (float)((float)(*(float *)(a1 + 72960) * v336) - (float)(*(float *)(a1 + 72960) * v337)) + v337;
  if ( v338 <= 0.0 )
    v339 = 0.0;
  else
    v339 = v338;
  v340 = v339;
  *(float *)(a1 + 72928) = v340;
  v341 = *(float *)(a1 + 72976);
  v342 = *(float *)(a1 + 63632);
  *(float *)(a1 + 72992) = v341;
  v343 = v341 * *(float *)(a1 + 73072);
  v344 = v341 + *(float *)(a1 + 73056);
  if ( v343 >= -1.0 )
    v345 = fminf(v343, 1.0);
  else
    v345 = -1.0;
  if ( (float)(v341 + *(float *)(a1 + 73024)) >= 0.0 )
    v344 = (float)((float)(*(float *)(a1 + 73040) * v342) - (float)(*(float *)(a1 + 73040) * v341)) + v341;
  v346 = (float)((float)(v345 * *(float *)(a1 + 73088)) - (float)(*(float *)(a1 + 73104) * v345))
       + *(float *)(a1 + 73104);
  v347 = (float)((float)(v346 * v342) - (float)(v346 * v341)) + v341;
  if ( v342 != 0.0 )
    v347 = v344;
  *(float *)(a1 + 73008) = v347;
  *(float *)(a1 + 72976) = v347;
  v348 = *(float *)(a1 + 72112);
  v349 = *(float *)(a1 + 65824);
  v350 = *(float *)(a1 + 69920);
  v351 = *(_DWORD *)(a1 + 66304);
  v352 = *(_DWORD *)(a1 + 72624);
  *(_DWORD *)(a1 + 73184) = *(_DWORD *)(a1 + 73168);
  *(_DWORD *)(a1 + 73216) = *(_DWORD *)(a1 + 73200);
  *(_DWORD *)(a1 + 73120) = v351;
  *(_DWORD *)(a1 + 73136) = v352;
  v353 = *(float *)(a1 + 73184);
  v354 = *(float *)(a1 + 73248);
  *(float *)(a1 + 73152) = v350 * *(float *)(a1 + 73408);
  v355 = v348 - v353;
  v356 = *(float *)(a1 + 73280);
  v357 = (float)(v349 * *(float *)(a1 + 73264)) + (float)(v354 * *(float *)(a1 + 73008));
  v358 = v353 + (float)((float)(v348 - v353) * *(float *)(a1 + 73312));
  *(float *)(a1 + 73168) = v358;
  v359 = (float)(v355 * *(float *)(a1 + 73424)) + (float)(v358 * *(float *)(a1 + 73440));
  v360 = (float)((float)(*(float *)(a1 + 73296) * *(float *)(a1 + 73136))
               - (float)(*(float *)(a1 + 73296) * (float)(v357 + (float)(v356 * *(float *)(a1 + 73120)))))
       + (float)(v357 + (float)(v356 * *(float *)(a1 + 73120)));
  v361 = *(float *)(a1 + 73328);
  v362 = v360 * *(float *)(a1 + 73376);
  v363 = v348 * (float)(1.0 - v361);
  if ( v362 <= 0.0 )
    v364 = 0.0;
  else
    v364 = v362;
  v365 = *(float *)(a1 + 73344);
  v366 = v364;
  v367 = v366 * *(float *)(a1 + 73392);
  v368 = (float)((float)(v361 * v359) + v363) * (float)(*(float *)(a1 + 73152) + 1.0);
  v369 = *(float *)(a1 + 73360) * v368;
  v370 = *(float *)(a1 + 73216)
       + (float)((float)(*(float *)(a1 + 73456) * v368) - (float)(*(float *)(a1 + 73456) * *(float *)(a1 + 73216)));
  *(float *)(a1 + 73200) = v370;
  v371 = (float)((float)((float)(v365 * v370) + v369) * v367) * *(float *)(a1 + 73472);
  *(float *)(a1 + 73232) = v371;
  *(_DWORD *)(a1 + 73520) = *(_DWORD *)(a1 + 73504);
  *(_DWORD *)(a1 + 73504) = *(_DWORD *)(a1 + 73488);
  v372 = *(float *)(a1 + 73520);
  v373 = *(float *)(a1 + 73536);
  v374 = v371 - v372;
  *(float *)(a1 + 73488) = v374;
  *(float *)(a1 + 73504) = (float)(v373 * v374) + v372;
  v375 = *(float *)(a1 + 73488);
  v376 = *(float *)(a1 + 72704);
  *(_DWORD *)(a1 + 73600) = *(_DWORD *)(a1 + 73584);
  *(_DWORD *)(a1 + 73584) = *(_DWORD *)(a1 + 73568);
  *(_DWORD *)(a1 + 73568) = *(_DWORD *)(a1 + 73552);
  *(float *)(a1 + 73552) = v375;
  v377 = (float)((float)(*(float *)(a1 + 73568) * *(float *)(a1 + 73648)) + (float)(v375 * *(float *)(a1 + 73632)))
       + (float)(*(float *)(a1 + 73664) * *(float *)(a1 + 73584));
  v378 = (float)((float)(*(float *)(a1 + 73568) * *(float *)(a1 + 73696)) + (float)(v375 * *(float *)(a1 + 73680)))
       + (float)(*(float *)(a1 + 73712) * *(float *)(a1 + 73600));
  if ( v376 <= 0.0 )
    v379 = 0.0;
  else
    v379 = v376;
  *(float *)(a1 + 73568) = v377;
  v380 = v379;
  *(float *)(a1 + 73584) = v378;
  v381 = (float)((float)(v380 * v377) - (float)(v380 * v375)) + v375;
  if ( v376 < -0.0 )
    v19 = (float)-v376;
  v382 = v19;
  v383 = v375 + (float)((float)(v382 * v378) - (float)(v382 * v375));
  if ( v376 >= 0.0 )
    v383 = v381;
  *(float *)(a1 + 73616) = v383;
  v384 = v383 * *(float *)(a1 + 72848);
  *(float *)(a1 + 73728) = v384;
  *(float *)(a1 + 73744) = v384 * *(float *)(a1 + 72928);
  v385 = fmin(fmax((float)(*(float *)(a1 + 67520) + *(float *)(a1 + 66848)), -20.0), 8.9);
  v386 = v385 * v385 * v385;
  v387 = (double *)((char *)&unk_7FF91E5E94E0 + 208 * (int)(v385 + 20.0));
  v388 = v386 * v385 * v385;
  v389 = v388 * v385 * v385 * v385;
  v390 = v389 * v385 * v385;
  v391 = fmaxf(
           fminf(
             v385 * v387[2]
           + *v387
           + v385 * v385 * v387[4]
           + v386 * v387[6]
           + v386 * v385 * v387[8]
           + v388 * v387[10]
           + v388 * v385 * v387[12]
           + v388 * v385 * v385 * v387[14]
           + v389 * v387[16]
           + v389 * v385 * v387[18]
           + v390 * v387[20]
           + v390 * v385 * v387[22]
           + v390 * v385 * v385 * v387[24],
             512.0),
           -512.0)
       * *(float *)(a1 + 66864);
  *(float *)(a1 + 67488) = v391;
  v392 = *(float *)(a1 + 66848);
  v393 = *(_DWORD *)(a1 + 67312);
  v394 = *(_DWORD *)(a1 + 67328);
  LODWORD(v386) = *(_DWORD *)(a1 + 67344);
  *(_DWORD *)(a1 + 67920) = *(_DWORD *)(a1 + 67904);
  *(_DWORD *)(a1 + 67952) = *(_DWORD *)(a1 + 67936);
  *(_DWORD *)(a1 + 68128) = *(_DWORD *)(a1 + 68112);
  *(_DWORD *)(a1 + 68112) = *(_DWORD *)(a1 + 68096);
  *(_DWORD *)(a1 + 68096) = *(_DWORD *)(a1 + 68080);
  *(_DWORD *)(a1 + 68080) = *(_DWORD *)(a1 + 68064);
  *(_DWORD *)(a1 + 68064) = *(_DWORD *)(a1 + 68048);
  *(_DWORD *)(a1 + 68048) = *(_DWORD *)(a1 + 68032);
  *(_DWORD *)(a1 + 68032) = *(_DWORD *)(a1 + 68016);
  *(_DWORD *)(a1 + 68256) = *(_DWORD *)(a1 + 68240);
  *(_DWORD *)(a1 + 68240) = *(_DWORD *)(a1 + 68224);
  *(_DWORD *)(a1 + 68224) = *(_DWORD *)(a1 + 68208);
  *(_DWORD *)(a1 + 68208) = *(_DWORD *)(a1 + 68192);
  *(_DWORD *)(a1 + 68192) = *(_DWORD *)(a1 + 68176);
  *(_DWORD *)(a1 + 68176) = *(_DWORD *)(a1 + 68160);
  *(_DWORD *)(a1 + 68160) = *(_DWORD *)(a1 + 68144);
  *(_DWORD *)(a1 + 68384) = *(_DWORD *)(a1 + 68368);
  *(_DWORD *)(a1 + 68368) = *(_DWORD *)(a1 + 68352);
  *(_DWORD *)(a1 + 68352) = *(_DWORD *)(a1 + 68336);
  *(_DWORD *)(a1 + 68336) = *(_DWORD *)(a1 + 68320);
  *(_DWORD *)(a1 + 68320) = *(_DWORD *)(a1 + 68304);
  *(_DWORD *)(a1 + 68304) = *(_DWORD *)(a1 + 68288);
  *(_DWORD *)(a1 + 68288) = *(_DWORD *)(a1 + 68272);
  *(_DWORD *)(a1 + 68512) = *(_DWORD *)(a1 + 68496);
  *(_DWORD *)(a1 + 68496) = *(_DWORD *)(a1 + 68480);
  *(_DWORD *)(a1 + 68480) = *(_DWORD *)(a1 + 68464);
  *(_DWORD *)(a1 + 68464) = *(_DWORD *)(a1 + 68448);
  *(_DWORD *)(a1 + 68448) = *(_DWORD *)(a1 + 68432);
  *(_DWORD *)(a1 + 68432) = *(_DWORD *)(a1 + 68416);
  *(_DWORD *)(a1 + 68416) = *(_DWORD *)(a1 + 68400);
  *(_DWORD *)(a1 + 68576) = *(_DWORD *)(a1 + 68560);
  *(_DWORD *)(a1 + 68560) = *(_DWORD *)(a1 + 68544);
  *(_DWORD *)(a1 + 67808) = v393;
  *(_DWORD *)(a1 + 67824) = v394;
  v395 = v392 + *(float *)(a1 + 69376);
  v396 = v391 * *(float *)(a1 + 68608);
  v397 = *(float *)(a1 + 68592);
  *(_DWORD *)(a1 + 67840) = LODWORD(v386);
  v398 = fmaxf(*(float *)(a1 + 68640), v396);
  v399 = (float)(v395 * *(float *)(a1 + 69392)) + *(float *)(a1 + 69360);
  *(float *)(a1 + 67856) = v398;
  *(float *)(a1 + 67888) = v397 + *(float *)(a1 + 66880);
  if ( v399 <= 0.0 )
    v400 = 0.0;
  else
    v400 = v399;
  *(float *)(a1 + 67872) = 0.00390625 / v398;
  *(float *)(a1 + 68528) = v400;
  v401 = *(float *)(a1 + 67952);
  v402 = *(_DWORD *)(a1 + 67920);
  *(float *)(a1 + 67728) = v401;
  v403 = v401 + v398;
  *(_DWORD *)(a1 + 67744) = v402;
  if ( v403 <= 1.0 )
  {
    if ( v403 < -1.0 )
      v403 = fmodf(v403 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v403 = fmodf(v403 + 1.0, 2.0) - 1.0;
  }
  *(float *)(a1 + 67712) = v403;
  v404 = v403 * *(float *)(a1 + 68720);
  v405 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v406 = (float)((float)(*(float *)&v405 * 256.0) * *(float *)(a1 + 67872)) * *(float *)(a1 + 68672);
  if ( v406 >= -1.0 )
    v407 = fminf(v406, 1.0);
  else
    v407 = -1.0;
  v408 = v407 * *(float *)(a1 + 68624);
  v409 = (float)(v408 * v408) * v408;
  v410 = v409 * *(float *)(a1 + 69024);
  v411 = (float)((float)((float)((float)((float)(v408 * v408) * *(float *)(a1 + 69088)) + *(float *)(a1 + 69072))
                       * (float)((float)(v408 * v408) * (float)(v408 * v408)))
               + (float)((float)((float)(v408 * v408) * *(float *)(a1 + 69056)) + *(float *)(a1 + 69040)))
       * (float)(v409 * (float)(v408 * v408));
  v412 = *(float *)(a1 + 67888) + v403;
  *(float *)(a1 + 67968) = (float)((float)(v411 + v410) + v408) * v404;
  v413 = v412;
  if ( v412 >= 0.0 )
  {
    if ( v412 > 0.0 )
      v413 = 1.0;
  }
  else
  {
    v413 = -1.0;
  }
  v414 = *(float *)(a1 + 67712);
  v415 = v413 * *(float *)(a1 + 68736);
  v416 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v417 = *(float *)&v416;
  v418 = *(float *)(a1 + 68656);
  if ( v414 < v418 || v418 <= *(float *)(a1 + 67728) )
    v419 = *(float *)(a1 + 67744);
  else
    v419 = *(float *)(a1 + 67744) + 2.0;
  v420 = (float)((float)(v417 * *(float *)(a1 + 67872)) * 256.0) * *(float *)(a1 + 68688);
  if ( v419 >= 4.0 )
    v419 = 0.0;
  if ( v420 >= -1.0 )
    v421 = fminf(v420, 1.0);
  else
    v421 = -1.0;
  *(float *)(a1 + 67744) = v419;
  v422 = v421 * *(float *)(a1 + 68624);
  v423 = (float)((float)((float)(v419 + v414) + 1.0) * 0.5) - 1.0;
  v424 = (float)((float)((float)((float)((float)((float)((float)((float)(v422 * v422) * *(float *)(a1 + 69088))
                                                       + *(float *)(a1 + 69072))
                                               * (float)((float)(v422 * v422) * (float)(v422 * v422)))
                                       + (float)((float)((float)(v422 * v422) * *(float *)(a1 + 69056))
                                               + *(float *)(a1 + 69040)))
                               * (float)((float)((float)(v422 * v422) * v422) * (float)(v422 * v422)))
                       + (float)((float)((float)(v422 * v422) * v422) * *(float *)(a1 + 69024)))
               + v422)
       * v415;
  *(float *)(a1 + 67984) = v424;
  v425 = ((double (*)(void))sub_7FF91DFC8FC0)();
  if ( v423 >= 0.0 )
  {
    if ( v423 > 0.0 )
      v423 = 1.0;
  }
  else
  {
    v423 = -1.0;
  }
  v426 = v423 * *(float *)(a1 + 68752);
  v427 = (float)((float)((float)(*(float *)&v425 + 1.0) * *(float *)(a1 + 67872)) * 512.0) * *(float *)(a1 + 68704);
  if ( v427 >= -1.0 )
    v428 = fminf(v427, 1.0);
  else
    v428 = -1.0;
  v429 = v428 * *(float *)(a1 + 68624);
  v430 = *(float *)(a1 + 67712);
  v431 = *(_DWORD *)(a1 + 67744);
  *(float *)(a1 + 68016) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v429 * v429)
                                                                                                 * *(float *)(a1 + 69088))
                                                                                         + *(float *)(a1 + 69072))
                                                                                 * (float)((float)(v429 * v429)
                                                                                         * (float)(v429 * v429)))
                                                                         + (float)((float)((float)(v429 * v429)
                                                                                         * *(float *)(a1 + 69056))
                                                                                 + *(float *)(a1 + 69040)))
                                                                 * (float)((float)((float)(v429 * v429) * v429)
                                                                         * (float)(v429 * v429)))
                                                         + (float)((float)((float)(v429 * v429) * v429)
                                                                 * *(float *)(a1 + 69024)))
                                                 + v429)
                                         * v426)
                                 * *(float *)(a1 + 67840))
                         + (float)((float)(*(float *)(a1 + 67968) * *(float *)(a1 + 67808))
                                 + (float)(v424 * *(float *)(a1 + 67824)));
  *(float *)(a1 + 67728) = v430;
  *(_DWORD *)(a1 + 67744) = v431;
  v432 = v430 + *(float *)(a1 + 67856);
  if ( v432 <= 1.0 )
  {
    if ( v432 < -1.0 )
      v432 = fmodf(v432 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v432 = fmodf(v432 + 1.0, 2.0) - 1.0;
  }
  *(float *)(a1 + 67712) = v432;
  v433 = v432 * *(float *)(a1 + 68720);
  v434 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v435 = (float)((float)(*(float *)&v434 * 256.0) * *(float *)(a1 + 67872)) * *(float *)(a1 + 68672);
  if ( v435 >= -1.0 )
    v436 = fminf(v435, 1.0);
  else
    v436 = -1.0;
  v437 = v436 * *(float *)(a1 + 68624);
  v438 = (float)(v437 * v437) * v437;
  v439 = v438 * *(float *)(a1 + 69024);
  v440 = (float)((float)((float)((float)((float)(v437 * v437) * *(float *)(a1 + 69088)) + *(float *)(a1 + 69072))
                       * (float)((float)(v437 * v437) * (float)(v437 * v437)))
               + (float)((float)((float)(v437 * v437) * *(float *)(a1 + 69056)) + *(float *)(a1 + 69040)))
       * (float)(v438 * (float)(v437 * v437));
  v441 = *(float *)(a1 + 67888) + v432;
  *(float *)(a1 + 67968) = (float)((float)(v440 + v439) + v437) * v433;
  v442 = v441;
  if ( v441 >= 0.0 )
  {
    if ( v441 > 0.0 )
      v442 = 1.0;
  }
  else
  {
    v442 = -1.0;
  }
  v443 = *(float *)(a1 + 67712);
  v444 = v442 * *(float *)(a1 + 68736);
  v445 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v446 = *(float *)&v445;
  v447 = *(float *)(a1 + 68656);
  if ( v443 < v447 || v447 <= *(float *)(a1 + 67728) )
    v448 = *(float *)(a1 + 67744);
  else
    v448 = *(float *)(a1 + 67744) + 2.0;
  v449 = (float)((float)(v446 * *(float *)(a1 + 67872)) * 256.0) * *(float *)(a1 + 68688);
  if ( v448 >= 4.0 )
    v448 = 0.0;
  if ( v449 >= -1.0 )
    v450 = fminf(v449, 1.0);
  else
    v450 = -1.0;
  *(float *)(a1 + 67744) = v448;
  v451 = v450 * *(float *)(a1 + 68624);
  v452 = (float)((float)((float)(v448 + v443) + 1.0) * 0.5) - 1.0;
  v453 = (float)((float)((float)((float)((float)((float)((float)((float)(v451 * v451) * *(float *)(a1 + 69088))
                                                       + *(float *)(a1 + 69072))
                                               * (float)((float)(v451 * v451) * (float)(v451 * v451)))
                                       + (float)((float)((float)(v451 * v451) * *(float *)(a1 + 69056))
                                               + *(float *)(a1 + 69040)))
                               * (float)((float)((float)(v451 * v451) * v451) * (float)(v451 * v451)))
                       + (float)((float)((float)(v451 * v451) * v451) * *(float *)(a1 + 69024)))
               + v451)
       * v444;
  *(float *)(a1 + 67984) = v453;
  v454 = ((double (*)(void))sub_7FF91DFC8FC0)();
  if ( v452 >= 0.0 )
  {
    if ( v452 > 0.0 )
      v452 = 1.0;
  }
  else
  {
    v452 = -1.0;
  }
  v455 = v452 * *(float *)(a1 + 68752);
  v456 = (float)((float)((float)(*(float *)&v454 + 1.0) * *(float *)(a1 + 67872)) * 512.0) * *(float *)(a1 + 68704);
  if ( v456 >= -1.0 )
    v457 = fminf(v456, 1.0);
  else
    v457 = -1.0;
  v458 = v457 * *(float *)(a1 + 68624);
  v459 = *(float *)(a1 + 67712);
  v460 = *(_DWORD *)(a1 + 67744);
  *(float *)(a1 + 68144) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v458 * v458)
                                                                                                 * *(float *)(a1 + 69088))
                                                                                         + *(float *)(a1 + 69072))
                                                                                 * (float)((float)(v458 * v458)
                                                                                         * (float)(v458 * v458)))
                                                                         + (float)((float)((float)(v458 * v458)
                                                                                         * *(float *)(a1 + 69056))
                                                                                 + *(float *)(a1 + 69040)))
                                                                 * (float)((float)((float)(v458 * v458) * v458)
                                                                         * (float)(v458 * v458)))
                                                         + (float)((float)((float)(v458 * v458) * v458)
                                                                 * *(float *)(a1 + 69024)))
                                                 + v458)
                                         * v455)
                                 * *(float *)(a1 + 67840))
                         + (float)((float)(*(float *)(a1 + 67968) * *(float *)(a1 + 67808))
                                 + (float)(v453 * *(float *)(a1 + 67824)));
  *(float *)(a1 + 67728) = v459;
  *(_DWORD *)(a1 + 67744) = v460;
  v461 = v459 + *(float *)(a1 + 67856);
  if ( v461 <= 1.0 )
  {
    if ( v461 < -1.0 )
      v461 = fmodf(v461 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v461 = fmodf(v461 + 1.0, 2.0) - 1.0;
  }
  *(float *)(a1 + 67712) = v461;
  v462 = v461 * *(float *)(a1 + 68720);
  v463 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v464 = (float)((float)(*(float *)&v463 * 256.0) * *(float *)(a1 + 67872)) * *(float *)(a1 + 68672);
  if ( v464 >= -1.0 )
    v465 = fminf(v464, 1.0);
  else
    v465 = -1.0;
  v466 = v465 * *(float *)(a1 + 68624);
  v467 = (float)(v466 * v466) * v466;
  v468 = v467 * *(float *)(a1 + 69024);
  v469 = (float)((float)((float)((float)((float)(v466 * v466) * *(float *)(a1 + 69088)) + *(float *)(a1 + 69072))
                       * (float)((float)(v466 * v466) * (float)(v466 * v466)))
               + (float)((float)((float)(v466 * v466) * *(float *)(a1 + 69056)) + *(float *)(a1 + 69040)))
       * (float)(v467 * (float)(v466 * v466));
  v470 = *(float *)(a1 + 67888) + v461;
  *(float *)(a1 + 67968) = (float)((float)(v469 + v468) + v466) * v462;
  v471 = v470;
  if ( v470 >= 0.0 )
  {
    if ( v470 > 0.0 )
      v471 = 1.0;
  }
  else
  {
    v471 = -1.0;
  }
  v472 = *(float *)(a1 + 67712);
  v473 = v471 * *(float *)(a1 + 68736);
  v474 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v475 = *(float *)&v474;
  v476 = *(float *)(a1 + 68656);
  if ( v472 < v476 || v476 <= *(float *)(a1 + 67728) )
    v477 = *(float *)(a1 + 67744);
  else
    v477 = *(float *)(a1 + 67744) + 2.0;
  v478 = (float)((float)(v475 * *(float *)(a1 + 67872)) * 256.0) * *(float *)(a1 + 68688);
  if ( v477 >= 4.0 )
    v477 = 0.0;
  if ( v478 >= -1.0 )
    v479 = fminf(v478, 1.0);
  else
    v479 = -1.0;
  *(float *)(a1 + 67744) = v477;
  v480 = v479 * *(float *)(a1 + 68624);
  v481 = (float)((float)((float)(v477 + v472) + 1.0) * 0.5) - 1.0;
  v482 = (float)((float)((float)((float)((float)((float)((float)((float)(v480 * v480) * *(float *)(a1 + 69088))
                                                       + *(float *)(a1 + 69072))
                                               * (float)((float)(v480 * v480) * (float)(v480 * v480)))
                                       + (float)((float)((float)(v480 * v480) * *(float *)(a1 + 69056))
                                               + *(float *)(a1 + 69040)))
                               * (float)((float)((float)(v480 * v480) * v480) * (float)(v480 * v480)))
                       + (float)((float)((float)(v480 * v480) * v480) * *(float *)(a1 + 69024)))
               + v480)
       * v473;
  *(float *)(a1 + 67984) = v482;
  v483 = ((double (*)(void))sub_7FF91DFC8FC0)();
  if ( v481 >= 0.0 )
  {
    if ( v481 > 0.0 )
      v481 = 1.0;
  }
  else
  {
    v481 = -1.0;
  }
  v484 = v481 * *(float *)(a1 + 68752);
  v485 = (float)((float)((float)(*(float *)&v483 + 1.0) * *(float *)(a1 + 67872)) * 512.0) * *(float *)(a1 + 68704);
  if ( v485 >= -1.0 )
    v486 = fminf(v485, 1.0);
  else
    v486 = -1.0;
  v487 = v486 * *(float *)(a1 + 68624);
  v488 = *(float *)(a1 + 67712);
  v489 = *(_DWORD *)(a1 + 67744);
  *(float *)(a1 + 68272) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v487 * v487)
                                                                                                 * *(float *)(a1 + 69088))
                                                                                         + *(float *)(a1 + 69072))
                                                                                 * (float)((float)(v487 * v487)
                                                                                         * (float)(v487 * v487)))
                                                                         + (float)((float)((float)(v487 * v487)
                                                                                         * *(float *)(a1 + 69056))
                                                                                 + *(float *)(a1 + 69040)))
                                                                 * (float)((float)((float)(v487 * v487) * v487)
                                                                         * (float)(v487 * v487)))
                                                         + (float)((float)((float)(v487 * v487) * v487)
                                                                 * *(float *)(a1 + 69024)))
                                                 + v487)
                                         * v484)
                                 * *(float *)(a1 + 67840))
                         + (float)((float)(*(float *)(a1 + 67968) * *(float *)(a1 + 67808))
                                 + (float)(v482 * *(float *)(a1 + 67824)));
  *(float *)(a1 + 67728) = v488;
  *(_DWORD *)(a1 + 67744) = v489;
  v490 = v488 + *(float *)(a1 + 67856);
  if ( v490 <= 1.0 )
  {
    if ( v490 < -1.0 )
      v490 = fmodf(v490 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v490 = fmodf(v490 + 1.0, 2.0) - 1.0;
  }
  *(float *)(a1 + 67712) = v490;
  v491 = v490 * *(float *)(a1 + 68720);
  v492 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v493 = (float)((float)(*(float *)&v492 * 256.0) * *(float *)(a1 + 67872)) * *(float *)(a1 + 68672);
  if ( v493 >= -1.0 )
    v494 = fminf(v493, 1.0);
  else
    v494 = -1.0;
  v495 = v494 * *(float *)(a1 + 68624);
  v496 = (float)(v495 * v495) * v495;
  v497 = v496 * *(float *)(a1 + 69024);
  v498 = (float)((float)((float)((float)((float)(v495 * v495) * *(float *)(a1 + 69088)) + *(float *)(a1 + 69072))
                       * (float)((float)(v495 * v495) * (float)(v495 * v495)))
               + (float)((float)((float)(v495 * v495) * *(float *)(a1 + 69056)) + *(float *)(a1 + 69040)))
       * (float)(v496 * (float)(v495 * v495));
  v499 = *(float *)(a1 + 67888) + v490;
  *(float *)(a1 + 67968) = (float)((float)(v498 + v497) + v495) * v491;
  v500 = v499;
  if ( v499 >= 0.0 )
  {
    if ( v499 > 0.0 )
      v500 = 1.0;
  }
  else
  {
    v500 = -1.0;
  }
  v501 = *(float *)(a1 + 67712);
  v502 = v500 * *(float *)(a1 + 68736);
  v503 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v504 = *(float *)&v503;
  v505 = *(float *)(a1 + 68656);
  if ( v501 < v505 || v505 <= *(float *)(a1 + 67728) )
    v506 = *(float *)(a1 + 67744);
  else
    v506 = *(float *)(a1 + 67744) + 2.0;
  v507 = (float)((float)(v504 * *(float *)(a1 + 67872)) * 256.0) * *(float *)(a1 + 68688);
  if ( v506 >= 4.0 )
    v506 = 0.0;
  if ( v507 >= -1.0 )
    v508 = fminf(v507, 1.0);
  else
    v508 = -1.0;
  *(float *)(a1 + 67744) = v506;
  v509 = v508 * *(float *)(a1 + 68624);
  v510 = (float)((float)((float)(v506 + v501) + 1.0) * 0.5) - 1.0;
  v511 = (float)((float)((float)((float)((float)((float)((float)((float)(v509 * v509) * *(float *)(a1 + 69088))
                                                       + *(float *)(a1 + 69072))
                                               * (float)((float)(v509 * v509) * (float)(v509 * v509)))
                                       + (float)((float)((float)(v509 * v509) * *(float *)(a1 + 69056))
                                               + *(float *)(a1 + 69040)))
                               * (float)((float)((float)(v509 * v509) * v509) * (float)(v509 * v509)))
                       + (float)((float)((float)(v509 * v509) * v509) * *(float *)(a1 + 69024)))
               + v509)
       * v502;
  *(float *)(a1 + 67984) = v511;
  v512 = sub_7FF91DFC8FC0() + 1.0;
  if ( v510 >= 0.0 )
  {
    if ( v510 > 0.0 )
      v510 = 1.0;
  }
  else
  {
    v510 = -1.0;
  }
  v513 = v510 * *(float *)(a1 + 68752);
  v514 = (float)((float)(v512 * *(float *)(a1 + 67872)) * 512.0) * *(float *)(a1 + 68704);
  if ( v514 >= -1.0 )
    v33 = fminf(v514, 1.0);
  v515 = v33 * *(float *)(a1 + 68624);
  v516 = *(_DWORD *)(a1 + 67712);
  v517 = *(_DWORD *)(a1 + 67744);
  *(float *)(a1 + 68400) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v515 * v515)
                                                                                                 * *(float *)(a1 + 69088))
                                                                                         + *(float *)(a1 + 69072))
                                                                                 * (float)((float)(v515 * v515)
                                                                                         * (float)(v515 * v515)))
                                                                         + (float)((float)((float)(v515 * v515)
                                                                                         * *(float *)(a1 + 69056))
                                                                                 + *(float *)(a1 + 69040)))
                                                                 * (float)((float)((float)(v515 * v515) * v515)
                                                                         * (float)(v515 * v515)))
                                                         + (float)((float)((float)(v515 * v515) * v515)
                                                                 * *(float *)(a1 + 69024)))
                                                 + v515)
                                         * v513)
                                 * *(float *)(a1 + 67840))
                         + (float)((float)(*(float *)(a1 + 67968) * *(float *)(a1 + 67808))
                                 + (float)(v511 * *(float *)(a1 + 67824)));
  v518 = *(float *)(a1 + 68512);
  *(_DWORD *)(a1 + 67936) = v516;
  *(_DWORD *)(a1 + 67904) = v517;
  v519 = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(*(float *)(a1 + 68384) + *(float *)(a1 + 68144))
                                                                                               * *(float *)(a1 + 68784))
                                                                                       + (float)((float)(v518 + *(float *)(a1 + 68016))
                                                                                               * *(float *)(a1 + 68768)))
                                                                               + (float)((float)(*(float *)(a1 + 68272)
                                                                                               + *(float *)(a1 + 68256))
                                                                                       * *(float *)(a1 + 68800)))
                                                                       + (float)((float)(*(float *)(a1 + 68400)
                                                                                       + *(float *)(a1 + 68128))
                                                                               * *(float *)(a1 + 68816)))
                                                               + (float)((float)(*(float *)(a1 + 68496)
                                                                               + *(float *)(a1 + 68032))
                                                                       * *(float *)(a1 + 68832)))
                                                       + (float)((float)(*(float *)(a1 + 68368) + *(float *)(a1 + 68160))
                                                               * *(float *)(a1 + 68848)))
                                               + (float)((float)(*(float *)(a1 + 68288) + *(float *)(a1 + 68240))
                                                       * *(float *)(a1 + 68864)))
                                       + (float)((float)(*(float *)(a1 + 68416) + *(float *)(a1 + 68112))
                                               * *(float *)(a1 + 68880)))
                               + (float)((float)(*(float *)(a1 + 68480) + *(float *)(a1 + 68048))
                                       * *(float *)(a1 + 68896)))
                       + (float)((float)(*(float *)(a1 + 68176) + *(float *)(a1 + 68352)) * *(float *)(a1 + 68912)))
               + (float)((float)(*(float *)(a1 + 68304) + *(float *)(a1 + 68224)) * *(float *)(a1 + 68928)))
       + (float)((float)(*(float *)(a1 + 68096) + *(float *)(a1 + 68432)) * *(float *)(a1 + 68944));
  v520 = *(float *)(a1 + 68560);
  v521 = (float)(v520 * *(float *)(a1 + 69328)) + *(float *)(a1 + 68576);
  v522 = (float)((float)(v519
                       + (float)((float)(*(float *)(a1 + 68464) + *(float *)(a1 + 68064)) * *(float *)(a1 + 68960)))
               + (float)((float)(*(float *)(a1 + 68336) + *(float *)(a1 + 68192)) * *(float *)(a1 + 68976)))
       + (float)((float)(*(float *)(a1 + 68320) + *(float *)(a1 + 68208)) * *(float *)(a1 + 68992));
  v523 = (float)(*(float *)(a1 + 68448) + *(float *)(a1 + 68080)) * *(float *)(a1 + 69008);
  *(float *)(a1 + 68560) = v521;
  v524 = v522 + v523;
  v525 = v524 - (float)((float)(v520 * *(float *)(a1 + 69344)) + v521);
  *(float *)(a1 + 68544) = (float)(v525 * *(float *)(a1 + 69328)) + v520;
  v526 = (float)((float)((float)(v521 - (float)(v525 * *(float *)(a1 + 68528))) * *(float *)(a1 + 69408))
               - (float)(*(float *)(a1 + 69408) * v524))
       + v524;
  *(float *)(a1 + 68000) = v526;
  *(float *)(a1 + 66592) = v526;
  if ( *(float *)(a1 + 101696) == 1.0 )
  {
    *(_DWORD *)(a1 + 63392) = v528;
    *(_DWORD *)(a1 + 101696) = 0;
  }
  **a2 = *(_DWORD *)(a1 + 73744);
  result = *(unsigned int *)(a1 + 73744);
  *a2[1] = result;
  return result;
}


// ==== sub_7FF91DFE3F20 @ rva 0x383F20 ====
__int64 __fastcall sub_7FF91DFE3F20(__int64 a1, _DWORD **a2)
{
  float v2; // xmm4_4
  float v5; // xmm0_4
  float v6; // xmm1_4
  float v7; // xmm2_4
  int v8; // edx
  int v9; // edx
  int v10; // eax
  float v11; // xmm3_4
  float v12; // xmm6_4
  int v13; // eax
  float v14; // xmm8_4
  int v15; // ecx
  float v16; // xmm7_4
  signed int v17; // edx
  float v18; // xmm1_4
  double v19; // xmm10_8
  float v20; // xmm0_4
  float v21; // xmm0_4
  float v22; // xmm1_4
  float v23; // xmm2_4
  float v24; // xmm1_4
  float v25; // xmm0_4
  float v26; // xmm2_4
  float v27; // xmm1_4
  float v28; // xmm6_4
  float v29; // xmm3_4
  float v30; // xmm1_4
  float v31; // xmm3_4
  double v32; // xmm0_8
  float v33; // xmm15_4
  float v34; // xmm5_4
  float v35; // xmm0_4
  float v36; // xmm5_4
  float v37; // xmm2_4
  float v38; // xmm1_4
  int v39; // eax
  float v40; // xmm4_4
  float v41; // xmm3_4
  double v42; // xmm12_8
  float v43; // xmm5_4
  float v44; // xmm0_4
  float v45; // xmm5_4
  float v46; // xmm1_4
  float v47; // xmm2_4
  float v48; // xmm2_4
  float v49; // xmm1_4
  float v50; // xmm2_4
  float v51; // xmm2_4
  float v52; // xmm2_4
  float v53; // xmm1_4
  double v54; // xmm0_8
  float v55; // xmm1_4
  float v56; // xmm1_4
  float v57; // xmm7_4
  float v58; // xmm0_4
  float v59; // xmm2_4
  int v60; // xmm9_4
  float v61; // xmm7_4
  int v62; // xmm8_4
  int v63; // eax
  float v64; // xmm7_4
  float v65; // xmm1_4
  int v66; // eax
  float v67; // xmm0_4
  float v68; // xmm2_4
  float v69; // xmm1_4
  float v70; // xmm2_4
  double v71; // xmm0_8
  float v72; // xmm1_4
  double v73; // xmm0_8
  float v74; // xmm6_4
  float v75; // xmm0_4
  float v76; // xmm1_4
  float v77; // xmm0_4
  float v78; // xmm3_4
  float v79; // xmm7_4
  float v80; // xmm2_4
  float v81; // xmm4_4
  int v82; // eax
  float v83; // xmm1_4
  float v84; // xmm0_4
  float v85; // xmm7_4
  float v86; // xmm7_4
  float v87; // xmm6_4
  float v88; // xmm6_4
  float v89; // xmm0_4
  float v90; // xmm0_4
  float v91; // xmm6_4
  float v92; // xmm2_4
  float v93; // xmm6_4
  float v94; // xmm1_4
  float v95; // xmm11_4
  float v96; // xmm0_4
  float v97; // xmm0_4
  float v98; // xmm6_4
  double v99; // xmm1_8
  float v100; // xmm0_4
  float v101; // xmm7_4
  float v102; // xmm7_4
  float v103; // xmm8_4
  float v104; // xmm0_4
  float v105; // xmm8_4
  float v106; // xmm0_4
  float v107; // xmm8_4
  float v108; // xmm7_4
  float v109; // xmm0_4
  float v110; // xmm7_4
  float v111; // xmm0_4
  float v112; // xmm6_4
  float v113; // xmm7_4
  float v114; // xmm6_4
  float v115; // xmm4_4
  float v116; // xmm3_4
  float v117; // xmm6_4
  float v118; // xmm4_4
  float v119; // xmm2_4
  float v120; // xmm3_4
  float v121; // xmm4_4
  int v122; // xmm0_4
  float v123; // xmm0_4
  float v124; // xmm1_4
  float v125; // xmm8_4
  float v126; // xmm5_4
  float v127; // xmm7_4
  float v128; // xmm4_4
  float v129; // xmm7_4
  float v130; // xmm6_4
  float v131; // xmm2_4
  float v132; // xmm3_4
  float v133; // xmm4_4
  float v134; // xmm3_4
  float v135; // xmm5_4
  float v136; // xmm7_4
  float v137; // xmm4_4
  float v138; // xmm0_4
  float v139; // xmm3_4
  float v140; // xmm5_4
  float v141; // xmm2_4
  float v142; // xmm3_4
  float v143; // xmm3_4
  float v144; // xmm0_4
  float v145; // xmm0_4
  float v146; // xmm1_4
  float v147; // xmm8_4
  float v148; // xmm5_4
  float v149; // xmm6_4
  float v150; // xmm4_4
  float v151; // xmm6_4
  float v152; // xmm7_4
  float v153; // xmm0_4
  float v154; // xmm2_4
  float v155; // xmm4_4
  float v156; // xmm3_4
  float v157; // xmm5_4
  float v158; // xmm6_4
  float v159; // xmm4_4
  float v160; // xmm0_4
  float v161; // xmm3_4
  float v162; // xmm5_4
  float v163; // xmm2_4
  float v164; // xmm3_4
  float v165; // xmm3_4
  float v166; // xmm0_4
  float v167; // xmm0_4
  float v168; // xmm8_4
  float v169; // xmm8_4
  float v170; // xmm7_4
  int v171; // xmm1_4
  int v172; // xmm2_4
  int v173; // xmm0_4
  float v174; // xmm4_4
  float v175; // xmm5_4
  float v176; // xmm7_4
  float v177; // xmm4_4
  float v178; // xmm2_4
  float v179; // xmm3_4
  float v180; // xmm7_4
  float v181; // xmm6_4
  float v182; // xmm5_4
  float v183; // xmm0_4
  float v184; // xmm3_4
  float v185; // xmm6_4
  float v186; // xmm3_4
  int v187; // xmm0_4
  float v188; // xmm2_4
  int v189; // xmm0_4
  float v190; // xmm4_4
  float v191; // xmm2_4
  float v192; // xmm3_4
  float v193; // xmm0_4
  float v194; // xmm3_4
  float v195; // xmm4_4
  float v196; // xmm1_4
  float v197; // xmm1_4
  float v198; // xmm1_4
  float v199; // xmm0_4
  float v200; // xmm4_4
  float v201; // xmm0_4
  double v202; // xmm0_8
  float v203; // xmm1_4
  float v204; // xmm0_4
  float v205; // xmm1_4
  float v206; // xmm0_4
  float v207; // xmm1_4
  float v208; // xmm0_4
  float v209; // xmm3_4
  float v210; // xmm2_4
  float v211; // xmm3_4
  float v212; // xmm0_4
  float v213; // xmm3_4
  float v214; // xmm1_4
  float v215; // xmm0_4
  float v216; // xmm0_4
  float v217; // xmm7_4
  float v218; // xmm7_4
  float v219; // xmm1_4
  float v220; // xmm0_4
  float v221; // xmm7_4
  float v222; // xmm4_4
  float v223; // xmm5_4
  float v224; // xmm6_4
  float v225; // xmm0_4
  float v226; // xmm3_4
  __m128 v227; // xmm9
  float v228; // xmm7_4
  float v229; // xmm8_4
  float v230; // xmm0_4
  float v231; // xmm6_4
  float v232; // xmm6_4
  float v233; // xmm2_4
  float v234; // xmm1_4
  int v235; // ecx
  float v236; // xmm9_4
  float v237; // xmm6_4
  float v238; // xmm4_4
  float v239; // xmm3_4
  float v240; // xmm8_4
  float v241; // xmm8_4
  float v242; // xmm1_4
  float v243; // xmm9_4
  float v244; // xmm0_4
  float v245; // xmm6_4
  float v246; // xmm6_4
  float v247; // xmm3_4
  float v248; // xmm1_4
  float v249; // xmm5_4
  float v250; // xmm5_4
  float v251; // xmm2_4
  float v252; // xmm1_4
  float v253; // xmm0_4
  float v254; // xmm5_4
  float v255; // xmm5_4
  float v256; // xmm5_4
  float v257; // xmm3_4
  float v258; // xmm4_4
  float v259; // xmm1_4
  float v260; // xmm3_4
  float v261; // xmm4_4
  float v262; // xmm3_4
  float v263; // xmm5_4
  float v264; // xmm2_4
  float v265; // xmm5_4
  float v266; // xmm4_4
  float v267; // xmm2_4
  float v268; // xmm5_4
  float v269; // xmm0_4
  float v270; // xmm5_4
  float v271; // xmm5_4
  float v272; // xmm5_4
  float v273; // xmm5_4
  float v274; // xmm1_4
  float v275; // xmm3_4
  float v276; // xmm4_4
  float v277; // xmm1_4
  float v278; // xmm3_4
  float v279; // xmm4_4
  float v280; // xmm3_4
  float v281; // xmm5_4
  float v282; // xmm2_4
  float v283; // xmm5_4
  float v284; // xmm1_4
  float v285; // xmm4_4
  float v286; // xmm2_4
  float v287; // xmm5_4
  float v288; // xmm0_4
  float v289; // xmm5_4
  float v290; // xmm5_4
  float v291; // xmm5_4
  float v292; // xmm5_4
  float v293; // xmm1_4
  float v294; // xmm3_4
  float v295; // xmm4_4
  float v296; // xmm1_4
  float v297; // xmm3_4
  float v298; // xmm4_4
  float v299; // xmm3_4
  float v300; // xmm5_4
  float v301; // xmm2_4
  float v302; // xmm5_4
  float v303; // xmm3_4
  float v304; // xmm1_4
  float v305; // xmm5_4
  float v306; // xmm0_4
  float v307; // xmm5_4
  float v308; // xmm5_4
  float v309; // xmm5_4
  float v310; // xmm5_4
  float v311; // xmm3_4
  float v312; // xmm4_4
  float v313; // xmm1_4
  float v314; // xmm3_4
  float v315; // xmm4_4
  float v316; // xmm3_4
  float v317; // xmm5_4
  float v318; // xmm2_4
  float v319; // xmm5_4
  float v320; // xmm8_4
  float v321; // xmm3_4
  float v322; // xmm4_4
  float v323; // xmm5_4
  float v324; // xmm5_4
  float v325; // xmm0_4
  float v326; // xmm4_4
  int v327; // xmm0_4
  float v328; // xmm2_4
  float v329; // xmm0_4
  float v330; // xmm2_4
  float v331; // xmm2_4
  float v332; // xmm1_4
  float v333; // xmm3_4
  double v334; // xmm0_8
  float v335; // xmm0_4
  float v336; // xmm1_4
  float v337; // xmm2_4
  float v338; // xmm3_4
  double v339; // xmm0_8
  float v340; // xmm0_4
  float v341; // xmm5_4
  float v342; // xmm6_4
  float v343; // xmm4_4
  float v344; // xmm3_4
  float v345; // xmm4_4
  float v346; // xmm2_4
  float v347; // xmm0_4
  float v348; // xmm7_4
  float v349; // xmm6_4
  float v350; // xmm3_4
  int v351; // xmm0_4
  int v352; // xmm1_4
  float v353; // xmm4_4
  float v354; // xmm2_4
  float v355; // xmm3_4
  float v356; // xmm1_4
  float v357; // xmm6_4
  float v358; // xmm4_4
  float v359; // xmm3_4
  float v360; // xmm1_4
  float v361; // xmm6_4
  float v362; // xmm1_4
  float v363; // xmm7_4
  double v364; // xmm0_8
  float v365; // xmm4_4
  float v366; // xmm5_4
  float v367; // xmm5_4
  float v368; // xmm6_4
  float v369; // xmm2_4
  float v370; // xmm3_4
  float v371; // xmm4_4
  float v372; // xmm0_4
  float v373; // xmm1_4
  float v374; // xmm4_4
  float v375; // xmm2_4
  float v376; // xmm6_4
  float v377; // xmm5_4
  float v378; // xmm4_4
  double v379; // xmm0_8
  float v380; // xmm3_4
  float v381; // xmm3_4
  float v382; // xmm1_4
  float v383; // xmm2_4
  float v384; // xmm2_4
  double v385; // xmm12_8
  double v386; // xmm2_8
  double *v387; // rax
  double v388; // xmm4_8
  double v389; // xmm8_8
  double v390; // xmm10_8
  float v391; // xmm3_4
  float v392; // xmm5_4
  int v393; // xmm0_4
  int v394; // xmm1_4
  float v395; // xmm5_4
  float v396; // xmm3_4
  float v397; // xmm0_4
  float v398; // xmm2_4
  float v399; // xmm5_4
  double v400; // xmm0_8
  float v401; // xmm6_4
  int v402; // xmm1_4
  float v403; // xmm6_4
  float v404; // xmm7_4
  double v405; // xmm0_8
  float v406; // xmm5_4
  float v407; // xmm5_4
  float v408; // xmm5_4
  float v409; // xmm0_4
  float v410; // xmm3_4
  float v411; // xmm4_4
  float v412; // xmm0_4
  float v413; // xmm6_4
  float v414; // xmm8_4
  float v415; // xmm6_4
  double v416; // xmm0_8
  float v417; // xmm4_4
  float v418; // xmm0_4
  float v419; // xmm7_4
  float v420; // xmm4_4
  float v421; // xmm4_4
  float v422; // xmm4_4
  float v423; // xmm7_4
  float v424; // xmm9_4
  double v425; // xmm0_8
  float v426; // xmm7_4
  float v427; // xmm8_4
  float v428; // xmm8_4
  float v429; // xmm8_4
  float v430; // xmm6_4
  int v431; // xmm5_4
  float v432; // xmm6_4
  float v433; // xmm7_4
  double v434; // xmm0_8
  float v435; // xmm5_4
  float v436; // xmm5_4
  float v437; // xmm5_4
  float v438; // xmm0_4
  float v439; // xmm3_4
  float v440; // xmm4_4
  float v441; // xmm0_4
  float v442; // xmm6_4
  float v443; // xmm8_4
  float v444; // xmm6_4
  double v445; // xmm0_8
  float v446; // xmm4_4
  float v447; // xmm0_4
  float v448; // xmm7_4
  float v449; // xmm4_4
  float v450; // xmm4_4
  float v451; // xmm4_4
  float v452; // xmm7_4
  float v453; // xmm9_4
  double v454; // xmm0_8
  float v455; // xmm7_4
  float v456; // xmm8_4
  float v457; // xmm8_4
  float v458; // xmm8_4
  float v459; // xmm6_4
  int v460; // xmm5_4
  float v461; // xmm6_4
  float v462; // xmm7_4
  double v463; // xmm0_8
  float v464; // xmm5_4
  float v465; // xmm5_4
  float v466; // xmm5_4
  float v467; // xmm0_4
  float v468; // xmm3_4
  float v469; // xmm4_4
  float v470; // xmm0_4
  float v471; // xmm6_4
  float v472; // xmm8_4
  float v473; // xmm6_4
  double v474; // xmm0_8
  float v475; // xmm4_4
  float v476; // xmm0_4
  float v477; // xmm7_4
  float v478; // xmm4_4
  float v479; // xmm4_4
  float v480; // xmm4_4
  float v481; // xmm7_4
  float v482; // xmm9_4
  double v483; // xmm0_8
  float v484; // xmm7_4
  float v485; // xmm8_4
  float v486; // xmm8_4
  float v487; // xmm8_4
  float v488; // xmm6_4
  int v489; // xmm5_4
  float v490; // xmm6_4
  float v491; // xmm7_4
  double v492; // xmm0_8
  float v493; // xmm5_4
  float v494; // xmm5_4
  float v495; // xmm5_4
  float v496; // xmm0_4
  float v497; // xmm3_4
  float v498; // xmm4_4
  float v499; // xmm0_4
  float v500; // xmm6_4
  float v501; // xmm8_4
  float v502; // xmm6_4
  double v503; // xmm0_8
  float v504; // xmm4_4
  float v505; // xmm0_4
  float v506; // xmm7_4
  float v507; // xmm4_4
  float v508; // xmm4_4
  float v509; // xmm4_4
  float v510; // xmm7_4
  float v511; // xmm8_4
  float v512; // xmm0_4
  float v513; // xmm7_4
  float v514; // xmm0_4
  float v515; // xmm15_4
  int v516; // xmm5_4
  int v517; // xmm6_4
  float v518; // xmm2_4
  float v519; // xmm5_4
  float v520; // xmm2_4
  float v521; // xmm4_4
  float v522; // xmm5_4
  float v523; // xmm1_4
  float v524; // xmm5_4
  float v525; // xmm3_4
  float v526; // xmm4_4
  __int64 result; // rax
  int v528; // [rsp+D0h] [rbp+8h]
  float v529; // [rsp+E0h] [rbp+18h]

  v2 = *(float *)(a1 + 73904);
  v528 = 0;
  if ( *(float *)(a1 + 101728) == 1.0 )
  {
    v528 = *(_DWORD *)(a1 + 73904);
    v2 = 0.0;
    *(_DWORD *)(a1 + 73904) = 0;
  }
  v5 = *(float *)(a1 + 84336);
  v6 = *(float *)(a1 + 84272);
  v7 = *(float *)(a1 + 84304);
  *(float *)(a1 + 84352) = v5;
  *(float *)(a1 + 84288) = v6;
  *(float *)(a1 + 84320) = v7;
  v8 = (int)(float)(v5 * -16777216.0);
  if ( !v8 )
  {
    v9 = 1;
    goto LABEL_11;
  }
  v10 = v8 & 0x200000;
  if ( (v8 & 0x800000) != 0 )
  {
    if ( !v10 )
    {
      v9 = 2 * v8;
      goto LABEL_11;
    }
  }
  else if ( v10 )
  {
    v9 = 2 * v8;
    goto LABEL_11;
  }
  v9 = 2 * v8 + 1;
LABEL_11:
  v11 = *(float *)(a1 + 73792);
  v12 = *(float *)(a1 + 73760);
  v13 = v9 & 0xFFFFFF;
  v14 = *(float *)(a1 + 73952);
  v15 = v9;
  v16 = *(float *)(a1 + 73968);
  v17 = v9 | 0xFF000000;
  v18 = v6 * v7;
  *(_DWORD *)(a1 + 74016) = 0;
  *(float *)(a1 + 73808) = v11;
  v19 = 0.0;
  if ( (v15 & 0x1000000) == 0 )
    v17 = v13;
  *(float *)(a1 + 73776) = v12;
  *(_DWORD *)(a1 + 84384) = *(_DWORD *)(a1 + 84368);
  *(_DWORD *)(a1 + 74096) = *(_DWORD *)(a1 + 74080);
  *(float *)(a1 + 73936) = v2;
  v20 = (float)v17 * 0.000000059604645;
  *(float *)(a1 + 73984) = v14;
  *(float *)(a1 + 74000) = v16;
  *(float *)(a1 + 84336) = v20;
  v21 = (float)(v20 * *(float *)(a1 + 84400)) + *(float *)(a1 + 84416);
  *(float *)(a1 + 84368) = v21;
  v22 = v18 - (float)(v7 * v21);
  v23 = *(float *)(a1 + 73856);
  *(float *)(a1 + 73872) = v23;
  v24 = v22 + v21;
  v25 = *(float *)(a1 + 73824);
  v26 = v23 * v25;
  *(float *)(a1 + 73840) = v25;
  *(float *)(a1 + 84432) = v24;
  v27 = *(float *)(a1 + 73888);
  *(float *)(a1 + 73920) = v27;
  *(float *)(a1 + 74032) = v26;
  v28 = (float)((float)(v12 * v26) - (float)(v26 * v27)) + v27;
  v29 = (float)((float)(v11 * v26) - (float)(v2 * v26)) + v2;
  *(float *)(a1 + 74048) = v28;
  *(float *)(a1 + 74064) = v29;
  v30 = v29;
  v31 = v29 + *(float *)(a1 + 74128);
  if ( v31 < 0.0 )
    v32 = v31;
  else
    v32 = 0.0;
  v33 = -1.0;
  if ( v30 == 0.0 )
    v34 = -1.0;
  else
    v34 = v32;
  *(float *)(a1 + 74080) = v34;
  if ( v34 >= 0.0 )
  {
    if ( v34 > 0.0 )
      v34 = 1.0;
  }
  else
  {
    v34 = -1.0;
  }
  v35 = *(float *)(a1 + 74192);
  v36 = v34 + 1.0;
  v37 = *(float *)(a1 + 74352);
  v38 = *(float *)(a1 + 74208);
  v39 = *(_DWORD *)(a1 + 74144);
  v40 = *(float *)(a1 + 74288);
  v41 = v38 + *(float *)(a1 + 74368);
  v42 = 1.0;
  *(float *)(a1 + 74112) = v36;
  *(float *)(a1 + 74144) = v36;
  *(_DWORD *)(a1 + 74160) = v39;
  *(float *)(a1 + 74304) = v40;
  v43 = (float)(v36 * v35) - v35;
  v44 = *(float *)(a1 + 74400);
  v45 = (float)(v43 + 1.0) * *(float *)(a1 + 74176);
  v46 = (float)(*(float *)(a1 + 74256) / (float)((float)(v37 * v38) + *(float *)(a1 + 74384))) * v37;
  v47 = *(float *)(a1 + 74240);
  *(float *)(a1 + 74320) = v45;
  v48 = v47 - v46;
  v49 = *(float *)(a1 + 74272);
  v50 = (float)(v48 + v28) - v40;
  *(float *)(a1 + 74240) = v50;
  v51 = v50 * v41;
  *(float *)(a1 + 74256) = v51;
  v52 = v51 + v40;
  if ( (float)(v44 - fabs(v40 - v28)) < 0.0 )
  {
    v53 = 0.0;
LABEL_25:
    v54 = v53;
    goto LABEL_26;
  }
  v53 = v49 + *(float *)(a1 + 74416);
  if ( v53 < 1.0 )
    goto LABEL_25;
  v54 = 1.0;
LABEL_26:
  v55 = v54;
  *(float *)(a1 + 74272) = v55;
  v56 = (float)((float)(v55 * v28) - (float)(v55 * v52)) + v52;
  if ( v45 == 0.0 )
    v56 = v28;
  v57 = v16 * *(float *)(a1 + 74448);
  *(_DWORD *)(a1 + 74480) = *(_DWORD *)(a1 + 74464);
  v58 = *(float *)(a1 + 74752);
  v59 = *(float *)(a1 + 74496);
  v60 = *(_DWORD *)(a1 + 74592);
  v61 = v57 + (float)(v14 * *(float *)(a1 + 74432));
  v62 = *(_DWORD *)(a1 + 74560);
  v63 = (int)v58;
  *(float *)(a1 + 74464) = v61;
  v64 = *(float *)(a1 + 74528);
  *(float *)(a1 + 74288) = v56;
  *(float *)(a1 + 74336) = v56;
  v65 = *(float *)(a1 + 74688);
  *(float *)(a1 + 74544) = v64;
  *(float *)(a1 + 74512) = v59;
  *(_DWORD *)(a1 + 74576) = v62;
  *(_DWORD *)(a1 + 74608) = v60;
  *(float *)(a1 + 74704) = v65;
  if ( (int)v58 < -32 )
  {
    v59 = v59 * 2.3283064e-10;
    goto LABEL_38;
  }
  if ( v63 > 32 )
  {
    v63 = 32;
LABEL_37:
    v59 = v59 * dword_7FF91E5EAD3C[v63];
    goto LABEL_38;
  }
  if ( v63 < 0 )
  {
    v59 = v59 * dword_7FF91E5EACC0[~v63];
    goto LABEL_38;
  }
  if ( v63 > 0 )
    goto LABEL_37;
LABEL_38:
  v66 = (int)(float)-v58;
  if ( v66 < -32 )
  {
    v59 = v59 * 2.3283064e-10;
    goto LABEL_46;
  }
  if ( v66 > 32 )
  {
    v66 = 32;
LABEL_45:
    v59 = v59 * dword_7FF91E5EAD3C[v66];
    goto LABEL_46;
  }
  if ( v66 < 0 )
  {
    v59 = v59 * dword_7FF91E5EACC0[~v66];
    goto LABEL_46;
  }
  if ( v66 > 0 )
    goto LABEL_45;
LABEL_46:
  v67 = *(float *)(a1 + 74624);
  v68 = (float)((float)(v59 - v65) * *(float *)(a1 + 74736)) + v65;
  v69 = *(float *)(a1 + 74672);
  *(float *)(a1 + 74688) = v68;
  v70 = (float)((float)(v68 * v67) - (float)(v67 * v69)) + v69;
  if ( v70 <= 0.0 )
    v71 = 0.0;
  else
    v71 = v70;
  v72 = v71;
  if ( v72 < 1.0 )
    v73 = v72;
  else
    v73 = 1.0;
  v74 = *(float *)(a1 + 74640);
  v75 = expf((float)v73 * *(float *)(a1 + 74784)) * *(float *)(a1 + 74768);
  v76 = v74 * *(float *)(a1 + 74656);
  *(_DWORD *)(a1 + 75168) = *(_DWORD *)(a1 + 75152);
  v77 = v75 + *(float *)(a1 + 74800);
  v78 = *(float *)(a1 + 75088);
  v79 = v64 * *(float *)(a1 + 75488);
  *(_DWORD *)(a1 + 75200) = *(_DWORD *)(a1 + 75184);
  v80 = *(float *)(a1 + 75072);
  v81 = *(float *)(a1 + 75120);
  *(_DWORD *)(a1 + 75232) = *(_DWORD *)(a1 + 75216);
  v82 = *(_DWORD *)(a1 + 84432);
  *(float *)(a1 + 75104) = v78;
  *(float *)(a1 + 75088) = v80;
  *(float *)(a1 + 75136) = v81;
  *(_DWORD *)(a1 + 75024) = v62;
  *(_DWORD *)(a1 + 75040) = v60;
  *(_DWORD *)(a1 + 75008) = v82;
  v83 = (float)(v76 - (float)(v74 * v77)) + v77;
  v84 = *(float *)(a1 + 75440);
  v85 = v79 + v84;
  *(float *)(a1 + 75424) = v84;
  *(float *)(a1 + 74720) = v83;
  if ( v85 >= -1.0 )
    v86 = fminf(v85, 1.0);
  else
    v86 = -1.0;
  v87 = *(float *)(a1 + 75712);
  *(float *)(a1 + 75072) = v86;
  v88 = fminf(v87, v83 * 0.000015258789);
  v89 = (float)((float)(1.0 - v78) * *(float *)(a1 + 75504)) + v78;
  if ( v89 >= -1.0 )
    v90 = fminf(v89, 1.0);
  else
    v90 = -1.0;
  v91 = v88 * *(float *)(a1 + 75728);
  v92 = v80 - v86;
  *(float *)(a1 + 75248) = v91;
  v93 = v91 + v81;
  if ( v92 < 0.0 )
    v90 = 0.0;
  v94 = *(float *)(a1 + 75456);
  v95 = *(float *)(a1 + 75008);
  *(float *)(a1 + 75088) = v90;
  v96 = v90 + *(float *)(a1 + 75856);
  if ( v92 >= 0.0 )
    v94 = 1.0;
  v97 = v96 * *(float *)(a1 + 75840);
  v98 = (float)(v93 * v94) * *(float *)(a1 + 75472);
  if ( v97 <= 0.0 )
    v99 = 0.0;
  else
    v99 = v97;
  v100 = v99;
  v101 = (float)((float)(v95 - *(float *)(a1 + 75168)) * *(float *)(a1 + 76048)) + *(float *)(a1 + 75168);
  *(float *)(a1 + 75152) = v101;
  *(float *)(a1 + 75056) = v100;
  v529 = *(float *)(a1 + 75136);
  v102 = (float)((float)((float)(v101 * *(float *)(a1 + 76032)) * *(float *)(a1 + 75648))
               - (float)(v95 * *(float *)(a1 + 75648)))
       + v95;
  if ( v98 <= 1.0 )
  {
    if ( v98 < -1.0 )
      v98 = fmodf(v98 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v98 = fmodf(v98 + 1.0, 2.0) - 1.0;
  }
  v103 = *(float *)(a1 + 75200);
  *(float *)(a1 + 75120) = v98;
  v104 = v98 + *(float *)(a1 + 75872);
  *(float *)(a1 + 74992) = v102 * *(float *)(a1 + 76016);
  if ( v529 < 0.0 && v98 > 0.0 )
    v103 = v95;
  if ( v104 <= 1.0 )
  {
    if ( v104 < -1.0 )
      v104 = fmodf(v104 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v104 = fmodf(v104 + 1.0, 2.0) - 1.0;
  }
  *(float *)(a1 + 75184) = v103;
  v105 = v103 * *(float *)(a1 + 76000);
  v106 = (float)(v104 * *(float *)(a1 + 75936)) + *(float *)(a1 + 76064);
  *(float *)(a1 + 75264) = v106;
  *(float *)(a1 + 75344) = v105;
  v107 = v98 + *(float *)(a1 + 75904);
  *(float *)(a1 + 75280) = -v106;
  if ( v107 <= 1.0 )
  {
    if ( v107 < -1.0 )
      fmodf(v107 - 1.0, 2.0);
  }
  else
  {
    fmodf(v107 + 1.0, 2.0);
  }
  v108 = v98 + *(float *)(a1 + 75888);
  if ( v108 <= 1.0 )
  {
    if ( v108 < -1.0 )
      v108 = fmodf(v108 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v108 = fmodf(v108 + 1.0, 2.0) - 1.0;
  }
  v109 = sub_7FF91DFC8FC0();
  v110 = v108 + *(float *)(a1 + 76080);
  v111 = v109 * *(float *)(a1 + 75968);
  if ( v110 >= 0.0 )
  {
    if ( v110 > 0.0 )
      v110 = 1.0;
  }
  else
  {
    v110 = -1.0;
  }
  v112 = v98 + *(float *)(a1 + 75920);
  *(float *)(a1 + 75312) = v111;
  *(float *)(a1 + 75408) = v110;
  v113 = (float)(v110 * *(float *)(a1 + 75952)) + *(float *)(a1 + 76096);
  if ( v112 <= 1.0 )
  {
    if ( v112 < -1.0 )
      v112 = fmodf(v112 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v112 = fmodf(v112 + 1.0, 2.0) - 1.0;
  }
  v114 = fabs(v112);
  *(float *)(a1 + 75296) = v113;
  v115 = *(float *)(a1 + 75552);
  v116 = (float)((float)(*(float *)(a1 + 75616) * *(float *)(a1 + 75344))
               + (float)(*(float *)(a1 + 75584) * *(float *)(a1 + 75264)))
       + (float)(*(float *)(a1 + 75600) * *(float *)(a1 + 75280));
  v117 = (float)((float)((float)((float)(v114 * (float)((float)(v114 * v114) * v114)) * *(float *)(a1 + 75808))
                       + (float)((float)((float)((float)(v114 * v114) * v114) * *(float *)(a1 + 75792))
                               + (float)((float)((float)(v114 * *(float *)(a1 + 75760)) + *(float *)(a1 + 75744))
                                       + (float)((float)(v114 * v114) * *(float *)(a1 + 75776)))))
               + *(float *)(a1 + 75824))
       * *(float *)(a1 + 75984);
  *(float *)(a1 + 75328) = v117;
  v118 = (float)(v115 * *(float *)(a1 + 75312)) + v116;
  v119 = *(float *)(a1 + 75664);
  v120 = (float)((float)(*(float *)(a1 + 75520) * *(float *)(a1 + 75056)) - *(float *)(a1 + 75520)) + 1.0;
  v121 = (float)((float)(v118 + (float)(*(float *)(a1 + 75568) * *(float *)(a1 + 75296)))
               + (float)(v117 * *(float *)(a1 + 75536)))
       + (float)(*(float *)(a1 + 75632) * *(float *)(a1 + 74992));
  *(float *)(a1 + 75360) = v120;
  *(float *)(a1 + 75392) = v121;
  *(float *)(a1 + 75376) = (float)((float)(*(float *)(a1 + 75680) * *(float *)(a1 + 75024))
                                 + (float)(*(float *)(a1 + 75696) * *(float *)(a1 + 75040)))
                         + (float)((float)(v119 * v120) * v121);
  v122 = *(_DWORD *)(a1 + 75392);
  *(_DWORD *)(a1 + 76112) = *(_DWORD *)(a1 + 75408);
  *(_DWORD *)(a1 + 76128) = v122;
  if ( *(float *)(a1 + 75408) <= 0.0 )
    v123 = 0.0;
  else
    v123 = 1.0;
  if ( *(float *)(a1 + 76144) == 0.0 )
    v123 = 1.0;
  v124 = *(float *)(a1 + 74144) * v123;
  *(float *)(a1 + 76160) = v124;
  *(_DWORD *)(a1 + 76192) = *(_DWORD *)(a1 + 76176);
  *(_DWORD *)(a1 + 76240) = *(_DWORD *)(a1 + 76224);
  *(_DWORD *)(a1 + 76224) = *(_DWORD *)(a1 + 76208);
  *(_DWORD *)(a1 + 76272) = *(_DWORD *)(a1 + 76256);
  *(_DWORD *)(a1 + 76320) = *(_DWORD *)(a1 + 76304);
  if ( (float)(v124 + *(float *)(a1 + 76448)) >= 0.0 )
    v125 = 0.0;
  else
    v125 = 1.0;
  v126 = 1.0 - v125;
  v127 = (float)(1.0 - v125)
       * (float)((float)(*(float *)(a1 + 76480) * *(float *)(a1 + 76240)) + *(float *)(a1 + 76192));
  *(float *)(a1 + 76208) = v127;
  v128 = v127 + *(float *)(a1 + 76464);
  v129 = v127 - *(float *)(a1 + 76224);
  *(float *)(a1 + 76288) = (float)((float)(*(float *)(a1 + 76432) * *(float *)(a1 + 76544))
                                 - (float)(*(float *)(a1 + 76512) * *(float *)(a1 + 76432)))
                         + *(float *)(a1 + 76512);
  if ( v128 < 0.0 )
    v130 = 0.0;
  else
    v130 = 1.0;
  if ( v129 < 0.0 )
    v130 = 1.0 - v125;
  v131 = *(float *)(a1 + 76368);
  v132 = v126 * (float)(*(float *)(a1 + 76384) * *(float *)(a1 + 76512));
  *(float *)(a1 + 76224) = v130;
  v133 = *(float *)(a1 + 76272);
  v134 = (float)(v132 - (float)(*(float *)(a1 + 76528) * v126)) + *(float *)(a1 + 76528);
  v135 = v126 * (float)(1.0 - v130);
  v136 = (float)((float)(*(float *)(a1 + 76400) * 0.00390625) * v130) + (float)((float)(v131 * 0.00390625) * v135);
  if ( (float)(v134 - v133) > 0.0 )
    v134 = v133 + *(float *)(a1 + 76288);
  v137 = *(float *)(a1 + 76192);
  v138 = fminf(*(float *)(a1 + 76512), v134);
  *(float *)(a1 + 76256) = v138;
  v139 = *(float *)(a1 + 76416);
  v140 = (float)((float)(v135 * *(float *)(a1 + 76496)) + (float)(v130 * v138)) - v137;
  v141 = (float)((float)(*(float *)(a1 + 76560) * v136) - (float)(*(float *)(a1 + 76560) * *(float *)(a1 + 76320)))
       + *(float *)(a1 + 76320);
  *(float *)(a1 + 76304) = v141;
  v142 = (float)((float)((float)((float)((float)(v139 * 0.00390625) * v125) - (float)(v125 * v141)) + v141) * v140)
       + v137;
  *(float *)(a1 + 76176) = v142;
  v143 = (float)(v142 * *(float *)(a1 + 76576)) * *(float *)(a1 + 76592);
  v144 = v143 * *(float *)(a1 + 76608);
  *(float *)(a1 + 76336) = v143;
  *(float *)(a1 + 76352) = v144;
  if ( *(float *)(a1 + 75408) <= 0.0 )
    v145 = 0.0;
  else
    v145 = 1.0;
  if ( *(float *)(a1 + 76624) == 0.0 )
    v145 = 1.0;
  v146 = *(float *)(a1 + 74144) * v145;
  *(float *)(a1 + 76640) = v146;
  *(_DWORD *)(a1 + 76672) = *(_DWORD *)(a1 + 76656);
  *(_DWORD *)(a1 + 76720) = *(_DWORD *)(a1 + 76704);
  *(_DWORD *)(a1 + 76704) = *(_DWORD *)(a1 + 76688);
  *(_DWORD *)(a1 + 76752) = *(_DWORD *)(a1 + 76736);
  *(_DWORD *)(a1 + 76800) = *(_DWORD *)(a1 + 76784);
  if ( (float)(v146 + *(float *)(a1 + 76928)) >= 0.0 )
    v147 = 0.0;
  else
    v147 = 1.0;
  v148 = 1.0 - v147;
  v149 = (float)(1.0 - v147)
       * (float)((float)(*(float *)(a1 + 76960) * *(float *)(a1 + 76720)) + *(float *)(a1 + 76672));
  *(float *)(a1 + 76688) = v149;
  v150 = v149 + *(float *)(a1 + 76944);
  v151 = v149 - *(float *)(a1 + 76704);
  *(float *)(a1 + 76768) = (float)((float)(*(float *)(a1 + 76912) * *(float *)(a1 + 77024))
                                 - (float)(*(float *)(a1 + 76992) * *(float *)(a1 + 76912)))
                         + *(float *)(a1 + 76992);
  if ( v150 < 0.0 )
    v152 = 0.0;
  else
    v152 = 1.0;
  if ( v151 < 0.0 )
    v152 = 1.0 - v147;
  v153 = *(float *)(a1 + 76864) * *(float *)(a1 + 76992);
  v154 = *(float *)(a1 + 76848);
  *(float *)(a1 + 76704) = v152;
  v155 = *(float *)(a1 + 76752);
  v156 = (float)((float)(v148 * v153) - (float)(*(float *)(a1 + 77008) * v148)) + *(float *)(a1 + 77008);
  v157 = v148 * (float)(1.0 - v152);
  v158 = (float)((float)(*(float *)(a1 + 76880) * 0.00390625) * v152) + (float)((float)(v154 * 0.00390625) * v157);
  if ( (float)(v156 - v155) > 0.0 )
    v156 = v155 + *(float *)(a1 + 76768);
  v159 = *(float *)(a1 + 76672);
  v160 = fminf(*(float *)(a1 + 76992), v156);
  *(float *)(a1 + 76736) = v160;
  v161 = (float)(*(float *)(a1 + 76896) * 0.00390625) * v147;
  v162 = (float)((float)(v157 * *(float *)(a1 + 76976)) + (float)(v152 * v160)) - v159;
  v163 = (float)((float)(*(float *)(a1 + 77040) * v158) - (float)(*(float *)(a1 + 77040) * *(float *)(a1 + 76800)))
       + *(float *)(a1 + 76800);
  *(float *)(a1 + 76784) = v163;
  v164 = (float)((float)((float)(v161 - (float)(v147 * v163)) + v163) * v162) + v159;
  *(float *)(a1 + 76656) = v164;
  v165 = (float)(v164 * *(float *)(a1 + 77056)) * *(float *)(a1 + 77072);
  v166 = v165 * *(float *)(a1 + 77088);
  *(float *)(a1 + 76816) = v165;
  *(float *)(a1 + 76832) = v166;
  *(_DWORD *)(a1 + 77120) = *(_DWORD *)(a1 + 77104);
  *(_DWORD *)(a1 + 77152) = *(_DWORD *)(a1 + 77136);
  v167 = *(float *)(a1 + 74336);
  v168 = *(float *)(a1 + 74464);
  *(_DWORD *)(a1 + 77216) = *(_DWORD *)(a1 + 77200);
  v169 = (float)(v168 * *(float *)(a1 + 77184)) + (float)(v167 * *(float *)(a1 + 77168));
  *(float *)(a1 + 77200) = v169;
  v170 = *(float *)(a1 + 75376);
  v171 = *(_DWORD *)(a1 + 76336);
  v172 = *(_DWORD *)(a1 + 76816);
  v173 = *(_DWORD *)(a1 + 74336);
  *(_DWORD *)(a1 + 77264) = *(_DWORD *)(a1 + 77136);
  *(_DWORD *)(a1 + 77280) = v173;
  v174 = *(float *)(a1 + 77600);
  *(_DWORD *)(a1 + 77232) = v171;
  *(_DWORD *)(a1 + 77248) = v172;
  v175 = *(float *)(a1 + 77568);
  v176 = v170 * v174;
  v177 = v174 * *(float *)(a1 + 75392);
  *(float *)(a1 + 77296) = v177;
  v178 = *(float *)(a1 + 77696);
  v179 = *(float *)(a1 + 77440);
  v180 = v176 * *(float *)(a1 + 77616);
  v181 = *(float *)(a1 + 77632);
  v182 = (float)(v175 * v177) * *(float *)(a1 + 77584);
  *(float *)(a1 + 77328) = v182;
  v183 = *(float *)(a1 + 77456);
  v184 = (float)((float)((float)(v179 * *(float *)(a1 + 77264)) - (float)(v178 * v179)) + v178) * *(float *)(a1 + 77712);
  *(float *)(a1 + 77344) = v184;
  v185 = (float)((float)(v181 * v180) + v182) + (float)(v183 * v184);
  v186 = *(float *)(a1 + 77296);
  v187 = *(_DWORD *)(a1 + 77424);
  *(float *)(a1 + 77360) = (float)((float)((float)((float)((float)((float)(*(float *)(a1 + 77664)
                                                                         * *(float *)(a1 + 77248))
                                                                 + (float)(*(float *)(a1 + 77648)
                                                                         * *(float *)(a1 + 77232)))
                                                         * *(float *)(a1 + 77680))
                                                 + v185)
                                         + v169)
                                 + *(float *)(a1 + 77536))
                         + *(float *)(a1 + 77552);
  *(_DWORD *)(a1 + 77376) = v187;
  v188 = (float)(*(float *)(a1 + 77328) + *(float *)(a1 + 77280)) + *(float *)(a1 + 77344);
  *(float *)(a1 + 77392) = (float)((float)((float)((float)((float)((float)(v186 * *(float *)(a1 + 77744))
                                                                 + *(float *)(a1 + 77760))
                                                         * *(float *)(a1 + 77472))
                                                 + (float)(*(float *)(a1 + 77488) * *(float *)(a1 + 77232)))
                                         + (float)(*(float *)(a1 + 77504) * *(float *)(a1 + 77248)))
                                 + *(float *)(a1 + 77520))
                         * *(float *)(a1 + 77728);
  *(float *)(a1 + 77408) = v188;
  v189 = *(_DWORD *)(a1 + 77792);
  *(_DWORD *)(a1 + 77824) = *(_DWORD *)(a1 + 77776);
  *(_DWORD *)(a1 + 77840) = v189;
  *(_DWORD *)(a1 + 77856) = *(_DWORD *)(a1 + 77808);
  v190 = *(float *)(a1 + 84432);
  *(_DWORD *)(a1 + 77904) = *(_DWORD *)(a1 + 77888);
  v191 = *(float *)(a1 + 77872);
  *(float *)(a1 + 77888) = v191;
  v192 = (float)(v191 * *(float *)(a1 + 77920)) + *(float *)(a1 + 77904);
  *(float *)(a1 + 77888) = v192;
  v193 = (float)(v191 * *(float *)(a1 + 77936)) + v192;
  v194 = v192 * *(float *)(a1 + 77984);
  v195 = v190 - v193;
  v196 = (float)(v195 * *(float *)(a1 + 77920)) + v191;
  *(float *)(a1 + 77872) = v196;
  *(float *)(a1 + 77904) = (float)((float)(v195 * *(float *)(a1 + 77952)) + v194)
                         + (float)(v196 * *(float *)(a1 + 77968));
  *(_DWORD *)(a1 + 80016) = *(_DWORD *)(a1 + 80000);
  v197 = *(float *)(a1 + 80032);
  *(float *)(a1 + 80048) = v197;
  v198 = v197 * *(float *)(a1 + 77120);
  v199 = *(float *)(a1 + 80016) * *(float *)(a1 + 77904);
  *(float *)(a1 + 80064) = v198;
  *(float *)(a1 + 80080) = v199;
  *(_DWORD *)(a1 + 80144) = *(_DWORD *)(a1 + 80128);
  *(float *)(a1 + 80128) = (float)(v199 * *(float *)(a1 + 80112)) + (float)(v198 * *(float *)(a1 + 80096));
  *(_DWORD *)(a1 + 80176) = *(_DWORD *)(a1 + 80160);
  *(_DWORD *)(a1 + 80208) = *(_DWORD *)(a1 + 80192);
  *(_DWORD *)(a1 + 80240) = *(_DWORD *)(a1 + 80224);
  *(_DWORD *)(a1 + 80272) = *(_DWORD *)(a1 + 80256);
  v200 = (float)((float)(*(float *)(a1 + 80304) * *(float *)(a1 + 80160))
               - (float)(*(float *)(a1 + 80320) * *(float *)(a1 + 80304)))
       + *(float *)(a1 + 80320);
  v201 = (float)((float)((float)((float)(v200 * v200) * v200) * v200) * *(float *)(a1 + 80400))
       + (float)((float)((float)((float)(v200 * v200) * v200) * *(float *)(a1 + 80384))
               + (float)((float)((float)(v200 * *(float *)(a1 + 80352)) + *(float *)(a1 + 80336))
                       + (float)((float)(v200 * v200) * *(float *)(a1 + 80368))));
  if ( v201 <= 0.0 )
    v202 = 0.0;
  else
    v202 = v201;
  v203 = v202;
  if ( v203 < 1.0 )
    v42 = v203;
  v204 = v42;
  *(float *)(a1 + 80288) = v204;
  *(_DWORD *)(a1 + 80432) = *(_DWORD *)(a1 + 80416);
  v205 = *(float *)(a1 + 80448);
  *(float *)(a1 + 80464) = v205;
  v206 = *(float *)(a1 + 80480);
  *(float *)(a1 + 80496) = v206;
  *(float *)(a1 + 80480) = (float)((float)(v205 - v206) * *(float *)(a1 + 80512)) + v206;
  v207 = *(float *)(a1 + 74336);
  v208 = *(float *)(a1 + 74464);
  *(_DWORD *)(a1 + 80576) = *(_DWORD *)(a1 + 80560);
  *(float *)(a1 + 80560) = (float)(v208 * *(float *)(a1 + 80544)) + (float)(v207 * *(float *)(a1 + 80528));
  *(_DWORD *)(a1 + 80624) = *(_DWORD *)(a1 + 80592);
  v209 = *(float *)(a1 + 80608);
  *(float *)(a1 + 80640) = v209;
  v210 = *(float *)(a1 + 76336)
       + (float)((float)(*(float *)(a1 + 80624) * *(float *)(a1 + 76816))
               - (float)(*(float *)(a1 + 80624) * *(float *)(a1 + 76336)));
  *(float *)(a1 + 80656) = (float)((float)(v209 * *(float *)(a1 + 80224)) - (float)(v209 * v210)) + v210;
  v211 = *(float *)(a1 + 75376);
  v212 = *(float *)(a1 + 80672);
  *(float *)(a1 + 80688) = v212;
  v213 = v211 - v212;
  v214 = (float)(v213 * *(float *)(a1 + 80704)) + v212;
  v215 = *(float *)(a1 + 80736);
  *(float *)(a1 + 80672) = v214;
  *(float *)(a1 + 80688) = (float)(v213 * *(float *)(a1 + 80720)) + (float)(v215 * v214);
  v216 = *(float *)(a1 + 80752);
  v217 = *(float *)(a1 + 75392);
  *(float *)(a1 + 80768) = v216;
  v218 = v217 - v216;
  v219 = (float)(v218 * *(float *)(a1 + 80784)) + v216;
  v220 = *(float *)(a1 + 80816);
  *(float *)(a1 + 80752) = v219;
  v221 = (float)(v218 * *(float *)(a1 + 80800)) + (float)(v220 * v219);
  *(float *)(a1 + 80768) = v221;
  v222 = *(float *)(a1 + 80688);
  v223 = *(float *)(a1 + 80656);
  v224 = *(float *)(a1 + 80560);
  v227 = (__m128)*(unsigned int *)(a1 + 80192);
  *(_DWORD *)(a1 + 80832) = *(_DWORD *)(a1 + 80480);
  *(_DWORD *)(a1 + 80848) = v227.m128_i32[0];
  v225 = *(float *)(a1 + 80880);
  v226 = *(float *)(a1 + 80896) * *(float *)(a1 + 80256);
  v227.m128_f32[0] = (float)((float)((float)((float)((float)(v227.m128_f32[0] * *(float *)(a1 + 80912))
                                                   - (float)(*(float *)(a1 + 81040) * *(float *)(a1 + 80912)))
                                           + *(float *)(a1 + 81040))
                                   * *(float *)(a1 + 81056))
                           + (float)((float)((float)(*(float *)(a1 + 81024) + *(float *)(a1 + 80832))
                                           * *(float *)(a1 + 81088))
                                   * *(float *)(a1 + 81008)))
                   + (float)((float)((float)((float)((float)((float)(v226
                                                                   - (float)(*(float *)(a1 + 80896)
                                                                           * (float)(v221 * v225)))
                                                           + (float)(v221 * v225))
                                                   * *(float *)(a1 + 80944))
                                           * *(float *)(a1 + 80960))
                                   + (float)((float)((float)(v226
                                                           - (float)(*(float *)(a1 + 80896) * (float)(v222 * v225)))
                                                   + (float)(v222 * v225))
                                           * *(float *)(a1 + 80928)))
                           + (float)((float)((float)(v224 + *(float *)(a1 + 81072)) * *(float *)(a1 + 80992))
                                   + (float)(v223 * *(float *)(a1 + 80976))));
  *(_DWORD *)(a1 + 80864) = v227.m128_i32[0];
  v228 = *(float *)(a1 + 80288);
  v229 = *(float *)(a1 + 80432);
  *(_DWORD *)(a1 + 81168) = *(_DWORD *)(a1 + 81152);
  v230 = *(float *)(a1 + 81136);
  *(float *)(a1 + 81152) = v230;
  if ( *(float *)(a1 + 81216) == 1.0 )
  {
    v231 = *(float *)(a1 + 81168)
         + (float)((float)(*(float *)(a1 + 81296) * v230) - (float)(*(float *)(a1 + 81296) * *(float *)(a1 + 81168)));
    *(float *)(a1 + 81152) = v231;
    v232 = (float)(v231 * *(float *)(a1 + 81280)) + *(float *)(a1 + 81184);
    *(float *)(a1 + 81136) = sub_7FF91DFC8D60();
    v233 = (float)(1.0 - v229) * *(float *)(a1 + 81312);
    *(float *)(a1 + 81120) = (float)(v229 * *(float *)(a1 + 81376)) + *(float *)(a1 + 81200);
    v227.m128_f32[0] = (float)(fmaxf(
                                 fminf(
                                   (float)((float)((float)((float)(v227.m128_f32[0] * *(float *)(a1 + 81264))
                                                         + (float)(v228 * *(float *)(a1 + 81232)))
                                                 + v232)
                                         + fminf(*(float *)(a1 + 81328), v233))
                                 + *(float *)(a1 + 81248),
                                   *(float *)(a1 + 81344)),
                                 *(float *)(a1 + 81360))
                             * *(float *)(a1 + 81408))
                     + *(float *)(a1 + 81424);
    v234 = v227.m128_f32[0];
    v235 = (int)v227.m128_f32[0];
    if ( (int)v227.m128_f32[0] != 0x80000000 && (float)v235 != v227.m128_f32[0] )
      v234 = (float)(v235 - (_mm_movemask_ps(_mm_unpacklo_ps(v227, v227)) & 1));
    v236 = v227.m128_f32[0] - v234;
    v237 = (float)(v236 * v236) * 0.25;
    v238 = (float)(expf(v234)
                 * (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v236 * *(float *)(a1 + 81616)) + *(float *)(a1 + 81600)) * v237) + (float)(v236 * *(float *)(a1 + 81584))) + *(float *)(a1 + 81568)) * v237) + (float)(v236 * *(float *)(a1 + 81552)))
                                                                                                 + *(float *)(a1 + 81536))
                                                                                         * v237)
                                                                                 + (float)(v236 * *(float *)(a1 + 81520)))
                                                                         + *(float *)(a1 + 81504))
                                                                 * v237)
                                                         + (float)(v236 * *(float *)(a1 + 81488)))
                                                 + *(float *)(a1 + 81472))
                                         * v237)
                                 + (float)(v236 * *(float *)(a1 + 81456)))
                         + 1.0))
         * *(float *)(a1 + 81440);
    v239 = v238 * v238;
    v240 = (float)((float)((float)((float)((float)((float)((float)((float)(v238 * v238) * *(float *)(a1 + 81776))
                                                         + *(float *)(a1 + 81744))
                                                 * (float)(v239 * v239))
                                         + (float)((float)((float)(v238 * v238) * *(float *)(a1 + 81712))
                                                 + *(float *)(a1 + 81680)))
                                 * (float)((float)((float)(v238 * v238) * v238) * (float)(v238 * v238)))
                         + (float)((float)((float)(v238 * v238) * v238) * *(float *)(a1 + 81648)))
                 + v238)
         / (float)((float)((float)((float)((float)((float)((float)((float)((float)(v238 * v238) * *(float *)(a1 + 81760))
                                                                 + *(float *)(a1 + 81728))
                                                         * (float)(v239 * v239))
                                                 + (float)((float)(v238 * v238) * *(float *)(a1 + 81696)))
                                         + *(float *)(a1 + 81664))
                                 * (float)(v239 * v239))
                         + (float)((float)(v238 * v238) * *(float *)(a1 + 81632)))
                 + 1.0);
    v241 = v240 / (float)(v240 + 1.0);
    *(float *)(a1 + 81104) = v241;
  }
  else
  {
    v241 = *(float *)(a1 + 81104);
  }
  v242 = *(float *)(a1 + 80128);
  v243 = *(float *)(a1 + 81120);
  *(_DWORD *)(a1 + 81904) = *(_DWORD *)(a1 + 81888);
  *(_DWORD *)(a1 + 81888) = *(_DWORD *)(a1 + 81872);
  *(_DWORD *)(a1 + 81872) = *(_DWORD *)(a1 + 81856);
  *(_DWORD *)(a1 + 81856) = *(_DWORD *)(a1 + 81840);
  *(_DWORD *)(a1 + 81840) = *(_DWORD *)(a1 + 81824);
  *(_DWORD *)(a1 + 81824) = *(_DWORD *)(a1 + 81808);
  *(_DWORD *)(a1 + 81808) = *(_DWORD *)(a1 + 81792);
  *(_DWORD *)(a1 + 82128) = *(_DWORD *)(a1 + 82112);
  *(_DWORD *)(a1 + 82112) = *(_DWORD *)(a1 + 82096);
  *(_DWORD *)(a1 + 82096) = *(_DWORD *)(a1 + 82080);
  *(_DWORD *)(a1 + 82080) = *(_DWORD *)(a1 + 82064);
  *(_DWORD *)(a1 + 82064) = *(_DWORD *)(a1 + 82048);
  *(_DWORD *)(a1 + 82048) = *(_DWORD *)(a1 + 82032);
  *(_DWORD *)(a1 + 82032) = *(_DWORD *)(a1 + 82016);
  *(_DWORD *)(a1 + 82256) = *(_DWORD *)(a1 + 82240);
  *(_DWORD *)(a1 + 82240) = *(_DWORD *)(a1 + 82224);
  *(_DWORD *)(a1 + 82224) = *(_DWORD *)(a1 + 82208);
  *(_DWORD *)(a1 + 82208) = *(_DWORD *)(a1 + 82192);
  *(_DWORD *)(a1 + 82192) = *(_DWORD *)(a1 + 82176);
  *(_DWORD *)(a1 + 82176) = *(_DWORD *)(a1 + 82160);
  *(_DWORD *)(a1 + 82160) = *(_DWORD *)(a1 + 82144);
  *(_DWORD *)(a1 + 82384) = *(_DWORD *)(a1 + 82368);
  *(_DWORD *)(a1 + 82368) = *(_DWORD *)(a1 + 82352);
  *(_DWORD *)(a1 + 82352) = *(_DWORD *)(a1 + 82336);
  *(_DWORD *)(a1 + 82336) = *(_DWORD *)(a1 + 82320);
  *(_DWORD *)(a1 + 82320) = *(_DWORD *)(a1 + 82304);
  *(_DWORD *)(a1 + 82304) = *(_DWORD *)(a1 + 82288);
  *(_DWORD *)(a1 + 82288) = *(_DWORD *)(a1 + 82272);
  *(_DWORD *)(a1 + 82512) = *(_DWORD *)(a1 + 82496);
  *(_DWORD *)(a1 + 82496) = *(_DWORD *)(a1 + 82480);
  *(_DWORD *)(a1 + 82480) = *(_DWORD *)(a1 + 82464);
  *(_DWORD *)(a1 + 82464) = *(_DWORD *)(a1 + 82448);
  *(_DWORD *)(a1 + 82448) = *(_DWORD *)(a1 + 82432);
  *(_DWORD *)(a1 + 82432) = *(_DWORD *)(a1 + 82416);
  *(_DWORD *)(a1 + 82416) = *(_DWORD *)(a1 + 82400);
  *(_DWORD *)(a1 + 82544) = *(_DWORD *)(a1 + 82528);
  v244 = *(float *)(a1 + 82560);
  *(float *)(a1 + 82576) = v244;
  if ( *(float *)(a1 + 82640) == 1.0 )
  {
    v245 = (float)((float)((float)(v243 * *(float *)(a1 + 82752)) + 1.0) * (float)(v242 * *(float *)(a1 + 82720)))
         + (float)((float)-v244 * *(float *)(a1 + 82704));
    *(float *)(a1 + 82560) = sub_7FF91DFC8D60();
    *(float *)(a1 + 82528) = v245;
    v246 = 1.0 - (float)(v241 + v241);
    v247 = 1.0 / (float)((float)((float)((float)(v241 * v241) * (float)(v241 * v241)) * v243) + 1.0);
    *(float *)(a1 + 82608) = v247;
    v248 = *(float *)(a1 + 82528);
    v249 = *(float *)(a1 + 82544);
    *(float *)(a1 + 82592) = v247 * v243;
    v250 = v249 * *(float *)(a1 + 82800);
    v251 = *(float *)(a1 + 81888);
    v252 = v248 * *(float *)(a1 + 82816);
    v253 = *(float *)(a1 + 81904);
    *(float *)(a1 + 82000) = v251;
    v254 = (float)((float)(v250 + v252) * v247)
         - (float)((float)((float)(v251 * *(float *)(a1 + 83104)) + (float)(v253 * *(float *)(a1 + 83120)))
                 * (float)(v247 * v243));
    if ( v254 >= -1.0 )
      v255 = fminf(v254, 1.0);
    else
      v255 = -1.0;
    v256 = v255 + (float)((float)((float)((float)(v255 * v255) * v255) * v255) * (float)(v255 * *(float *)(a1 + 82768)));
    *(float *)(a1 + 81920) = v256;
    v257 = *(float *)(a1 + 81824);
    v258 = (float)(v241 * (float)(v256 + *(float *)(a1 + 81808))) + (float)(v257 * v246);
    *(float *)(a1 + 81936) = v258;
    v259 = *(float *)(a1 + 81840);
    v260 = v241 * (float)(v258 + v257);
    v261 = v241 * (float)((float)((float)(v241 * v256) + (float)(v246 * v258)) + v258);
    v262 = v260 + (float)(v259 * v246);
    *(float *)(a1 + 81952) = v262;
    v263 = *(float *)(a1 + 81856);
    v264 = (float)(v241 * (float)(v262 + v259)) + (float)(v263 * v246);
    *(float *)(a1 + 81968) = v264;
    v265 = (float)((float)(v263 + v264) * v241) + (float)(v246 * *(float *)(a1 + 81872));
    *(float *)(a1 + 81984) = v265;
    v266 = (float)(v241
                 * (float)((float)((float)(v241 * (float)((float)(v261 + (float)(v246 * v262)) + v262))
                                 + (float)(v246 * v264))
                         + v264))
         + (float)(v246 * v265);
    v267 = (float)(*(float *)(a1 + 81968) * *(float *)(a1 + 82672)) + (float)(v265 * *(float *)(a1 + 82688));
    v268 = *(float *)(a1 + 82544);
    *(float *)(a1 + 82400) = v267 + (float)(*(float *)(a1 + 82656) * *(float *)(a1 + 81952));
    v269 = *(float *)(a1 + 82000);
    v270 = (float)((float)(v268 + *(float *)(a1 + 82528)) * *(float *)(a1 + 82832)) * *(float *)(a1 + 82608);
    *(float *)(a1 + 82000) = v266;
    v271 = v270
         - (float)((float)((float)(v266 * *(float *)(a1 + 83104)) + (float)(v269 * *(float *)(a1 + 83120)))
                 * *(float *)(a1 + 82592));
    if ( v271 >= -1.0 )
      v272 = fminf(v271, 1.0);
    else
      v272 = -1.0;
    v273 = v272 + (float)((float)((float)((float)(v272 * v272) * v272) * v272) * (float)(v272 * *(float *)(a1 + 82768)));
    v274 = *(float *)(a1 + 81920);
    *(float *)(a1 + 81920) = v273;
    v275 = *(float *)(a1 + 81936);
    v276 = (float)(v241 * (float)(v273 + v274)) + (float)(v275 * v246);
    *(float *)(a1 + 81936) = v276;
    v277 = *(float *)(a1 + 81952);
    v278 = v241 * (float)(v276 + v275);
    v279 = v241 * (float)((float)((float)(v241 * v273) + (float)(v246 * v276)) + v276);
    v280 = v278 + (float)(v277 * v246);
    *(float *)(a1 + 81952) = v280;
    v281 = *(float *)(a1 + 81968);
    v282 = (float)(v241 * (float)(v280 + v277)) + (float)(v281 * v246);
    *(float *)(a1 + 81968) = v282;
    v283 = (float)((float)(v281 + v282) * v241) + (float)(v246 * *(float *)(a1 + 81984));
    *(float *)(a1 + 81984) = v283;
    v284 = *(float *)(a1 + 82528);
    v285 = (float)(v241
                 * (float)((float)((float)(v241 * (float)((float)(v279 + (float)(v246 * v280)) + v280))
                                 + (float)(v246 * v282))
                         + v282))
         + (float)(v246 * v283);
    v286 = (float)(*(float *)(a1 + 81968) * *(float *)(a1 + 82672)) + (float)(v283 * *(float *)(a1 + 82688));
    v287 = *(float *)(a1 + 82544);
    *(float *)(a1 + 82272) = v286 + (float)(*(float *)(a1 + 82656) * *(float *)(a1 + 81952));
    v288 = *(float *)(a1 + 82000);
    v289 = (float)((float)(v287 * *(float *)(a1 + 82816)) + (float)(v284 * *(float *)(a1 + 82800)))
         * *(float *)(a1 + 82608);
    *(float *)(a1 + 82000) = v285;
    v290 = v289
         - (float)((float)((float)(v285 * *(float *)(a1 + 83104)) + (float)(v288 * *(float *)(a1 + 83120)))
                 * *(float *)(a1 + 82592));
    if ( v290 >= -1.0 )
      v291 = fminf(v290, 1.0);
    else
      v291 = -1.0;
    v292 = v291 + (float)((float)((float)((float)(v291 * v291) * v291) * v291) * (float)(v291 * *(float *)(a1 + 82768)));
    v293 = *(float *)(a1 + 81920);
    *(float *)(a1 + 81920) = v292;
    v294 = *(float *)(a1 + 81936);
    v295 = (float)(v241 * (float)(v292 + v293)) + (float)(v294 * v246);
    *(float *)(a1 + 81936) = v295;
    v296 = *(float *)(a1 + 81952);
    v297 = v241 * (float)(v295 + v294);
    v298 = v241 * (float)((float)((float)(v241 * v292) + (float)(v246 * v295)) + v295);
    v299 = v297 + (float)(v296 * v246);
    *(float *)(a1 + 81952) = v299;
    v300 = *(float *)(a1 + 81968);
    v301 = (float)(v241 * (float)(v299 + v296)) + (float)(v300 * v246);
    *(float *)(a1 + 81968) = v301;
    v302 = (float)((float)(v300 + v301) * v241) + (float)(v246 * *(float *)(a1 + 81984));
    *(float *)(a1 + 81984) = v302;
    v303 = (float)(v241
                 * (float)((float)((float)(v241 * (float)((float)(v298 + (float)(v246 * v299)) + v299))
                                 + (float)(v246 * v301))
                         + v301))
         + (float)(v246 * v302);
    v304 = (float)(*(float *)(a1 + 81968) * *(float *)(a1 + 82672)) + (float)(v302 * *(float *)(a1 + 82688));
    v305 = *(float *)(a1 + 82528);
    *(float *)(a1 + 82144) = v304 + (float)(*(float *)(a1 + 82656) * *(float *)(a1 + 81952));
    v306 = *(float *)(a1 + 82000);
    v307 = (float)(v305 * *(float *)(a1 + 82784)) * *(float *)(a1 + 82608);
    *(float *)(a1 + 81888) = v303;
    v308 = v307
         - (float)((float)((float)(v303 * *(float *)(a1 + 83104)) + (float)(v306 * *(float *)(a1 + 83120)))
                 * *(float *)(a1 + 82592));
    if ( v308 >= -1.0 )
      v309 = fminf(v308, 1.0);
    else
      v309 = -1.0;
    v310 = v309 + (float)((float)((float)((float)(v309 * v309) * v309) * v309) * (float)(v309 * *(float *)(a1 + 82768)));
    *(float *)(a1 + 81792) = v310;
    v311 = *(float *)(a1 + 81936);
    v312 = (float)(v241 * (float)(v310 + *(float *)(a1 + 81920))) + (float)(v311 * v246);
    *(float *)(a1 + 81808) = v312;
    v313 = *(float *)(a1 + 81952);
    v314 = v241 * (float)(v312 + v311);
    v315 = v241 * (float)((float)((float)(v241 * v310) + (float)(v246 * v312)) + v312);
    v316 = v314 + (float)(v313 * v246);
    *(float *)(a1 + 81824) = v316;
    v317 = *(float *)(a1 + 81968);
    v318 = (float)(v241 * (float)(v316 + v313)) + (float)(v317 * v246);
    *(float *)(a1 + 81840) = v318;
    v319 = (float)((float)(v317 + v318) * v241) + (float)(v246 * *(float *)(a1 + 81984));
    v320 = v241
         * (float)((float)((float)(v241 * (float)((float)(v315 + (float)(v246 * v316)) + v316)) + (float)(v246 * v318))
                 + v318);
    *(float *)(a1 + 81856) = v319;
    v321 = *(float *)(a1 + 81824);
    *(float *)(a1 + 81872) = v320 + (float)(v246 * v319);
    v322 = *(float *)(a1 + 82080);
    v323 = (float)((float)(v319 * *(float *)(a1 + 82688)) + (float)(*(float *)(a1 + 82672) * *(float *)(a1 + 81840)))
         + (float)(v321 * *(float *)(a1 + 82656));
    *(float *)(a1 + 82016) = v323;
    v324 = (float)(v323 + *(float *)(a1 + 82512)) * *(float *)(a1 + 82848);
    v325 = (float)(*(float *)(a1 + 82272) + *(float *)(a1 + 82256)) * *(float *)(a1 + 82880);
    v326 = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v322 + *(float *)(a1 + 82448)) * *(float *)(a1 + 83088)) + (float)((float)(*(float *)(a1 + 82208) + *(float *)(a1 + 82320)) * *(float *)(a1 + 83072))) + (float)((float)(*(float *)(a1 + 82336) + *(float *)(a1 + 82192)) * *(float *)(a1 + 83056))) + (float)((float)(*(float *)(a1 + 82064) + *(float *)(a1 + 82464)) * *(float *)(a1 + 83040))) + (float)((float)(*(float *)(a1 + 82432) + *(float *)(a1 + 82096)) * *(float *)(a1 + 83024)))
                                                                                                 + (float)((float)(*(float *)(a1 + 82304) + *(float *)(a1 + 82224)) * *(float *)(a1 + 83008)))
                                                                                         + (float)((float)(*(float *)(a1 + 82352) + *(float *)(a1 + 82176))
                                                                                                 * *(float *)(a1 + 82992)))
                                                                                 + (float)((float)(*(float *)(a1 + 82480)
                                                                                                 + *(float *)(a1 + 82048))
                                                                                         * *(float *)(a1 + 82976)))
                                                                         + (float)((float)(*(float *)(a1 + 82416)
                                                                                         + *(float *)(a1 + 82112))
                                                                                 * *(float *)(a1 + 82960)))
                                                                 + (float)((float)(*(float *)(a1 + 82288)
                                                                                 + *(float *)(a1 + 82240))
                                                                         * *(float *)(a1 + 82944)))
                                                         + (float)((float)(*(float *)(a1 + 82368)
                                                                         + *(float *)(a1 + 82160))
                                                                 * *(float *)(a1 + 82928)))
                                                 + (float)((float)(*(float *)(a1 + 82496) + *(float *)(a1 + 82032))
                                                         * *(float *)(a1 + 82912)))
                                         + (float)((float)(*(float *)(a1 + 82400) + *(float *)(a1 + 82128))
                                                 * *(float *)(a1 + 82896)))
                                 + v325)
                         + (float)((float)(*(float *)(a1 + 82384) + *(float *)(a1 + 82144)) * *(float *)(a1 + 82864)))
                 + v324)
         * *(float *)(a1 + 82736);
    *(float *)(a1 + 82624) = v326;
  }
  *(_DWORD *)(a1 + 83152) = *(_DWORD *)(a1 + 83136);
  v327 = *(_DWORD *)(a1 + 83184);
  *(_DWORD *)(a1 + 83216) = *(_DWORD *)(a1 + 83168);
  *(_DWORD *)(a1 + 83232) = v327;
  *(_DWORD *)(a1 + 83248) = *(_DWORD *)(a1 + 83200);
  v328 = *(float *)(a1 + 83264);
  *(float *)(a1 + 83280) = v328;
  v329 = *(float *)(a1 + 83296);
  *(float *)(a1 + 83312) = v329;
  v330 = (float)((float)(v328 - v329) * *(float *)(a1 + 83328)) + v329;
  *(float *)(a1 + 83296) = v330;
  v331 = (float)((float)(v330 * *(float *)(a1 + 83232)) - (float)(*(float *)(a1 + 83232) * *(float *)(a1 + 83248)))
       + *(float *)(a1 + 83248);
  *(float *)(a1 + 83344) = v331;
  v332 = *(float *)(a1 + 83360);
  *(float *)(a1 + 83376) = v332;
  v333 = (float)((float)(*(float *)(a1 + 83392) * v331) - (float)(*(float *)(a1 + 83392) * v332)) + v332;
  if ( v333 <= 0.0 )
    v334 = 0.0;
  else
    v334 = v333;
  v335 = v334;
  *(float *)(a1 + 83360) = v335;
  v336 = *(float *)(a1 + 83408);
  *(float *)(a1 + 83424) = v336;
  v337 = *(float *)(a1 + 83440);
  *(float *)(a1 + 83456) = v337;
  v338 = (float)((float)(*(float *)(a1 + 83472) * v336) - (float)(*(float *)(a1 + 83472) * v337)) + v337;
  if ( v338 <= 0.0 )
    v339 = 0.0;
  else
    v339 = v338;
  v340 = v339;
  *(float *)(a1 + 83440) = v340;
  v341 = *(float *)(a1 + 83488);
  v342 = *(float *)(a1 + 74144);
  *(float *)(a1 + 83504) = v341;
  v343 = v341 * *(float *)(a1 + 83584);
  v344 = v341 + *(float *)(a1 + 83568);
  if ( v343 >= -1.0 )
    v345 = fminf(v343, 1.0);
  else
    v345 = -1.0;
  if ( (float)(v341 + *(float *)(a1 + 83536)) >= 0.0 )
    v344 = (float)((float)(*(float *)(a1 + 83552) * v342) - (float)(*(float *)(a1 + 83552) * v341)) + v341;
  v346 = (float)((float)(v345 * *(float *)(a1 + 83600)) - (float)(*(float *)(a1 + 83616) * v345))
       + *(float *)(a1 + 83616);
  v347 = (float)((float)(v346 * v342) - (float)(v346 * v341)) + v341;
  if ( v342 != 0.0 )
    v347 = v344;
  *(float *)(a1 + 83520) = v347;
  *(float *)(a1 + 83488) = v347;
  v348 = *(float *)(a1 + 82624);
  v349 = *(float *)(a1 + 76336);
  v350 = *(float *)(a1 + 80432);
  v351 = *(_DWORD *)(a1 + 76816);
  v352 = *(_DWORD *)(a1 + 83136);
  *(_DWORD *)(a1 + 83696) = *(_DWORD *)(a1 + 83680);
  *(_DWORD *)(a1 + 83728) = *(_DWORD *)(a1 + 83712);
  *(_DWORD *)(a1 + 83632) = v351;
  *(_DWORD *)(a1 + 83648) = v352;
  v353 = *(float *)(a1 + 83696);
  v354 = *(float *)(a1 + 83760);
  *(float *)(a1 + 83664) = v350 * *(float *)(a1 + 83920);
  v355 = v348 - v353;
  v356 = *(float *)(a1 + 83792);
  v357 = (float)(v349 * *(float *)(a1 + 83776)) + (float)(v354 * *(float *)(a1 + 83520));
  v358 = v353 + (float)((float)(v348 - v353) * *(float *)(a1 + 83824));
  *(float *)(a1 + 83680) = v358;
  v359 = (float)(v355 * *(float *)(a1 + 83936)) + (float)(v358 * *(float *)(a1 + 83952));
  v360 = (float)((float)(*(float *)(a1 + 83808) * *(float *)(a1 + 83648))
               - (float)(*(float *)(a1 + 83808) * (float)(v357 + (float)(v356 * *(float *)(a1 + 83632)))))
       + (float)(v357 + (float)(v356 * *(float *)(a1 + 83632)));
  v361 = *(float *)(a1 + 83840);
  v362 = v360 * *(float *)(a1 + 83888);
  v363 = v348 * (float)(1.0 - v361);
  if ( v362 <= 0.0 )
    v364 = 0.0;
  else
    v364 = v362;
  v365 = *(float *)(a1 + 83856);
  v366 = v364;
  v367 = v366 * *(float *)(a1 + 83904);
  v368 = (float)((float)(v361 * v359) + v363) * (float)(*(float *)(a1 + 83664) + 1.0);
  v369 = *(float *)(a1 + 83872) * v368;
  v370 = *(float *)(a1 + 83728)
       + (float)((float)(*(float *)(a1 + 83968) * v368) - (float)(*(float *)(a1 + 83968) * *(float *)(a1 + 83728)));
  *(float *)(a1 + 83712) = v370;
  v371 = (float)((float)((float)(v365 * v370) + v369) * v367) * *(float *)(a1 + 83984);
  *(float *)(a1 + 83744) = v371;
  *(_DWORD *)(a1 + 84032) = *(_DWORD *)(a1 + 84016);
  *(_DWORD *)(a1 + 84016) = *(_DWORD *)(a1 + 84000);
  v372 = *(float *)(a1 + 84032);
  v373 = *(float *)(a1 + 84048);
  v374 = v371 - v372;
  *(float *)(a1 + 84000) = v374;
  *(float *)(a1 + 84016) = (float)(v373 * v374) + v372;
  v375 = *(float *)(a1 + 84000);
  v376 = *(float *)(a1 + 83216);
  *(_DWORD *)(a1 + 84112) = *(_DWORD *)(a1 + 84096);
  *(_DWORD *)(a1 + 84096) = *(_DWORD *)(a1 + 84080);
  *(_DWORD *)(a1 + 84080) = *(_DWORD *)(a1 + 84064);
  *(float *)(a1 + 84064) = v375;
  v377 = (float)((float)(*(float *)(a1 + 84080) * *(float *)(a1 + 84160)) + (float)(v375 * *(float *)(a1 + 84144)))
       + (float)(*(float *)(a1 + 84176) * *(float *)(a1 + 84096));
  v378 = (float)((float)(*(float *)(a1 + 84080) * *(float *)(a1 + 84208)) + (float)(v375 * *(float *)(a1 + 84192)))
       + (float)(*(float *)(a1 + 84224) * *(float *)(a1 + 84112));
  if ( v376 <= 0.0 )
    v379 = 0.0;
  else
    v379 = v376;
  *(float *)(a1 + 84080) = v377;
  v380 = v379;
  *(float *)(a1 + 84096) = v378;
  v381 = (float)((float)(v380 * v377) - (float)(v380 * v375)) + v375;
  if ( v376 < -0.0 )
    v19 = (float)-v376;
  v382 = v19;
  v383 = v375 + (float)((float)(v382 * v378) - (float)(v382 * v375));
  if ( v376 >= 0.0 )
    v383 = v381;
  *(float *)(a1 + 84128) = v383;
  v384 = v383 * *(float *)(a1 + 83360);
  *(float *)(a1 + 84240) = v384;
  *(float *)(a1 + 84256) = v384 * *(float *)(a1 + 83440);
  v385 = fmin(fmax((float)(*(float *)(a1 + 78032) + *(float *)(a1 + 77360)), -20.0), 8.9);
  v386 = v385 * v385 * v385;
  v387 = (double *)((char *)&unk_7FF91E5E94E0 + 208 * (int)(v385 + 20.0));
  v388 = v386 * v385 * v385;
  v389 = v388 * v385 * v385 * v385;
  v390 = v389 * v385 * v385;
  v391 = fmaxf(
           fminf(
             v385 * v387[2]
           + *v387
           + v385 * v385 * v387[4]
           + v386 * v387[6]
           + v386 * v385 * v387[8]
           + v388 * v387[10]
           + v388 * v385 * v387[12]
           + v388 * v385 * v385 * v387[14]
           + v389 * v387[16]
           + v389 * v385 * v387[18]
           + v390 * v387[20]
           + v390 * v385 * v387[22]
           + v390 * v385 * v385 * v387[24],
             512.0),
           -512.0)
       * *(float *)(a1 + 77376);
  *(float *)(a1 + 78000) = v391;
  v392 = *(float *)(a1 + 77360);
  v393 = *(_DWORD *)(a1 + 77824);
  v394 = *(_DWORD *)(a1 + 77840);
  LODWORD(v386) = *(_DWORD *)(a1 + 77856);
  *(_DWORD *)(a1 + 78432) = *(_DWORD *)(a1 + 78416);
  *(_DWORD *)(a1 + 78464) = *(_DWORD *)(a1 + 78448);
  *(_DWORD *)(a1 + 78640) = *(_DWORD *)(a1 + 78624);
  *(_DWORD *)(a1 + 78624) = *(_DWORD *)(a1 + 78608);
  *(_DWORD *)(a1 + 78608) = *(_DWORD *)(a1 + 78592);
  *(_DWORD *)(a1 + 78592) = *(_DWORD *)(a1 + 78576);
  *(_DWORD *)(a1 + 78576) = *(_DWORD *)(a1 + 78560);
  *(_DWORD *)(a1 + 78560) = *(_DWORD *)(a1 + 78544);
  *(_DWORD *)(a1 + 78544) = *(_DWORD *)(a1 + 78528);
  *(_DWORD *)(a1 + 78768) = *(_DWORD *)(a1 + 78752);
  *(_DWORD *)(a1 + 78752) = *(_DWORD *)(a1 + 78736);
  *(_DWORD *)(a1 + 78736) = *(_DWORD *)(a1 + 78720);
  *(_DWORD *)(a1 + 78720) = *(_DWORD *)(a1 + 78704);
  *(_DWORD *)(a1 + 78704) = *(_DWORD *)(a1 + 78688);
  *(_DWORD *)(a1 + 78688) = *(_DWORD *)(a1 + 78672);
  *(_DWORD *)(a1 + 78672) = *(_DWORD *)(a1 + 78656);
  *(_DWORD *)(a1 + 78896) = *(_DWORD *)(a1 + 78880);
  *(_DWORD *)(a1 + 78880) = *(_DWORD *)(a1 + 78864);
  *(_DWORD *)(a1 + 78864) = *(_DWORD *)(a1 + 78848);
  *(_DWORD *)(a1 + 78848) = *(_DWORD *)(a1 + 78832);
  *(_DWORD *)(a1 + 78832) = *(_DWORD *)(a1 + 78816);
  *(_DWORD *)(a1 + 78816) = *(_DWORD *)(a1 + 78800);
  *(_DWORD *)(a1 + 78800) = *(_DWORD *)(a1 + 78784);
  *(_DWORD *)(a1 + 79024) = *(_DWORD *)(a1 + 79008);
  *(_DWORD *)(a1 + 79008) = *(_DWORD *)(a1 + 78992);
  *(_DWORD *)(a1 + 78992) = *(_DWORD *)(a1 + 78976);
  *(_DWORD *)(a1 + 78976) = *(_DWORD *)(a1 + 78960);
  *(_DWORD *)(a1 + 78960) = *(_DWORD *)(a1 + 78944);
  *(_DWORD *)(a1 + 78944) = *(_DWORD *)(a1 + 78928);
  *(_DWORD *)(a1 + 78928) = *(_DWORD *)(a1 + 78912);
  *(_DWORD *)(a1 + 79088) = *(_DWORD *)(a1 + 79072);
  *(_DWORD *)(a1 + 79072) = *(_DWORD *)(a1 + 79056);
  *(_DWORD *)(a1 + 78320) = v393;
  *(_DWORD *)(a1 + 78336) = v394;
  v395 = v392 + *(float *)(a1 + 79888);
  v396 = v391 * *(float *)(a1 + 79120);
  v397 = *(float *)(a1 + 79104);
  *(_DWORD *)(a1 + 78352) = LODWORD(v386);
  v398 = fmaxf(*(float *)(a1 + 79152), v396);
  v399 = (float)(v395 * *(float *)(a1 + 79904)) + *(float *)(a1 + 79872);
  *(float *)(a1 + 78368) = v398;
  *(float *)(a1 + 78400) = v397 + *(float *)(a1 + 77392);
  if ( v399 <= 0.0 )
    v400 = 0.0;
  else
    v400 = v399;
  *(float *)(a1 + 78384) = 0.00390625 / v398;
  *(float *)(a1 + 79040) = v400;
  v401 = *(float *)(a1 + 78464);
  v402 = *(_DWORD *)(a1 + 78432);
  *(float *)(a1 + 78240) = v401;
  v403 = v401 + v398;
  *(_DWORD *)(a1 + 78256) = v402;
  if ( v403 <= 1.0 )
  {
    if ( v403 < -1.0 )
      v403 = fmodf(v403 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v403 = fmodf(v403 + 1.0, 2.0) - 1.0;
  }
  *(float *)(a1 + 78224) = v403;
  v404 = v403 * *(float *)(a1 + 79232);
  v405 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v406 = (float)((float)(*(float *)&v405 * 256.0) * *(float *)(a1 + 78384)) * *(float *)(a1 + 79184);
  if ( v406 >= -1.0 )
    v407 = fminf(v406, 1.0);
  else
    v407 = -1.0;
  v408 = v407 * *(float *)(a1 + 79136);
  v409 = (float)(v408 * v408) * v408;
  v410 = v409 * *(float *)(a1 + 79536);
  v411 = (float)((float)((float)((float)((float)(v408 * v408) * *(float *)(a1 + 79600)) + *(float *)(a1 + 79584))
                       * (float)((float)(v408 * v408) * (float)(v408 * v408)))
               + (float)((float)((float)(v408 * v408) * *(float *)(a1 + 79568)) + *(float *)(a1 + 79552)))
       * (float)(v409 * (float)(v408 * v408));
  v412 = *(float *)(a1 + 78400) + v403;
  *(float *)(a1 + 78480) = (float)((float)(v411 + v410) + v408) * v404;
  v413 = v412;
  if ( v412 >= 0.0 )
  {
    if ( v412 > 0.0 )
      v413 = 1.0;
  }
  else
  {
    v413 = -1.0;
  }
  v414 = *(float *)(a1 + 78224);
  v415 = v413 * *(float *)(a1 + 79248);
  v416 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v417 = *(float *)&v416;
  v418 = *(float *)(a1 + 79168);
  if ( v414 < v418 || v418 <= *(float *)(a1 + 78240) )
    v419 = *(float *)(a1 + 78256);
  else
    v419 = *(float *)(a1 + 78256) + 2.0;
  v420 = (float)((float)(v417 * *(float *)(a1 + 78384)) * 256.0) * *(float *)(a1 + 79200);
  if ( v419 >= 4.0 )
    v419 = 0.0;
  if ( v420 >= -1.0 )
    v421 = fminf(v420, 1.0);
  else
    v421 = -1.0;
  *(float *)(a1 + 78256) = v419;
  v422 = v421 * *(float *)(a1 + 79136);
  v423 = (float)((float)((float)(v419 + v414) + 1.0) * 0.5) - 1.0;
  v424 = (float)((float)((float)((float)((float)((float)((float)((float)(v422 * v422) * *(float *)(a1 + 79600))
                                                       + *(float *)(a1 + 79584))
                                               * (float)((float)(v422 * v422) * (float)(v422 * v422)))
                                       + (float)((float)((float)(v422 * v422) * *(float *)(a1 + 79568))
                                               + *(float *)(a1 + 79552)))
                               * (float)((float)((float)(v422 * v422) * v422) * (float)(v422 * v422)))
                       + (float)((float)((float)(v422 * v422) * v422) * *(float *)(a1 + 79536)))
               + v422)
       * v415;
  *(float *)(a1 + 78496) = v424;
  v425 = ((double (*)(void))sub_7FF91DFC8FC0)();
  if ( v423 >= 0.0 )
  {
    if ( v423 > 0.0 )
      v423 = 1.0;
  }
  else
  {
    v423 = -1.0;
  }
  v426 = v423 * *(float *)(a1 + 79264);
  v427 = (float)((float)((float)(*(float *)&v425 + 1.0) * *(float *)(a1 + 78384)) * 512.0) * *(float *)(a1 + 79216);
  if ( v427 >= -1.0 )
    v428 = fminf(v427, 1.0);
  else
    v428 = -1.0;
  v429 = v428 * *(float *)(a1 + 79136);
  v430 = *(float *)(a1 + 78224);
  v431 = *(_DWORD *)(a1 + 78256);
  *(float *)(a1 + 78528) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v429 * v429)
                                                                                                 * *(float *)(a1 + 79600))
                                                                                         + *(float *)(a1 + 79584))
                                                                                 * (float)((float)(v429 * v429)
                                                                                         * (float)(v429 * v429)))
                                                                         + (float)((float)((float)(v429 * v429)
                                                                                         * *(float *)(a1 + 79568))
                                                                                 + *(float *)(a1 + 79552)))
                                                                 * (float)((float)((float)(v429 * v429) * v429)
                                                                         * (float)(v429 * v429)))
                                                         + (float)((float)((float)(v429 * v429) * v429)
                                                                 * *(float *)(a1 + 79536)))
                                                 + v429)
                                         * v426)
                                 * *(float *)(a1 + 78352))
                         + (float)((float)(*(float *)(a1 + 78480) * *(float *)(a1 + 78320))
                                 + (float)(v424 * *(float *)(a1 + 78336)));
  *(float *)(a1 + 78240) = v430;
  *(_DWORD *)(a1 + 78256) = v431;
  v432 = v430 + *(float *)(a1 + 78368);
  if ( v432 <= 1.0 )
  {
    if ( v432 < -1.0 )
      v432 = fmodf(v432 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v432 = fmodf(v432 + 1.0, 2.0) - 1.0;
  }
  *(float *)(a1 + 78224) = v432;
  v433 = v432 * *(float *)(a1 + 79232);
  v434 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v435 = (float)((float)(*(float *)&v434 * 256.0) * *(float *)(a1 + 78384)) * *(float *)(a1 + 79184);
  if ( v435 >= -1.0 )
    v436 = fminf(v435, 1.0);
  else
    v436 = -1.0;
  v437 = v436 * *(float *)(a1 + 79136);
  v438 = (float)(v437 * v437) * v437;
  v439 = v438 * *(float *)(a1 + 79536);
  v440 = (float)((float)((float)((float)((float)(v437 * v437) * *(float *)(a1 + 79600)) + *(float *)(a1 + 79584))
                       * (float)((float)(v437 * v437) * (float)(v437 * v437)))
               + (float)((float)((float)(v437 * v437) * *(float *)(a1 + 79568)) + *(float *)(a1 + 79552)))
       * (float)(v438 * (float)(v437 * v437));
  v441 = *(float *)(a1 + 78400) + v432;
  *(float *)(a1 + 78480) = (float)((float)(v440 + v439) + v437) * v433;
  v442 = v441;
  if ( v441 >= 0.0 )
  {
    if ( v441 > 0.0 )
      v442 = 1.0;
  }
  else
  {
    v442 = -1.0;
  }
  v443 = *(float *)(a1 + 78224);
  v444 = v442 * *(float *)(a1 + 79248);
  v445 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v446 = *(float *)&v445;
  v447 = *(float *)(a1 + 79168);
  if ( v443 < v447 || v447 <= *(float *)(a1 + 78240) )
    v448 = *(float *)(a1 + 78256);
  else
    v448 = *(float *)(a1 + 78256) + 2.0;
  v449 = (float)((float)(v446 * *(float *)(a1 + 78384)) * 256.0) * *(float *)(a1 + 79200);
  if ( v448 >= 4.0 )
    v448 = 0.0;
  if ( v449 >= -1.0 )
    v450 = fminf(v449, 1.0);
  else
    v450 = -1.0;
  *(float *)(a1 + 78256) = v448;
  v451 = v450 * *(float *)(a1 + 79136);
  v452 = (float)((float)((float)(v448 + v443) + 1.0) * 0.5) - 1.0;
  v453 = (float)((float)((float)((float)((float)((float)((float)((float)(v451 * v451) * *(float *)(a1 + 79600))
                                                       + *(float *)(a1 + 79584))
                                               * (float)((float)(v451 * v451) * (float)(v451 * v451)))
                                       + (float)((float)((float)(v451 * v451) * *(float *)(a1 + 79568))
                                               + *(float *)(a1 + 79552)))
                               * (float)((float)((float)(v451 * v451) * v451) * (float)(v451 * v451)))
                       + (float)((float)((float)(v451 * v451) * v451) * *(float *)(a1 + 79536)))
               + v451)
       * v444;
  *(float *)(a1 + 78496) = v453;
  v454 = ((double (*)(void))sub_7FF91DFC8FC0)();
  if ( v452 >= 0.0 )
  {
    if ( v452 > 0.0 )
      v452 = 1.0;
  }
  else
  {
    v452 = -1.0;
  }
  v455 = v452 * *(float *)(a1 + 79264);
  v456 = (float)((float)((float)(*(float *)&v454 + 1.0) * *(float *)(a1 + 78384)) * 512.0) * *(float *)(a1 + 79216);
  if ( v456 >= -1.0 )
    v457 = fminf(v456, 1.0);
  else
    v457 = -1.0;
  v458 = v457 * *(float *)(a1 + 79136);
  v459 = *(float *)(a1 + 78224);
  v460 = *(_DWORD *)(a1 + 78256);
  *(float *)(a1 + 78656) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v458 * v458)
                                                                                                 * *(float *)(a1 + 79600))
                                                                                         + *(float *)(a1 + 79584))
                                                                                 * (float)((float)(v458 * v458)
                                                                                         * (float)(v458 * v458)))
                                                                         + (float)((float)((float)(v458 * v458)
                                                                                         * *(float *)(a1 + 79568))
                                                                                 + *(float *)(a1 + 79552)))
                                                                 * (float)((float)((float)(v458 * v458) * v458)
                                                                         * (float)(v458 * v458)))
                                                         + (float)((float)((float)(v458 * v458) * v458)
                                                                 * *(float *)(a1 + 79536)))
                                                 + v458)
                                         * v455)
                                 * *(float *)(a1 + 78352))
                         + (float)((float)(*(float *)(a1 + 78480) * *(float *)(a1 + 78320))
                                 + (float)(v453 * *(float *)(a1 + 78336)));
  *(float *)(a1 + 78240) = v459;
  *(_DWORD *)(a1 + 78256) = v460;
  v461 = v459 + *(float *)(a1 + 78368);
  if ( v461 <= 1.0 )
  {
    if ( v461 < -1.0 )
      v461 = fmodf(v461 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v461 = fmodf(v461 + 1.0, 2.0) - 1.0;
  }
  *(float *)(a1 + 78224) = v461;
  v462 = v461 * *(float *)(a1 + 79232);
  v463 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v464 = (float)((float)(*(float *)&v463 * 256.0) * *(float *)(a1 + 78384)) * *(float *)(a1 + 79184);
  if ( v464 >= -1.0 )
    v465 = fminf(v464, 1.0);
  else
    v465 = -1.0;
  v466 = v465 * *(float *)(a1 + 79136);
  v467 = (float)(v466 * v466) * v466;
  v468 = v467 * *(float *)(a1 + 79536);
  v469 = (float)((float)((float)((float)((float)(v466 * v466) * *(float *)(a1 + 79600)) + *(float *)(a1 + 79584))
                       * (float)((float)(v466 * v466) * (float)(v466 * v466)))
               + (float)((float)((float)(v466 * v466) * *(float *)(a1 + 79568)) + *(float *)(a1 + 79552)))
       * (float)(v467 * (float)(v466 * v466));
  v470 = *(float *)(a1 + 78400) + v461;
  *(float *)(a1 + 78480) = (float)((float)(v469 + v468) + v466) * v462;
  v471 = v470;
  if ( v470 >= 0.0 )
  {
    if ( v470 > 0.0 )
      v471 = 1.0;
  }
  else
  {
    v471 = -1.0;
  }
  v472 = *(float *)(a1 + 78224);
  v473 = v471 * *(float *)(a1 + 79248);
  v474 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v475 = *(float *)&v474;
  v476 = *(float *)(a1 + 79168);
  if ( v472 < v476 || v476 <= *(float *)(a1 + 78240) )
    v477 = *(float *)(a1 + 78256);
  else
    v477 = *(float *)(a1 + 78256) + 2.0;
  v478 = (float)((float)(v475 * *(float *)(a1 + 78384)) * 256.0) * *(float *)(a1 + 79200);
  if ( v477 >= 4.0 )
    v477 = 0.0;
  if ( v478 >= -1.0 )
    v479 = fminf(v478, 1.0);
  else
    v479 = -1.0;
  *(float *)(a1 + 78256) = v477;
  v480 = v479 * *(float *)(a1 + 79136);
  v481 = (float)((float)((float)(v477 + v472) + 1.0) * 0.5) - 1.0;
  v482 = (float)((float)((float)((float)((float)((float)((float)((float)(v480 * v480) * *(float *)(a1 + 79600))
                                                       + *(float *)(a1 + 79584))
                                               * (float)((float)(v480 * v480) * (float)(v480 * v480)))
                                       + (float)((float)((float)(v480 * v480) * *(float *)(a1 + 79568))
                                               + *(float *)(a1 + 79552)))
                               * (float)((float)((float)(v480 * v480) * v480) * (float)(v480 * v480)))
                       + (float)((float)((float)(v480 * v480) * v480) * *(float *)(a1 + 79536)))
               + v480)
       * v473;
  *(float *)(a1 + 78496) = v482;
  v483 = ((double (*)(void))sub_7FF91DFC8FC0)();
  if ( v481 >= 0.0 )
  {
    if ( v481 > 0.0 )
      v481 = 1.0;
  }
  else
  {
    v481 = -1.0;
  }
  v484 = v481 * *(float *)(a1 + 79264);
  v485 = (float)((float)((float)(*(float *)&v483 + 1.0) * *(float *)(a1 + 78384)) * 512.0) * *(float *)(a1 + 79216);
  if ( v485 >= -1.0 )
    v486 = fminf(v485, 1.0);
  else
    v486 = -1.0;
  v487 = v486 * *(float *)(a1 + 79136);
  v488 = *(float *)(a1 + 78224);
  v489 = *(_DWORD *)(a1 + 78256);
  *(float *)(a1 + 78784) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v487 * v487)
                                                                                                 * *(float *)(a1 + 79600))
                                                                                         + *(float *)(a1 + 79584))
                                                                                 * (float)((float)(v487 * v487)
                                                                                         * (float)(v487 * v487)))
                                                                         + (float)((float)((float)(v487 * v487)
                                                                                         * *(float *)(a1 + 79568))
                                                                                 + *(float *)(a1 + 79552)))
                                                                 * (float)((float)((float)(v487 * v487) * v487)
                                                                         * (float)(v487 * v487)))
                                                         + (float)((float)((float)(v487 * v487) * v487)
                                                                 * *(float *)(a1 + 79536)))
                                                 + v487)
                                         * v484)
                                 * *(float *)(a1 + 78352))
                         + (float)((float)(*(float *)(a1 + 78480) * *(float *)(a1 + 78320))
                                 + (float)(v482 * *(float *)(a1 + 78336)));
  *(float *)(a1 + 78240) = v488;
  *(_DWORD *)(a1 + 78256) = v489;
  v490 = v488 + *(float *)(a1 + 78368);
  if ( v490 <= 1.0 )
  {
    if ( v490 < -1.0 )
      v490 = fmodf(v490 - 1.0, 2.0) + 1.0;
  }
  else
  {
    v490 = fmodf(v490 + 1.0, 2.0) - 1.0;
  }
  *(float *)(a1 + 78224) = v490;
  v491 = v490 * *(float *)(a1 + 79232);
  v492 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v493 = (float)((float)(*(float *)&v492 * 256.0) * *(float *)(a1 + 78384)) * *(float *)(a1 + 79184);
  if ( v493 >= -1.0 )
    v494 = fminf(v493, 1.0);
  else
    v494 = -1.0;
  v495 = v494 * *(float *)(a1 + 79136);
  v496 = (float)(v495 * v495) * v495;
  v497 = v496 * *(float *)(a1 + 79536);
  v498 = (float)((float)((float)((float)((float)(v495 * v495) * *(float *)(a1 + 79600)) + *(float *)(a1 + 79584))
                       * (float)((float)(v495 * v495) * (float)(v495 * v495)))
               + (float)((float)((float)(v495 * v495) * *(float *)(a1 + 79568)) + *(float *)(a1 + 79552)))
       * (float)(v496 * (float)(v495 * v495));
  v499 = *(float *)(a1 + 78400) + v490;
  *(float *)(a1 + 78480) = (float)((float)(v498 + v497) + v495) * v491;
  v500 = v499;
  if ( v499 >= 0.0 )
  {
    if ( v499 > 0.0 )
      v500 = 1.0;
  }
  else
  {
    v500 = -1.0;
  }
  v501 = *(float *)(a1 + 78224);
  v502 = v500 * *(float *)(a1 + 79248);
  v503 = ((double (*)(void))sub_7FF91DFC8FC0)();
  v504 = *(float *)&v503;
  v505 = *(float *)(a1 + 79168);
  if ( v501 < v505 || v505 <= *(float *)(a1 + 78240) )
    v506 = *(float *)(a1 + 78256);
  else
    v506 = *(float *)(a1 + 78256) + 2.0;
  v507 = (float)((float)(v504 * *(float *)(a1 + 78384)) * 256.0) * *(float *)(a1 + 79200);
  if ( v506 >= 4.0 )
    v506 = 0.0;
  if ( v507 >= -1.0 )
    v508 = fminf(v507, 1.0);
  else
    v508 = -1.0;
  *(float *)(a1 + 78256) = v506;
  v509 = v508 * *(float *)(a1 + 79136);
  v510 = (float)((float)((float)(v506 + v501) + 1.0) * 0.5) - 1.0;
  v511 = (float)((float)((float)((float)((float)((float)((float)((float)(v509 * v509) * *(float *)(a1 + 79600))
                                                       + *(float *)(a1 + 79584))
                                               * (float)((float)(v509 * v509) * (float)(v509 * v509)))
                                       + (float)((float)((float)(v509 * v509) * *(float *)(a1 + 79568))
                                               + *(float *)(a1 + 79552)))
                               * (float)((float)((float)(v509 * v509) * v509) * (float)(v509 * v509)))
                       + (float)((float)((float)(v509 * v509) * v509) * *(float *)(a1 + 79536)))
               + v509)
       * v502;
  *(float *)(a1 + 78496) = v511;
  v512 = sub_7FF91DFC8FC0() + 1.0;
  if ( v510 >= 0.0 )
  {
    if ( v510 > 0.0 )
      v510 = 1.0;
  }
  else
  {
    v510 = -1.0;
  }
  v513 = v510 * *(float *)(a1 + 79264);
  v514 = (float)((float)(v512 * *(float *)(a1 + 78384)) * 512.0) * *(float *)(a1 + 79216);
  if ( v514 >= -1.0 )
    v33 = fminf(v514, 1.0);
  v515 = v33 * *(float *)(a1 + 79136);
  v516 = *(_DWORD *)(a1 + 78224);
  v517 = *(_DWORD *)(a1 + 78256);
  *(float *)(a1 + 78912) = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(v515 * v515)
                                                                                                 * *(float *)(a1 + 79600))
                                                                                         + *(float *)(a1 + 79584))
                                                                                 * (float)((float)(v515 * v515)
                                                                                         * (float)(v515 * v515)))
                                                                         + (float)((float)((float)(v515 * v515)
                                                                                         * *(float *)(a1 + 79568))
                                                                                 + *(float *)(a1 + 79552)))
                                                                 * (float)((float)((float)(v515 * v515) * v515)
                                                                         * (float)(v515 * v515)))
                                                         + (float)((float)((float)(v515 * v515) * v515)
                                                                 * *(float *)(a1 + 79536)))
                                                 + v515)
                                         * v513)
                                 * *(float *)(a1 + 78352))
                         + (float)((float)(*(float *)(a1 + 78480) * *(float *)(a1 + 78320))
                                 + (float)(v511 * *(float *)(a1 + 78336)));
  v518 = *(float *)(a1 + 79024);
  *(_DWORD *)(a1 + 78448) = v516;
  *(_DWORD *)(a1 + 78416) = v517;
  v519 = (float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)((float)(*(float *)(a1 + 78896) + *(float *)(a1 + 78656))
                                                                                               * *(float *)(a1 + 79296))
                                                                                       + (float)((float)(v518 + *(float *)(a1 + 78528))
                                                                                               * *(float *)(a1 + 79280)))
                                                                               + (float)((float)(*(float *)(a1 + 78784)
                                                                                               + *(float *)(a1 + 78768))
                                                                                       * *(float *)(a1 + 79312)))
                                                                       + (float)((float)(*(float *)(a1 + 78912)
                                                                                       + *(float *)(a1 + 78640))
                                                                               * *(float *)(a1 + 79328)))
                                                               + (float)((float)(*(float *)(a1 + 79008)
                                                                               + *(float *)(a1 + 78544))
                                                                       * *(float *)(a1 + 79344)))
                                                       + (float)((float)(*(float *)(a1 + 78880) + *(float *)(a1 + 78672))
                                                               * *(float *)(a1 + 79360)))
                                               + (float)((float)(*(float *)(a1 + 78800) + *(float *)(a1 + 78752))
                                                       * *(float *)(a1 + 79376)))
                                       + (float)((float)(*(float *)(a1 + 78928) + *(float *)(a1 + 78624))
                                               * *(float *)(a1 + 79392)))
                               + (float)((float)(*(float *)(a1 + 78992) + *(float *)(a1 + 78560))
                                       * *(float *)(a1 + 79408)))
                       + (float)((float)(*(float *)(a1 + 78688) + *(float *)(a1 + 78864)) * *(float *)(a1 + 79424)))
               + (float)((float)(*(float *)(a1 + 78816) + *(float *)(a1 + 78736)) * *(float *)(a1 + 79440)))
       + (float)((float)(*(float *)(a1 + 78608) + *(float *)(a1 + 78944)) * *(float *)(a1 + 79456));
  v520 = *(float *)(a1 + 79072);
  v521 = (float)(v520 * *(float *)(a1 + 79840)) + *(float *)(a1 + 79088);
  v522 = (float)((float)(v519
                       + (float)((float)(*(float *)(a1 + 78976) + *(float *)(a1 + 78576)) * *(float *)(a1 + 79472)))
               + (float)((float)(*(float *)(a1 + 78848) + *(float *)(a1 + 78704)) * *(float *)(a1 + 79488)))
       + (float)((float)(*(float *)(a1 + 78832) + *(float *)(a1 + 78720)) * *(float *)(a1 + 79504));
  v523 = (float)(*(float *)(a1 + 78960) + *(float *)(a1 + 78592)) * *(float *)(a1 + 79520);
  *(float *)(a1 + 79072) = v521;
  v524 = v522 + v523;
  v525 = v524 - (float)((float)(v520 * *(float *)(a1 + 79856)) + v521);
  *(float *)(a1 + 79056) = (float)(v525 * *(float *)(a1 + 79840)) + v520;
  v526 = (float)((float)((float)(v521 - (float)(v525 * *(float *)(a1 + 79040))) * *(float *)(a1 + 79920))
               - (float)(*(float *)(a1 + 79920) * v524))
       + v524;
  *(float *)(a1 + 78512) = v526;
  *(float *)(a1 + 77104) = v526;
  if ( *(float *)(a1 + 101728) == 1.0 )
  {
    *(_DWORD *)(a1 + 73904) = v528;
    *(_DWORD *)(a1 + 101728) = 0;
  }
  **a2 = *(_DWORD *)(a1 + 84256);
  result = *(unsigned int *)(a1 + 84256);
  *a2[1] = result;
  return result;
}


// ==== sub_7FF91DFE7CB0 @ rva 0x387CB0 ====
__int64 __fastcall sub_7FF91DFE7CB0(__int64 *a1, __int64 a2, __int64 a3)
{
  __int64 v6; // r10
  __int64 v7; // r12
  __int64 v8; // rcx
  unsigned __int64 v9; // r14
  unsigned __int64 v10; // rdx
  unsigned __int64 v11; // rax
  __int64 v12; // rbx
  __int64 v13; // rsi
  __int64 v14; // r12
  __int64 v15; // r8
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // r8

  v6 = *a1;
  v7 = (a2 - *a1) / 40;
  v8 = a1[1] - *a1;
  if ( v8 / 40 == 0x666666666666666LL )
    std::vector<void *>::_Xlen(v8);
  v9 = v8 / 40 + 1;
  v10 = (a1[2] - v6) / 40;
  v11 = v10 >> 1;
  if ( v10 <= 0x666666666666666LL - (v10 >> 1) )
  {
    v12 = v11 + v10;
    if ( v11 + v10 < v9 )
      v12 = v8 / 40 + 1;
  }
  else
  {
    v12 = v8 / 40 + 1;
  }
  v13 = sub_7FF91E00B860(a1, v12);
  v14 = 40 * v7;
  *(_OWORD *)(v14 + v13) = *(_OWORD *)a3;
  *(_OWORD *)(v14 + v13 + 16) = *(_OWORD *)(a3 + 16);
  *(_QWORD *)(v14 + v13 + 32) = *(_QWORD *)(a3 + 32);
  v15 = a1[1];
  v16 = *a1;
  v17 = v13;
  if ( a2 == v15 )
  {
    v18 = v15 - v16;
  }
  else
  {
    sub_7FF91E30DC00(v13, v16, a2 - v16);
    v17 = v13 + v14 + 40;
    v18 = a1[1] - a2;
    v16 = a2;
  }
  sub_7FF91E30DC00(v17, v16, v18);
  sub_7FF91E00B580(a1, v13, v9, v12, -2);
  return v14 + *a1;
}


// ==== sub_7FF91DFE7E20 @ rva 0x387E20 ====
__int64 __fastcall sub_7FF91DFE7E20(__int64 *a1, __int64 a2, __int64 a3)
{
  __int64 v6; // r10
  __int64 v7; // r12
  __int64 v8; // rcx
  unsigned __int64 v9; // r14
  unsigned __int64 v10; // rdx
  unsigned __int64 v11; // rax
  __int64 v12; // rbx
  __int64 v13; // rsi
  __int64 v14; // r12
  __int64 v15; // r8
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // r8

  v6 = *a1;
  v7 = (a2 - *a1) / 24;
  v8 = a1[1] - *a1;
  if ( v8 / 24 == 0xAAAAAAAAAAAAAAALL )
    std::vector<void *>::_Xlen(v8);
  v9 = v8 / 24 + 1;
  v10 = (a1[2] - v6) / 24;
  v11 = v10 >> 1;
  if ( v10 <= 0xAAAAAAAAAAAAAAALL - (v10 >> 1) )
  {
    v12 = v11 + v10;
    if ( v11 + v10 < v9 )
      v12 = v8 / 24 + 1;
  }
  else
  {
    v12 = v8 / 24 + 1;
  }
  v13 = sub_7FF91E00B8E0(a1, v12);
  v14 = 24 * v7;
  *(_OWORD *)(v14 + v13) = *(_OWORD *)a3;
  *(_QWORD *)(v14 + v13 + 16) = *(_QWORD *)(a3 + 16);
  v15 = a1[1];
  v16 = *a1;
  v17 = v13;
  if ( a2 == v15 )
  {
    v18 = v15 - v16;
  }
  else
  {
    sub_7FF91E30DC00(v13, v16, a2 - v16);
    v17 = v13 + v14 + 24;
    v18 = a1[1] - a2;
    v16 = a2;
  }
  sub_7FF91E30DC00(v17, v16, v18);
  sub_7FF91E00B630(a1, v13, v9, v12, -2);
  return v14 + *a1;
}


// ==== sub_7FF91DFE7F80 @ rva 0x387F80 ====
__int64 __fastcall sub_7FF91DFE7F80(__int64 *a1, __int64 a2, __int64 a3)
{
  __int64 v6; // r10
  __int64 v7; // r12
  __int64 v8; // rcx
  unsigned __int64 v9; // r14
  unsigned __int64 v10; // rdx
  unsigned __int64 v11; // rax
  __int64 v12; // rbx
  __int64 v13; // rsi
  __int64 v14; // r12
  __int64 v15; // r8
  __int64 v16; // rdx
  __int64 v17; // rcx
  __int64 v18; // r8

  v6 = *a1;
  v7 = (a2 - *a1) / 40;
  v8 = a1[1] - *a1;
  if ( v8 / 40 == 0x666666666666666LL )
    std::vector<void *>::_Xlen(v8);
  v9 = v8 / 40 + 1;
  v10 = (a1[2] - v6) / 40;
  v11 = v10 >> 1;
  if ( v10 <= 0x666666666666666LL - (v10 >> 1) )
  {
    v12 = v11 + v10;
    if ( v11 + v10 < v9 )
      v12 = v8 / 40 + 1;
  }
  else
  {
    v12 = v8 / 40 + 1;
  }
  v13 = sub_7FF91E00B860(a1, v12);
  v14 = 40 * v7;
  *(_OWORD *)(v14 + v13) = *(_OWORD *)a3;
  *(_OWORD *)(v14 + v13 + 16) = *(_OWORD *)(a3 + 16);
  *(_QWORD *)(v14 + v13 + 32) = *(_QWORD *)(a3 + 32);
  v15 = a1[1];
  v16 = *a1;
  v17 = v13;
  if ( a2 == v15 )
  {
    v18 = v15 - v16;
  }
  else
  {
    sub_7FF91E30DC00(v13, v16, a2 - v16);
    v17 = v13 + v14 + 40;
    v18 = a1[1] - a2;
    v16 = a2;
  }
  sub_7FF91E30DC00(v17, v16, v18);
  sub_7FF91E00B580(a1, v13, v9, v12, -2);
  return v14 + *a1;
}


// ==== sub_7FF91DFE80F0 @ rva 0x3880F0 ====
_QWORD *__fastcall sub_7FF91DFE80F0(_QWORD *a1)
{
  sub_7FF91E022410();
  *a1 = &CJu60Sim::`vftable';
  return a1;
}


// ==== sub_7FF91DFE8120 @ rva 0x388120 ====
__int64 __fastcall sub_7FF91DFE8120(_QWORD *a1, __int64 a2)
{
  return *a1 + 40 * a2;
}


// ==== sub_7FF91DFE8130 @ rva 0x388130 ====
__int64 __fastcall sub_7FF91DFE8130(__int64 a1, int a2, int a3)
{
  __int64 v3; // rdx
  __int64 v4; // rax

  if ( a2 >= 6 )
    return 0;
  v3 = 3LL * a2;
  v4 = *(_QWORD *)(a1 + 136);
  if ( a3 >= *(_DWORD *)(v4 + 8 * v3 + 12) )
    return 0;
  **(_DWORD **)(v4 + 8 * v3 + 16) = a3;
  return 1;
}


// ==== sub_7FF91DFE8160 @ rva 0x388160 ====
void __fastcall sub_7FF91DFE8160(__int64 a1, int a2)
{
  if ( !a2 )
    *(_DWORD *)(a1 + 10759872) = 256;
}


// ==== sub_7FF91DFE8170 @ rva 0x388170 ====
// None

// ==== sub_7FF91DFF8BF0 @ rva 0x398BF0 ====
unsigned __int64 __fastcall sub_7FF91DFF8BF0(__int64 a1)
{
  __int64 *v1; // rbx
  __int64 v3; // rcx
  __int64 v4; // rdx
  __int64 v5; // xmm1_8
  __int64 v6; // rdx
  __int64 v7; // xmm1_8
  __int64 v8; // rdx
  __int64 v9; // xmm1_8
  __int64 v10; // rdx
  __int64 v11; // xmm1_8
  __int64 v12; // rdx
  __int64 v13; // xmm1_8
  __int64 v14; // rdx
  __int64 v15; // xmm1_8
  __int64 v16; // rcx
  __int64 v17; // rcx
  __int128 v19; // [rsp+20h] [rbp-20h] BYREF
  __int64 v20; // [rsp+30h] [rbp-10h]

  v1 = (__int64 *)(a1 + 136);
  v3 = *(_QWORD *)(a1 + 152);
  if ( (unsigned __int64)((v3 - *v1) / 24) < 6 )
  {
    sub_7FF91E00B790(v1, 6);
    v3 = *(_QWORD *)(a1 + 152);
  }
  v4 = v1[1];
  *(_QWORD *)&v19 = "Prog_ID_LFO";
  *((_QWORD *)&v19 + 1) = 0x300000000LL;
  v20 = a1 + 11022036;
  if ( v3 == v4 )
  {
    sub_7FF91DFE7E20(v1, v4, (__int64)&v19);
    v6 = *(_QWORD *)(a1 + 144);
  }
  else
  {
    v5 = v20;
    *(_OWORD *)v4 = v19;
    *(_QWORD *)(v4 + 16) = v5;
    v1[1] += 24;
    v6 = v1[1];
  }
  *((_QWORD *)&v19 + 1) = 0xC00000000LL;
  *(_QWORD *)&v19 = "Prog_ID_Osc1";
  v20 = a1 + 11022040;
  if ( v1[2] == v6 )
  {
    sub_7FF91DFE7E20(v1, v6, (__int64)&v19);
    v8 = *(_QWORD *)(a1 + 144);
  }
  else
  {
    v7 = v20;
    *(_OWORD *)v6 = v19;
    *(_QWORD *)(v6 + 16) = v7;
    v1[1] += 24;
    v8 = v1[1];
  }
  *((_QWORD *)&v19 + 1) = 0xC00000000LL;
  *(_QWORD *)&v19 = "Prog_ID_Osc2";
  v20 = a1 + 11022044;
  if ( v1[2] == v8 )
  {
    sub_7FF91DFE7E20(v1, v8, (__int64)&v19);
    v10 = *(_QWORD *)(a1 + 144);
  }
  else
  {
    v9 = v20;
    *(_OWORD *)v8 = v19;
    *(_QWORD *)(v8 + 16) = v9;
    v1[1] += 24;
    v10 = v1[1];
  }
  *((_QWORD *)&v19 + 1) = 0x200000000LL;
  *(_QWORD *)&v19 = "Prog_ID_VCF";
  v20 = a1 + 11022048;
  if ( v1[2] == v10 )
  {
    sub_7FF91DFE7E20(v1, v10, (__int64)&v19);
    v12 = *(_QWORD *)(a1 + 144);
  }
  else
  {
    v11 = v20;
    *(_OWORD *)v10 = v19;
    *(_QWORD *)(v10 + 16) = v11;
    v1[1] += 24;
    v12 = v1[1];
  }
  *((_QWORD *)&v19 + 1) = 0x600000000LL;
  *(_QWORD *)&v19 = "Prog_ID_EFX";
  v20 = a1 + 11022052;
  if ( v1[2] == v12 )
  {
    sub_7FF91DFE7E20(v1, v12, (__int64)&v19);
    v14 = *(_QWORD *)(a1 + 144);
  }
  else
  {
    v13 = v20;
    *(_OWORD *)v12 = v19;
    *(_QWORD *)(v12 + 16) = v13;
    v1[1] += 24;
    v14 = v1[1];
  }
  *((_QWORD *)&v19 + 1) = 0x600000000LL;
  *(_QWORD *)&v19 = "Prog_ID_DLY";
  v20 = a1 + 11022056;
  if ( v1[2] == v14 )
  {
    sub_7FF91DFE7E20(v1, v14, (__int64)&v19);
    v16 = *(_QWORD *)(a1 + 144);
  }
  else
  {
    v15 = v20;
    *(_OWORD *)v14 = v19;
    *(_QWORD *)(v14 + 16) = v15;
    v1[1] += 24;
    v16 = v1[1];
  }
  v17 = v16 - *v1;
  *(_DWORD *)(a1 + 160) = v17 / 24;
  return (unsigned __int64)((unsigned __int128)(v17 * (__int128)0x2AAAAAAAAAAAAAABLL) >> 64) >> 63;
}


// ==== sub_7FF91DFF8EA0 @ rva 0x398EA0 ====
void __fastcall sub_7FF91DFF8EA0(__int64 a1)
{
  *(_DWORD *)(a1 + 11022344) = 960;
}


// ==== nullsub_78 @ rva 0x398EB0 ====
void nullsub_78()
{
  ;
}


// ==== sub_7FF91DFF8EC0 @ rva 0x398EC0 ====
void __fastcall sub_7FF91DFF8EC0(__int64 a1, float **a2, __int64 a3)
{
  int v4; // eax

  if ( *(_BYTE *)(a1 + 20) )
  {
    v4 = *(_DWORD *)(a1 + 11022344);
    if ( v4 <= 0 )
    {
      **(_DWORD **)a3 = 0;
      **(_DWORD **)(a3 + 8) = 0;
      sub_7FF91DFC3380(a1, a2, (float **)a3);
      sub_7FF91E0224A0((_QWORD *)a1);
    }
    else
    {
      *(_DWORD *)(a1 + 11022344) = v4 - 1;
      **(_DWORD **)a3 = 0;
      **(_DWORD **)(a3 + 8) = 0;
      sub_7FF91E0224A0((_QWORD *)a1);
    }
  }
}


// ==== sub_7FF91DFF8F30 @ rva 0x398F30 ====
void __fastcall sub_7FF91DFF8F30(__int64 a1, int a2, _DWORD **a3)
{
  int v4; // eax

  if ( *(_BYTE *)(a1 + 20) )
  {
    v4 = *(_DWORD *)(a1 + 11022344);
    if ( v4 <= 0 )
    {
      **a3 = 0;
      *a3[1] = 0;
      switch ( a2 )
      {
        case 0:
          sub_7FF91DFC9070(a1, a3);
          sub_7FF91E0224A0((_QWORD *)a1);
          break;
        case 1:
          sub_7FF91DFCCE00(a1, a3);
          sub_7FF91E0224A0((_QWORD *)a1);
          break;
        case 2:
          sub_7FF91DFD0B90(a1, a3);
          sub_7FF91E0224A0((_QWORD *)a1);
          break;
        case 3:
          sub_7FF91DFD4900(a1, a3);
          sub_7FF91E0224A0((_QWORD *)a1);
          break;
        case 4:
          sub_7FF91DFD8690(a1, a3);
          sub_7FF91E0224A0((_QWORD *)a1);
          break;
        case 5:
          sub_7FF91DFDC420(a1, a3);
          sub_7FF91E0224A0((_QWORD *)a1);
          break;
        case 6:
          sub_7FF91DFE0190(a1, a3);
          sub_7FF91E0224A0((_QWORD *)a1);
          break;
        case 7:
          sub_7FF91DFE3F20(a1, a3);
          goto LABEL_13;
        default:
LABEL_13:
          sub_7FF91E0224A0((_QWORD *)a1);
          break;
      }
    }
    else
    {
      *(_DWORD *)(a1 + 11022344) = v4 - 1;
      **a3 = 0;
      *a3[1] = 0;
      sub_7FF91E0224A0((_QWORD *)a1);
    }
  }
}


// ==== sub_7FF91DFF9090 @ rva 0x399090 ====
char sub_7FF91DFF9090()
{
  return 0;
}


// ==== sub_7FF91DFF90A0 @ rva 0x3990A0 ====
char sub_7FF91DFF90A0()
{
  return 0;
}


// ==== sub_7FF91DFF90B0 @ rva 0x3990B0 ====
__int64 sub_7FF91DFF90B0()
{
  return 0;
}


// ==== sub_7FF91DFF90C0 @ rva 0x3990C0 ====
__int64 __fastcall sub_7FF91DFF90C0(__int64 a1)
{
  __int64 result; // rax
  int v2; // xmm6_4
  int v3; // xmm7_4
  int v4; // xmm8_4
  int v5; // xmm9_4
  int v6; // xmm10_4
  int v7; // xmm11_4
  int v8; // xmm0_4
  int v9; // xmm14_4
  int v10; // xmm15_4
  int v11; // xmm1_4
  int v12; // xmm12_4
  int v13; // xmm13_4
  int v14; // xmm4_4
  int v15; // xmm2_4
  int v16; // xmm3_4
  int v17; // [rsp+0h] [rbp-538h]
  int v18; // [rsp+4h] [rbp-534h]
  int v19; // [rsp+8h] [rbp-530h]
  int v20; // [rsp+Ch] [rbp-52Ch]
  int v21; // [rsp+10h] [rbp-528h]
  int v22; // [rsp+14h] [rbp-524h]
  int v23; // [rsp+18h] [rbp-520h]
  int v24; // [rsp+1Ch] [rbp-51Ch]
  int v25; // [rsp+20h] [rbp-518h]
  int v26; // [rsp+24h] [rbp-514h]
  int v27; // [rsp+28h] [rbp-510h]
  int v28; // [rsp+2Ch] [rbp-50Ch]
  int v29; // [rsp+30h] [rbp-508h]
  int v30; // [rsp+34h] [rbp-504h]
  int v31; // [rsp+38h] [rbp-500h]
  int v32; // [rsp+3Ch] [rbp-4FCh]
  int v33; // [rsp+40h] [rbp-4F8h]
  int v34; // [rsp+44h] [rbp-4F4h]
  int v35; // [rsp+48h] [rbp-4F0h]
  int v36; // [rsp+4Ch] [rbp-4ECh]
  int v37; // [rsp+50h] [rbp-4E8h]
  int v38; // [rsp+54h] [rbp-4E4h]
  int v39; // [rsp+58h] [rbp-4E0h]
  int v40; // [rsp+5Ch] [rbp-4DCh]
  int v41; // [rsp+60h] [rbp-4D8h]
  int v42; // [rsp+64h] [rbp-4D4h]
  int v43; // [rsp+68h] [rbp-4D0h]
  int v44; // [rsp+8Ch] [rbp-4ACh]
  int v45; // [rsp+90h] [rbp-4A8h]
  int v46; // [rsp+94h] [rbp-4A4h]
  int v47; // [rsp+98h] [rbp-4A0h]
  int v48; // [rsp+9Ch] [rbp-49Ch]
  int v49; // [rsp+A0h] [rbp-498h]
  int v50; // [rsp+A4h] [rbp-494h]
  int v51; // [rsp+A8h] [rbp-490h]
  int v52; // [rsp+ACh] [rbp-48Ch]
  int v53; // [rsp+B0h] [rbp-488h]
  int v54; // [rsp+B4h] [rbp-484h]
  int v55; // [rsp+B8h] [rbp-480h]
  int v56; // [rsp+BCh] [rbp-47Ch]
  int v57; // [rsp+C0h] [rbp-478h]
  int v58; // [rsp+C4h] [rbp-474h]
  int v59; // [rsp+C8h] [rbp-470h]
  int v60; // [rsp+CCh] [rbp-46Ch]
  int v61; // [rsp+D0h] [rbp-468h]
  int v62; // [rsp+D4h] [rbp-464h]
  int v63; // [rsp+D8h] [rbp-460h]
  int v64; // [rsp+DCh] [rbp-45Ch]
  int v65; // [rsp+E0h] [rbp-458h]
  int v66; // [rsp+E4h] [rbp-454h]
  int v67; // [rsp+E8h] [rbp-450h]
  int v68; // [rsp+ECh] [rbp-44Ch]
  int v69; // [rsp+F0h] [rbp-448h]
  int v70; // [rsp+F4h] [rbp-444h]
  int v71; // [rsp+F8h] [rbp-440h]
  int v72; // [rsp+FCh] [rbp-43Ch]
  int v73; // [rsp+100h] [rbp-438h]
  int v74; // [rsp+104h] [rbp-434h]
  int v75; // [rsp+108h] [rbp-430h]
  int v76; // [rsp+10Ch] [rbp-42Ch]
  int v77; // [rsp+110h] [rbp-428h]
  int v78; // [rsp+114h] [rbp-424h]
  int v79; // [rsp+118h] [rbp-420h]
  int v80; // [rsp+11Ch] [rbp-41Ch]
  int v81; // [rsp+120h] [rbp-418h]
  int v82; // [rsp+124h] [rbp-414h]
  int v83; // [rsp+128h] [rbp-410h]
  int v84; // [rsp+12Ch] [rbp-40Ch]
  int v85; // [rsp+130h] [rbp-408h]
  int v86; // [rsp+134h] [rbp-404h]
  int v87; // [rsp+138h] [rbp-400h]
  int v88; // [rsp+13Ch] [rbp-3FCh]
  int v89; // [rsp+140h] [rbp-3F8h]
  int v90; // [rsp+144h] [rbp-3F4h]
  int v91; // [rsp+148h] [rbp-3F0h]
  int v92; // [rsp+14Ch] [rbp-3ECh]
  int v93; // [rsp+150h] [rbp-3E8h]
  int v94; // [rsp+154h] [rbp-3E4h]
  int v95; // [rsp+158h] [rbp-3E0h]
  int v96; // [rsp+15Ch] [rbp-3DCh]
  int v97; // [rsp+160h] [rbp-3D8h]
  int v98; // [rsp+164h] [rbp-3D4h]
  int v99; // [rsp+168h] [rbp-3D0h]
  int v100; // [rsp+16Ch] [rbp-3CCh]
  int v101; // [rsp+170h] [rbp-3C8h]
  int v102; // [rsp+174h] [rbp-3C4h]
  int v103; // [rsp+178h] [rbp-3C0h]
  int v104; // [rsp+17Ch] [rbp-3BCh]
  int v105; // [rsp+180h] [rbp-3B8h]
  int v106; // [rsp+184h] [rbp-3B4h]
  int v107; // [rsp+188h] [rbp-3B0h]
  int v108; // [rsp+18Ch] [rbp-3ACh]
  int v109; // [rsp+190h] [rbp-3A8h]
  int v110; // [rsp+194h] [rbp-3A4h]
  int v111; // [rsp+198h] [rbp-3A0h]
  int v112; // [rsp+19Ch] [rbp-39Ch]
  int v113; // [rsp+1A0h] [rbp-398h]
  int v114; // [rsp+1A4h] [rbp-394h]
  int v115; // [rsp+1A8h] [rbp-390h]
  int v116; // [rsp+1ACh] [rbp-38Ch]
  int v117; // [rsp+1B0h] [rbp-388h]
  int v118; // [rsp+1B4h] [rbp-384h]
  int v119; // [rsp+1B8h] [rbp-380h]
  int v120; // [rsp+1BCh] [rbp-37Ch]
  int v121; // [rsp+1C0h] [rbp-378h]
  int v122; // [rsp+1C4h] [rbp-374h]
  int v123; // [rsp+1C8h] [rbp-370h]
  int v124; // [rsp+1CCh] [rbp-36Ch]
  int v125; // [rsp+1D0h] [rbp-368h]
  int v126; // [rsp+1D4h] [rbp-364h]
  int v127; // [rsp+1D8h] [rbp-360h]
  int v128; // [rsp+1DCh] [rbp-35Ch]
  int v129; // [rsp+1E0h] [rbp-358h]
  int v130; // [rsp+1E4h] [rbp-354h]
  int v131; // [rsp+1E8h] [rbp-350h]
  int v132; // [rsp+1ECh] [rbp-34Ch]
  int v133; // [rsp+1F0h] [rbp-348h]
  int v134; // [rsp+1F4h] [rbp-344h]
  int v135; // [rsp+1F8h] [rbp-340h]
  int v136; // [rsp+1FCh] [rbp-33Ch]
  int v137; // [rsp+200h] [rbp-338h]
  int v138; // [rsp+204h] [rbp-334h]
  int v139; // [rsp+208h] [rbp-330h]
  int v140; // [rsp+20Ch] [rbp-32Ch]
  int v141; // [rsp+210h] [rbp-328h]
  int v142; // [rsp+214h] [rbp-324h]
  int v143; // [rsp+218h] [rbp-320h]
  int v144; // [rsp+21Ch] [rbp-31Ch]
  int v145; // [rsp+220h] [rbp-318h]
  int v146; // [rsp+224h] [rbp-314h]
  int v147; // [rsp+228h] [rbp-310h]
  int v148; // [rsp+22Ch] [rbp-30Ch]
  int v149; // [rsp+230h] [rbp-308h]
  int v150; // [rsp+234h] [rbp-304h]
  int v151; // [rsp+238h] [rbp-300h]
  int v152; // [rsp+23Ch] [rbp-2FCh]
  int v153; // [rsp+240h] [rbp-2F8h]
  int v154; // [rsp+244h] [rbp-2F4h]
  int v155; // [rsp+248h] [rbp-2F0h]
  int v156; // [rsp+24Ch] [rbp-2ECh]
  int v157; // [rsp+250h] [rbp-2E8h]
  int v158; // [rsp+254h] [rbp-2E4h]
  int v159; // [rsp+258h] [rbp-2E0h]
  int v160; // [rsp+25Ch] [rbp-2DCh]
  int v161; // [rsp+260h] [rbp-2D8h]
  int v162; // [rsp+264h] [rbp-2D4h]
  int v163; // [rsp+268h] [rbp-2D0h]
  int v164; // [rsp+26Ch] [rbp-2CCh]
  int v165; // [rsp+270h] [rbp-2C8h]
  int v166; // [rsp+274h] [rbp-2C4h]
  int v167; // [rsp+278h] [rbp-2C0h]
  int v168; // [rsp+27Ch] [rbp-2BCh]
  int v169; // [rsp+280h] [rbp-2B8h]
  int v170; // [rsp+284h] [rbp-2B4h]
  int v171; // [rsp+288h] [rbp-2B0h]
  int v172; // [rsp+28Ch] [rbp-2ACh]
  int v173; // [rsp+290h] [rbp-2A8h]
  int v174; // [rsp+294h] [rbp-2A4h]
  int v175; // [rsp+298h] [rbp-2A0h]
  int v176; // [rsp+29Ch] [rbp-29Ch]
  int v177; // [rsp+2A0h] [rbp-298h]
  int v178; // [rsp+2A4h] [rbp-294h]
  int v179; // [rsp+2A8h] [rbp-290h]
  int v180; // [rsp+2ACh] [rbp-28Ch]
  int v181; // [rsp+2B0h] [rbp-288h]
  int v182; // [rsp+2B4h] [rbp-284h]
  int v183; // [rsp+2B8h] [rbp-280h]
  int v184; // [rsp+2BCh] [rbp-27Ch]
  int v185; // [rsp+2C0h] [rbp-278h]
  int v186; // [rsp+2C4h] [rbp-274h]
  int v187; // [rsp+2C8h] [rbp-270h]
  int v188; // [rsp+2CCh] [rbp-26Ch]
  int v189; // [rsp+2D0h] [rbp-268h]
  int v190; // [rsp+2D4h] [rbp-264h]
  int v191; // [rsp+2D8h] [rbp-260h]
  int v192; // [rsp+2DCh] [rbp-25Ch]
  int v193; // [rsp+2E0h] [rbp-258h]
  int v194; // [rsp+2E4h] [rbp-254h]
  int v195; // [rsp+2E8h] [rbp-250h]
  int v196; // [rsp+2ECh] [rbp-24Ch]
  int v197; // [rsp+2F0h] [rbp-248h]
  int v198; // [rsp+2F4h] [rbp-244h]
  int v199; // [rsp+2F8h] [rbp-240h]
  int v200; // [rsp+2FCh] [rbp-23Ch]
  int v201; // [rsp+300h] [rbp-238h]
  int v202; // [rsp+304h] [rbp-234h]
  int v203; // [rsp+308h] [rbp-230h]
  int v204; // [rsp+30Ch] [rbp-22Ch]
  int v205; // [rsp+310h] [rbp-228h]
  int v206; // [rsp+314h] [rbp-224h]
  int v207; // [rsp+318h] [rbp-220h]
  int v208; // [rsp+31Ch] [rbp-21Ch]
  int v209; // [rsp+320h] [rbp-218h]
  int v210; // [rsp+324h] [rbp-214h]
  int v211; // [rsp+328h] [rbp-210h]
  int v212; // [rsp+32Ch] [rbp-20Ch]
  int v213; // [rsp+330h] [rbp-208h]
  int v214; // [rsp+334h] [rbp-204h]
  int v215; // [rsp+338h] [rbp-200h]
  int v216; // [rsp+33Ch] [rbp-1FCh]
  int v217; // [rsp+340h] [rbp-1F8h]
  int v218; // [rsp+344h] [rbp-1F4h]
  int v219; // [rsp+348h] [rbp-1F0h]
  int v220; // [rsp+34Ch] [rbp-1ECh]
  int v221; // [rsp+350h] [rbp-1E8h]
  int v222; // [rsp+354h] [rbp-1E4h]
  int v223; // [rsp+358h] [rbp-1E0h]
  int v224; // [rsp+35Ch] [rbp-1DCh]
  int v225; // [rsp+360h] [rbp-1D8h]
  int v226; // [rsp+364h] [rbp-1D4h]
  int v227; // [rsp+368h] [rbp-1D0h]
  int v228; // [rsp+36Ch] [rbp-1CCh]
  int v229; // [rsp+370h] [rbp-1C8h]
  int v230; // [rsp+374h] [rbp-1C4h]
  int v231; // [rsp+378h] [rbp-1C0h]
  int v232; // [rsp+37Ch] [rbp-1BCh]
  int v233; // [rsp+380h] [rbp-1B8h]
  int v234; // [rsp+384h] [rbp-1B4h]
  int v235; // [rsp+388h] [rbp-1B0h]
  int v236; // [rsp+38Ch] [rbp-1ACh]
  int v237; // [rsp+390h] [rbp-1A8h]
  int v238; // [rsp+394h] [rbp-1A4h]
  int v239; // [rsp+398h] [rbp-1A0h]
  int v240; // [rsp+39Ch] [rbp-19Ch]
  int v241; // [rsp+3A0h] [rbp-198h]
  int v242; // [rsp+3A4h] [rbp-194h]
  int v243; // [rsp+3A8h] [rbp-190h]
  int v244; // [rsp+3ACh] [rbp-18Ch]
  int v245; // [rsp+3B0h] [rbp-188h]
  int v246; // [rsp+3B4h] [rbp-184h]
  int v247; // [rsp+3B8h] [rbp-180h]
  int v248; // [rsp+3BCh] [rbp-17Ch]
  int v249; // [rsp+3C0h] [rbp-178h]
  int v250; // [rsp+3C4h] [rbp-174h]
  int v251; // [rsp+3C8h] [rbp-170h]
  int v252; // [rsp+3CCh] [rbp-16Ch]
  int v253; // [rsp+3D0h] [rbp-168h]
  int v254; // [rsp+3D4h] [rbp-164h]
  int v255; // [rsp+3D8h] [rbp-160h]
  int v256; // [rsp+3DCh] [rbp-15Ch]
  int v257; // [rsp+3E0h] [rbp-158h]
  int v258; // [rsp+3E4h] [rbp-154h]
  int v259; // [rsp+3E8h] [rbp-150h]
  int v260; // [rsp+3ECh] [rbp-14Ch]
  int v261; // [rsp+3F0h] [rbp-148h]
  int v262; // [rsp+3F4h] [rbp-144h]
  int v263; // [rsp+3F8h] [rbp-140h]
  int v264; // [rsp+3FCh] [rbp-13Ch]
  int v265; // [rsp+400h] [rbp-138h]
  int v266; // [rsp+404h] [rbp-134h]
  int v267; // [rsp+408h] [rbp-130h]
  int v268; // [rsp+40Ch] [rbp-12Ch]
  int v269; // [rsp+410h] [rbp-128h]
  int v270; // [rsp+414h] [rbp-124h]
  int v271; // [rsp+418h] [rbp-120h]
  int v272; // [rsp+41Ch] [rbp-11Ch]
  int v273; // [rsp+420h] [rbp-118h]
  int v274; // [rsp+424h] [rbp-114h]
  int v275; // [rsp+428h] [rbp-110h]
  int v276; // [rsp+42Ch] [rbp-10Ch]
  int v277; // [rsp+430h] [rbp-108h]
  int v278; // [rsp+434h] [rbp-104h]
  int v279; // [rsp+438h] [rbp-100h]
  int v280; // [rsp+43Ch] [rbp-FCh]
  int v281; // [rsp+440h] [rbp-F8h]
  int v282; // [rsp+444h] [rbp-F4h]
  int v283; // [rsp+448h] [rbp-F0h]
  int v284; // [rsp+44Ch] [rbp-ECh]
  int v285; // [rsp+450h] [rbp-E8h]
  int v286; // [rsp+454h] [rbp-E4h]
  int v287; // [rsp+458h] [rbp-E0h]
  int v288; // [rsp+45Ch] [rbp-DCh]
  int v289; // [rsp+460h] [rbp-D8h]
  int v290; // [rsp+464h] [rbp-D4h]
  int v291; // [rsp+468h] [rbp-D0h]
  int v292; // [rsp+46Ch] [rbp-CCh]
  int v293; // [rsp+470h] [rbp-C8h]
  int v294; // [rsp+474h] [rbp-C4h]
  int v295; // [rsp+478h] [rbp-C0h]
  int v296; // [rsp+47Ch] [rbp-BCh]
  int v297; // [rsp+540h] [rbp+8h]
  int v298; // [rsp+548h] [rbp+10h]
  int v299; // [rsp+550h] [rbp+18h]
  int v300; // [rsp+558h] [rbp+20h]

  result = (unsigned int)(int)*(float *)(a1 + 16);
  if ( (_DWORD)result == 44100 )
  {
    v292 = 1006658356;
    v295 = 1025859584;
    v296 = 1031639859;
    v2 = 1064762360;
    v3 = -1083601980;
    v4 = 1065793560;
    v5 = 1057929808;
    v6 = -1070054672;
    v7 = 1079284828;
    v271 = 1023410176;
    v270 = 1076642816;
    v269 = 898766424;
    v291 = 989862803;
    v290 = 973085588;
    v289 = 1000365617;
    v288 = 1063520739;
    v287 = -1083046671;
    v286 = 1064436977;
    v285 = -1098698120;
    v284 = 1064127740;
    v282 = 1034459265;
    v283 = 1042847873;
    v281 = 1065315014;
    v280 = -1082149533;
    v279 = 1065334115;
    v278 = -1094300355;
    v277 = 1059488386;
    v275 = 1044161564;
    v276 = 1052550172;
    v274 = 1055544028;
    v273 = -1086679881;
    v272 = 1060803767;
    v268 = 1057675886;
    v267 = 1065281658;
    v266 = -1082166211;
    v265 = 1065317437;
    v264 = -1095952137;
    v263 = 1044865988;
    v261 = 1049778629;
    v262 = 1058167237;
    v294 = 1017346030;
    v293 = 977156038;
    v28 = 1059947129;
    v258 = 1063124992;
    v257 = -1128267776;
    v256 = 1042284544;
    v255 = -1094916096;
    v254 = -1126268928;
    v253 = 1052637184;
    v216 = 1065091072;
    v250 = 1063518208;
    v249 = -1114636288;
    v248 = 1036517376;
    v247 = -1088389120;
    v246 = 1067663360;
    v245 = 1048788992;
    v244 = -1079820288;
    v243 = 1068457984;
    v242 = 1013972992;
    v240 = -1090610586;
    v239 = 1056873062;
    v238 = -1094076416;
    v237 = -1102729216;
    v236 = 1037205504;
    v235 = 1043447808;
    v234 = 1057402880;
    v232 = 1065312256;
    v231 = -1098907648;
    v230 = 1048576000;
    v229 = -1083490304;
    v228 = 1072914432;
    v227 = 1048182784;
    v260 = -1120070302;
    v226 = -1080459264;
    v259 = 1027413346;
    v225 = 1064787968;
    v26 = 1048901991;
    v213 = 1042933686;
    v252 = 1030786113;
    v251 = 1015026523;
    v241 = 1065287680;
    v233 = 973078528;
    v215 = -1065484288;
    v214 = 1081999360;
    v212 = 1030786113;
    v199 = 1030786113;
    v197 = 1063387136;
    v195 = 1034133504;
    v27 = -1082261504;
    v193 = -1082261504;
    v190 = 1064435712;
    v189 = -1074566136;
    v188 = 1072917512;
    v187 = 1063780352;
    v219 = -1094915072;
    v186 = -1065746432;
    v218 = -1134706354;
    v185 = 1081737216;
    v217 = 1044218654;
    v184 = 1065353216;
    v182 = 1065353216;
    v209 = -1115588437;
    v22 = 1021299906;
    v210 = 1065287680;
    v208 = 1031895211;
    v194 = 1065287680;
    v21 = 1007467008;
    v224 = 1063649280;
    v206 = 1006632960;
    v18 = 1006658378;
    v20 = 1023434152;
    v222 = 1038090240;
    v205 = 1035780096;
    v17 = 1093032477;
    v19 = 1016514268;
    v8 = 1006087669;
    v211 = 1015026523;
    v203 = -1065484288;
    v9 = 976928503;
    v202 = 1081999360;
    v10 = 1005153941;
    v198 = 1015026523;
    v11 = 1067930805;
    v223 = 0;
    v221 = 1065222144;
    v220 = 1065222144;
    v207 = 973078528;
    v204 = 1065222144;
    v201 = 1048901991;
    v200 = 1042933686;
    v196 = 0;
    v192 = 1065222144;
    v191 = 973078528;
    v183 = 0;
    v300 = 1000564493;
    v12 = 0x40000000;
    v13 = 1060440002;
    v14 = 969806273;
    v23 = 1074483674;
    v297 = 1018806884;
    v173 = 1021299906;
    v172 = 1007467008;
    v171 = 1023434152;
    v170 = 1016514268;
    v169 = 1006658378;
    v168 = 1093032477;
    v167 = 1000564493;
    v299 = 1031798784;
    v15 = 1046113595;
    v166 = 1031798784;
    v298 = 1000568814;
    v16 = 1049716469;
    v162 = 1000568814;
    v160 = 1074483674;
    v159 = 1018806884;
    v150 = 1021299906;
    v149 = 1007467008;
    v148 = 1023434152;
    v147 = 1016514268;
    v146 = 1006658378;
    v145 = 1093032477;
    v144 = 1000564493;
    v143 = 1031798784;
    v139 = 1000568814;
    v137 = 1074483674;
    v25 = 0x40000000;
    v24 = 1060440002;
    v181 = 1064762360;
    v180 = -1083601980;
    v179 = 1065793560;
    v178 = 1057929808;
    v177 = -1070054672;
    v176 = 1079284828;
    v175 = 976928503;
    v174 = 1005153941;
    v165 = 0x40000000;
    v164 = 0x40000000;
    v163 = 1060440002;
    v161 = 1060440002;
    v158 = 1064762360;
    v157 = -1083601980;
    v156 = 1065793560;
    v155 = 1057929808;
    v154 = -1070054672;
    v153 = 1079284828;
    v152 = 976928503;
    v151 = 1005153941;
    v142 = 0x40000000;
    v141 = 0x40000000;
    v140 = 1060440002;
    v138 = 1060440002;
    v136 = 1018806884;
    v127 = 1021299906;
    v126 = 1007467008;
    v125 = 1023434152;
    v124 = 1016514268;
    v123 = 1006658378;
    v122 = 1093032477;
    v121 = 1000564493;
    v120 = 1031798784;
    v116 = 1000568814;
    v114 = 1074483674;
    v113 = 1018806884;
    v104 = 1021299906;
    v103 = 1007467008;
    v102 = 1023434152;
    v101 = 1016514268;
    v100 = 1006658378;
    v99 = 1093032477;
    v98 = 1000564493;
    v97 = 1031798784;
    v93 = 1000568814;
    v91 = 1074483674;
    v90 = 1018806884;
    v81 = 1021299906;
    v135 = 1064762360;
    v134 = -1083601980;
    v133 = 1065793560;
    v132 = 1057929808;
    v131 = -1070054672;
    v130 = 1079284828;
    v129 = 976928503;
    v128 = 1005153941;
    v119 = 0x40000000;
    v118 = 0x40000000;
    v117 = 1060440002;
    v115 = 1060440002;
    v112 = 1064762360;
    v111 = -1083601980;
    v110 = 1065793560;
    v109 = 1057929808;
    v108 = -1070054672;
    v107 = 1079284828;
    v106 = 976928503;
    v105 = 1005153941;
    v96 = 0x40000000;
    v95 = 0x40000000;
    v94 = 1060440002;
    v92 = 1060440002;
    v89 = 1064762360;
    v88 = -1083601980;
    v87 = 1065793560;
    v86 = 1057929808;
    v85 = -1070054672;
    v84 = 1079284828;
    v83 = 976928503;
    v82 = 1005153941;
    v80 = 1007467008;
    v79 = 1023434152;
    v78 = 1016514268;
    v77 = 1006658378;
    v76 = 1093032477;
    v75 = 1000564493;
    v74 = 1031798784;
    v70 = 1000568814;
    v68 = 1074483674;
    v67 = 1018806884;
    v58 = 1021299906;
    v57 = 1007467008;
    v56 = 1023434152;
    v55 = 1016514268;
    v54 = 1006658378;
    v53 = 1093032477;
    v52 = 1000564493;
    v51 = 1031798784;
    v47 = 1000568814;
    v45 = 1074483674;
    v44 = 1018806884;
    v43 = 1021299906;
    v42 = 1007467008;
    v41 = 1023434152;
    v40 = 1016514268;
    v39 = 1006658378;
    v38 = 1093032477;
    v37 = 1000564493;
    v36 = 1031798784;
    v32 = 1000568814;
    v30 = 1074483674;
    v73 = 0x40000000;
    v72 = 0x40000000;
    v71 = 1060440002;
    v69 = 1060440002;
    v66 = 1064762360;
    v65 = -1083601980;
    v64 = 1065793560;
    v63 = 1057929808;
    v62 = -1070054672;
    v61 = 1079284828;
    v60 = 976928503;
    v59 = 1005153941;
    v50 = 0x40000000;
    v49 = 0x40000000;
    v48 = 1060440002;
    v46 = 1060440002;
    v35 = 0x40000000;
    v34 = 0x40000000;
    v33 = 1060440002;
    v31 = 1060440002;
    v29 = 1018806884;
  }
  else
  {
    v292 = 996927900;
    v295 = 1035206656;
    v296 = 1040842752;
    v2 = 1065079548;
    v3 = -1082812016;
    v4 = 1065557172;
    v5 = 1061484384;
    v6 = -1067841472;
    v7 = 1080609384;
    v271 = 1031798784;
    v270 = 1086029824;
    v269 = 889599933;
    v291 = 980116959;
    v290 = 963339744;
    v289 = 991123089;
    v288 = 1064486552;
    v287 = -1082563764;
    v286 = 1064919884;
    v285 = -1089730274;
    v284 = 1069197545;
    v282 = 1018542693;
    v283 = 1026931301;
    v281 = 1065335656;
    v280 = -1082139212;
    v279 = 1065344436;
    v278 = -1088593801;
    v277 = 1068868653;
    v275 = 1028153461;
    v276 = 1036542069;
    v274 = 1060598383;
    v273 = -1084507849;
    v272 = 1062975799;
    v268 = 1048631502;
    v267 = 1065320306;
    v266 = -1082146887;
    v265 = 1065336761;
    v264 = -1089960448;
    v263 = 1067168884;
    v261 = 1034041905;
    v262 = 1042430513;
    v294 = 1008086985;
    v293 = 967754558;
    v28 = 1065353216;
    v258 = 1064292352;
    v257 = -1115930624;
    v256 = 1040162816;
    v254 = -1100587008;
    v253 = 1055494144;
    v216 = 1065232384;
    v215 = -1065413632;
    v214 = 1082070016;
    v250 = 1064484864;
    v249 = -1113202688;
    v248 = 1036017664;
    v247 = -1085390848;
    v246 = 1071399936;
    v245 = 1058853460;
    v244 = -1076083900;
    v243 = 1066970693;
    v242 = 1004306479;
    v240 = -1090592768;
    v239 = 1056890880;
    v238 = -1090078720;
    v237 = 1066017792;
    v236 = 1041054948;
    v235 = -1094519593;
    v234 = 1055921370;
    v232 = 1065334784;
    v231 = -1098901504;
    v230 = 1048582144;
    v229 = -1082771456;
    v228 = 1073390592;
    v227 = 1055255824;
    v260 = -1120059392;
    v226 = -1080159304;
    v259 = 1027424256;
    v225 = 1061803129;
    v26 = 1043810503;
    v213 = 1041424828;
    v252 = 1036745141;
    v251 = 1033908547;
    v241 = 1065323520;
    v233 = 963326771;
    v255 = 1034084352;
    v212 = 1036745141;
    v199 = 1036745141;
    v197 = 1064421376;
    v196 = -1128857600;
    v195 = 1031176192;
    v193 = -1082244096;
    v192 = 1065239552;
    v190 = 1064925184;
    v189 = -1074326528;
    v188 = 1073157120;
    v187 = 1064612864;
    v186 = -1065336832;
    v185 = 1082146816;
    v219 = 1034084352;
    v184 = 0;
    v218 = -1109008384;
    v224 = 1064549376;
    v182 = 1069341347;
    v217 = 1047068672;
    v223 = -1124532224;
    v22 = 1011719939;
    v209 = -1115578368;
    v222 = 1034420224;
    v21 = 998329080;
    v208 = 1031905280;
    v221 = 1065292800;
    v204 = 1065292800;
    v20 = 1013702475;
    v27 = -1082225664;
    v206 = 996881232;
    v210 = 1065323520;
    v203 = -1065449472;
    v194 = 1065323520;
    v19 = 1007322905;
    v8 = 996380217;
    v220 = 1065257984;
    v10 = 995522378;
    v211 = 1033908547;
    v205 = 1026390485;
    v9 = 967545510;
    v198 = 1033908547;
    v11 = 1059361719;
    v207 = 963326771;
    v202 = 1082034176;
    v201 = 1043810503;
    v200 = 1041424828;
    v191 = 963326771;
    v183 = 1065353216;
    v18 = 996927908;
    v13 = 1065353216;
    v14 = 960320387;
    v297 = 1009429091;
    v173 = 1011719939;
    v172 = 998329080;
    v171 = 1013702475;
    v170 = 1007322905;
    v169 = 996927908;
    v17 = 1093664768;
    v168 = 1093664768;
    v25 = 1068826100;
    v300 = 991305807;
    v167 = 991305807;
    v299 = 1035786915;
    v15 = 1036581680;
    v166 = 1035786915;
    v164 = 1068826100;
    v298 = 991309769;
    v162 = 991309769;
    v24 = 1051277267;
    v16 = 1040577043;
    v161 = 1051277267;
    v159 = 1009429091;
    v150 = 1011719939;
    v149 = 998329080;
    v148 = 1013702475;
    v147 = 1007322905;
    v146 = 996927908;
    v145 = 1093664768;
    v144 = 991305807;
    v143 = 1035786915;
    v23 = 1065353216;
    v181 = 1065079548;
    v180 = -1082812016;
    v179 = 1065557172;
    v178 = 1061484384;
    v177 = -1067841472;
    v176 = 1080609384;
    v175 = 967545510;
    v174 = 995522378;
    v165 = 1065353216;
    v163 = 1065353216;
    v160 = 1065353216;
    v158 = 1065079548;
    v157 = -1082812016;
    v156 = 1065557172;
    v155 = 1061484384;
    v154 = -1067841472;
    v153 = 1080609384;
    v152 = 967545510;
    v151 = 995522378;
    v142 = 1065353216;
    v141 = 1068826100;
    v139 = 991309769;
    v138 = 1051277267;
    v136 = 1009429091;
    v127 = 1011719939;
    v126 = 998329080;
    v125 = 1013702475;
    v124 = 1007322905;
    v123 = 996927908;
    v122 = 1093664768;
    v121 = 991305807;
    v120 = 1035786915;
    v118 = 1068826100;
    v116 = 991309769;
    v115 = 1051277267;
    v113 = 1009429091;
    v104 = 1011719939;
    v103 = 998329080;
    v102 = 1013702475;
    v101 = 1007322905;
    v100 = 996927908;
    v99 = 1093664768;
    v98 = 991305807;
    v97 = 1035786915;
    v95 = 1068826100;
    v93 = 991309769;
    v92 = 1051277267;
    v90 = 1009429091;
    v140 = 1065353216;
    v137 = 1065353216;
    v135 = 1065079548;
    v134 = -1082812016;
    v133 = 1065557172;
    v132 = 1061484384;
    v131 = -1067841472;
    v130 = 1080609384;
    v129 = 967545510;
    v128 = 995522378;
    v119 = 1065353216;
    v117 = 1065353216;
    v114 = 1065353216;
    v112 = 1065079548;
    v111 = -1082812016;
    v110 = 1065557172;
    v109 = 1061484384;
    v108 = -1067841472;
    v107 = 1080609384;
    v106 = 967545510;
    v105 = 995522378;
    v96 = 1065353216;
    v94 = 1065353216;
    v91 = 1065353216;
    v89 = 1065079548;
    v88 = -1082812016;
    v81 = 1011719939;
    v80 = 998329080;
    v79 = 1013702475;
    v78 = 1007322905;
    v77 = 996927908;
    v76 = 1093664768;
    v75 = 991305807;
    v74 = 1035786915;
    v72 = 1068826100;
    v70 = 991309769;
    v69 = 1051277267;
    v67 = 1009429091;
    v58 = 1011719939;
    v57 = 998329080;
    v56 = 1013702475;
    v55 = 1007322905;
    v54 = 996927908;
    v53 = 1093664768;
    v52 = 991305807;
    v51 = 1035786915;
    v49 = 1068826100;
    v47 = 991309769;
    v46 = 1051277267;
    v44 = 1009429091;
    v43 = 1011719939;
    v42 = 998329080;
    v41 = 1013702475;
    v40 = 1007322905;
    v39 = 996927908;
    v38 = 1093664768;
    v87 = 1065557172;
    v86 = 1061484384;
    v85 = -1067841472;
    v84 = 1080609384;
    v83 = 967545510;
    v82 = 995522378;
    v73 = 1065353216;
    v71 = 1065353216;
    v68 = 1065353216;
    v66 = 1065079548;
    v65 = -1082812016;
    v64 = 1065557172;
    v63 = 1061484384;
    v62 = -1067841472;
    v61 = 1080609384;
    v60 = 967545510;
    v59 = 995522378;
    v50 = 1065353216;
    v48 = 1065353216;
    v45 = 1065353216;
    v37 = 991305807;
    v36 = 1035786915;
    v34 = 1068826100;
    v32 = 991309769;
    v31 = 1051277267;
    v29 = 1009429091;
    v12 = 1065353216;
    v35 = 1065353216;
    v33 = 1065353216;
    v30 = 1065353216;
  }
  *(_DWORD *)(a1 + 544) = v29;
  *(_DWORD *)(a1 + 768) = 1132462080;
  *(_DWORD *)(a1 + 784) = 805306368;
  *(_DWORD *)(a1 + 800) = 872415232;
  *(_DWORD *)(a1 + 816) = 1028443341;
  *(_DWORD *)(a1 + 832) = 814313567;
  *(_DWORD *)(a1 + 848) = 1065353216;
  *(_DWORD *)(a1 + 864) = 1065353216;
  *(_DWORD *)(a1 + 1152) = 1023805706;
  *(_DWORD *)(a1 + 1168) = -1046478848;
  *(_DWORD *)(a1 + 1184) = 1055831741;
  *(_DWORD *)(a1 + 1200) = 1084821962;
  *(_DWORD *)(a1 + 1216) = -1093425406;
  *(_DWORD *)(a1 + 1232) = 1065353216;
  *(_DWORD *)(a1 + 1248) = 0x40000000;
  *(_DWORD *)(a1 + 1264) = 1059760811;
  *(_DWORD *)(a1 + 1280) = 1059760811;
  *(_DWORD *)(a1 + 1296) = 1040746633;
  *(_DWORD *)(a1 + 1312) = 1035340641;
  *(_DWORD *)(a1 + 1328) = 1011879169;
  *(_DWORD *)(a1 + 1344) = 1003490561;
  *(_DWORD *)(a1 + 1360) = 976809758;
  *(_DWORD *)(a1 + 1376) = 965997180;
  *(_DWORD *)(a1 + 1392) = 936849986;
  *(_DWORD *)(a1 + 2128) = 1014923857;
  *(_DWORD *)(a1 + 2144) = v30;
  *(_DWORD *)(a1 + 2160) = 993063548;
  *(_DWORD *)(a1 + 2176) = 1039798161;
  *(_DWORD *)(a1 + 2192) = 1074365517;
  *(_DWORD *)(a1 + 2208) = -1084150409;
  *(_DWORD *)(a1 + 2224) = -1094106009;
  *(_DWORD *)(a1 + 2240) = -1090489680;
  *(_DWORD *)(a1 + 2256) = 1076754517;
  *(_DWORD *)(a1 + 2272) = -1088302417;
  *(_DWORD *)(a1 + 2288) = -1082130432;
  *(_DWORD *)(a1 + 2304) = 0;
  *(_DWORD *)(a1 + 2320) = -1090519040;
  *(_DWORD *)(a1 + 2336) = 0;
  *(_DWORD *)(a1 + 2352) = 1056964608;
  *(_DWORD *)(a1 + 2368) = 1065353216;
  *(_DWORD *)(a1 + 2384) = 1065353216;
  *(_DWORD *)(a1 + 2400) = 0x40000000;
  *(_DWORD *)(a1 + 2416) = 1065353216;
  *(_DWORD *)(a1 + 2432) = 1056964608;
  *(_DWORD *)(a1 + 2448) = 1096810496;
  *(_DWORD *)(a1 + 2464) = 1013491486;
  *(_DWORD *)(a1 + 2480) = -1090519040;
  *(_DWORD *)(a1 + 2496) = 0;
  *(_DWORD *)(a1 + 2512) = 0;
  *(_DWORD *)(a1 + 2864) = -1090519040;
  *(_DWORD *)(a1 + 2880) = -1056178176;
  *(_DWORD *)(a1 + 2896) = 1094451200;
  *(_DWORD *)(a1 + 2912) = 1097596928;
  *(_DWORD *)(a1 + 2928) = 1091305472;
  *(_DWORD *)(a1 + 2944) = 1090676326;
  *(_DWORD *)(a1 + 2960) = v14;
  *(_DWORD *)(a1 + 2976) = v16;
  *(_DWORD *)(a1 + 2992) = 1038749345;
  *(_DWORD *)(a1 + 3008) = 1065353216;
  *(_DWORD *)(a1 + 3024) = 1065353216;
  *(_DWORD *)(a1 + 3344) = -1090519040;
  *(_DWORD *)(a1 + 3360) = -1056178176;
  *(_DWORD *)(a1 + 3376) = 1094451200;
  *(_DWORD *)(a1 + 3392) = 1097596928;
  *(_DWORD *)(a1 + 3408) = 1091305472;
  *(_DWORD *)(a1 + 3424) = 1090676326;
  *(_DWORD *)(a1 + 3440) = v14;
  *(_DWORD *)(a1 + 3456) = v16;
  *(_DWORD *)(a1 + 3472) = 1038749345;
  *(_DWORD *)(a1 + 3488) = 1065353216;
  *(_DWORD *)(a1 + 3504) = 1065353216;
  *(_DWORD *)(a1 + 3584) = 1065353216;
  *(_DWORD *)(a1 + 3600) = 1065353216;
  *(_DWORD *)(a1 + 4160) = 1056964608;
  *(_DWORD *)(a1 + 4176) = 1056964608;
  *(_DWORD *)(a1 + 4336) = v31;
  *(_DWORD *)(a1 + 4352) = 0x40000000;
  *(_DWORD *)(a1 + 4368) = -1097229926;
  *(_DWORD *)(a1 + 4384) = 0;
  *(_DWORD *)(a1 + 4400) = 1067030938;
  *(_DWORD *)(a1 + 4432) = 1060205080;
  *(_DWORD *)(a1 + 4448) = -1063780352;
  *(_DWORD *)(a1 + 4464) = 1065353216;
  *(_DWORD *)(a1 + 4480) = 0x40000000;
  *(_DWORD *)(a1 + 4496) = 1059760811;
  *(_DWORD *)(a1 + 4512) = 1059760811;
  *(_DWORD *)(a1 + 4528) = 1040746633;
  *(_DWORD *)(a1 + 4544) = 1035340641;
  *(_DWORD *)(a1 + 4560) = 1011879169;
  *(_DWORD *)(a1 + 4576) = 1003490561;
  *(_DWORD *)(a1 + 4592) = 976809758;
  *(_DWORD *)(a1 + 4608) = 965997180;
  *(_DWORD *)(a1 + 4624) = 936849986;
  *(_DWORD *)(a1 + 5536) = v32;
  *(_DWORD *)(a1 + 5552) = 1070141403;
  *(_DWORD *)(a1 + 5568) = 796917760;
  *(_DWORD *)(a1 + 5584) = -1146890486;
  *(_DWORD *)(a1 + 5600) = 1045220557;
  *(_DWORD *)(a1 + 5616) = 1036831949;
  *(_DWORD *)(a1 + 5632) = 1036831949;
  *(_DWORD *)(a1 + 5648) = 1065353216;
  *(_DWORD *)(a1 + 5664) = 1062836634;
  *(_DWORD *)(a1 + 5680) = 1062836634;
  *(_DWORD *)(a1 + 5696) = -1171962351;
  *(_DWORD *)(a1 + 5712) = -1158783739;
  *(_DWORD *)(a1 + 5728) = -1155013057;
  *(_DWORD *)(a1 + 5744) = -1160768650;
  *(_DWORD *)(a1 + 5760) = 991644115;
  *(_DWORD *)(a1 + 5776) = 1007191303;
  *(_DWORD *)(a1 + 5792) = 1010918385;
  *(_DWORD *)(a1 + 5808) = 1004371223;
  *(_DWORD *)(a1 + 5824) = -1139388239;
  *(_DWORD *)(a1 + 5840) = -1124889029;
  *(_DWORD *)(a1 + 5856) = -1121773932;
  *(_DWORD *)(a1 + 5872) = -1128877582;
  *(_DWORD *)(a1 + 5888) = 1023290972;
  *(_DWORD *)(a1 + 5904) = 1038327604;
  *(_DWORD *)(a1 + 5920) = 1044714247;
  *(_DWORD *)(a1 + 5936) = 1048155241;
  *(_DWORD *)(a1 + 5952) = -1104500053;
  *(_DWORD *)(a1 + 5968) = 1007192200;
  *(_DWORD *)(a1 + 5984) = -1185936127;
  *(_DWORD *)(a1 + 6000) = 909700753;
  *(_DWORD *)(a1 + 6016) = -1294492804;
  *(_DWORD *)(a1 + 6032) = 1060205080;
  *(_DWORD *)(a1 + 6048) = -1063780352;
  *(_DWORD *)(a1 + 6064) = -1068320896;
  *(_DWORD *)(a1 + 6080) = 1065353216;
  *(_DWORD *)(a1 + 6096) = 0x40000000;
  *(_DWORD *)(a1 + 6112) = 1059760811;
  *(_DWORD *)(a1 + 6128) = 1059760811;
  *(_DWORD *)(a1 + 6144) = 1040746633;
  *(_DWORD *)(a1 + 6160) = 1035340641;
  *(_DWORD *)(a1 + 6176) = 1011879169;
  *(_DWORD *)(a1 + 6192) = 1003490561;
  *(_DWORD *)(a1 + 6208) = 976809758;
  *(_DWORD *)(a1 + 6224) = 965997180;
  *(_DWORD *)(a1 + 6240) = 936849986;
  *(_DWORD *)(a1 + 6256) = v33;
  *(_DWORD *)(a1 + 6272) = v34;
  *(_DWORD *)(a1 + 6288) = v35;
  *(_DWORD *)(a1 + 6304) = -1069547520;
  *(_DWORD *)(a1 + 6320) = 0;
  *(_DWORD *)(a1 + 6336) = 1065353216;
  *(_DWORD *)(a1 + 6416) = 1065353216;
  *(_DWORD *)(a1 + 6752) = 126279680;
  *(_DWORD *)(a1 + 6768) = 1042787764;
  *(_DWORD *)(a1 + 6784) = 1077222050;
  *(_DWORD *)(a1 + 6800) = -1073771922;
  *(_DWORD *)(a1 + 6816) = 1017280963;
  *(_DWORD *)(a1 + 6928) = v11;
  *(_DWORD *)(a1 + 6944) = 1065353216;
  *(_DWORD *)(a1 + 6960) = 1065353216;
  *(_DWORD *)(a1 + 7120) = v15;
  *(_DWORD *)(a1 + 7136) = 0;
  *(_DWORD *)(a1 + 7152) = 1065353216;
  *(_DWORD *)(a1 + 7200) = v15;
  *(_DWORD *)(a1 + 7216) = 0;
  *(_DWORD *)(a1 + 7232) = 1065353216;
  *(_DWORD *)(a1 + 7488) = -1065353216;
  *(_DWORD *)(a1 + 7504) = 1090519040;
  *(_DWORD *)(a1 + 7648) = 1094847562;
  *(_DWORD *)(a1 + 7664) = -1093102731;
  *(_DWORD *)(a1 + 7680) = 1065353216;
  *(_DWORD *)(a1 + 7696) = v36;
  *(_DWORD *)(a1 + 7712) = v37;
  *(_DWORD *)(a1 + 7728) = 1036831949;
  *(_DWORD *)(a1 + 7744) = 1033476506;
  *(_DWORD *)(a1 + 7760) = v38;
  *(_DWORD *)(a1 + 7776) = -1069547520;
  *(_DWORD *)(a1 + 7792) = 1085066445;
  *(_DWORD *)(a1 + 7808) = -1063780352;
  *(_DWORD *)(a1 + 7824) = 1060205080;
  *(_DWORD *)(a1 + 7840) = -1068320900;
  *(_DWORD *)(a1 + 7856) = v39;
  *(_DWORD *)(a1 + 7872) = 1065353216;
  *(_DWORD *)(a1 + 7888) = 0x40000000;
  *(_DWORD *)(a1 + 7904) = 1059760811;
  *(_DWORD *)(a1 + 7920) = 1059760811;
  *(_DWORD *)(a1 + 7936) = 1040746633;
  *(_DWORD *)(a1 + 7952) = 1035340641;
  *(_DWORD *)(a1 + 7968) = 1011879169;
  *(_DWORD *)(a1 + 7984) = 1003490561;
  *(_DWORD *)(a1 + 8000) = 976809758;
  *(_DWORD *)(a1 + 8016) = 965997180;
  *(_DWORD *)(a1 + 8032) = 936849986;
  *(_DWORD *)(a1 + 8048) = -1090519040;
  *(_DWORD *)(a1 + 8064) = -1104500053;
  *(_DWORD *)(a1 + 8080) = 1026206379;
  *(_DWORD *)(a1 + 8096) = 1007192201;
  *(_DWORD *)(a1 + 8112) = -1162474655;
  *(_DWORD *)(a1 + 8128) = -1185936127;
  *(_DWORD *)(a1 + 8144) = 936381697;
  *(_DWORD *)(a1 + 8160) = 909700893;
  *(_DWORD *)(a1 + 8176) = -1265372546;
  *(_DWORD *)(a1 + 0x2000) = -1294519765;
  *(_DWORD *)(a1 + 9120) = 941764110;
  *(_DWORD *)(a1 + 9136) = 1048576000;
  *(_DWORD *)(a1 + 9152) = 1082130432;
  *(_DWORD *)(a1 + 9168) = 1056964608;
  *(_DWORD *)(a1 + 9184) = -1102263091;
  *(_DWORD *)(a1 + 9200) = 1065353216;
  *(_DWORD *)(a1 + 9216) = 1061158912;
  *(_DWORD *)(a1 + 9232) = 1048576000;
  *(_DWORD *)(a1 + 9248) = 1056964608;
  *(_DWORD *)(a1 + 9264) = -1171962351;
  *(_DWORD *)(a1 + 9280) = -1158783739;
  *(_DWORD *)(a1 + 9296) = -1155013057;
  *(_DWORD *)(a1 + 9312) = -1160768650;
  *(_DWORD *)(a1 + 9328) = 991644115;
  *(_DWORD *)(a1 + 9344) = 1007191303;
  *(_DWORD *)(a1 + 9360) = 1010918385;
  *(_DWORD *)(a1 + 9376) = 1004371223;
  *(_DWORD *)(a1 + 9392) = -1139388239;
  *(_DWORD *)(a1 + 9408) = -1124889029;
  *(_DWORD *)(a1 + 9424) = -1121773932;
  *(_DWORD *)(a1 + 9440) = -1128877582;
  *(_DWORD *)(a1 + 9456) = 1023290972;
  *(_DWORD *)(a1 + 9472) = 1038327604;
  *(_DWORD *)(a1 + 9488) = 1044714247;
  *(_DWORD *)(a1 + 9504) = 1048155241;
  *(_DWORD *)(a1 + 9520) = 1065353216;
  *(_DWORD *)(a1 + 9536) = 0;
  *(_DWORD *)(a1 + 9744) = v11;
  *(_DWORD *)(a1 + 9808) = v8;
  *(_DWORD *)(a1 + 9888) = v8;
  *(_DWORD *)(a1 + 9952) = -1116138302;
  *(_DWORD *)(a1 + 9968) = v40;
  *(_DWORD *)(a1 + 9984) = v41;
  *(_DWORD *)(a1 + 10000) = 1076754516;
  *(_DWORD *)(a1 + 10016) = v42;
  *(_DWORD *)(a1 + 10032) = v43;
  *(_DWORD *)(a1 + 10336) = -1105618534;
  *(_DWORD *)(a1 + 10352) = 1065353216;
  *(_DWORD *)(a1 + 10368) = 0;
  *(_DWORD *)(a1 + 10384) = v10;
  *(_DWORD *)(a1 + 10400) = 1018980991;
  *(_DWORD *)(a1 + 10464) = v9;
  *(_DWORD *)(a1 + 10560) = v7;
  *(_DWORD *)(a1 + 10576) = v6;
  *(_DWORD *)(a1 + 10592) = v5;
  *(_DWORD *)(a1 + 10608) = v4;
  *(_DWORD *)(a1 + 10624) = v3;
  *(_DWORD *)(a1 + 10640) = v2;
  *(_DWORD *)(a1 + 11056) = v44;
  *(_DWORD *)(a1 + 11280) = 1132462080;
  *(_DWORD *)(a1 + 11296) = 805306368;
  *(_DWORD *)(a1 + 11312) = 872415232;
  *(_DWORD *)(a1 + 11328) = 1028443341;
  *(_DWORD *)(a1 + 11344) = 814313567;
  *(_DWORD *)(a1 + 11360) = 1065353216;
  *(_DWORD *)(a1 + 11376) = 1065353216;
  *(_DWORD *)(a1 + 11664) = 1023805706;
  *(_DWORD *)(a1 + 11680) = -1046478848;
  *(_DWORD *)(a1 + 11696) = 1055831741;
  *(_DWORD *)(a1 + 11712) = 1084821962;
  *(_DWORD *)(a1 + 11728) = -1093425406;
  *(_DWORD *)(a1 + 11744) = 1065353216;
  *(_DWORD *)(a1 + 11760) = 0x40000000;
  *(_DWORD *)(a1 + 11776) = 1059760811;
  *(_DWORD *)(a1 + 11792) = 1059760811;
  *(_DWORD *)(a1 + 11808) = 1040746633;
  *(_DWORD *)(a1 + 11824) = 1035340641;
  *(_DWORD *)(a1 + 11840) = 1011879169;
  *(_DWORD *)(a1 + 11856) = 1003490561;
  *(_DWORD *)(a1 + 11872) = 976809758;
  *(_DWORD *)(a1 + 11888) = 965997180;
  *(_DWORD *)(a1 + 11904) = 936849986;
  *(_DWORD *)(a1 + 12640) = 1014923857;
  *(_DWORD *)(a1 + 12656) = v45;
  *(_DWORD *)(a1 + 12672) = 993063548;
  *(_DWORD *)(a1 + 12688) = 1039798161;
  *(_DWORD *)(a1 + 12704) = 1074365517;
  *(_DWORD *)(a1 + 12720) = -1084150409;
  *(_DWORD *)(a1 + 12736) = -1094106009;
  *(_DWORD *)(a1 + 12752) = -1090489680;
  *(_DWORD *)(a1 + 12768) = 1076754517;
  *(_DWORD *)(a1 + 12784) = -1088302417;
  *(_DWORD *)(a1 + 12800) = -1082130432;
  *(_DWORD *)(a1 + 12816) = 0;
  *(_DWORD *)(a1 + 12832) = -1090519040;
  *(_DWORD *)(a1 + 12848) = 0;
  *(_DWORD *)(a1 + 12864) = 1056964608;
  *(_DWORD *)(a1 + 12880) = 1065353216;
  *(_DWORD *)(a1 + 12896) = 1065353216;
  *(_DWORD *)(a1 + 12912) = 0x40000000;
  *(_DWORD *)(a1 + 12928) = 1065353216;
  *(_DWORD *)(a1 + 12944) = 1056964608;
  *(_DWORD *)(a1 + 12960) = 1096810496;
  *(_DWORD *)(a1 + 12976) = 1013491486;
  *(_DWORD *)(a1 + 12992) = -1090519040;
  *(_DWORD *)(a1 + 13008) = 0;
  *(_DWORD *)(a1 + 13024) = 0;
  *(_DWORD *)(a1 + 13376) = -1090519040;
  *(_DWORD *)(a1 + 13392) = -1056178176;
  *(_DWORD *)(a1 + 13408) = 1094451200;
  *(_DWORD *)(a1 + 13424) = 1097596928;
  *(_DWORD *)(a1 + 13440) = 1091305472;
  *(_DWORD *)(a1 + 13456) = 1090676326;
  *(_DWORD *)(a1 + 13472) = v14;
  *(_DWORD *)(a1 + 13488) = v16;
  *(_DWORD *)(a1 + 13504) = 1038749345;
  *(_DWORD *)(a1 + 13520) = 1065353216;
  *(_DWORD *)(a1 + 13536) = 1065353216;
  *(_DWORD *)(a1 + 13856) = -1090519040;
  *(_DWORD *)(a1 + 13872) = -1056178176;
  *(_DWORD *)(a1 + 13888) = 1094451200;
  *(_DWORD *)(a1 + 13904) = 1097596928;
  *(_DWORD *)(a1 + 13920) = 1091305472;
  *(_DWORD *)(a1 + 13936) = 1090676326;
  *(_DWORD *)(a1 + 13952) = v14;
  *(_DWORD *)(a1 + 13968) = v16;
  *(_DWORD *)(a1 + 13984) = 1038749345;
  *(_DWORD *)(a1 + 14000) = 1065353216;
  *(_DWORD *)(a1 + 14016) = 1065353216;
  *(_DWORD *)(a1 + 14096) = 1065353216;
  *(_DWORD *)(a1 + 14112) = 1065353216;
  *(_DWORD *)(a1 + 14672) = 1056964608;
  *(_DWORD *)(a1 + 14688) = 1056964608;
  *(_DWORD *)(a1 + 14848) = v46;
  *(_DWORD *)(a1 + 14864) = 0x40000000;
  *(_DWORD *)(a1 + 14880) = -1097229926;
  *(_DWORD *)(a1 + 14896) = 0;
  *(_DWORD *)(a1 + 14912) = 1067030938;
  *(_DWORD *)(a1 + 14944) = 1060205080;
  *(_DWORD *)(a1 + 14960) = -1063780352;
  *(_DWORD *)(a1 + 14976) = 1065353216;
  *(_DWORD *)(a1 + 14992) = 0x40000000;
  *(_DWORD *)(a1 + 15008) = 1059760811;
  *(_DWORD *)(a1 + 15024) = 1059760811;
  *(_DWORD *)(a1 + 15040) = 1040746633;
  *(_DWORD *)(a1 + 15056) = 1035340641;
  *(_DWORD *)(a1 + 15072) = 1011879169;
  *(_DWORD *)(a1 + 15088) = 1003490561;
  *(_DWORD *)(a1 + 15104) = 976809758;
  *(_DWORD *)(a1 + 15120) = 965997180;
  *(_DWORD *)(a1 + 15136) = 936849986;
  *(_DWORD *)(a1 + 16048) = v47;
  *(_DWORD *)(a1 + 16064) = 1070141403;
  *(_DWORD *)(a1 + 16080) = 796917760;
  *(_DWORD *)(a1 + 16096) = -1146890486;
  *(_DWORD *)(a1 + 16112) = 1045220557;
  *(_DWORD *)(a1 + 16128) = 1036831949;
  *(_DWORD *)(a1 + 16144) = 1036831949;
  *(_DWORD *)(a1 + 16160) = 1065353216;
  *(_DWORD *)(a1 + 16176) = 1062836634;
  *(_DWORD *)(a1 + 16192) = 1062836634;
  *(_DWORD *)(a1 + 16208) = -1171962351;
  *(_DWORD *)(a1 + 16224) = -1158783739;
  *(_DWORD *)(a1 + 16240) = -1155013057;
  *(_DWORD *)(a1 + 16256) = -1160768650;
  *(_DWORD *)(a1 + 16272) = 991644115;
  *(_DWORD *)(a1 + 16288) = 1007191303;
  *(_DWORD *)(a1 + 16304) = 1010918385;
  *(_DWORD *)(a1 + 16320) = 1004371223;
  *(_DWORD *)(a1 + 16336) = -1139388239;
  *(_DWORD *)(a1 + 16352) = -1124889029;
  *(_DWORD *)(a1 + 16368) = -1121773932;
  *(_DWORD *)(a1 + 0x4000) = -1128877582;
  *(_DWORD *)(a1 + 16400) = 1023290972;
  *(_DWORD *)(a1 + 16416) = 1038327604;
  *(_DWORD *)(a1 + 16432) = 1044714247;
  *(_DWORD *)(a1 + 16448) = 1048155241;
  *(_DWORD *)(a1 + 16464) = -1104500053;
  *(_DWORD *)(a1 + 16480) = 1007192200;
  *(_DWORD *)(a1 + 16496) = -1185936127;
  *(_DWORD *)(a1 + 16512) = 909700753;
  *(_DWORD *)(a1 + 16528) = -1294492804;
  *(_DWORD *)(a1 + 16544) = 1060205080;
  *(_DWORD *)(a1 + 16560) = -1063780352;
  *(_DWORD *)(a1 + 16576) = -1068320896;
  *(_DWORD *)(a1 + 16592) = 1065353216;
  *(_DWORD *)(a1 + 16608) = 0x40000000;
  *(_DWORD *)(a1 + 16624) = 1059760811;
  *(_DWORD *)(a1 + 16640) = 1059760811;
  *(_DWORD *)(a1 + 16656) = 1040746633;
  *(_DWORD *)(a1 + 16672) = 1035340641;
  *(_DWORD *)(a1 + 16688) = 1011879169;
  *(_DWORD *)(a1 + 16704) = 1003490561;
  *(_DWORD *)(a1 + 16720) = 976809758;
  *(_DWORD *)(a1 + 16736) = 965997180;
  *(_DWORD *)(a1 + 16752) = 936849986;
  *(_DWORD *)(a1 + 16768) = v48;
  *(_DWORD *)(a1 + 16784) = v49;
  *(_DWORD *)(a1 + 16800) = v50;
  *(_DWORD *)(a1 + 16816) = -1069547520;
  *(_DWORD *)(a1 + 16832) = 0;
  *(_DWORD *)(a1 + 16848) = 1065353216;
  *(_DWORD *)(a1 + 16928) = 1065353216;
  *(_DWORD *)(a1 + 17264) = 126279680;
  *(_DWORD *)(a1 + 17280) = 1042787764;
  *(_DWORD *)(a1 + 17296) = 1077222050;
  *(_DWORD *)(a1 + 17312) = -1073771922;
  *(_DWORD *)(a1 + 17328) = 1017280963;
  *(_DWORD *)(a1 + 17440) = v11;
  *(_DWORD *)(a1 + 17456) = 1065353216;
  *(_DWORD *)(a1 + 17472) = 1065353216;
  *(_DWORD *)(a1 + 17632) = v15;
  *(_DWORD *)(a1 + 17648) = 0;
  *(_DWORD *)(a1 + 17664) = 1065353216;
  *(_DWORD *)(a1 + 17712) = v15;
  *(_DWORD *)(a1 + 17728) = 0;
  *(_DWORD *)(a1 + 17744) = 1065353216;
  *(_DWORD *)(a1 + 18000) = -1065353216;
  *(_DWORD *)(a1 + 18016) = 1090519040;
  *(_DWORD *)(a1 + 18160) = 1094847562;
  *(_DWORD *)(a1 + 18176) = -1093102731;
  *(_DWORD *)(a1 + 18192) = 1065353216;
  *(_DWORD *)(a1 + 18208) = v51;
  *(_DWORD *)(a1 + 18224) = v52;
  *(_DWORD *)(a1 + 18240) = 1036831949;
  *(_DWORD *)(a1 + 18256) = 1033476506;
  *(_DWORD *)(a1 + 18272) = v53;
  *(_DWORD *)(a1 + 18288) = -1069547520;
  *(_DWORD *)(a1 + 18304) = 1085066445;
  *(_DWORD *)(a1 + 18320) = -1063780352;
  *(_DWORD *)(a1 + 18336) = 1060205080;
  *(_DWORD *)(a1 + 18352) = -1068320900;
  *(_DWORD *)(a1 + 18368) = v54;
  *(_DWORD *)(a1 + 18384) = 1065353216;
  *(_DWORD *)(a1 + 18400) = 0x40000000;
  *(_DWORD *)(a1 + 18416) = 1059760811;
  *(_DWORD *)(a1 + 18432) = 1059760811;
  *(_DWORD *)(a1 + 18448) = 1040746633;
  *(_DWORD *)(a1 + 18464) = 1035340641;
  *(_DWORD *)(a1 + 18480) = 1011879169;
  *(_DWORD *)(a1 + 18496) = 1003490561;
  *(_DWORD *)(a1 + 18512) = 976809758;
  *(_DWORD *)(a1 + 18528) = 965997180;
  *(_DWORD *)(a1 + 18544) = 936849986;
  *(_DWORD *)(a1 + 18560) = -1090519040;
  *(_DWORD *)(a1 + 18576) = -1104500053;
  *(_DWORD *)(a1 + 18592) = 1026206379;
  *(_DWORD *)(a1 + 18608) = 1007192201;
  *(_DWORD *)(a1 + 18624) = -1162474655;
  *(_DWORD *)(a1 + 18640) = -1185936127;
  *(_DWORD *)(a1 + 18656) = 936381697;
  *(_DWORD *)(a1 + 18672) = 909700893;
  *(_DWORD *)(a1 + 18688) = -1265372546;
  *(_DWORD *)(a1 + 18704) = -1294519765;
  *(_DWORD *)(a1 + 19632) = 941764110;
  *(_DWORD *)(a1 + 19648) = 1048576000;
  *(_DWORD *)(a1 + 19664) = 1082130432;
  *(_DWORD *)(a1 + 19680) = 1056964608;
  *(_DWORD *)(a1 + 19696) = -1102263091;
  *(_DWORD *)(a1 + 19712) = 1065353216;
  *(_DWORD *)(a1 + 19728) = 1061158912;
  *(_DWORD *)(a1 + 19744) = 1048576000;
  *(_DWORD *)(a1 + 19760) = 1056964608;
  *(_DWORD *)(a1 + 19776) = -1171962351;
  *(_DWORD *)(a1 + 19792) = -1158783739;
  *(_DWORD *)(a1 + 19808) = -1155013057;
  *(_DWORD *)(a1 + 19824) = -1160768650;
  *(_DWORD *)(a1 + 19840) = 991644115;
  *(_DWORD *)(a1 + 19856) = 1007191303;
  *(_DWORD *)(a1 + 19872) = 1010918385;
  *(_DWORD *)(a1 + 19888) = 1004371223;
  *(_DWORD *)(a1 + 19904) = -1139388239;
  *(_DWORD *)(a1 + 19920) = -1124889029;
  *(_DWORD *)(a1 + 19936) = -1121773932;
  *(_DWORD *)(a1 + 19952) = -1128877582;
  *(_DWORD *)(a1 + 19968) = 1023290972;
  *(_DWORD *)(a1 + 19984) = 1038327604;
  *(_DWORD *)(a1 + 20000) = 1044714247;
  *(_DWORD *)(a1 + 20016) = 1048155241;
  *(_DWORD *)(a1 + 20032) = 1065353216;
  *(_DWORD *)(a1 + 20048) = 0;
  *(_DWORD *)(a1 + 20256) = v11;
  *(_DWORD *)(a1 + 20320) = v8;
  *(_DWORD *)(a1 + 20400) = v8;
  *(_DWORD *)(a1 + 20464) = -1116138302;
  *(_DWORD *)(a1 + 20480) = v55;
  *(_DWORD *)(a1 + 20496) = v56;
  *(_DWORD *)(a1 + 20512) = 1076754516;
  *(_DWORD *)(a1 + 20528) = v57;
  *(_DWORD *)(a1 + 20544) = v58;
  *(_DWORD *)(a1 + 20848) = -1105618534;
  *(_DWORD *)(a1 + 20864) = 1065353216;
  *(_DWORD *)(a1 + 20880) = 0;
  *(_DWORD *)(a1 + 20896) = v59;
  *(_DWORD *)(a1 + 20912) = 1018980991;
  *(_DWORD *)(a1 + 20976) = v60;
  *(_DWORD *)(a1 + 21072) = v61;
  *(_DWORD *)(a1 + 21088) = v62;
  *(_DWORD *)(a1 + 21104) = v63;
  *(_DWORD *)(a1 + 21120) = v64;
  *(_DWORD *)(a1 + 21136) = v65;
  *(_DWORD *)(a1 + 21152) = v66;
  *(_DWORD *)(a1 + 21568) = v67;
  *(_DWORD *)(a1 + 21792) = 1132462080;
  *(_DWORD *)(a1 + 21808) = 805306368;
  *(_DWORD *)(a1 + 21824) = 872415232;
  *(_DWORD *)(a1 + 21840) = 1028443341;
  *(_DWORD *)(a1 + 21856) = 814313567;
  *(_DWORD *)(a1 + 21872) = 1065353216;
  *(_DWORD *)(a1 + 21888) = 1065353216;
  *(_DWORD *)(a1 + 22176) = 1023805706;
  *(_DWORD *)(a1 + 22192) = -1046478848;
  *(_DWORD *)(a1 + 22208) = 1055831741;
  *(_DWORD *)(a1 + 22224) = 1084821962;
  *(_DWORD *)(a1 + 22240) = -1093425406;
  *(_DWORD *)(a1 + 22256) = 1065353216;
  *(_DWORD *)(a1 + 22272) = 0x40000000;
  *(_DWORD *)(a1 + 22288) = 1059760811;
  *(_DWORD *)(a1 + 22304) = 1059760811;
  *(_DWORD *)(a1 + 22320) = 1040746633;
  *(_DWORD *)(a1 + 22336) = 1035340641;
  *(_DWORD *)(a1 + 22352) = 1011879169;
  *(_DWORD *)(a1 + 22368) = 1003490561;
  *(_DWORD *)(a1 + 22384) = 976809758;
  *(_DWORD *)(a1 + 22400) = 965997180;
  *(_DWORD *)(a1 + 22416) = 936849986;
  *(_DWORD *)(a1 + 23152) = 1014923857;
  *(_DWORD *)(a1 + 23168) = v68;
  *(_DWORD *)(a1 + 23184) = 993063548;
  *(_DWORD *)(a1 + 23200) = 1039798161;
  *(_DWORD *)(a1 + 23216) = 1074365517;
  *(_DWORD *)(a1 + 23232) = -1084150409;
  *(_DWORD *)(a1 + 23248) = -1094106009;
  *(_DWORD *)(a1 + 23264) = -1090489680;
  *(_DWORD *)(a1 + 23280) = 1076754517;
  *(_DWORD *)(a1 + 23296) = -1088302417;
  *(_DWORD *)(a1 + 23312) = -1082130432;
  *(_DWORD *)(a1 + 23328) = 0;
  *(_DWORD *)(a1 + 23344) = -1090519040;
  *(_DWORD *)(a1 + 23360) = 0;
  *(_DWORD *)(a1 + 23376) = 1056964608;
  *(_DWORD *)(a1 + 23392) = 1065353216;
  *(_DWORD *)(a1 + 23408) = 1065353216;
  *(_DWORD *)(a1 + 23424) = 0x40000000;
  *(_DWORD *)(a1 + 23440) = 1065353216;
  *(_DWORD *)(a1 + 23456) = 1056964608;
  *(_DWORD *)(a1 + 23472) = 1096810496;
  *(_DWORD *)(a1 + 23488) = 1013491486;
  *(_DWORD *)(a1 + 23504) = -1090519040;
  *(_DWORD *)(a1 + 23520) = 0;
  *(_DWORD *)(a1 + 23536) = 0;
  *(_DWORD *)(a1 + 23888) = -1090519040;
  *(_DWORD *)(a1 + 23904) = -1056178176;
  *(_DWORD *)(a1 + 23920) = 1094451200;
  *(_DWORD *)(a1 + 23936) = 1097596928;
  *(_DWORD *)(a1 + 23952) = 1091305472;
  *(_DWORD *)(a1 + 23968) = 1090676326;
  *(_DWORD *)(a1 + 23984) = v14;
  *(_DWORD *)(a1 + 24000) = v16;
  *(_DWORD *)(a1 + 24016) = 1038749345;
  *(_DWORD *)(a1 + 24032) = 1065353216;
  *(_DWORD *)(a1 + 24048) = 1065353216;
  *(_DWORD *)(a1 + 24368) = -1090519040;
  *(_DWORD *)(a1 + 24384) = -1056178176;
  *(_DWORD *)(a1 + 24400) = 1094451200;
  *(_DWORD *)(a1 + 24416) = 1097596928;
  *(_DWORD *)(a1 + 24432) = 1091305472;
  *(_DWORD *)(a1 + 24448) = 1090676326;
  *(_DWORD *)(a1 + 24464) = v14;
  *(_DWORD *)(a1 + 24480) = v16;
  *(_DWORD *)(a1 + 24496) = 1038749345;
  *(_DWORD *)(a1 + 24512) = 1065353216;
  *(_DWORD *)(a1 + 24528) = 1065353216;
  *(_DWORD *)(a1 + 24608) = 1065353216;
  *(_DWORD *)(a1 + 24624) = 1065353216;
  *(_DWORD *)(a1 + 25184) = 1056964608;
  *(_DWORD *)(a1 + 25200) = 1056964608;
  *(_DWORD *)(a1 + 25360) = v69;
  *(_DWORD *)(a1 + 25376) = 0x40000000;
  *(_DWORD *)(a1 + 25392) = -1097229926;
  *(_DWORD *)(a1 + 25408) = 0;
  *(_DWORD *)(a1 + 25424) = 1067030938;
  *(_DWORD *)(a1 + 25456) = 1060205080;
  *(_DWORD *)(a1 + 25472) = -1063780352;
  *(_DWORD *)(a1 + 25488) = 1065353216;
  *(_DWORD *)(a1 + 25504) = 0x40000000;
  *(_DWORD *)(a1 + 25520) = 1059760811;
  *(_DWORD *)(a1 + 25536) = 1059760811;
  *(_DWORD *)(a1 + 25552) = 1040746633;
  *(_DWORD *)(a1 + 25568) = 1035340641;
  *(_DWORD *)(a1 + 25584) = 1011879169;
  *(_DWORD *)(a1 + 25600) = 1003490561;
  *(_DWORD *)(a1 + 25616) = 976809758;
  *(_DWORD *)(a1 + 25632) = 965997180;
  *(_DWORD *)(a1 + 25648) = 936849986;
  *(_DWORD *)(a1 + 26560) = v70;
  *(_DWORD *)(a1 + 26576) = 1070141403;
  *(_DWORD *)(a1 + 26592) = 796917760;
  *(_DWORD *)(a1 + 26608) = -1146890486;
  *(_DWORD *)(a1 + 26624) = 1045220557;
  *(_DWORD *)(a1 + 26640) = 1036831949;
  *(_DWORD *)(a1 + 26656) = 1036831949;
  *(_DWORD *)(a1 + 26672) = 1065353216;
  *(_DWORD *)(a1 + 26688) = 1062836634;
  *(_DWORD *)(a1 + 26704) = 1062836634;
  *(_DWORD *)(a1 + 26720) = -1171962351;
  *(_DWORD *)(a1 + 26736) = -1158783739;
  *(_DWORD *)(a1 + 26752) = -1155013057;
  *(_DWORD *)(a1 + 26768) = -1160768650;
  *(_DWORD *)(a1 + 26784) = 991644115;
  *(_DWORD *)(a1 + 26800) = 1007191303;
  *(_DWORD *)(a1 + 26816) = 1010918385;
  *(_DWORD *)(a1 + 26832) = 1004371223;
  *(_DWORD *)(a1 + 26848) = -1139388239;
  *(_DWORD *)(a1 + 26864) = -1124889029;
  *(_DWORD *)(a1 + 26880) = -1121773932;
  *(_DWORD *)(a1 + 26896) = -1128877582;
  *(_DWORD *)(a1 + 26912) = 1023290972;
  *(_DWORD *)(a1 + 26928) = 1038327604;
  *(_DWORD *)(a1 + 26944) = 1044714247;
  *(_DWORD *)(a1 + 26960) = 1048155241;
  *(_DWORD *)(a1 + 26976) = -1104500053;
  *(_DWORD *)(a1 + 26992) = 1007192200;
  *(_DWORD *)(a1 + 27008) = -1185936127;
  *(_DWORD *)(a1 + 27024) = 909700753;
  *(_DWORD *)(a1 + 27040) = -1294492804;
  *(_DWORD *)(a1 + 27056) = 1060205080;
  *(_DWORD *)(a1 + 27072) = -1063780352;
  *(_DWORD *)(a1 + 27088) = -1068320896;
  *(_DWORD *)(a1 + 27104) = 1065353216;
  *(_DWORD *)(a1 + 27120) = 0x40000000;
  *(_DWORD *)(a1 + 27136) = 1059760811;
  *(_DWORD *)(a1 + 27152) = 1059760811;
  *(_DWORD *)(a1 + 27168) = 1040746633;
  *(_DWORD *)(a1 + 27184) = 1035340641;
  *(_DWORD *)(a1 + 27200) = 1011879169;
  *(_DWORD *)(a1 + 27216) = 1003490561;
  *(_DWORD *)(a1 + 27232) = 976809758;
  *(_DWORD *)(a1 + 27248) = 965997180;
  *(_DWORD *)(a1 + 27264) = 936849986;
  *(_DWORD *)(a1 + 27280) = v71;
  *(_DWORD *)(a1 + 27296) = v72;
  *(_DWORD *)(a1 + 27312) = v73;
  *(_DWORD *)(a1 + 27328) = -1069547520;
  *(_DWORD *)(a1 + 27344) = 0;
  *(_DWORD *)(a1 + 27360) = 1065353216;
  *(_DWORD *)(a1 + 27440) = 1065353216;
  *(_DWORD *)(a1 + 27776) = 126279680;
  *(_DWORD *)(a1 + 27792) = 1042787764;
  *(_DWORD *)(a1 + 27808) = 1077222050;
  *(_DWORD *)(a1 + 27824) = -1073771922;
  *(_DWORD *)(a1 + 27840) = 1017280963;
  *(_DWORD *)(a1 + 27952) = v11;
  *(_DWORD *)(a1 + 27968) = 1065353216;
  *(_DWORD *)(a1 + 27984) = 1065353216;
  *(_DWORD *)(a1 + 28144) = v15;
  *(_DWORD *)(a1 + 28160) = 0;
  *(_DWORD *)(a1 + 28176) = 1065353216;
  *(_DWORD *)(a1 + 28224) = v15;
  *(_DWORD *)(a1 + 28240) = 0;
  *(_DWORD *)(a1 + 28256) = 1065353216;
  *(_DWORD *)(a1 + 28512) = -1065353216;
  *(_DWORD *)(a1 + 28528) = 1090519040;
  *(_DWORD *)(a1 + 28672) = 1094847562;
  *(_DWORD *)(a1 + 28688) = -1093102731;
  *(_DWORD *)(a1 + 28704) = 1065353216;
  *(_DWORD *)(a1 + 28720) = v74;
  *(_DWORD *)(a1 + 28736) = v75;
  *(_DWORD *)(a1 + 28752) = 1036831949;
  *(_DWORD *)(a1 + 28768) = 1033476506;
  *(_DWORD *)(a1 + 28784) = v76;
  *(_DWORD *)(a1 + 28800) = -1069547520;
  *(_DWORD *)(a1 + 28816) = 1085066445;
  *(_DWORD *)(a1 + 28832) = -1063780352;
  *(_DWORD *)(a1 + 28848) = 1060205080;
  *(_DWORD *)(a1 + 28864) = -1068320900;
  *(_DWORD *)(a1 + 28880) = v77;
  *(_DWORD *)(a1 + 28896) = 1065353216;
  *(_DWORD *)(a1 + 28912) = 0x40000000;
  *(_DWORD *)(a1 + 28928) = 1059760811;
  *(_DWORD *)(a1 + 28944) = 1059760811;
  *(_DWORD *)(a1 + 28960) = 1040746633;
  *(_DWORD *)(a1 + 28976) = 1035340641;
  *(_DWORD *)(a1 + 28992) = 1011879169;
  *(_DWORD *)(a1 + 29008) = 1003490561;
  *(_DWORD *)(a1 + 29024) = 976809758;
  *(_DWORD *)(a1 + 29040) = 965997180;
  *(_DWORD *)(a1 + 29056) = 936849986;
  *(_DWORD *)(a1 + 29072) = -1090519040;
  *(_DWORD *)(a1 + 29088) = -1104500053;
  *(_DWORD *)(a1 + 29104) = 1026206379;
  *(_DWORD *)(a1 + 29120) = 1007192201;
  *(_DWORD *)(a1 + 29136) = -1162474655;
  *(_DWORD *)(a1 + 29152) = -1185936127;
  *(_DWORD *)(a1 + 29168) = 936381697;
  *(_DWORD *)(a1 + 29184) = 909700893;
  *(_DWORD *)(a1 + 29200) = -1265372546;
  *(_DWORD *)(a1 + 29216) = -1294519765;
  *(_DWORD *)(a1 + 30144) = 941764110;
  *(_DWORD *)(a1 + 30160) = 1048576000;
  *(_DWORD *)(a1 + 30176) = 1082130432;
  *(_DWORD *)(a1 + 30192) = 1056964608;
  *(_DWORD *)(a1 + 30208) = -1102263091;
  *(_DWORD *)(a1 + 30224) = 1065353216;
  *(_DWORD *)(a1 + 30240) = 1061158912;
  *(_DWORD *)(a1 + 30256) = 1048576000;
  *(_DWORD *)(a1 + 30272) = 1056964608;
  *(_DWORD *)(a1 + 30288) = -1171962351;
  *(_DWORD *)(a1 + 30304) = -1158783739;
  *(_DWORD *)(a1 + 30320) = -1155013057;
  *(_DWORD *)(a1 + 30336) = -1160768650;
  *(_DWORD *)(a1 + 30352) = 991644115;
  *(_DWORD *)(a1 + 30368) = 1007191303;
  *(_DWORD *)(a1 + 30384) = 1010918385;
  *(_DWORD *)(a1 + 30400) = 1004371223;
  *(_DWORD *)(a1 + 30416) = -1139388239;
  *(_DWORD *)(a1 + 30432) = -1124889029;
  *(_DWORD *)(a1 + 30448) = -1121773932;
  *(_DWORD *)(a1 + 30464) = -1128877582;
  *(_DWORD *)(a1 + 30480) = 1023290972;
  *(_DWORD *)(a1 + 30496) = 1038327604;
  *(_DWORD *)(a1 + 30512) = 1044714247;
  *(_DWORD *)(a1 + 30528) = 1048155241;
  *(_DWORD *)(a1 + 30544) = 1065353216;
  *(_DWORD *)(a1 + 30560) = 0;
  *(_DWORD *)(a1 + 30768) = v11;
  *(_DWORD *)(a1 + 30832) = v8;
  *(_DWORD *)(a1 + 30912) = v8;
  *(_DWORD *)(a1 + 30976) = -1116138302;
  *(_DWORD *)(a1 + 30992) = v78;
  *(_DWORD *)(a1 + 31008) = v79;
  *(_DWORD *)(a1 + 31024) = 1076754516;
  *(_DWORD *)(a1 + 31040) = v80;
  *(_DWORD *)(a1 + 31056) = v81;
  *(_DWORD *)(a1 + 31360) = -1105618534;
  *(_DWORD *)(a1 + 31376) = 1065353216;
  *(_DWORD *)(a1 + 31392) = 0;
  *(_DWORD *)(a1 + 31408) = v82;
  *(_DWORD *)(a1 + 31424) = 1018980991;
  *(_DWORD *)(a1 + 31488) = v83;
  *(_DWORD *)(a1 + 31584) = v84;
  *(_DWORD *)(a1 + 31600) = v85;
  *(_DWORD *)(a1 + 31616) = v86;
  *(_DWORD *)(a1 + 31632) = v87;
  *(_DWORD *)(a1 + 31648) = v88;
  *(_DWORD *)(a1 + 31664) = v89;
  *(_DWORD *)(a1 + 32080) = v90;
  *(_DWORD *)(a1 + 32304) = 1132462080;
  *(_DWORD *)(a1 + 32320) = 805306368;
  *(_DWORD *)(a1 + 32336) = 872415232;
  *(_DWORD *)(a1 + 32352) = 1028443341;
  *(_DWORD *)(a1 + 32368) = 814313567;
  *(_DWORD *)(a1 + 32384) = 1065353216;
  *(_DWORD *)(a1 + 32400) = 1065353216;
  *(_DWORD *)(a1 + 32688) = 1023805706;
  *(_DWORD *)(a1 + 32704) = -1046478848;
  *(_DWORD *)(a1 + 32720) = 1055831741;
  *(_DWORD *)(a1 + 32736) = 1084821962;
  *(_DWORD *)(a1 + 32752) = -1093425406;
  *(_DWORD *)(a1 + 0x8000) = 1065353216;
  *(_DWORD *)(a1 + 32784) = 0x40000000;
  *(_DWORD *)(a1 + 32800) = 1059760811;
  *(_DWORD *)(a1 + 32816) = 1059760811;
  *(_DWORD *)(a1 + 32832) = 1040746633;
  *(_DWORD *)(a1 + 32848) = 1035340641;
  *(_DWORD *)(a1 + 32864) = 1011879169;
  *(_DWORD *)(a1 + 32880) = 1003490561;
  *(_DWORD *)(a1 + 32896) = 976809758;
  *(_DWORD *)(a1 + 32912) = 965997180;
  *(_DWORD *)(a1 + 32928) = 936849986;
  *(_DWORD *)(a1 + 33664) = 1014923857;
  *(_DWORD *)(a1 + 33680) = v91;
  *(_DWORD *)(a1 + 33696) = 993063548;
  *(_DWORD *)(a1 + 33712) = 1039798161;
  *(_DWORD *)(a1 + 33728) = 1074365517;
  *(_DWORD *)(a1 + 33744) = -1084150409;
  *(_DWORD *)(a1 + 33760) = -1094106009;
  *(_DWORD *)(a1 + 33776) = -1090489680;
  *(_DWORD *)(a1 + 33792) = 1076754517;
  *(_DWORD *)(a1 + 33808) = -1088302417;
  *(_DWORD *)(a1 + 33824) = -1082130432;
  *(_DWORD *)(a1 + 33840) = 0;
  *(_DWORD *)(a1 + 33856) = -1090519040;
  *(_DWORD *)(a1 + 33872) = 0;
  *(_DWORD *)(a1 + 33888) = 1056964608;
  *(_DWORD *)(a1 + 33904) = 1065353216;
  *(_DWORD *)(a1 + 33920) = 1065353216;
  *(_DWORD *)(a1 + 33936) = 0x40000000;
  *(_DWORD *)(a1 + 33952) = 1065353216;
  *(_DWORD *)(a1 + 33968) = 1056964608;
  *(_DWORD *)(a1 + 33984) = 1096810496;
  *(_DWORD *)(a1 + 34000) = 1013491486;
  *(_DWORD *)(a1 + 34016) = -1090519040;
  *(_DWORD *)(a1 + 34032) = 0;
  *(_DWORD *)(a1 + 34048) = 0;
  *(_DWORD *)(a1 + 34400) = -1090519040;
  *(_DWORD *)(a1 + 34416) = -1056178176;
  *(_DWORD *)(a1 + 34432) = 1094451200;
  *(_DWORD *)(a1 + 34448) = 1097596928;
  *(_DWORD *)(a1 + 34464) = 1091305472;
  *(_DWORD *)(a1 + 34480) = 1090676326;
  *(_DWORD *)(a1 + 34496) = v14;
  *(_DWORD *)(a1 + 34512) = v16;
  *(_DWORD *)(a1 + 34528) = 1038749345;
  *(_DWORD *)(a1 + 34544) = 1065353216;
  *(_DWORD *)(a1 + 34560) = 1065353216;
  *(_DWORD *)(a1 + 34880) = -1090519040;
  *(_DWORD *)(a1 + 34896) = -1056178176;
  *(_DWORD *)(a1 + 34912) = 1094451200;
  *(_DWORD *)(a1 + 34928) = 1097596928;
  *(_DWORD *)(a1 + 34944) = 1091305472;
  *(_DWORD *)(a1 + 34960) = 1090676326;
  *(_DWORD *)(a1 + 34976) = v14;
  *(_DWORD *)(a1 + 34992) = v16;
  *(_DWORD *)(a1 + 35008) = 1038749345;
  *(_DWORD *)(a1 + 35024) = 1065353216;
  *(_DWORD *)(a1 + 35040) = 1065353216;
  *(_DWORD *)(a1 + 35120) = 1065353216;
  *(_DWORD *)(a1 + 35136) = 1065353216;
  *(_DWORD *)(a1 + 35696) = 1056964608;
  *(_DWORD *)(a1 + 35712) = 1056964608;
  *(_DWORD *)(a1 + 35872) = v92;
  *(_DWORD *)(a1 + 35888) = 0x40000000;
  *(_DWORD *)(a1 + 35904) = -1097229926;
  *(_DWORD *)(a1 + 35920) = 0;
  *(_DWORD *)(a1 + 35936) = 1067030938;
  *(_DWORD *)(a1 + 35968) = 1060205080;
  *(_DWORD *)(a1 + 35984) = -1063780352;
  *(_DWORD *)(a1 + 36000) = 1065353216;
  *(_DWORD *)(a1 + 36016) = 0x40000000;
  *(_DWORD *)(a1 + 36032) = 1059760811;
  *(_DWORD *)(a1 + 36048) = 1059760811;
  *(_DWORD *)(a1 + 36064) = 1040746633;
  *(_DWORD *)(a1 + 36080) = 1035340641;
  *(_DWORD *)(a1 + 36096) = 1011879169;
  *(_DWORD *)(a1 + 36112) = 1003490561;
  *(_DWORD *)(a1 + 36128) = 976809758;
  *(_DWORD *)(a1 + 36144) = 965997180;
  *(_DWORD *)(a1 + 36160) = 936849986;
  *(_DWORD *)(a1 + 37072) = v93;
  *(_DWORD *)(a1 + 37088) = 1070141403;
  *(_DWORD *)(a1 + 37104) = 796917760;
  *(_DWORD *)(a1 + 37120) = -1146890486;
  *(_DWORD *)(a1 + 37136) = 1045220557;
  *(_DWORD *)(a1 + 37152) = 1036831949;
  *(_DWORD *)(a1 + 37168) = 1036831949;
  *(_DWORD *)(a1 + 37184) = 1065353216;
  *(_DWORD *)(a1 + 37200) = 1062836634;
  *(_DWORD *)(a1 + 37216) = 1062836634;
  *(_DWORD *)(a1 + 37232) = -1171962351;
  *(_DWORD *)(a1 + 37248) = -1158783739;
  *(_DWORD *)(a1 + 37264) = -1155013057;
  *(_DWORD *)(a1 + 37280) = -1160768650;
  *(_DWORD *)(a1 + 37296) = 991644115;
  *(_DWORD *)(a1 + 37312) = 1007191303;
  *(_DWORD *)(a1 + 37328) = 1010918385;
  *(_DWORD *)(a1 + 37344) = 1004371223;
  *(_DWORD *)(a1 + 37360) = -1139388239;
  *(_DWORD *)(a1 + 37376) = -1124889029;
  *(_DWORD *)(a1 + 37392) = -1121773932;
  *(_DWORD *)(a1 + 37408) = -1128877582;
  *(_DWORD *)(a1 + 37424) = 1023290972;
  *(_DWORD *)(a1 + 37440) = 1038327604;
  *(_DWORD *)(a1 + 37456) = 1044714247;
  *(_DWORD *)(a1 + 37472) = 1048155241;
  *(_DWORD *)(a1 + 37488) = -1104500053;
  *(_DWORD *)(a1 + 37504) = 1007192200;
  *(_DWORD *)(a1 + 37520) = -1185936127;
  *(_DWORD *)(a1 + 37536) = 909700753;
  *(_DWORD *)(a1 + 37552) = -1294492804;
  *(_DWORD *)(a1 + 37568) = 1060205080;
  *(_DWORD *)(a1 + 37584) = -1063780352;
  *(_DWORD *)(a1 + 37600) = -1068320896;
  *(_DWORD *)(a1 + 37616) = 1065353216;
  *(_DWORD *)(a1 + 37632) = 0x40000000;
  *(_DWORD *)(a1 + 37648) = 1059760811;
  *(_DWORD *)(a1 + 37664) = 1059760811;
  *(_DWORD *)(a1 + 37680) = 1040746633;
  *(_DWORD *)(a1 + 37696) = 1035340641;
  *(_DWORD *)(a1 + 37712) = 1011879169;
  *(_DWORD *)(a1 + 37728) = 1003490561;
  *(_DWORD *)(a1 + 37744) = 976809758;
  *(_DWORD *)(a1 + 37760) = 965997180;
  *(_DWORD *)(a1 + 37776) = 936849986;
  *(_DWORD *)(a1 + 37792) = v94;
  *(_DWORD *)(a1 + 37808) = v95;
  *(_DWORD *)(a1 + 37824) = v96;
  *(_DWORD *)(a1 + 37840) = -1069547520;
  *(_DWORD *)(a1 + 37856) = 0;
  *(_DWORD *)(a1 + 37872) = 1065353216;
  *(_DWORD *)(a1 + 37952) = 1065353216;
  *(_DWORD *)(a1 + 38288) = 126279680;
  *(_DWORD *)(a1 + 38304) = 1042787764;
  *(_DWORD *)(a1 + 38320) = 1077222050;
  *(_DWORD *)(a1 + 38336) = -1073771922;
  *(_DWORD *)(a1 + 38352) = 1017280963;
  *(_DWORD *)(a1 + 38464) = v11;
  *(_DWORD *)(a1 + 38480) = 1065353216;
  *(_DWORD *)(a1 + 38496) = 1065353216;
  *(_DWORD *)(a1 + 38656) = v15;
  *(_DWORD *)(a1 + 38672) = 0;
  *(_DWORD *)(a1 + 38688) = 1065353216;
  *(_DWORD *)(a1 + 38736) = v15;
  *(_DWORD *)(a1 + 38752) = 0;
  *(_DWORD *)(a1 + 38768) = 1065353216;
  *(_DWORD *)(a1 + 39024) = -1065353216;
  *(_DWORD *)(a1 + 39040) = 1090519040;
  *(_DWORD *)(a1 + 39184) = 1094847562;
  *(_DWORD *)(a1 + 39200) = -1093102731;
  *(_DWORD *)(a1 + 39216) = 1065353216;
  *(_DWORD *)(a1 + 39232) = v97;
  *(_DWORD *)(a1 + 39248) = v98;
  *(_DWORD *)(a1 + 39264) = 1036831949;
  *(_DWORD *)(a1 + 39280) = 1033476506;
  *(_DWORD *)(a1 + 39296) = v99;
  *(_DWORD *)(a1 + 39312) = -1069547520;
  *(_DWORD *)(a1 + 39328) = 1085066445;
  *(_DWORD *)(a1 + 39344) = -1063780352;
  *(_DWORD *)(a1 + 39360) = 1060205080;
  *(_DWORD *)(a1 + 39376) = -1068320900;
  *(_DWORD *)(a1 + 39392) = v100;
  *(_DWORD *)(a1 + 39408) = 1065353216;
  *(_DWORD *)(a1 + 39424) = 0x40000000;
  *(_DWORD *)(a1 + 39440) = 1059760811;
  *(_DWORD *)(a1 + 39456) = 1059760811;
  *(_DWORD *)(a1 + 39472) = 1040746633;
  *(_DWORD *)(a1 + 39488) = 1035340641;
  *(_DWORD *)(a1 + 39504) = 1011879169;
  *(_DWORD *)(a1 + 39520) = 1003490561;
  *(_DWORD *)(a1 + 39536) = 976809758;
  *(_DWORD *)(a1 + 39552) = 965997180;
  *(_DWORD *)(a1 + 39568) = 936849986;
  *(_DWORD *)(a1 + 39584) = -1090519040;
  *(_DWORD *)(a1 + 39600) = -1104500053;
  *(_DWORD *)(a1 + 39616) = 1026206379;
  *(_DWORD *)(a1 + 39632) = 1007192201;
  *(_DWORD *)(a1 + 39648) = -1162474655;
  *(_DWORD *)(a1 + 39664) = -1185936127;
  *(_DWORD *)(a1 + 39680) = 936381697;
  *(_DWORD *)(a1 + 39696) = 909700893;
  *(_DWORD *)(a1 + 39712) = -1265372546;
  *(_DWORD *)(a1 + 39728) = -1294519765;
  *(_DWORD *)(a1 + 40656) = 941764110;
  *(_DWORD *)(a1 + 40672) = 1048576000;
  *(_DWORD *)(a1 + 40688) = 1082130432;
  *(_DWORD *)(a1 + 40704) = 1056964608;
  *(_DWORD *)(a1 + 40720) = -1102263091;
  *(_DWORD *)(a1 + 40736) = 1065353216;
  *(_DWORD *)(a1 + 40752) = 1061158912;
  *(_DWORD *)(a1 + 40768) = 1048576000;
  *(_DWORD *)(a1 + 40784) = 1056964608;
  *(_DWORD *)(a1 + 40800) = -1171962351;
  *(_DWORD *)(a1 + 40816) = -1158783739;
  *(_DWORD *)(a1 + 40832) = -1155013057;
  *(_DWORD *)(a1 + 40848) = -1160768650;
  *(_DWORD *)(a1 + 40864) = 991644115;
  *(_DWORD *)(a1 + 40880) = 1007191303;
  *(_DWORD *)(a1 + 40896) = 1010918385;
  *(_DWORD *)(a1 + 40912) = 1004371223;
  *(_DWORD *)(a1 + 40928) = -1139388239;
  *(_DWORD *)(a1 + 40944) = -1124889029;
  *(_DWORD *)(a1 + 40960) = -1121773932;
  *(_DWORD *)(a1 + 40976) = -1128877582;
  *(_DWORD *)(a1 + 40992) = 1023290972;
  *(_DWORD *)(a1 + 41008) = 1038327604;
  *(_DWORD *)(a1 + 41024) = 1044714247;
  *(_DWORD *)(a1 + 41040) = 1048155241;
  *(_DWORD *)(a1 + 41056) = 1065353216;
  *(_DWORD *)(a1 + 41072) = 0;
  *(_DWORD *)(a1 + 41280) = v11;
  *(_DWORD *)(a1 + 41344) = v8;
  *(_DWORD *)(a1 + 41424) = v8;
  *(_DWORD *)(a1 + 41488) = -1116138302;
  *(_DWORD *)(a1 + 41504) = v101;
  *(_DWORD *)(a1 + 41520) = v102;
  *(_DWORD *)(a1 + 41536) = 1076754516;
  *(_DWORD *)(a1 + 41552) = v103;
  *(_DWORD *)(a1 + 41568) = v104;
  *(_DWORD *)(a1 + 41872) = -1105618534;
  *(_DWORD *)(a1 + 41888) = 1065353216;
  *(_DWORD *)(a1 + 41904) = 0;
  *(_DWORD *)(a1 + 41920) = v105;
  *(_DWORD *)(a1 + 41936) = 1018980991;
  *(_DWORD *)(a1 + 42000) = v106;
  *(_DWORD *)(a1 + 42096) = v107;
  *(_DWORD *)(a1 + 42112) = v108;
  *(_DWORD *)(a1 + 42128) = v109;
  *(_DWORD *)(a1 + 42144) = v110;
  *(_DWORD *)(a1 + 42160) = v111;
  *(_DWORD *)(a1 + 42176) = v112;
  *(_DWORD *)(a1 + 42592) = v113;
  *(_DWORD *)(a1 + 42816) = 1132462080;
  *(_DWORD *)(a1 + 42832) = 805306368;
  *(_DWORD *)(a1 + 42848) = 872415232;
  *(_DWORD *)(a1 + 42864) = 1028443341;
  *(_DWORD *)(a1 + 42880) = 814313567;
  *(_DWORD *)(a1 + 42896) = 1065353216;
  *(_DWORD *)(a1 + 42912) = 1065353216;
  *(_DWORD *)(a1 + 43200) = 1023805706;
  *(_DWORD *)(a1 + 43216) = -1046478848;
  *(_DWORD *)(a1 + 43232) = 1055831741;
  *(_DWORD *)(a1 + 43248) = 1084821962;
  *(_DWORD *)(a1 + 43264) = -1093425406;
  *(_DWORD *)(a1 + 43280) = 1065353216;
  *(_DWORD *)(a1 + 43296) = 0x40000000;
  *(_DWORD *)(a1 + 43312) = 1059760811;
  *(_DWORD *)(a1 + 43328) = 1059760811;
  *(_DWORD *)(a1 + 43344) = 1040746633;
  *(_DWORD *)(a1 + 43360) = 1035340641;
  *(_DWORD *)(a1 + 43376) = 1011879169;
  *(_DWORD *)(a1 + 43392) = 1003490561;
  *(_DWORD *)(a1 + 43408) = 976809758;
  *(_DWORD *)(a1 + 43424) = 965997180;
  *(_DWORD *)(a1 + 43440) = 936849986;
  *(_DWORD *)(a1 + 44176) = 1014923857;
  *(_DWORD *)(a1 + 44192) = v114;
  *(_DWORD *)(a1 + 44208) = 993063548;
  *(_DWORD *)(a1 + 44224) = 1039798161;
  *(_DWORD *)(a1 + 44240) = 1074365517;
  *(_DWORD *)(a1 + 44256) = -1084150409;
  *(_DWORD *)(a1 + 44272) = -1094106009;
  *(_DWORD *)(a1 + 44288) = -1090489680;
  *(_DWORD *)(a1 + 44304) = 1076754517;
  *(_DWORD *)(a1 + 44320) = -1088302417;
  *(_DWORD *)(a1 + 44336) = -1082130432;
  *(_DWORD *)(a1 + 44352) = 0;
  *(_DWORD *)(a1 + 44368) = -1090519040;
  *(_DWORD *)(a1 + 44384) = 0;
  *(_DWORD *)(a1 + 44400) = 1056964608;
  *(_DWORD *)(a1 + 44416) = 1065353216;
  *(_DWORD *)(a1 + 44432) = 1065353216;
  *(_DWORD *)(a1 + 44448) = 0x40000000;
  *(_DWORD *)(a1 + 44464) = 1065353216;
  *(_DWORD *)(a1 + 44480) = 1056964608;
  *(_DWORD *)(a1 + 44496) = 1096810496;
  *(_DWORD *)(a1 + 44512) = 1013491486;
  *(_DWORD *)(a1 + 44528) = -1090519040;
  *(_DWORD *)(a1 + 44544) = 0;
  *(_DWORD *)(a1 + 44560) = 0;
  *(_DWORD *)(a1 + 44912) = -1090519040;
  *(_DWORD *)(a1 + 44928) = -1056178176;
  *(_DWORD *)(a1 + 44944) = 1094451200;
  *(_DWORD *)(a1 + 44960) = 1097596928;
  *(_DWORD *)(a1 + 44976) = 1091305472;
  *(_DWORD *)(a1 + 44992) = 1090676326;
  *(_DWORD *)(a1 + 45008) = v14;
  *(_DWORD *)(a1 + 45024) = v16;
  *(_DWORD *)(a1 + 45040) = 1038749345;
  *(_DWORD *)(a1 + 45056) = 1065353216;
  *(_DWORD *)(a1 + 45072) = 1065353216;
  *(_DWORD *)(a1 + 45392) = -1090519040;
  *(_DWORD *)(a1 + 45408) = -1056178176;
  *(_DWORD *)(a1 + 45424) = 1094451200;
  *(_DWORD *)(a1 + 45440) = 1097596928;
  *(_DWORD *)(a1 + 45456) = 1091305472;
  *(_DWORD *)(a1 + 45472) = 1090676326;
  *(_DWORD *)(a1 + 45488) = v14;
  *(_DWORD *)(a1 + 45504) = v16;
  *(_DWORD *)(a1 + 45520) = 1038749345;
  *(_DWORD *)(a1 + 45536) = 1065353216;
  *(_DWORD *)(a1 + 45552) = 1065353216;
  *(_DWORD *)(a1 + 45632) = 1065353216;
  *(_DWORD *)(a1 + 45648) = 1065353216;
  *(_DWORD *)(a1 + 46208) = 1056964608;
  *(_DWORD *)(a1 + 46224) = 1056964608;
  *(_DWORD *)(a1 + 46384) = v115;
  *(_DWORD *)(a1 + 46400) = 0x40000000;
  *(_DWORD *)(a1 + 46416) = -1097229926;
  *(_DWORD *)(a1 + 46432) = 0;
  *(_DWORD *)(a1 + 46448) = 1067030938;
  *(_DWORD *)(a1 + 46480) = 1060205080;
  *(_DWORD *)(a1 + 46496) = -1063780352;
  *(_DWORD *)(a1 + 46512) = 1065353216;
  *(_DWORD *)(a1 + 46528) = 0x40000000;
  *(_DWORD *)(a1 + 46544) = 1059760811;
  *(_DWORD *)(a1 + 46560) = 1059760811;
  *(_DWORD *)(a1 + 46576) = 1040746633;
  *(_DWORD *)(a1 + 46592) = 1035340641;
  *(_DWORD *)(a1 + 46608) = 1011879169;
  *(_DWORD *)(a1 + 46624) = 1003490561;
  *(_DWORD *)(a1 + 46640) = 976809758;
  *(_DWORD *)(a1 + 46656) = 965997180;
  *(_DWORD *)(a1 + 46672) = 936849986;
  *(_DWORD *)(a1 + 47584) = v116;
  *(_DWORD *)(a1 + 47600) = 1070141403;
  *(_DWORD *)(a1 + 47616) = 796917760;
  *(_DWORD *)(a1 + 47632) = -1146890486;
  *(_DWORD *)(a1 + 47648) = 1045220557;
  *(_DWORD *)(a1 + 47664) = 1036831949;
  *(_DWORD *)(a1 + 47680) = 1036831949;
  *(_DWORD *)(a1 + 47696) = 1065353216;
  *(_DWORD *)(a1 + 47712) = 1062836634;
  *(_DWORD *)(a1 + 47728) = 1062836634;
  *(_DWORD *)(a1 + 47744) = -1171962351;
  *(_DWORD *)(a1 + 47760) = -1158783739;
  *(_DWORD *)(a1 + 47776) = -1155013057;
  *(_DWORD *)(a1 + 47792) = -1160768650;
  *(_DWORD *)(a1 + 47808) = 991644115;
  *(_DWORD *)(a1 + 47824) = 1007191303;
  *(_DWORD *)(a1 + 47840) = 1010918385;
  *(_DWORD *)(a1 + 47856) = 1004371223;
  *(_DWORD *)(a1 + 47872) = -1139388239;
  *(_DWORD *)(a1 + 47888) = -1124889029;
  *(_DWORD *)(a1 + 47904) = -1121773932;
  *(_DWORD *)(a1 + 47920) = -1128877582;
  *(_DWORD *)(a1 + 47936) = 1023290972;
  *(_DWORD *)(a1 + 47952) = 1038327604;
  *(_DWORD *)(a1 + 47968) = 1044714247;
  *(_DWORD *)(a1 + 47984) = 1048155241;
  *(_DWORD *)(a1 + 48000) = -1104500053;
  *(_DWORD *)(a1 + 48016) = 1007192200;
  *(_DWORD *)(a1 + 48032) = -1185936127;
  *(_DWORD *)(a1 + 48048) = 909700753;
  *(_DWORD *)(a1 + 48064) = -1294492804;
  *(_DWORD *)(a1 + 48080) = 1060205080;
  *(_DWORD *)(a1 + 48096) = -1063780352;
  *(_DWORD *)(a1 + 48112) = -1068320896;
  *(_DWORD *)(a1 + 48128) = 1065353216;
  *(_DWORD *)(a1 + 48144) = 0x40000000;
  *(_DWORD *)(a1 + 48160) = 1059760811;
  *(_DWORD *)(a1 + 48176) = 1059760811;
  *(_DWORD *)(a1 + 48192) = 1040746633;
  *(_DWORD *)(a1 + 48208) = 1035340641;
  *(_DWORD *)(a1 + 48224) = 1011879169;
  *(_DWORD *)(a1 + 48240) = 1003490561;
  *(_DWORD *)(a1 + 48256) = 976809758;
  *(_DWORD *)(a1 + 48272) = 965997180;
  *(_DWORD *)(a1 + 48288) = 936849986;
  *(_DWORD *)(a1 + 48304) = v117;
  *(_DWORD *)(a1 + 48320) = v118;
  *(_DWORD *)(a1 + 48336) = v119;
  *(_DWORD *)(a1 + 48352) = -1069547520;
  *(_DWORD *)(a1 + 48368) = 0;
  *(_DWORD *)(a1 + 48384) = 1065353216;
  *(_DWORD *)(a1 + 48464) = 1065353216;
  *(_DWORD *)(a1 + 48800) = 126279680;
  *(_DWORD *)(a1 + 48816) = 1042787764;
  *(_DWORD *)(a1 + 48832) = 1077222050;
  *(_DWORD *)(a1 + 48848) = -1073771922;
  *(_DWORD *)(a1 + 48864) = 1017280963;
  *(_DWORD *)(a1 + 48976) = v11;
  *(_DWORD *)(a1 + 48992) = 1065353216;
  *(_DWORD *)(a1 + 49008) = 1065353216;
  *(_DWORD *)(a1 + 49168) = v15;
  *(_DWORD *)(a1 + 49184) = 0;
  *(_DWORD *)(a1 + 49200) = 1065353216;
  *(_DWORD *)(a1 + 49248) = v15;
  *(_DWORD *)(a1 + 49264) = 0;
  *(_DWORD *)(a1 + 49280) = 1065353216;
  *(_DWORD *)(a1 + 49536) = -1065353216;
  *(_DWORD *)(a1 + 49552) = 1090519040;
  *(_DWORD *)(a1 + 49696) = 1094847562;
  *(_DWORD *)(a1 + 49712) = -1093102731;
  *(_DWORD *)(a1 + 49728) = 1065353216;
  *(_DWORD *)(a1 + 49744) = v120;
  *(_DWORD *)(a1 + 49760) = v121;
  *(_DWORD *)(a1 + 49776) = 1036831949;
  *(_DWORD *)(a1 + 49792) = 1033476506;
  *(_DWORD *)(a1 + 49808) = v122;
  *(_DWORD *)(a1 + 49824) = -1069547520;
  *(_DWORD *)(a1 + 49840) = 1085066445;
  *(_DWORD *)(a1 + 49856) = -1063780352;
  *(_DWORD *)(a1 + 49872) = 1060205080;
  *(_DWORD *)(a1 + 49888) = -1068320900;
  *(_DWORD *)(a1 + 49904) = v123;
  *(_DWORD *)(a1 + 49920) = 1065353216;
  *(_DWORD *)(a1 + 49936) = 0x40000000;
  *(_DWORD *)(a1 + 49952) = 1059760811;
  *(_DWORD *)(a1 + 49968) = 1059760811;
  *(_DWORD *)(a1 + 49984) = 1040746633;
  *(_DWORD *)(a1 + 50000) = 1035340641;
  *(_DWORD *)(a1 + 50016) = 1011879169;
  *(_DWORD *)(a1 + 50032) = 1003490561;
  *(_DWORD *)(a1 + 50048) = 976809758;
  *(_DWORD *)(a1 + 50064) = 965997180;
  *(_DWORD *)(a1 + 50080) = 936849986;
  *(_DWORD *)(a1 + 50096) = -1090519040;
  *(_DWORD *)(a1 + 50112) = -1104500053;
  *(_DWORD *)(a1 + 50128) = 1026206379;
  *(_DWORD *)(a1 + 50144) = 1007192201;
  *(_DWORD *)(a1 + 50160) = -1162474655;
  *(_DWORD *)(a1 + 50176) = -1185936127;
  *(_DWORD *)(a1 + 50192) = 936381697;
  *(_DWORD *)(a1 + 50208) = 909700893;
  *(_DWORD *)(a1 + 50224) = -1265372546;
  *(_DWORD *)(a1 + 50240) = -1294519765;
  *(_DWORD *)(a1 + 51168) = 941764110;
  *(_DWORD *)(a1 + 51184) = 1048576000;
  *(_DWORD *)(a1 + 51200) = 1082130432;
  *(_DWORD *)(a1 + 51216) = 1056964608;
  *(_DWORD *)(a1 + 51232) = -1102263091;
  *(_DWORD *)(a1 + 51248) = 1065353216;
  *(_DWORD *)(a1 + 51264) = 1061158912;
  *(_DWORD *)(a1 + 51280) = 1048576000;
  *(_DWORD *)(a1 + 51296) = 1056964608;
  *(_DWORD *)(a1 + 51312) = -1171962351;
  *(_DWORD *)(a1 + 51328) = -1158783739;
  *(_DWORD *)(a1 + 51344) = -1155013057;
  *(_DWORD *)(a1 + 51360) = -1160768650;
  *(_DWORD *)(a1 + 51376) = 991644115;
  *(_DWORD *)(a1 + 51392) = 1007191303;
  *(_DWORD *)(a1 + 51408) = 1010918385;
  *(_DWORD *)(a1 + 51424) = 1004371223;
  *(_DWORD *)(a1 + 51440) = -1139388239;
  *(_DWORD *)(a1 + 51456) = -1124889029;
  *(_DWORD *)(a1 + 51472) = -1121773932;
  *(_DWORD *)(a1 + 51488) = -1128877582;
  *(_DWORD *)(a1 + 51504) = 1023290972;
  *(_DWORD *)(a1 + 51520) = 1038327604;
  *(_DWORD *)(a1 + 51536) = 1044714247;
  *(_DWORD *)(a1 + 51552) = 1048155241;
  *(_DWORD *)(a1 + 51568) = 1065353216;
  *(_DWORD *)(a1 + 51584) = 0;
  *(_DWORD *)(a1 + 51792) = v11;
  *(_DWORD *)(a1 + 51856) = v8;
  *(_DWORD *)(a1 + 51936) = v8;
  *(_DWORD *)(a1 + 52000) = -1116138302;
  *(_DWORD *)(a1 + 52016) = v124;
  *(_DWORD *)(a1 + 52032) = v125;
  *(_DWORD *)(a1 + 52048) = 1076754516;
  *(_DWORD *)(a1 + 52064) = v126;
  *(_DWORD *)(a1 + 52080) = v127;
  *(_DWORD *)(a1 + 52384) = -1105618534;
  *(_DWORD *)(a1 + 52400) = 1065353216;
  *(_DWORD *)(a1 + 52416) = 0;
  *(_DWORD *)(a1 + 52432) = v128;
  *(_DWORD *)(a1 + 52448) = 1018980991;
  *(_DWORD *)(a1 + 52512) = v129;
  *(_DWORD *)(a1 + 52608) = v130;
  *(_DWORD *)(a1 + 52624) = v131;
  *(_DWORD *)(a1 + 52640) = v132;
  *(_DWORD *)(a1 + 52656) = v133;
  *(_DWORD *)(a1 + 52672) = v134;
  *(_DWORD *)(a1 + 52688) = v135;
  *(_DWORD *)(a1 + 53104) = v136;
  *(_DWORD *)(a1 + 53328) = 1132462080;
  *(_DWORD *)(a1 + 53344) = 805306368;
  *(_DWORD *)(a1 + 53360) = 872415232;
  *(_DWORD *)(a1 + 53376) = 1028443341;
  *(_DWORD *)(a1 + 53392) = 814313567;
  *(_DWORD *)(a1 + 53408) = 1065353216;
  *(_DWORD *)(a1 + 53424) = 1065353216;
  *(_DWORD *)(a1 + 53712) = 1023805706;
  *(_DWORD *)(a1 + 53728) = -1046478848;
  *(_DWORD *)(a1 + 53744) = 1055831741;
  *(_DWORD *)(a1 + 53760) = 1084821962;
  *(_DWORD *)(a1 + 53776) = -1093425406;
  *(_DWORD *)(a1 + 53792) = 1065353216;
  *(_DWORD *)(a1 + 53808) = 0x40000000;
  *(_DWORD *)(a1 + 53824) = 1059760811;
  *(_DWORD *)(a1 + 53840) = 1059760811;
  *(_DWORD *)(a1 + 53856) = 1040746633;
  *(_DWORD *)(a1 + 53872) = 1035340641;
  *(_DWORD *)(a1 + 53888) = 1011879169;
  *(_DWORD *)(a1 + 53904) = 1003490561;
  *(_DWORD *)(a1 + 53920) = 976809758;
  *(_DWORD *)(a1 + 53936) = 965997180;
  *(_DWORD *)(a1 + 53952) = 936849986;
  *(_DWORD *)(a1 + 54688) = 1014923857;
  *(_DWORD *)(a1 + 54704) = v137;
  *(_DWORD *)(a1 + 54720) = 993063548;
  *(_DWORD *)(a1 + 54736) = 1039798161;
  *(_DWORD *)(a1 + 54752) = 1074365517;
  *(_DWORD *)(a1 + 54768) = -1084150409;
  *(_DWORD *)(a1 + 54784) = -1094106009;
  *(_DWORD *)(a1 + 54800) = -1090489680;
  *(_DWORD *)(a1 + 54816) = 1076754517;
  *(_DWORD *)(a1 + 54832) = -1088302417;
  *(_DWORD *)(a1 + 54848) = -1082130432;
  *(_DWORD *)(a1 + 54864) = 0;
  *(_DWORD *)(a1 + 54880) = -1090519040;
  *(_DWORD *)(a1 + 54896) = 0;
  *(_DWORD *)(a1 + 54912) = 1056964608;
  *(_DWORD *)(a1 + 54928) = 1065353216;
  *(_DWORD *)(a1 + 54944) = 1065353216;
  *(_DWORD *)(a1 + 54960) = 0x40000000;
  *(_DWORD *)(a1 + 54976) = 1065353216;
  *(_DWORD *)(a1 + 54992) = 1056964608;
  *(_DWORD *)(a1 + 55008) = 1096810496;
  *(_DWORD *)(a1 + 55024) = 1013491486;
  *(_DWORD *)(a1 + 55040) = -1090519040;
  *(_DWORD *)(a1 + 55056) = 0;
  *(_DWORD *)(a1 + 55072) = 0;
  *(_DWORD *)(a1 + 55424) = -1090519040;
  *(_DWORD *)(a1 + 55440) = -1056178176;
  *(_DWORD *)(a1 + 55456) = 1094451200;
  *(_DWORD *)(a1 + 55472) = 1097596928;
  *(_DWORD *)(a1 + 55488) = 1091305472;
  *(_DWORD *)(a1 + 55504) = 1090676326;
  *(_DWORD *)(a1 + 55520) = v14;
  *(_DWORD *)(a1 + 55536) = v16;
  *(_DWORD *)(a1 + 55552) = 1038749345;
  *(_DWORD *)(a1 + 55568) = 1065353216;
  *(_DWORD *)(a1 + 55584) = 1065353216;
  *(_DWORD *)(a1 + 55904) = -1090519040;
  *(_DWORD *)(a1 + 55920) = -1056178176;
  *(_DWORD *)(a1 + 55936) = 1094451200;
  *(_DWORD *)(a1 + 55952) = 1097596928;
  *(_DWORD *)(a1 + 55968) = 1091305472;
  *(_DWORD *)(a1 + 55984) = 1090676326;
  *(_DWORD *)(a1 + 56000) = v14;
  *(_DWORD *)(a1 + 56016) = v16;
  *(_DWORD *)(a1 + 56032) = 1038749345;
  *(_DWORD *)(a1 + 56048) = 1065353216;
  *(_DWORD *)(a1 + 56064) = 1065353216;
  *(_DWORD *)(a1 + 56144) = 1065353216;
  *(_DWORD *)(a1 + 56160) = 1065353216;
  *(_DWORD *)(a1 + 56720) = 1056964608;
  *(_DWORD *)(a1 + 56736) = 1056964608;
  *(_DWORD *)(a1 + 56896) = v138;
  *(_DWORD *)(a1 + 56912) = 0x40000000;
  *(_DWORD *)(a1 + 56928) = -1097229926;
  *(_DWORD *)(a1 + 56944) = 0;
  *(_DWORD *)(a1 + 56960) = 1067030938;
  *(_DWORD *)(a1 + 56992) = 1060205080;
  *(_DWORD *)(a1 + 57008) = -1063780352;
  *(_DWORD *)(a1 + 57024) = 1065353216;
  *(_DWORD *)(a1 + 57040) = 0x40000000;
  *(_DWORD *)(a1 + 57056) = 1059760811;
  *(_DWORD *)(a1 + 57072) = 1059760811;
  *(_DWORD *)(a1 + 57088) = 1040746633;
  *(_DWORD *)(a1 + 57104) = 1035340641;
  *(_DWORD *)(a1 + 57120) = 1011879169;
  *(_DWORD *)(a1 + 57136) = 1003490561;
  *(_DWORD *)(a1 + 57152) = 976809758;
  *(_DWORD *)(a1 + 57168) = 965997180;
  *(_DWORD *)(a1 + 57184) = 936849986;
  *(_DWORD *)(a1 + 58096) = v139;
  *(_DWORD *)(a1 + 58112) = 1070141403;
  *(_DWORD *)(a1 + 58128) = 796917760;
  *(_DWORD *)(a1 + 58144) = -1146890486;
  *(_DWORD *)(a1 + 58160) = 1045220557;
  *(_DWORD *)(a1 + 58176) = 1036831949;
  *(_DWORD *)(a1 + 58192) = 1036831949;
  *(_DWORD *)(a1 + 58208) = 1065353216;
  *(_DWORD *)(a1 + 58224) = 1062836634;
  *(_DWORD *)(a1 + 58240) = 1062836634;
  *(_DWORD *)(a1 + 58256) = -1171962351;
  *(_DWORD *)(a1 + 58272) = -1158783739;
  *(_DWORD *)(a1 + 58288) = -1155013057;
  *(_DWORD *)(a1 + 58304) = -1160768650;
  *(_DWORD *)(a1 + 58320) = 991644115;
  *(_DWORD *)(a1 + 58336) = 1007191303;
  *(_DWORD *)(a1 + 58352) = 1010918385;
  *(_DWORD *)(a1 + 58368) = 1004371223;
  *(_DWORD *)(a1 + 58384) = -1139388239;
  *(_DWORD *)(a1 + 58400) = -1124889029;
  *(_DWORD *)(a1 + 58416) = -1121773932;
  *(_DWORD *)(a1 + 58432) = -1128877582;
  *(_DWORD *)(a1 + 58448) = 1023290972;
  *(_DWORD *)(a1 + 58464) = 1038327604;
  *(_DWORD *)(a1 + 58480) = 1044714247;
  *(_DWORD *)(a1 + 58496) = 1048155241;
  *(_DWORD *)(a1 + 58512) = -1104500053;
  *(_DWORD *)(a1 + 58528) = 1007192200;
  *(_DWORD *)(a1 + 58544) = -1185936127;
  *(_DWORD *)(a1 + 58560) = 909700753;
  *(_DWORD *)(a1 + 58576) = -1294492804;
  *(_DWORD *)(a1 + 58592) = 1060205080;
  *(_DWORD *)(a1 + 58608) = -1063780352;
  *(_DWORD *)(a1 + 58624) = -1068320896;
  *(_DWORD *)(a1 + 58640) = 1065353216;
  *(_DWORD *)(a1 + 58656) = 0x40000000;
  *(_DWORD *)(a1 + 58672) = 1059760811;
  *(_DWORD *)(a1 + 58688) = 1059760811;
  *(_DWORD *)(a1 + 58704) = 1040746633;
  *(_DWORD *)(a1 + 58720) = 1035340641;
  *(_DWORD *)(a1 + 58736) = 1011879169;
  *(_DWORD *)(a1 + 58752) = 1003490561;
  *(_DWORD *)(a1 + 58768) = 976809758;
  *(_DWORD *)(a1 + 58784) = 965997180;
  *(_DWORD *)(a1 + 58800) = 936849986;
  *(_DWORD *)(a1 + 58816) = v140;
  *(_DWORD *)(a1 + 58832) = v141;
  *(_DWORD *)(a1 + 58848) = v142;
  *(_DWORD *)(a1 + 58864) = -1069547520;
  *(_DWORD *)(a1 + 58880) = 0;
  *(_DWORD *)(a1 + 58896) = 1065353216;
  *(_DWORD *)(a1 + 58976) = 1065353216;
  *(_DWORD *)(a1 + 59312) = 126279680;
  *(_DWORD *)(a1 + 59328) = 1042787764;
  *(_DWORD *)(a1 + 59344) = 1077222050;
  *(_DWORD *)(a1 + 59360) = -1073771922;
  *(_DWORD *)(a1 + 59376) = 1017280963;
  *(_DWORD *)(a1 + 59488) = v11;
  *(_DWORD *)(a1 + 59504) = 1065353216;
  *(_DWORD *)(a1 + 59520) = 1065353216;
  *(_DWORD *)(a1 + 59680) = v15;
  *(_DWORD *)(a1 + 59696) = 0;
  *(_DWORD *)(a1 + 59712) = 1065353216;
  *(_DWORD *)(a1 + 59760) = v15;
  *(_DWORD *)(a1 + 59776) = 0;
  *(_DWORD *)(a1 + 59792) = 1065353216;
  *(_DWORD *)(a1 + 60048) = -1065353216;
  *(_DWORD *)(a1 + 60064) = 1090519040;
  *(_DWORD *)(a1 + 60208) = 1094847562;
  *(_DWORD *)(a1 + 60224) = -1093102731;
  *(_DWORD *)(a1 + 60240) = 1065353216;
  *(_DWORD *)(a1 + 60256) = v143;
  *(_DWORD *)(a1 + 60272) = v144;
  *(_DWORD *)(a1 + 60288) = 1036831949;
  *(_DWORD *)(a1 + 60304) = 1033476506;
  *(_DWORD *)(a1 + 60320) = v145;
  *(_DWORD *)(a1 + 60336) = -1069547520;
  *(_DWORD *)(a1 + 60352) = 1085066445;
  *(_DWORD *)(a1 + 60368) = -1063780352;
  *(_DWORD *)(a1 + 60384) = 1060205080;
  *(_DWORD *)(a1 + 60400) = -1068320900;
  *(_DWORD *)(a1 + 60416) = v146;
  *(_DWORD *)(a1 + 60432) = 1065353216;
  *(_DWORD *)(a1 + 60448) = 0x40000000;
  *(_DWORD *)(a1 + 60464) = 1059760811;
  *(_DWORD *)(a1 + 60480) = 1059760811;
  *(_DWORD *)(a1 + 60496) = 1040746633;
  *(_DWORD *)(a1 + 60512) = 1035340641;
  *(_DWORD *)(a1 + 60528) = 1011879169;
  *(_DWORD *)(a1 + 60544) = 1003490561;
  *(_DWORD *)(a1 + 60560) = 976809758;
  *(_DWORD *)(a1 + 60576) = 965997180;
  *(_DWORD *)(a1 + 60592) = 936849986;
  *(_DWORD *)(a1 + 60608) = -1090519040;
  *(_DWORD *)(a1 + 60624) = -1104500053;
  *(_DWORD *)(a1 + 60640) = 1026206379;
  *(_DWORD *)(a1 + 60656) = 1007192201;
  *(_DWORD *)(a1 + 60672) = -1162474655;
  *(_DWORD *)(a1 + 60688) = -1185936127;
  *(_DWORD *)(a1 + 60704) = 936381697;
  *(_DWORD *)(a1 + 60720) = 909700893;
  *(_DWORD *)(a1 + 60736) = -1265372546;
  *(_DWORD *)(a1 + 60752) = -1294519765;
  *(_DWORD *)(a1 + 61680) = 941764110;
  *(_DWORD *)(a1 + 61696) = 1048576000;
  *(_DWORD *)(a1 + 61712) = 1082130432;
  *(_DWORD *)(a1 + 61728) = 1056964608;
  *(_DWORD *)(a1 + 61744) = -1102263091;
  *(_DWORD *)(a1 + 61760) = 1065353216;
  *(_DWORD *)(a1 + 61776) = 1061158912;
  *(_DWORD *)(a1 + 61792) = 1048576000;
  *(_DWORD *)(a1 + 61808) = 1056964608;
  *(_DWORD *)(a1 + 61824) = -1171962351;
  *(_DWORD *)(a1 + 61840) = -1158783739;
  *(_DWORD *)(a1 + 61856) = -1155013057;
  *(_DWORD *)(a1 + 61872) = -1160768650;
  *(_DWORD *)(a1 + 61888) = 991644115;
  *(_DWORD *)(a1 + 61904) = 1007191303;
  *(_DWORD *)(a1 + 61920) = 1010918385;
  *(_DWORD *)(a1 + 61936) = 1004371223;
  *(_DWORD *)(a1 + 61952) = -1139388239;
  *(_DWORD *)(a1 + 61968) = -1124889029;
  *(_DWORD *)(a1 + 61984) = -1121773932;
  *(_DWORD *)(a1 + 62000) = -1128877582;
  *(_DWORD *)(a1 + 62016) = 1023290972;
  *(_DWORD *)(a1 + 62032) = 1038327604;
  *(_DWORD *)(a1 + 62048) = 1044714247;
  *(_DWORD *)(a1 + 62064) = 1048155241;
  *(_DWORD *)(a1 + 62080) = 1065353216;
  *(_DWORD *)(a1 + 62096) = 0;
  *(_DWORD *)(a1 + 62304) = v11;
  *(_DWORD *)(a1 + 62368) = v8;
  *(_DWORD *)(a1 + 62448) = v8;
  *(_DWORD *)(a1 + 62512) = -1116138302;
  *(_DWORD *)(a1 + 62528) = v147;
  *(_DWORD *)(a1 + 62544) = v148;
  *(_DWORD *)(a1 + 62560) = 1076754516;
  *(_DWORD *)(a1 + 62576) = v149;
  *(_DWORD *)(a1 + 62592) = v150;
  *(_DWORD *)(a1 + 62896) = -1105618534;
  *(_DWORD *)(a1 + 62912) = 1065353216;
  *(_DWORD *)(a1 + 62928) = 0;
  *(_DWORD *)(a1 + 62944) = v151;
  *(_DWORD *)(a1 + 62960) = 1018980991;
  *(_DWORD *)(a1 + 63024) = v152;
  *(_DWORD *)(a1 + 63120) = v153;
  *(_DWORD *)(a1 + 63136) = v154;
  *(_DWORD *)(a1 + 63152) = v155;
  *(_DWORD *)(a1 + 63168) = v156;
  *(_DWORD *)(a1 + 63184) = v157;
  *(_DWORD *)(a1 + 63200) = v158;
  *(_DWORD *)(a1 + 63616) = v159;
  *(_DWORD *)(a1 + 63840) = 1132462080;
  *(_DWORD *)(a1 + 63856) = 805306368;
  *(_DWORD *)(a1 + 63872) = 872415232;
  *(_DWORD *)(a1 + 63888) = 1028443341;
  *(_DWORD *)(a1 + 63904) = 814313567;
  *(_DWORD *)(a1 + 63920) = 1065353216;
  *(_DWORD *)(a1 + 63936) = 1065353216;
  *(_DWORD *)(a1 + 64224) = 1023805706;
  *(_DWORD *)(a1 + 64240) = -1046478848;
  *(_DWORD *)(a1 + 64256) = 1055831741;
  *(_DWORD *)(a1 + 64272) = 1084821962;
  *(_DWORD *)(a1 + 64288) = -1093425406;
  *(_DWORD *)(a1 + 64304) = 1065353216;
  *(_DWORD *)(a1 + 64320) = 0x40000000;
  *(_DWORD *)(a1 + 64336) = 1059760811;
  *(_DWORD *)(a1 + 64352) = 1059760811;
  *(_DWORD *)(a1 + 64368) = 1040746633;
  *(_DWORD *)(a1 + 64384) = 1035340641;
  *(_DWORD *)(a1 + 64400) = 1011879169;
  *(_DWORD *)(a1 + 64416) = 1003490561;
  *(_DWORD *)(a1 + 64432) = 976809758;
  *(_DWORD *)(a1 + 64448) = 965997180;
  *(_DWORD *)(a1 + 64464) = 936849986;
  *(_DWORD *)(a1 + 65200) = 1014923857;
  *(_DWORD *)(a1 + 65216) = v160;
  *(_DWORD *)(a1 + 65232) = 993063548;
  *(_DWORD *)(a1 + 65248) = 1039798161;
  *(_DWORD *)(a1 + 65264) = 1074365517;
  *(_DWORD *)(a1 + 65280) = -1084150409;
  *(_DWORD *)(a1 + 65296) = -1094106009;
  *(_DWORD *)(a1 + 65312) = -1090489680;
  *(_DWORD *)(a1 + 65328) = 1076754517;
  *(_DWORD *)(a1 + 65344) = -1088302417;
  *(_DWORD *)(a1 + 65360) = -1082130432;
  *(_DWORD *)(a1 + 65376) = 0;
  *(_DWORD *)(a1 + 65392) = -1090519040;
  *(_DWORD *)(a1 + 65408) = 0;
  *(_DWORD *)(a1 + 65424) = 1056964608;
  *(_DWORD *)(a1 + 65440) = 1065353216;
  *(_DWORD *)(a1 + 65456) = 1065353216;
  *(_DWORD *)(a1 + 65472) = 0x40000000;
  *(_DWORD *)(a1 + 65488) = 1065353216;
  *(_DWORD *)(a1 + 65504) = 1056964608;
  *(_DWORD *)(a1 + 65520) = 1096810496;
  *(_DWORD *)(a1 + 0x10000) = 1013491486;
  *(_DWORD *)(a1 + 65552) = -1090519040;
  *(_DWORD *)(a1 + 65568) = 0;
  *(_DWORD *)(a1 + 65584) = 0;
  *(_DWORD *)(a1 + 65936) = -1090519040;
  *(_DWORD *)(a1 + 65952) = -1056178176;
  *(_DWORD *)(a1 + 65968) = 1094451200;
  *(_DWORD *)(a1 + 65984) = 1097596928;
  *(_DWORD *)(a1 + 66000) = 1091305472;
  *(_DWORD *)(a1 + 66016) = 1090676326;
  *(_DWORD *)(a1 + 66032) = v14;
  *(_DWORD *)(a1 + 66048) = v16;
  *(_DWORD *)(a1 + 66064) = 1038749345;
  *(_DWORD *)(a1 + 66080) = 1065353216;
  *(_DWORD *)(a1 + 66096) = 1065353216;
  *(_DWORD *)(a1 + 66416) = -1090519040;
  *(_DWORD *)(a1 + 66432) = -1056178176;
  *(_DWORD *)(a1 + 66448) = 1094451200;
  *(_DWORD *)(a1 + 66464) = 1097596928;
  *(_DWORD *)(a1 + 66480) = 1091305472;
  *(_DWORD *)(a1 + 66496) = 1090676326;
  *(_DWORD *)(a1 + 66512) = v14;
  *(_DWORD *)(a1 + 66528) = v16;
  *(_DWORD *)(a1 + 66544) = 1038749345;
  *(_DWORD *)(a1 + 66560) = 1065353216;
  *(_DWORD *)(a1 + 66576) = 1065353216;
  *(_DWORD *)(a1 + 66656) = 1065353216;
  *(_DWORD *)(a1 + 66672) = 1065353216;
  *(_DWORD *)(a1 + 67232) = 1056964608;
  *(_DWORD *)(a1 + 67248) = 1056964608;
  *(_DWORD *)(a1 + 67408) = v161;
  *(_DWORD *)(a1 + 67424) = 0x40000000;
  *(_DWORD *)(a1 + 67440) = -1097229926;
  *(_DWORD *)(a1 + 67456) = 0;
  *(_DWORD *)(a1 + 67472) = 1067030938;
  *(_DWORD *)(a1 + 67504) = 1060205080;
  *(_DWORD *)(a1 + 67520) = -1063780352;
  *(_DWORD *)(a1 + 67536) = 1065353216;
  *(_DWORD *)(a1 + 67552) = 0x40000000;
  *(_DWORD *)(a1 + 67568) = 1059760811;
  *(_DWORD *)(a1 + 67584) = 1059760811;
  *(_DWORD *)(a1 + 67600) = 1040746633;
  *(_DWORD *)(a1 + 67616) = 1035340641;
  *(_DWORD *)(a1 + 67632) = 1011879169;
  *(_DWORD *)(a1 + 67648) = 1003490561;
  *(_DWORD *)(a1 + 67664) = 976809758;
  *(_DWORD *)(a1 + 67680) = 965997180;
  *(_DWORD *)(a1 + 67696) = 936849986;
  *(_DWORD *)(a1 + 68608) = v162;
  *(_DWORD *)(a1 + 68624) = 1070141403;
  *(_DWORD *)(a1 + 68640) = 796917760;
  *(_DWORD *)(a1 + 68656) = -1146890486;
  *(_DWORD *)(a1 + 68672) = 1045220557;
  *(_DWORD *)(a1 + 68688) = 1036831949;
  *(_DWORD *)(a1 + 68704) = 1036831949;
  *(_DWORD *)(a1 + 68720) = 1065353216;
  *(_DWORD *)(a1 + 68736) = 1062836634;
  *(_DWORD *)(a1 + 68752) = 1062836634;
  *(_DWORD *)(a1 + 68768) = -1171962351;
  *(_DWORD *)(a1 + 68784) = -1158783739;
  *(_DWORD *)(a1 + 68800) = -1155013057;
  *(_DWORD *)(a1 + 68816) = -1160768650;
  *(_DWORD *)(a1 + 68832) = 991644115;
  *(_DWORD *)(a1 + 68848) = 1007191303;
  *(_DWORD *)(a1 + 68864) = 1010918385;
  *(_DWORD *)(a1 + 68880) = 1004371223;
  *(_DWORD *)(a1 + 68896) = -1139388239;
  *(_DWORD *)(a1 + 68912) = -1124889029;
  *(_DWORD *)(a1 + 68928) = -1121773932;
  *(_DWORD *)(a1 + 68944) = -1128877582;
  *(_DWORD *)(a1 + 68960) = 1023290972;
  *(_DWORD *)(a1 + 68976) = 1038327604;
  *(_DWORD *)(a1 + 68992) = 1044714247;
  *(_DWORD *)(a1 + 69008) = 1048155241;
  *(_DWORD *)(a1 + 69024) = -1104500053;
  *(_DWORD *)(a1 + 69040) = 1007192200;
  *(_DWORD *)(a1 + 69056) = -1185936127;
  *(_DWORD *)(a1 + 69072) = 909700753;
  *(_DWORD *)(a1 + 69088) = -1294492804;
  *(_DWORD *)(a1 + 69104) = 1060205080;
  *(_DWORD *)(a1 + 69120) = -1063780352;
  *(_DWORD *)(a1 + 69136) = -1068320896;
  *(_DWORD *)(a1 + 69152) = 1065353216;
  *(_DWORD *)(a1 + 69168) = 0x40000000;
  *(_DWORD *)(a1 + 69184) = 1059760811;
  *(_DWORD *)(a1 + 69200) = 1059760811;
  *(_DWORD *)(a1 + 69216) = 1040746633;
  *(_DWORD *)(a1 + 69232) = 1035340641;
  *(_DWORD *)(a1 + 69248) = 1011879169;
  *(_DWORD *)(a1 + 69264) = 1003490561;
  *(_DWORD *)(a1 + 69280) = 976809758;
  *(_DWORD *)(a1 + 69296) = 965997180;
  *(_DWORD *)(a1 + 69312) = 936849986;
  *(_DWORD *)(a1 + 69328) = v163;
  *(_DWORD *)(a1 + 69344) = v164;
  *(_DWORD *)(a1 + 69360) = v165;
  *(_DWORD *)(a1 + 69376) = -1069547520;
  *(_DWORD *)(a1 + 69392) = 0;
  *(_DWORD *)(a1 + 69408) = 1065353216;
  *(_DWORD *)(a1 + 69488) = 1065353216;
  *(_DWORD *)(a1 + 69824) = 126279680;
  *(_DWORD *)(a1 + 69840) = 1042787764;
  *(_DWORD *)(a1 + 69856) = 1077222050;
  *(_DWORD *)(a1 + 69872) = -1073771922;
  *(_DWORD *)(a1 + 69888) = 1017280963;
  *(_DWORD *)(a1 + 70000) = v11;
  *(_DWORD *)(a1 + 70016) = 1065353216;
  *(_DWORD *)(a1 + 70032) = 1065353216;
  *(_DWORD *)(a1 + 70192) = v15;
  *(_DWORD *)(a1 + 70208) = 0;
  *(_DWORD *)(a1 + 70224) = 1065353216;
  *(_DWORD *)(a1 + 70272) = v15;
  *(_DWORD *)(a1 + 70288) = 0;
  *(_DWORD *)(a1 + 70304) = 1065353216;
  *(_DWORD *)(a1 + 70560) = -1065353216;
  *(_DWORD *)(a1 + 70576) = 1090519040;
  *(_DWORD *)(a1 + 70720) = 1094847562;
  *(_DWORD *)(a1 + 70736) = -1093102731;
  *(_DWORD *)(a1 + 70752) = 1065353216;
  *(_DWORD *)(a1 + 70768) = v166;
  *(_DWORD *)(a1 + 70784) = v167;
  *(_DWORD *)(a1 + 70800) = 1036831949;
  *(_DWORD *)(a1 + 70816) = 1033476506;
  *(_DWORD *)(a1 + 70832) = v168;
  *(_DWORD *)(a1 + 70848) = -1069547520;
  *(_DWORD *)(a1 + 70864) = 1085066445;
  *(_DWORD *)(a1 + 70880) = -1063780352;
  *(_DWORD *)(a1 + 70896) = 1060205080;
  *(_DWORD *)(a1 + 70912) = -1068320900;
  *(_DWORD *)(a1 + 70928) = v169;
  *(_DWORD *)(a1 + 70944) = 1065353216;
  *(_DWORD *)(a1 + 70960) = 0x40000000;
  *(_DWORD *)(a1 + 70976) = 1059760811;
  *(_DWORD *)(a1 + 70992) = 1059760811;
  *(_DWORD *)(a1 + 71008) = 1040746633;
  *(_DWORD *)(a1 + 71024) = 1035340641;
  *(_DWORD *)(a1 + 71040) = 1011879169;
  *(_DWORD *)(a1 + 71056) = 1003490561;
  *(_DWORD *)(a1 + 71072) = 976809758;
  *(_DWORD *)(a1 + 71088) = 965997180;
  *(_DWORD *)(a1 + 71104) = 936849986;
  *(_DWORD *)(a1 + 71120) = -1090519040;
  *(_DWORD *)(a1 + 71136) = -1104500053;
  *(_DWORD *)(a1 + 71152) = 1026206379;
  *(_DWORD *)(a1 + 71168) = 1007192201;
  *(_DWORD *)(a1 + 71184) = -1162474655;
  *(_DWORD *)(a1 + 71200) = -1185936127;
  *(_DWORD *)(a1 + 71216) = 936381697;
  *(_DWORD *)(a1 + 71232) = 909700893;
  *(_DWORD *)(a1 + 71248) = -1265372546;
  *(_DWORD *)(a1 + 71264) = -1294519765;
  *(_DWORD *)(a1 + 72192) = 941764110;
  *(_DWORD *)(a1 + 72208) = 1048576000;
  *(_DWORD *)(a1 + 72224) = 1082130432;
  *(_DWORD *)(a1 + 72240) = 1056964608;
  *(_DWORD *)(a1 + 72256) = -1102263091;
  *(_DWORD *)(a1 + 72272) = 1065353216;
  *(_DWORD *)(a1 + 72288) = 1061158912;
  *(_DWORD *)(a1 + 72304) = 1048576000;
  *(_DWORD *)(a1 + 72320) = 1056964608;
  *(_DWORD *)(a1 + 72336) = -1171962351;
  *(_DWORD *)(a1 + 72352) = -1158783739;
  *(_DWORD *)(a1 + 72368) = -1155013057;
  *(_DWORD *)(a1 + 72384) = -1160768650;
  *(_DWORD *)(a1 + 72400) = 991644115;
  *(_DWORD *)(a1 + 72416) = 1007191303;
  *(_DWORD *)(a1 + 72432) = 1010918385;
  *(_DWORD *)(a1 + 72448) = 1004371223;
  *(_DWORD *)(a1 + 72464) = -1139388239;
  *(_DWORD *)(a1 + 72480) = -1124889029;
  *(_DWORD *)(a1 + 72496) = -1121773932;
  *(_DWORD *)(a1 + 72512) = -1128877582;
  *(_DWORD *)(a1 + 72528) = 1023290972;
  *(_DWORD *)(a1 + 72544) = 1038327604;
  *(_DWORD *)(a1 + 72560) = 1044714247;
  *(_DWORD *)(a1 + 72576) = 1048155241;
  *(_DWORD *)(a1 + 72592) = 1065353216;
  *(_DWORD *)(a1 + 72608) = 0;
  *(_DWORD *)(a1 + 72816) = v11;
  *(_DWORD *)(a1 + 72880) = v8;
  *(_DWORD *)(a1 + 72960) = v8;
  *(_DWORD *)(a1 + 73024) = -1116138302;
  *(_DWORD *)(a1 + 73040) = v170;
  *(_DWORD *)(a1 + 73056) = v171;
  *(_DWORD *)(a1 + 73072) = 1076754516;
  *(_DWORD *)(a1 + 73088) = v172;
  *(_DWORD *)(a1 + 73104) = v173;
  *(_DWORD *)(a1 + 73408) = -1105618534;
  *(_DWORD *)(a1 + 73424) = 1065353216;
  *(_DWORD *)(a1 + 73440) = 0;
  *(_DWORD *)(a1 + 73456) = v174;
  *(_DWORD *)(a1 + 73472) = 1018980991;
  *(_DWORD *)(a1 + 73536) = v175;
  *(_DWORD *)(a1 + 73632) = v176;
  *(_DWORD *)(a1 + 73648) = v177;
  *(_DWORD *)(a1 + 73664) = v178;
  *(_DWORD *)(a1 + 73680) = v179;
  *(_DWORD *)(a1 + 73696) = v180;
  *(_DWORD *)(a1 + 73712) = v181;
  *(_DWORD *)(a1 + 74128) = v297;
  *(_DWORD *)(a1 + 74352) = 1132462080;
  *(_DWORD *)(a1 + 74368) = 805306368;
  *(_DWORD *)(a1 + 74384) = 872415232;
  *(_DWORD *)(a1 + 74400) = 1028443341;
  *(_DWORD *)(a1 + 74416) = 814313567;
  *(_DWORD *)(a1 + 74432) = 1065353216;
  *(_DWORD *)(a1 + 74448) = 1065353216;
  *(_DWORD *)(a1 + 74736) = 1023805706;
  *(_DWORD *)(a1 + 74752) = -1046478848;
  *(_DWORD *)(a1 + 74768) = 1055831741;
  *(_DWORD *)(a1 + 74784) = 1084821962;
  *(_DWORD *)(a1 + 74800) = -1093425406;
  *(_DWORD *)(a1 + 74816) = 1065353216;
  *(_DWORD *)(a1 + 74832) = 0x40000000;
  *(_DWORD *)(a1 + 74848) = 1059760811;
  *(_DWORD *)(a1 + 74864) = 1059760811;
  *(_DWORD *)(a1 + 74880) = 1040746633;
  *(_DWORD *)(a1 + 74896) = 1035340641;
  *(_DWORD *)(a1 + 74912) = 1011879169;
  *(_DWORD *)(a1 + 74928) = 1003490561;
  *(_DWORD *)(a1 + 74944) = 976809758;
  *(_DWORD *)(a1 + 74960) = 965997180;
  *(_DWORD *)(a1 + 74976) = 936849986;
  *(_DWORD *)(a1 + 75712) = 1014923857;
  *(_DWORD *)(a1 + 75728) = v23;
  *(_DWORD *)(a1 + 75744) = 993063548;
  *(_DWORD *)(a1 + 75760) = 1039798161;
  *(_DWORD *)(a1 + 75776) = 1074365517;
  *(_DWORD *)(a1 + 75792) = -1084150409;
  *(_DWORD *)(a1 + 75808) = -1094106009;
  *(_DWORD *)(a1 + 75824) = -1090489680;
  *(_DWORD *)(a1 + 75840) = 1076754517;
  *(_DWORD *)(a1 + 75856) = -1088302417;
  *(_DWORD *)(a1 + 75872) = -1082130432;
  *(_DWORD *)(a1 + 75888) = 0;
  *(_DWORD *)(a1 + 75904) = -1090519040;
  *(_DWORD *)(a1 + 75920) = 0;
  *(_DWORD *)(a1 + 75936) = 1056964608;
  *(_DWORD *)(a1 + 75952) = 1065353216;
  *(_DWORD *)(a1 + 75968) = 1065353216;
  *(_DWORD *)(a1 + 75984) = 0x40000000;
  *(_DWORD *)(a1 + 76000) = 1065353216;
  *(_DWORD *)(a1 + 76016) = 1056964608;
  *(_DWORD *)(a1 + 76032) = 1096810496;
  *(_DWORD *)(a1 + 76048) = 1013491486;
  *(_DWORD *)(a1 + 76064) = -1090519040;
  *(_DWORD *)(a1 + 76080) = 0;
  *(_DWORD *)(a1 + 76096) = 0;
  *(_DWORD *)(a1 + 76448) = -1090519040;
  *(_DWORD *)(a1 + 76464) = -1056178176;
  *(_DWORD *)(a1 + 76480) = 1094451200;
  *(_DWORD *)(a1 + 76496) = 1097596928;
  *(_DWORD *)(a1 + 76512) = 1091305472;
  *(_DWORD *)(a1 + 76528) = 1090676326;
  *(_DWORD *)(a1 + 76544) = v14;
  *(_DWORD *)(a1 + 76560) = v16;
  *(_DWORD *)(a1 + 76576) = 1038749345;
  *(_DWORD *)(a1 + 76592) = 1065353216;
  *(_DWORD *)(a1 + 76608) = 1065353216;
  *(_DWORD *)(a1 + 76928) = -1090519040;
  *(_DWORD *)(a1 + 76944) = -1056178176;
  *(_DWORD *)(a1 + 76960) = 1094451200;
  *(_DWORD *)(a1 + 76976) = 1097596928;
  *(_DWORD *)(a1 + 76992) = 1091305472;
  *(_DWORD *)(a1 + 77008) = 1090676326;
  *(_DWORD *)(a1 + 77024) = v14;
  *(_DWORD *)(a1 + 77040) = v16;
  *(_DWORD *)(a1 + 77056) = 1038749345;
  *(_DWORD *)(a1 + 77072) = 1065353216;
  *(_DWORD *)(a1 + 77088) = 1065353216;
  *(_DWORD *)(a1 + 77168) = 1065353216;
  *(_DWORD *)(a1 + 77184) = 1065353216;
  *(_DWORD *)(a1 + 77744) = 1056964608;
  *(_DWORD *)(a1 + 77760) = 1056964608;
  *(_DWORD *)(a1 + 77920) = v24;
  *(_DWORD *)(a1 + 77936) = 0x40000000;
  *(_DWORD *)(a1 + 77952) = -1097229926;
  *(_DWORD *)(a1 + 77968) = 0;
  *(_DWORD *)(a1 + 77984) = 1067030938;
  *(_DWORD *)(a1 + 78016) = 1060205080;
  *(_DWORD *)(a1 + 78032) = -1063780352;
  *(_DWORD *)(a1 + 78048) = 1065353216;
  *(_DWORD *)(a1 + 78064) = 0x40000000;
  *(_DWORD *)(a1 + 78080) = 1059760811;
  *(_DWORD *)(a1 + 78096) = 1059760811;
  *(_DWORD *)(a1 + 78112) = 1040746633;
  *(_DWORD *)(a1 + 78128) = 1035340641;
  *(_DWORD *)(a1 + 78144) = 1011879169;
  *(_DWORD *)(a1 + 78160) = 1003490561;
  *(_DWORD *)(a1 + 78176) = 976809758;
  *(_DWORD *)(a1 + 78192) = 965997180;
  *(_DWORD *)(a1 + 78208) = 936849986;
  *(_DWORD *)(a1 + 79120) = v298;
  *(_DWORD *)(a1 + 79136) = 1070141403;
  *(_DWORD *)(a1 + 79152) = 796917760;
  *(_DWORD *)(a1 + 79168) = -1146890486;
  *(_DWORD *)(a1 + 79184) = 1045220557;
  *(_DWORD *)(a1 + 79200) = 1036831949;
  *(_DWORD *)(a1 + 79216) = 1036831949;
  *(_DWORD *)(a1 + 79232) = 1065353216;
  *(_DWORD *)(a1 + 79248) = 1062836634;
  *(_DWORD *)(a1 + 79264) = 1062836634;
  *(_DWORD *)(a1 + 79280) = -1171962351;
  *(_DWORD *)(a1 + 79296) = -1158783739;
  *(_DWORD *)(a1 + 79312) = -1155013057;
  *(_DWORD *)(a1 + 79328) = -1160768650;
  *(_DWORD *)(a1 + 79344) = 991644115;
  *(_DWORD *)(a1 + 79360) = 1007191303;
  *(_DWORD *)(a1 + 79376) = 1010918385;
  *(_DWORD *)(a1 + 79392) = 1004371223;
  *(_DWORD *)(a1 + 79408) = -1139388239;
  *(_DWORD *)(a1 + 79424) = -1124889029;
  *(_DWORD *)(a1 + 79440) = -1121773932;
  *(_DWORD *)(a1 + 79456) = -1128877582;
  *(_DWORD *)(a1 + 79472) = 1023290972;
  *(_DWORD *)(a1 + 79488) = 1038327604;
  *(_DWORD *)(a1 + 79504) = 1044714247;
  *(_DWORD *)(a1 + 79520) = 1048155241;
  *(_DWORD *)(a1 + 79536) = -1104500053;
  *(_DWORD *)(a1 + 79552) = 1007192200;
  *(_DWORD *)(a1 + 79568) = -1185936127;
  *(_DWORD *)(a1 + 79584) = 909700753;
  *(_DWORD *)(a1 + 79600) = -1294492804;
  *(_DWORD *)(a1 + 79616) = 1060205080;
  *(_DWORD *)(a1 + 79632) = -1063780352;
  *(_DWORD *)(a1 + 79648) = -1068320896;
  *(_DWORD *)(a1 + 79664) = 1065353216;
  *(_DWORD *)(a1 + 79680) = 0x40000000;
  *(_DWORD *)(a1 + 79696) = 1059760811;
  *(_DWORD *)(a1 + 79712) = 1059760811;
  *(_DWORD *)(a1 + 79728) = 1040746633;
  *(_DWORD *)(a1 + 79744) = 1035340641;
  *(_DWORD *)(a1 + 79760) = 1011879169;
  *(_DWORD *)(a1 + 79776) = 1003490561;
  *(_DWORD *)(a1 + 79792) = 976809758;
  *(_DWORD *)(a1 + 79808) = 965997180;
  *(_DWORD *)(a1 + 79824) = 936849986;
  *(_DWORD *)(a1 + 79840) = v13;
  *(_DWORD *)(a1 + 79856) = v25;
  *(_DWORD *)(a1 + 79872) = v12;
  *(_DWORD *)(a1 + 79888) = -1069547520;
  *(_DWORD *)(a1 + 79904) = 0;
  *(_DWORD *)(a1 + 79920) = 1065353216;
  *(_DWORD *)(a1 + 80000) = 1065353216;
  *(_DWORD *)(a1 + 80336) = 126279680;
  *(_DWORD *)(a1 + 80352) = 1042787764;
  *(_DWORD *)(a1 + 80368) = 1077222050;
  *(_DWORD *)(a1 + 80384) = -1073771922;
  *(_DWORD *)(a1 + 80400) = 1017280963;
  *(_DWORD *)(a1 + 80512) = v11;
  *(_DWORD *)(a1 + 80528) = 1065353216;
  *(_DWORD *)(a1 + 80544) = 1065353216;
  *(_DWORD *)(a1 + 80704) = v15;
  *(_DWORD *)(a1 + 80720) = 0;
  *(_DWORD *)(a1 + 80736) = 1065353216;
  *(_DWORD *)(a1 + 80784) = v15;
  *(_DWORD *)(a1 + 80800) = 0;
  *(_DWORD *)(a1 + 80816) = 1065353216;
  *(_DWORD *)(a1 + 81072) = -1065353216;
  *(_DWORD *)(a1 + 81088) = 1090519040;
  *(_DWORD *)(a1 + 81232) = 1094847562;
  *(_DWORD *)(a1 + 81248) = -1093102731;
  *(_DWORD *)(a1 + 81264) = 1065353216;
  *(_DWORD *)(a1 + 81280) = v299;
  *(_DWORD *)(a1 + 81296) = v300;
  *(_DWORD *)(a1 + 81312) = 1036831949;
  *(_DWORD *)(a1 + 81328) = 1033476506;
  *(_DWORD *)(a1 + 81344) = v17;
  *(_DWORD *)(a1 + 81360) = -1069547520;
  *(_DWORD *)(a1 + 81376) = 1085066445;
  *(_DWORD *)(a1 + 81392) = -1063780352;
  *(_DWORD *)(a1 + 81408) = 1060205080;
  *(_DWORD *)(a1 + 81424) = -1068320900;
  *(_DWORD *)(a1 + 81440) = v18;
  *(_DWORD *)(a1 + 81456) = 1065353216;
  *(_DWORD *)(a1 + 81472) = 0x40000000;
  *(_DWORD *)(a1 + 81488) = 1059760811;
  *(_DWORD *)(a1 + 81504) = 1059760811;
  *(_DWORD *)(a1 + 81520) = 1040746633;
  *(_DWORD *)(a1 + 81536) = 1035340641;
  *(_DWORD *)(a1 + 81552) = 1011879169;
  *(_DWORD *)(a1 + 81568) = 1003490561;
  *(_DWORD *)(a1 + 81584) = 976809758;
  *(_DWORD *)(a1 + 81600) = 965997180;
  *(_DWORD *)(a1 + 81616) = 936849986;
  *(_DWORD *)(a1 + 81632) = -1090519040;
  *(_DWORD *)(a1 + 81648) = -1104500053;
  *(_DWORD *)(a1 + 81664) = 1026206379;
  *(_DWORD *)(a1 + 81680) = 1007192201;
  *(_DWORD *)(a1 + 81696) = -1162474655;
  *(_DWORD *)(a1 + 81712) = -1185936127;
  *(_DWORD *)(a1 + 81728) = 936381697;
  *(_DWORD *)(a1 + 81744) = 909700893;
  *(_DWORD *)(a1 + 81760) = -1265372546;
  *(_DWORD *)(a1 + 81776) = -1294519765;
  *(_DWORD *)(a1 + 82704) = 941764110;
  *(_DWORD *)(a1 + 82720) = 1048576000;
  *(_DWORD *)(a1 + 82736) = 1082130432;
  *(_DWORD *)(a1 + 82752) = 1056964608;
  *(_DWORD *)(a1 + 82768) = -1102263091;
  *(_DWORD *)(a1 + 82784) = 1065353216;
  *(_DWORD *)(a1 + 82800) = 1061158912;
  *(_DWORD *)(a1 + 82816) = 1048576000;
  *(_DWORD *)(a1 + 82832) = 1056964608;
  *(_DWORD *)(a1 + 82848) = -1171962351;
  *(_DWORD *)(a1 + 82864) = -1158783739;
  *(_DWORD *)(a1 + 82880) = -1155013057;
  *(_DWORD *)(a1 + 82896) = -1160768650;
  *(_DWORD *)(a1 + 82912) = 991644115;
  *(_DWORD *)(a1 + 82928) = 1007191303;
  *(_DWORD *)(a1 + 82944) = 1010918385;
  *(_DWORD *)(a1 + 82960) = 1004371223;
  *(_DWORD *)(a1 + 82976) = -1139388239;
  *(_DWORD *)(a1 + 82992) = -1124889029;
  *(_DWORD *)(a1 + 83008) = -1121773932;
  *(_DWORD *)(a1 + 83024) = -1128877582;
  *(_DWORD *)(a1 + 83040) = 1023290972;
  *(_DWORD *)(a1 + 83056) = 1038327604;
  *(_DWORD *)(a1 + 83072) = 1044714247;
  *(_DWORD *)(a1 + 83088) = 1048155241;
  *(_DWORD *)(a1 + 83104) = 1065353216;
  *(_DWORD *)(a1 + 83120) = 0;
  *(_DWORD *)(a1 + 83328) = v11;
  *(_DWORD *)(a1 + 83392) = v8;
  *(_DWORD *)(a1 + 83472) = v8;
  *(_DWORD *)(a1 + 83536) = -1116138302;
  *(_DWORD *)(a1 + 83552) = v19;
  *(_DWORD *)(a1 + 83568) = v20;
  *(_DWORD *)(a1 + 83584) = 1076754516;
  *(_DWORD *)(a1 + 83600) = v21;
  *(_DWORD *)(a1 + 83616) = v22;
  *(_DWORD *)(a1 + 83920) = -1105618534;
  *(_DWORD *)(a1 + 83936) = 1065353216;
  *(_DWORD *)(a1 + 83952) = 0;
  *(_DWORD *)(a1 + 83968) = v10;
  *(_DWORD *)(a1 + 83984) = 1018980991;
  *(_DWORD *)(a1 + 84048) = v9;
  *(_DWORD *)(a1 + 84144) = v7;
  *(_DWORD *)(a1 + 84160) = v6;
  *(_DWORD *)(a1 + 84176) = v5;
  *(_DWORD *)(a1 + 84192) = v4;
  *(_DWORD *)(a1 + 84208) = v3;
  *(_DWORD *)(a1 + 84224) = v2;
  *(_DWORD *)(a1 + 84400) = v182;
  *(_DWORD *)(a1 + 84416) = 0;
  *(_DWORD *)(a1 + 84512) = 1094713344;
  *(_DWORD *)(a1 + 84640) = 1065353216;
  *(_DWORD *)(a1 + 84656) = 0;
  *(_DWORD *)(a1 + 84800) = v183;
  *(_DWORD *)(a1 + 84816) = v184;
  *(_DWORD *)(a1 + 85200) = 1015021568;
  *(_DWORD *)(a1 + 85216) = v185;
  *(_DWORD *)(a1 + 85232) = v186;
  *(_DWORD *)(a1 + 85248) = v187;
  *(_DWORD *)(a1 + 85264) = v188;
  *(_DWORD *)(a1 + 85280) = v189;
  *(_DWORD *)(a1 + 85296) = v190;
  *(_DWORD *)(a1 + 85312) = -2147468975;
  *(_DWORD *)(a1 + 85328) = 1062116885;
  *(_DWORD *)(a1 + 85344) = 1083489464;
  *(_DWORD *)(a1 + 85360) = 1092926403;
  *(_DWORD *)(a1 + 85376) = 1041235968;
  *(_DWORD *)(a1 + 85392) = 1057488896;
  *(_DWORD *)(a1 + 85408) = v191;
  *(_DWORD *)(a1 + 85424) = -1124073472;
  *(_DWORD *)(a1 + 85440) = 1043207291;
  *(_DWORD *)(a1 + 85456) = 1065353216;
  *(_DWORD *)(a1 + 85472) = v192;
  *(_DWORD *)(a1 + 85488) = v193;
  *(_DWORD *)(a1 + 85504) = v194;
  *(_DWORD *)(a1 + 85520) = v195;
  *(_DWORD *)(a1 + 85536) = v196;
  *(_DWORD *)(a1 + 85552) = v197;
  *(_DWORD *)(a1 + 85568) = 934200126;
  *(_DWORD *)(a1 + 85744) = 1056964608;
  *(_DWORD *)(a1 + 85760) = 1048576000;
  *(_DWORD *)(a1 + 85776) = 1061158912;
  *(_DWORD *)(a1 + 85792) = 1117950188;
  *(_DWORD *)(a1 + 85808) = 1069547520;
  *(_DWORD *)(a1 + 85824) = -1090519040;
  *(_DWORD *)(a1 + 85840) = v198;
  *(_DWORD *)(a1 + 85856) = v199;
  *(_DWORD *)(a1 + 85872) = v200;
  *(_DWORD *)(a1 + 85888) = v201;
  *(_DWORD *)(a1 + 86000) = v7;
  *(_DWORD *)(a1 + 86016) = v6;
  *(_DWORD *)(a1 + 86032) = v5;
  *(_DWORD *)(a1 + 86048) = v4;
  *(_DWORD *)(a1 + 86064) = v3;
  *(_DWORD *)(a1 + 86080) = v2;
  *(_DWORD *)(a1 + 86352) = 1015021568;
  *(_DWORD *)(a1 + 86368) = v202;
  *(_DWORD *)(a1 + 86384) = v203;
  *(_DWORD *)(a1 + 86400) = v204;
  *(_DWORD *)(a1 + 86416) = 1033459357;
  *(_DWORD *)(a1 + 86432) = -1084962706;
  *(_DWORD *)(a1 + 86448) = 1075002741;
  *(_DWORD *)(a1 + 86464) = v205;
  *(_DWORD *)(a1 + 86480) = v206;
  *(_DWORD *)(a1 + 86496) = 1052770304;
  *(_DWORD *)(a1 + 86512) = -2147468975;
  *(_DWORD *)(a1 + 86528) = 1062116885;
  *(_DWORD *)(a1 + 86544) = 1083489464;
  *(_DWORD *)(a1 + 86560) = 1092926403;
  *(_DWORD *)(a1 + 86576) = 1041760256;
  *(_DWORD *)(a1 + 86592) = v207;
  *(_DWORD *)(a1 + 86608) = v208;
  *(_DWORD *)(a1 + 86624) = v209;
  *(_DWORD *)(a1 + 86640) = v210;
  *(_DWORD *)(a1 + 86816) = 1056964608;
  *(_DWORD *)(a1 + 86832) = 1048576000;
  *(_DWORD *)(a1 + 86848) = 1061158912;
  *(_DWORD *)(a1 + 86864) = 1129778723;
  *(_DWORD *)(a1 + 86880) = 1069547520;
  *(_DWORD *)(a1 + 86896) = -1090519040;
  *(_DWORD *)(a1 + 86912) = v211;
  *(_DWORD *)(a1 + 86928) = v212;
  *(_DWORD *)(a1 + 86944) = v213;
  *(_DWORD *)(a1 + 86960) = v26;
  *(_DWORD *)(a1 + 87072) = v7;
  *(_DWORD *)(a1 + 87088) = v6;
  *(_DWORD *)(a1 + 87104) = v5;
  *(_DWORD *)(a1 + 87120) = v4;
  *(_DWORD *)(a1 + 87136) = v3;
  *(_DWORD *)(a1 + 87152) = v2;
  *(_DWORD *)(a1 + 87664) = 1015021568;
  *(_DWORD *)(a1 + 87680) = v214;
  *(_DWORD *)(a1 + 87696) = v215;
  *(_DWORD *)(a1 + 87712) = v216;
  *(_DWORD *)(a1 + 87728) = v217;
  *(_DWORD *)(a1 + 87744) = v218;
  *(_DWORD *)(a1 + 87760) = v219;
  *(_DWORD *)(a1 + 87776) = v220;
  *(_DWORD *)(a1 + 87792) = v27;
  *(_DWORD *)(a1 + 87808) = v221;
  *(_DWORD *)(a1 + 87824) = v222;
  *(_DWORD *)(a1 + 87840) = v223;
  *(_DWORD *)(a1 + 87856) = v224;
  *(_DWORD *)(a1 + 87872) = v225;
  *(_DWORD *)(a1 + 87888) = v226;
  *(_DWORD *)(a1 + 87904) = v227;
  *(_DWORD *)(a1 + 87920) = v228;
  *(_DWORD *)(a1 + 87936) = v229;
  *(_DWORD *)(a1 + 87952) = v230;
  *(_DWORD *)(a1 + 87968) = v231;
  *(_DWORD *)(a1 + 87984) = v232;
  *(_DWORD *)(a1 + 88000) = -2147468975;
  *(_DWORD *)(a1 + 88016) = 1062116885;
  *(_DWORD *)(a1 + 88032) = 1083489464;
  *(_DWORD *)(a1 + 88048) = 1092926403;
  *(_DWORD *)(a1 + 88064) = 1025507328;
  *(_DWORD *)(a1 + 88080) = v233;
  *(_DWORD *)(a1 + 88096) = v234;
  *(_DWORD *)(a1 + 88112) = v235;
  *(_DWORD *)(a1 + 88128) = v236;
  *(_DWORD *)(a1 + 88144) = v237;
  *(_DWORD *)(a1 + 88160) = v238;
  *(_DWORD *)(a1 + 88176) = v239;
  *(_DWORD *)(a1 + 88192) = v240;
  *(_DWORD *)(a1 + 88208) = v241;
  *(_DWORD *)(a1 + 88224) = 1063256064;
  *(_DWORD *)(a1 + 88240) = v242;
  *(_DWORD *)(a1 + 88256) = -1070944223;
  *(_DWORD *)(a1 + 88272) = v243;
  *(_DWORD *)(a1 + 88288) = v244;
  *(_DWORD *)(a1 + 88304) = v245;
  *(_DWORD *)(a1 + 88320) = v246;
  *(_DWORD *)(a1 + 88336) = v247;
  *(_DWORD *)(a1 + 88352) = v248;
  *(_DWORD *)(a1 + 88368) = v249;
  *(_DWORD *)(a1 + 88384) = v250;
  *(_DWORD *)(a1 + 88720) = 1056964608;
  *(_DWORD *)(a1 + 88736) = 1048576000;
  *(_DWORD *)(a1 + 88752) = 1061158912;
  *(_DWORD *)(a1 + 88768) = 1113778639;
  *(_DWORD *)(a1 + 88784) = 1117950188;
  *(_DWORD *)(a1 + 88800) = 1069547520;
  *(_DWORD *)(a1 + 88816) = -1090519040;
  *(_DWORD *)(a1 + 88832) = v251;
  *(_DWORD *)(a1 + 88848) = v252;
  *(_DWORD *)(a1 + 88864) = v213;
  *(_DWORD *)(a1 + 88880) = v26;
  *(_DWORD *)(a1 + 88992) = v7;
  *(_DWORD *)(a1 + 89008) = v6;
  *(_DWORD *)(a1 + 89024) = v5;
  *(_DWORD *)(a1 + 89040) = v4;
  *(_DWORD *)(a1 + 89056) = v3;
  *(_DWORD *)(a1 + 89072) = v2;
  *(_DWORD *)(a1 + 89376) = 1015021568;
  *(_DWORD *)(a1 + 89392) = v214;
  *(_DWORD *)(a1 + 89408) = v215;
  *(_DWORD *)(a1 + 89424) = v216;
  *(_DWORD *)(a1 + 89440) = v253;
  *(_DWORD *)(a1 + 89456) = v254;
  *(_DWORD *)(a1 + 89472) = v255;
  *(_DWORD *)(a1 + 89488) = v256;
  *(_DWORD *)(a1 + 89504) = v257;
  *(_DWORD *)(a1 + 89520) = v258;
  *(_DWORD *)(a1 + 89536) = -2147468975;
  *(_DWORD *)(a1 + 89552) = 1062116885;
  *(_DWORD *)(a1 + 89568) = 1083489464;
  *(_DWORD *)(a1 + 89584) = 1092926403;
  *(_DWORD *)(a1 + 89600) = 1006632960;
  *(_DWORD *)(a1 + 89616) = v233;
  *(_DWORD *)(a1 + 89632) = v259;
  *(_DWORD *)(a1 + 89648) = v260;
  *(_DWORD *)(a1 + 89664) = v241;
  *(_DWORD *)(a1 + 90000) = 1056964608;
  *(_DWORD *)(a1 + 90016) = 1048576000;
  *(_DWORD *)(a1 + 90032) = 1061158912;
  *(_DWORD *)(a1 + 90048) = 1108821443;
  *(_DWORD *)(a1 + 90064) = 1104723343;
  *(_DWORD *)(a1 + 90080) = 1069547520;
  *(_DWORD *)(a1 + 90096) = -1090519040;
  *(_DWORD *)(a1 + 90112) = v251;
  *(_DWORD *)(a1 + 90128) = v252;
  *(_DWORD *)(a1 + 90144) = v213;
  *(_DWORD *)(a1 + 90160) = v26;
  *(_DWORD *)(a1 + 90272) = v7;
  *(_DWORD *)(a1 + 90288) = v6;
  *(_DWORD *)(a1 + 90304) = v5;
  *(_DWORD *)(a1 + 90320) = v4;
  *(_DWORD *)(a1 + 90336) = v3;
  *(_DWORD *)(a1 + 90352) = v2;
  *(_DWORD *)(a1 + 91296) = v261;
  *(_DWORD *)(a1 + 91312) = v262;
  *(_DWORD *)(a1 + 91328) = v261;
  *(_DWORD *)(a1 + 91344) = v263;
  *(_DWORD *)(a1 + 91360) = v264;
  *(_DWORD *)(a1 + 91376) = v265;
  *(_DWORD *)(a1 + 91392) = v266;
  *(_DWORD *)(a1 + 91408) = v267;
  *(_DWORD *)(a1 + 91424) = v268;
  *(_DWORD *)(a1 + 91440) = 1069870159;
  *(_DWORD *)(a1 + 91456) = v269;
  *(_DWORD *)(a1 + 91472) = v270;
  *(_DWORD *)(a1 + 91488) = 956301312;
  *(_DWORD *)(a1 + 91504) = 947912704;
  *(_DWORD *)(a1 + 91520) = v271;
  *(_DWORD *)(a1 + 91536) = 1006632960;
  *(_DWORD *)(a1 + 91552) = -1140850688;
  *(_DWORD *)(a1 + 91568) = v28;
  *(_DWORD *)(a1 + 91584) = 1050253722;
  *(_DWORD *)(a1 + 91600) = v272;
  *(_DWORD *)(a1 + 91616) = v273;
  *(_DWORD *)(a1 + 91632) = v274;
  *(_DWORD *)(a1 + 91648) = v275;
  *(_DWORD *)(a1 + 91664) = v276;
  *(_DWORD *)(a1 + 91680) = v275;
  *(_DWORD *)(a1 + 91696) = v277;
  *(_DWORD *)(a1 + 91712) = v278;
  *(_DWORD *)(a1 + 96432) = v279;
  *(_DWORD *)(a1 + 96448) = v280;
  *(_DWORD *)(a1 + 96464) = v281;
  *(_DWORD *)(a1 + 96480) = v282;
  *(_DWORD *)(a1 + 96496) = v283;
  *(_DWORD *)(a1 + 96512) = v282;
  *(_DWORD *)(a1 + 96528) = v284;
  *(_DWORD *)(a1 + 96544) = v285;
  *(_DWORD *)(a1 + 96560) = v286;
  *(_DWORD *)(a1 + 96576) = v287;
  *(_DWORD *)(a1 + 96592) = v288;
  *(_DWORD *)(a1 + 96608) = 1064304640;
  *(_DWORD *)(a1 + 96624) = 1049624576;
  *(_DWORD *)(a1 + 96640) = v289;
  *(_DWORD *)(a1 + 96656) = 1058013184;
  *(_DWORD *)(a1 + 96672) = 1054867456;
  *(_DWORD *)(a1 + 96688) = v290;
  *(_DWORD *)(a1 + 96704) = v291;
  *(_DWORD *)(a1 + 96720) = 1056964608;
  *(_DWORD *)(a1 + 96736) = 1056964608;
  *(_DWORD *)(a1 + 96752) = 0x40000000;
  *(_DWORD *)(a1 + 96768) = 1050673152;
  *(_DWORD *)(a1 + 96784) = v269;
  *(_DWORD *)(a1 + 96800) = v270;
  *(_DWORD *)(a1 + 96816) = 956301312;
  *(_DWORD *)(a1 + 96832) = 947912704;
  *(_DWORD *)(a1 + 96848) = v271;
  *(_DWORD *)(a1 + 96864) = 1006632960;
  *(_DWORD *)(a1 + 96880) = -1140850688;
  *(_DWORD *)(a1 + 96896) = 1068826100;
  *(_DWORD *)(a1 + 96912) = 1060437492;
  *(_DWORD *)(a1 + 101296) = 1048576000;
  *(_DWORD *)(a1 + 101312) = 1065353216;
  *(_DWORD *)(a1 + 101328) = -1448043405;
  *(_DWORD *)(a1 + 101344) = 1082118242;
  *(_DWORD *)(a1 + 101360) = 749584326;
  *(_DWORD *)(a1 + 101376) = 1072502679;
  *(_DWORD *)(a1 + 101392) = -1370528464;
  *(_DWORD *)(a1 + 101408) = -1026209629;
  *(_DWORD *)(a1 + 101424) = -1097121539;
  *(_DWORD *)(a1 + 101440) = -1082293348;
  *(_DWORD *)(a1 + 101456) = 1050362109;
  *(_DWORD *)(a1 + 101472) = 1065190300;
  *(_DWORD *)(a1 + 102704) = v292;
  *(_DWORD *)(a1 + 102720) = 947912704;
  *(_DWORD *)(a1 + 102736) = 1107296256;
  *(_DWORD *)(a1 + 102752) = 1006632960;
  *(_DWORD *)(a1 + 102768) = -1140850688;
  *(_DWORD *)(a1 + 102784) = v293;
  *(_DWORD *)(a1 + 4298000) = v292;
  *(_DWORD *)(a1 + 4298016) = 947912704;
  *(_DWORD *)(a1 + 4298032) = 1107296256;
  *(_DWORD *)(a1 + 4298048) = 1006632960;
  *(_DWORD *)(a1 + 4298064) = -1140850688;
  *(_DWORD *)(a1 + 4298080) = v293;
  *(_DWORD *)(a1 + 6395392) = 1060205080;
  *(_DWORD *)(a1 + 6395408) = -1063780352;
  *(_DWORD *)(a1 + 6395424) = 1065353216;
  *(_DWORD *)(a1 + 6395440) = 0x40000000;
  *(_DWORD *)(a1 + 6395456) = 1059760811;
  *(_DWORD *)(a1 + 6395472) = 1059760811;
  *(_DWORD *)(a1 + 6395488) = 1040746633;
  *(_DWORD *)(a1 + 6395504) = 1035340641;
  *(_DWORD *)(a1 + 6395520) = 1011879169;
  *(_DWORD *)(a1 + 6395536) = 1003490561;
  *(_DWORD *)(a1 + 6395552) = 976809758;
  *(_DWORD *)(a1 + 6395568) = 965997180;
  *(_DWORD *)(a1 + 6395584) = 936849986;
  *(_DWORD *)(a1 + 6395648) = v294;
  *(_DWORD *)(a1 + 6395664) = 796917760;
  *(_DWORD *)(a1 + 6395696) = 1056964608;
  *(_DWORD *)(a1 + 6395712) = 1056964608;
  *(_DWORD *)(a1 + 6396528) = v295;
  *(_DWORD *)(a1 + 6396544) = 956301312;
  *(_DWORD *)(a1 + 6396560) = v292;
  *(_DWORD *)(a1 + 6396576) = 947912704;
  *(_DWORD *)(a1 + 6396592) = 1056964608;
  *(_DWORD *)(a1 + 6396608) = 1006632960;
  *(_DWORD *)(a1 + 6396624) = -1140850688;
  *(_DWORD *)(a1 + 6429552) = 1060205080;
  *(_DWORD *)(a1 + 6429568) = -1063780352;
  *(_DWORD *)(a1 + 6429584) = 1065353216;
  *(_DWORD *)(a1 + 6429600) = 0x40000000;
  *(_DWORD *)(a1 + 6429616) = 1059760811;
  *(_DWORD *)(a1 + 6429632) = 1059760811;
  *(_DWORD *)(a1 + 6429648) = 1040746633;
  *(_DWORD *)(a1 + 6429664) = 1035340641;
  *(_DWORD *)(a1 + 6429680) = 1011879169;
  *(_DWORD *)(a1 + 6429696) = 1003490561;
  *(_DWORD *)(a1 + 6429712) = 976809758;
  *(_DWORD *)(a1 + 6429728) = 965997180;
  *(_DWORD *)(a1 + 6429744) = 936849986;
  *(_DWORD *)(a1 + 6429808) = v294;
  *(_DWORD *)(a1 + 6429824) = 796917760;
  *(_DWORD *)(a1 + 6429856) = 1056964608;
  *(_DWORD *)(a1 + 6429872) = 1056964608;
  *(_DWORD *)(a1 + 6430832) = v296;
  *(_DWORD *)(a1 + 6430848) = 956301312;
  *(_DWORD *)(a1 + 6430864) = v292;
  *(_DWORD *)(a1 + 6430880) = 947912704;
  *(_DWORD *)(a1 + 6430896) = 1056964608;
  *(_DWORD *)(a1 + 6430912) = 1006632960;
  *(_DWORD *)(a1 + 6430928) = -1140850688;
  *(_DWORD *)(a1 + 6497520) = v292;
  *(_DWORD *)(a1 + 6497536) = 947912704;
  *(_DWORD *)(a1 + 6497552) = 1107296256;
  *(_DWORD *)(a1 + 6497568) = 1006632960;
  *(_DWORD *)(a1 + 6497584) = -1140850688;
  *(_DWORD *)(a1 + 6497600) = v293;
  *(_DWORD *)(a1 + 10692096) = 1060205080;
  *(_DWORD *)(a1 + 10692112) = -1063780352;
  *(_DWORD *)(a1 + 10692128) = 1065353216;
  *(_DWORD *)(a1 + 10692144) = 0x40000000;
  *(_DWORD *)(a1 + 10692160) = 1059760811;
  *(_DWORD *)(a1 + 10692176) = 1059760811;
  *(_DWORD *)(a1 + 10692192) = 1040746633;
  *(_DWORD *)(a1 + 10692208) = 1035340641;
  *(_DWORD *)(a1 + 10692224) = 1011879169;
  *(_DWORD *)(a1 + 10692240) = 1003490561;
  *(_DWORD *)(a1 + 10692256) = 976809758;
  *(_DWORD *)(a1 + 10692272) = 965997180;
  *(_DWORD *)(a1 + 10692288) = 936849986;
  *(_DWORD *)(a1 + 10692352) = v294;
  *(_DWORD *)(a1 + 10692368) = 796917760;
  *(_DWORD *)(a1 + 10692400) = 1056964608;
  *(_DWORD *)(a1 + 10692416) = 1056964608;
  *(_DWORD *)(a1 + 10693376) = v295;
  *(_DWORD *)(a1 + 10693392) = 956301312;
  *(_DWORD *)(a1 + 10693408) = v292;
  *(_DWORD *)(a1 + 10693424) = 947912704;
  *(_DWORD *)(a1 + 10693440) = 1056964608;
  *(_DWORD *)(a1 + 10693456) = 1006632960;
  *(_DWORD *)(a1 + 10693472) = -1140850688;
  return result;
}


// ==== sub_7FF91E001300 @ rva 0x3A1300 ====
_QWORD *__fastcall sub_7FF91E001300(__int64 a1)
{
  _QWORD *v2; // rax
  __int64 v3; // rcx
  __int64 v4; // rdi
  _QWORD *v5; // rax
  _DWORD *v6; // rdi
  __int64 v7; // rcx
  _DWORD *v8; // rdi
  __int64 i; // rcx
  _DWORD *v10; // rdi
  __int64 v11; // rcx
  __int64 v12; // r8
  _QWORD *v13; // rax
  __int64 v14; // rcx
  _QWORD *v15; // rax
  __int64 v16; // rcx
  _QWORD *v17; // rax
  __int64 v18; // rcx
  _DWORD *v19; // rdi
  __int64 v20; // rcx
  _DWORD *v21; // rdi
  __int64 j; // rcx
  _QWORD *v23; // rax
  __int64 v24; // rcx
  _QWORD *result; // rax

  *(_DWORD *)(a1 + 176) = 0;
  *(_DWORD *)(a1 + 192) = 0;
  *(_DWORD *)(a1 + 208) = 0;
  *(_DWORD *)(a1 + 224) = 0;
  *(_DWORD *)(a1 + 240) = 0;
  *(_DWORD *)(a1 + 256) = 0;
  *(_DWORD *)(a1 + 288) = 0;
  *(_DWORD *)(a1 + 336) = 0;
  *(_DWORD *)(a1 + 352) = 0;
  *(_DWORD *)(a1 + 400) = 0;
  *(_DWORD *)(a1 + 416) = 0;
  *(_DWORD *)(a1 + 432) = 0;
  *(_DWORD *)(a1 + 448) = 0;
  *(_DWORD *)(a1 + 464) = 0;
  *(_DWORD *)(a1 + 480) = 0;
  *(_DWORD *)(a1 + 496) = 0;
  *(_DWORD *)(a1 + 512) = 0;
  *(_DWORD *)(a1 + 528) = 0;
  *(_DWORD *)(a1 + 560) = 0;
  *(_DWORD *)(a1 + 576) = 0;
  *(_DWORD *)(a1 + 640) = 0;
  *(_DWORD *)(a1 + 656) = 0;
  *(_DWORD *)(a1 + 672) = 0;
  *(_DWORD *)(a1 + 688) = 0;
  *(_DWORD *)(a1 + 704) = 0;
  *(_DWORD *)(a1 + 720) = 0;
  *(_DWORD *)(a1 + 736) = 0;
  *(_DWORD *)(a1 + 752) = 0;
  *(_DWORD *)(a1 + 880) = 0;
  *(_DWORD *)(a1 + 896) = 0;
  *(_DWORD *)(a1 + 912) = 0;
  *(_DWORD *)(a1 + 928) = 0;
  *(_DWORD *)(a1 + 944) = 0;
  *(_DWORD *)(a1 + 960) = 0;
  *(_DWORD *)(a1 + 976) = 0;
  *(_DWORD *)(a1 + 992) = 0;
  *(_DWORD *)(a1 + 1008) = 0;
  *(_DWORD *)(a1 + 1024) = 0;
  *(_DWORD *)(a1 + 1104) = 0;
  *(_DWORD *)(a1 + 1120) = 0;
  *(_DWORD *)(a1 + 1136) = 0;
  *(_DWORD *)(a1 + 1408) = 0;
  *(_DWORD *)(a1 + 1424) = 0;
  *(_DWORD *)(a1 + 1440) = 0;
  *(_DWORD *)(a1 + 1456) = 0;
  *(_DWORD *)(a1 + 1472) = 0;
  *(_DWORD *)(a1 + 1488) = 0;
  *(_DWORD *)(a1 + 1504) = 0;
  *(_DWORD *)(a1 + 1520) = 0;
  *(_DWORD *)(a1 + 1536) = 0;
  *(_DWORD *)(a1 + 1552) = 0;
  *(_DWORD *)(a1 + 1568) = 0;
  *(_DWORD *)(a1 + 1584) = 0;
  *(_DWORD *)(a1 + 1600) = 0;
  *(_DWORD *)(a1 + 1616) = 0;
  *(_DWORD *)(a1 + 1632) = 0;
  *(_DWORD *)(a1 + 1648) = 0;
  *(_DWORD *)(a1 + 1664) = 0;
  *(_DWORD *)(a1 + 1680) = 0;
  *(_DWORD *)(a1 + 1696) = 0;
  *(_DWORD *)(a1 + 1712) = 0;
  *(_DWORD *)(a1 + 1728) = 0;
  *(_DWORD *)(a1 + 1744) = 0;
  *(_DWORD *)(a1 + 1760) = 0;
  *(_DWORD *)(a1 + 1776) = 0;
  *(_DWORD *)(a1 + 1792) = 0;
  *(_DWORD *)(a1 + 1808) = 0;
  *(_DWORD *)(a1 + 1824) = 0;
  *(_DWORD *)(a1 + 1840) = 0;
  *(_DWORD *)(a1 + 2576) = 0;
  *(_DWORD *)(a1 + 2592) = 0;
  *(_DWORD *)(a1 + 2608) = 0;
  *(_DWORD *)(a1 + 2624) = 0;
  *(_DWORD *)(a1 + 2640) = 0;
  *(_DWORD *)(a1 + 2656) = 0;
  *(_DWORD *)(a1 + 2672) = 0;
  *(_DWORD *)(a1 + 2688) = 0;
  *(_DWORD *)(a1 + 2704) = 0;
  *(_DWORD *)(a1 + 2720) = 0;
  *(_DWORD *)(a1 + 2736) = 0;
  *(_DWORD *)(a1 + 2752) = 0;
  *(_DWORD *)(a1 + 2768) = 0;
  *(_DWORD *)(a1 + 3056) = 0;
  *(_DWORD *)(a1 + 3072) = 0;
  *(_DWORD *)(a1 + 3088) = 0;
  *(_DWORD *)(a1 + 3104) = 0;
  *(_DWORD *)(a1 + 3120) = 0;
  *(_DWORD *)(a1 + 3136) = 0;
  *(_DWORD *)(a1 + 3152) = 0;
  *(_DWORD *)(a1 + 3168) = 0;
  *(_DWORD *)(a1 + 3184) = 0;
  *(_DWORD *)(a1 + 3200) = 0;
  *(_DWORD *)(a1 + 3216) = 0;
  *(_DWORD *)(a1 + 3232) = 0;
  *(_DWORD *)(a1 + 3248) = 0;
  *(_DWORD *)(a1 + 3520) = 0;
  *(_DWORD *)(a1 + 3536) = 0;
  *(_DWORD *)(a1 + 3552) = 0;
  *(_DWORD *)(a1 + 3568) = 0;
  *(_DWORD *)(a1 + 3616) = 0;
  *(_DWORD *)(a1 + 3632) = 0;
  *(_DWORD *)(a1 + 3648) = 0;
  *(_DWORD *)(a1 + 3664) = 0;
  *(_DWORD *)(a1 + 3680) = 0;
  *(_DWORD *)(a1 + 3696) = 0;
  *(_DWORD *)(a1 + 3712) = 0;
  *(_DWORD *)(a1 + 3728) = 0;
  *(_DWORD *)(a1 + 3744) = 0;
  *(_DWORD *)(a1 + 3760) = 0;
  *(_DWORD *)(a1 + 3776) = 0;
  *(_DWORD *)(a1 + 3792) = 0;
  *(_DWORD *)(a1 + 3808) = 0;
  *(_DWORD *)(a1 + 3824) = 0;
  *(_DWORD *)(a1 + 4240) = 0;
  *(_DWORD *)(a1 + 4256) = 0;
  *(_DWORD *)(a1 + 4272) = 0;
  *(_DWORD *)(a1 + 4288) = 0;
  *(_DWORD *)(a1 + 4304) = 0;
  *(_DWORD *)(a1 + 4320) = 0;
  *(_DWORD *)(a1 + 4416) = 0;
  *(_DWORD *)(a1 + 4640) = 0;
  *(_DWORD *)(a1 + 4656) = 0;
  *(_DWORD *)(a1 + 4672) = 0;
  *(_DWORD *)(a1 + 4688) = 0;
  *(_DWORD *)(a1 + 4704) = 0;
  *(_DWORD *)(a1 + 4720) = 0;
  *(_DWORD *)(a1 + 4736) = 0;
  *(_DWORD *)(a1 + 4752) = 0;
  *(_DWORD *)(a1 + 4768) = 0;
  *(_DWORD *)(a1 + 4784) = 0;
  *(_DWORD *)(a1 + 4800) = 0;
  *(_DWORD *)(a1 + 4816) = 0;
  *(_DWORD *)(a1 + 4832) = 0;
  *(_DWORD *)(a1 + 4848) = 0;
  *(_DWORD *)(a1 + 4864) = 0;
  *(_DWORD *)(a1 + 4880) = 0;
  *(_DWORD *)(a1 + 4896) = 0;
  *(_DWORD *)(a1 + 4912) = 0;
  *(_DWORD *)(a1 + 4928) = 0;
  *(_DWORD *)(a1 + 4944) = 0;
  *(_DWORD *)(a1 + 4960) = 0;
  *(_DWORD *)(a1 + 4976) = 0;
  *(_DWORD *)(a1 + 4992) = 0;
  *(_DWORD *)(a1 + 5008) = 0;
  *(_DWORD *)(a1 + 5024) = 0;
  *(_DWORD *)(a1 + 5040) = 0;
  *(_DWORD *)(a1 + 5056) = 0;
  *(_DWORD *)(a1 + 5072) = 0;
  *(_DWORD *)(a1 + 5088) = 0;
  *(_DWORD *)(a1 + 5104) = 0;
  *(_DWORD *)(a1 + 5120) = 0;
  *(_DWORD *)(a1 + 5136) = 0;
  *(_DWORD *)(a1 + 5152) = 0;
  *(_DWORD *)(a1 + 5168) = 0;
  *(_DWORD *)(a1 + 5184) = 0;
  *(_DWORD *)(a1 + 5200) = 0;
  *(_DWORD *)(a1 + 5216) = 0;
  *(_DWORD *)(a1 + 5232) = 0;
  *(_DWORD *)(a1 + 5248) = 0;
  *(_DWORD *)(a1 + 5264) = 0;
  *(_DWORD *)(a1 + 5280) = 0;
  *(_DWORD *)(a1 + 5296) = 0;
  *(_DWORD *)(a1 + 5312) = 0;
  *(_DWORD *)(a1 + 5328) = 0;
  *(_DWORD *)(a1 + 5344) = 0;
  *(_DWORD *)(a1 + 5360) = 0;
  *(_DWORD *)(a1 + 5376) = 0;
  *(_DWORD *)(a1 + 5392) = 0;
  *(_DWORD *)(a1 + 5408) = 0;
  *(_DWORD *)(a1 + 5424) = 0;
  *(_DWORD *)(a1 + 5440) = 0;
  *(_DWORD *)(a1 + 5456) = 0;
  *(_DWORD *)(a1 + 5472) = 0;
  *(_DWORD *)(a1 + 5488) = 0;
  *(_DWORD *)(a1 + 5504) = 0;
  *(_DWORD *)(a1 + 6352) = 0;
  *(_DWORD *)(a1 + 6368) = 0;
  *(_DWORD *)(a1 + 6384) = 0;
  *(_DWORD *)(a1 + 6400) = 0;
  *(_DWORD *)(a1 + 6432) = 0;
  *(_DWORD *)(a1 + 6464) = 0;
  *(_DWORD *)(a1 + 6480) = 0;
  *(_DWORD *)(a1 + 6496) = 0;
  *(_DWORD *)(a1 + 6544) = 0;
  *(_DWORD *)(a1 + 6560) = 0;
  *(_DWORD *)(a1 + 6576) = 0;
  *(_DWORD *)(a1 + 6592) = 0;
  *(_DWORD *)(a1 + 6608) = 0;
  *(_DWORD *)(a1 + 6624) = 0;
  *(_DWORD *)(a1 + 6640) = 0;
  *(_DWORD *)(a1 + 6656) = 0;
  *(_DWORD *)(a1 + 6672) = 0;
  *(_DWORD *)(a1 + 6688) = 0;
  *(_DWORD *)(a1 + 6704) = 0;
  *(_DWORD *)(a1 + 6848) = 0;
  *(_DWORD *)(a1 + 6880) = 0;
  *(_DWORD *)(a1 + 6896) = 0;
  *(_DWORD *)(a1 + 6912) = 0;
  *(_DWORD *)(a1 + 6976) = 0;
  *(_DWORD *)(a1 + 6992) = 0;
  *(_DWORD *)(a1 + 7040) = 0;
  *(_DWORD *)(a1 + 7056) = 0;
  *(_DWORD *)(a1 + 7072) = 0;
  *(_DWORD *)(a1 + 7088) = 0;
  *(_DWORD *)(a1 + 7104) = 0;
  *(_DWORD *)(a1 + 7168) = 0;
  *(_DWORD *)(a1 + 7184) = 0;
  *(_DWORD *)(a1 + 7248) = 0;
  *(_DWORD *)(a1 + 7264) = 0;
  *(_DWORD *)(a1 + 7280) = 0;
  *(_DWORD *)(a1 + 7520) = 0;
  *(_DWORD *)(a1 + 7536) = 0;
  *(_DWORD *)(a1 + 7552) = 0;
  *(_DWORD *)(a1 + 7568) = 0;
  *(_DWORD *)(a1 + 7584) = 0;
  *(_DWORD *)(a1 + 8208) = 0;
  *(_DWORD *)(a1 + 8224) = 0;
  *(_DWORD *)(a1 + 8240) = 0;
  *(_DWORD *)(a1 + 8256) = 0;
  *(_DWORD *)(a1 + 8272) = 0;
  *(_DWORD *)(a1 + 8288) = 0;
  *(_DWORD *)(a1 + 8304) = 0;
  *(_DWORD *)(a1 + 8320) = 0;
  *(_DWORD *)(a1 + 8336) = 0;
  *(_DWORD *)(a1 + 8352) = 0;
  *(_DWORD *)(a1 + 8368) = 0;
  *(_DWORD *)(a1 + 8384) = 0;
  *(_DWORD *)(a1 + 8400) = 0;
  *(_DWORD *)(a1 + 8416) = 0;
  *(_DWORD *)(a1 + 8432) = 0;
  *(_DWORD *)(a1 + 8448) = 0;
  *(_DWORD *)(a1 + 8464) = 0;
  *(_DWORD *)(a1 + 8480) = 0;
  *(_DWORD *)(a1 + 8496) = 0;
  *(_DWORD *)(a1 + 8512) = 0;
  *(_DWORD *)(a1 + 8528) = 0;
  *(_DWORD *)(a1 + 8544) = 0;
  *(_DWORD *)(a1 + 8560) = 0;
  *(_DWORD *)(a1 + 8576) = 0;
  *(_DWORD *)(a1 + 8592) = 0;
  *(_DWORD *)(a1 + 8608) = 0;
  *(_DWORD *)(a1 + 8624) = 0;
  *(_DWORD *)(a1 + 8640) = 0;
  *(_DWORD *)(a1 + 8656) = 0;
  *(_DWORD *)(a1 + 8672) = 0;
  *(_DWORD *)(a1 + 8688) = 0;
  *(_DWORD *)(a1 + 8704) = 0;
  *(_DWORD *)(a1 + 8720) = 0;
  *(_DWORD *)(a1 + 8736) = 0;
  *(_DWORD *)(a1 + 8752) = 0;
  *(_DWORD *)(a1 + 8768) = 0;
  *(_DWORD *)(a1 + 8784) = 0;
  *(_DWORD *)(a1 + 8800) = 0;
  *(_DWORD *)(a1 + 8816) = 0;
  *(_DWORD *)(a1 + 8832) = 0;
  *(_DWORD *)(a1 + 8848) = 0;
  *(_DWORD *)(a1 + 8864) = 0;
  *(_DWORD *)(a1 + 8880) = 0;
  *(_DWORD *)(a1 + 8896) = 0;
  *(_DWORD *)(a1 + 8912) = 0;
  *(_DWORD *)(a1 + 8928) = 0;
  *(_DWORD *)(a1 + 8944) = 0;
  *(_DWORD *)(a1 + 8960) = 0;
  *(_DWORD *)(a1 + 8976) = 0;
  *(_DWORD *)(a1 + 8992) = 0;
  *(_DWORD *)(a1 + 9008) = 0;
  *(_DWORD *)(a1 + 9024) = 0;
  *(_DWORD *)(a1 + 9040) = 0;
  *(_DWORD *)(a1 + 9552) = 0;
  *(_DWORD *)(a1 + 9568) = 0;
  *(_DWORD *)(a1 + 9632) = 0;
  *(_DWORD *)(a1 + 9648) = 0;
  *(_DWORD *)(a1 + 9664) = 0;
  *(_DWORD *)(a1 + 9696) = 0;
  *(_DWORD *)(a1 + 9712) = 0;
  *(_DWORD *)(a1 + 9728) = 0;
  *(_DWORD *)(a1 + 9760) = 0;
  *(_DWORD *)(a1 + 9776) = 0;
  *(_DWORD *)(a1 + 9792) = 0;
  *(_DWORD *)(a1 + 9840) = 0;
  *(_DWORD *)(a1 + 9856) = 0;
  *(_DWORD *)(a1 + 9872) = 0;
  *(_DWORD *)(a1 + 9904) = 0;
  *(_DWORD *)(a1 + 9920) = 0;
  *(_DWORD *)(a1 + 9936) = 0;
  *(_DWORD *)(a1 + 10048) = 0;
  *(_DWORD *)(a1 + 10064) = 0;
  *(_DWORD *)(a1 + 10080) = 0;
  *(_DWORD *)(a1 + 10096) = 0;
  *(_DWORD *)(a1 + 10112) = 0;
  *(_DWORD *)(a1 + 10128) = 0;
  *(_DWORD *)(a1 + 10144) = 0;
  *(_DWORD *)(a1 + 10160) = 0;
  *(_DWORD *)(a1 + 10416) = 0;
  *(_DWORD *)(a1 + 10432) = 0;
  *(_DWORD *)(a1 + 10448) = 0;
  *(_DWORD *)(a1 + 10480) = 0;
  *(_DWORD *)(a1 + 10496) = 0;
  *(_DWORD *)(a1 + 10512) = 0;
  *(_DWORD *)(a1 + 10528) = 0;
  *(_DWORD *)(a1 + 10544) = 0;
  *(_DWORD *)(a1 + 10656) = 0;
  *(_DWORD *)(a1 + 10672) = 0;
  *(_DWORD *)(a1 + 10688) = 0;
  *(_DWORD *)(a1 + 10704) = 0;
  *(_DWORD *)(a1 + 10720) = 0;
  *(_DWORD *)(a1 + 10736) = 0;
  *(_DWORD *)(a1 + 10752) = 0;
  *(_DWORD *)(a1 + 10768) = 0;
  *(_DWORD *)(a1 + 10800) = 0;
  *(_DWORD *)(a1 + 10848) = 0;
  *(_DWORD *)(a1 + 10864) = 0;
  *(_DWORD *)(a1 + 10912) = 0;
  *(_DWORD *)(a1 + 10928) = 0;
  *(_DWORD *)(a1 + 10944) = 0;
  *(_DWORD *)(a1 + 10960) = 0;
  *(_DWORD *)(a1 + 10976) = 0;
  *(_DWORD *)(a1 + 10992) = 0;
  *(_DWORD *)(a1 + 11008) = 0;
  *(_DWORD *)(a1 + 11024) = 0;
  *(_DWORD *)(a1 + 11040) = 0;
  *(_DWORD *)(a1 + 11072) = 0;
  *(_DWORD *)(a1 + 11088) = 0;
  *(_DWORD *)(a1 + 11152) = 0;
  *(_DWORD *)(a1 + 11168) = 0;
  *(_DWORD *)(a1 + 11184) = 0;
  *(_DWORD *)(a1 + 11200) = 0;
  *(_DWORD *)(a1 + 11216) = 0;
  *(_DWORD *)(a1 + 11232) = 0;
  *(_DWORD *)(a1 + 11248) = 0;
  *(_DWORD *)(a1 + 11264) = 0;
  *(_DWORD *)(a1 + 11392) = 0;
  *(_DWORD *)(a1 + 11408) = 0;
  *(_DWORD *)(a1 + 11424) = 0;
  *(_DWORD *)(a1 + 11440) = 0;
  *(_DWORD *)(a1 + 11456) = 0;
  *(_DWORD *)(a1 + 11472) = 0;
  *(_DWORD *)(a1 + 11488) = 0;
  *(_DWORD *)(a1 + 11504) = 0;
  *(_DWORD *)(a1 + 11520) = 0;
  *(_DWORD *)(a1 + 11536) = 0;
  *(_DWORD *)(a1 + 11616) = 0;
  *(_DWORD *)(a1 + 11632) = 0;
  *(_DWORD *)(a1 + 11648) = 0;
  *(_DWORD *)(a1 + 11920) = 0;
  *(_DWORD *)(a1 + 11936) = 0;
  *(_DWORD *)(a1 + 11952) = 0;
  *(_DWORD *)(a1 + 11968) = 0;
  *(_DWORD *)(a1 + 11984) = 0;
  *(_DWORD *)(a1 + 12000) = 0;
  *(_DWORD *)(a1 + 12016) = 0;
  *(_DWORD *)(a1 + 12032) = 0;
  *(_DWORD *)(a1 + 12048) = 0;
  *(_DWORD *)(a1 + 12064) = 0;
  *(_DWORD *)(a1 + 12080) = 0;
  *(_DWORD *)(a1 + 12096) = 0;
  *(_DWORD *)(a1 + 12112) = 0;
  *(_DWORD *)(a1 + 12128) = 0;
  *(_DWORD *)(a1 + 12144) = 0;
  *(_DWORD *)(a1 + 12160) = 0;
  *(_DWORD *)(a1 + 12176) = 0;
  *(_DWORD *)(a1 + 12192) = 0;
  *(_DWORD *)(a1 + 12208) = 0;
  *(_DWORD *)(a1 + 12224) = 0;
  *(_DWORD *)(a1 + 12240) = 0;
  *(_DWORD *)(a1 + 12256) = 0;
  *(_DWORD *)(a1 + 12272) = 0;
  *(_DWORD *)(a1 + 12288) = 0;
  *(_DWORD *)(a1 + 12304) = 0;
  *(_DWORD *)(a1 + 12320) = 0;
  *(_DWORD *)(a1 + 12336) = 0;
  *(_DWORD *)(a1 + 12352) = 0;
  *(_DWORD *)(a1 + 13088) = 0;
  *(_DWORD *)(a1 + 13104) = 0;
  *(_DWORD *)(a1 + 13120) = 0;
  *(_DWORD *)(a1 + 13136) = 0;
  *(_DWORD *)(a1 + 13152) = 0;
  *(_DWORD *)(a1 + 13168) = 0;
  *(_DWORD *)(a1 + 13184) = 0;
  *(_DWORD *)(a1 + 13200) = 0;
  *(_DWORD *)(a1 + 13216) = 0;
  *(_DWORD *)(a1 + 13232) = 0;
  *(_DWORD *)(a1 + 13248) = 0;
  *(_DWORD *)(a1 + 13264) = 0;
  *(_DWORD *)(a1 + 13280) = 0;
  *(_DWORD *)(a1 + 13568) = 0;
  *(_DWORD *)(a1 + 13584) = 0;
  *(_DWORD *)(a1 + 13600) = 0;
  *(_DWORD *)(a1 + 13616) = 0;
  *(_DWORD *)(a1 + 13632) = 0;
  *(_DWORD *)(a1 + 13648) = 0;
  *(_DWORD *)(a1 + 13664) = 0;
  *(_DWORD *)(a1 + 13680) = 0;
  *(_DWORD *)(a1 + 13696) = 0;
  *(_DWORD *)(a1 + 13712) = 0;
  *(_DWORD *)(a1 + 13728) = 0;
  *(_DWORD *)(a1 + 13744) = 0;
  *(_DWORD *)(a1 + 13760) = 0;
  *(_DWORD *)(a1 + 14032) = 0;
  *(_DWORD *)(a1 + 14048) = 0;
  *(_DWORD *)(a1 + 14064) = 0;
  *(_DWORD *)(a1 + 14080) = 0;
  *(_DWORD *)(a1 + 14128) = 0;
  *(_DWORD *)(a1 + 14144) = 0;
  *(_DWORD *)(a1 + 14160) = 0;
  *(_DWORD *)(a1 + 14176) = 0;
  *(_DWORD *)(a1 + 14192) = 0;
  *(_DWORD *)(a1 + 14208) = 0;
  *(_DWORD *)(a1 + 14224) = 0;
  *(_DWORD *)(a1 + 14240) = 0;
  *(_DWORD *)(a1 + 14256) = 0;
  *(_DWORD *)(a1 + 14272) = 0;
  *(_DWORD *)(a1 + 14288) = 0;
  *(_DWORD *)(a1 + 14304) = 0;
  *(_DWORD *)(a1 + 14320) = 0;
  *(_DWORD *)(a1 + 14336) = 0;
  *(_DWORD *)(a1 + 14752) = 0;
  *(_DWORD *)(a1 + 14768) = 0;
  *(_DWORD *)(a1 + 14784) = 0;
  *(_DWORD *)(a1 + 14800) = 0;
  *(_DWORD *)(a1 + 14816) = 0;
  *(_DWORD *)(a1 + 14832) = 0;
  *(_DWORD *)(a1 + 14928) = 0;
  *(_DWORD *)(a1 + 15152) = 0;
  *(_DWORD *)(a1 + 15168) = 0;
  *(_DWORD *)(a1 + 15184) = 0;
  *(_DWORD *)(a1 + 15200) = 0;
  *(_DWORD *)(a1 + 15216) = 0;
  *(_DWORD *)(a1 + 15232) = 0;
  *(_DWORD *)(a1 + 15248) = 0;
  *(_DWORD *)(a1 + 15264) = 0;
  *(_DWORD *)(a1 + 15280) = 0;
  *(_DWORD *)(a1 + 15296) = 0;
  *(_DWORD *)(a1 + 15312) = 0;
  *(_DWORD *)(a1 + 15328) = 0;
  *(_DWORD *)(a1 + 15344) = 0;
  *(_DWORD *)(a1 + 15360) = 0;
  *(_DWORD *)(a1 + 15376) = 0;
  *(_DWORD *)(a1 + 15392) = 0;
  *(_DWORD *)(a1 + 15408) = 0;
  *(_DWORD *)(a1 + 15424) = 0;
  *(_DWORD *)(a1 + 15440) = 0;
  *(_DWORD *)(a1 + 15456) = 0;
  *(_DWORD *)(a1 + 15472) = 0;
  *(_DWORD *)(a1 + 15488) = 0;
  *(_DWORD *)(a1 + 15504) = 0;
  *(_DWORD *)(a1 + 15520) = 0;
  *(_DWORD *)(a1 + 15536) = 0;
  *(_DWORD *)(a1 + 15552) = 0;
  *(_DWORD *)(a1 + 15568) = 0;
  *(_DWORD *)(a1 + 15584) = 0;
  *(_DWORD *)(a1 + 15600) = 0;
  *(_DWORD *)(a1 + 15616) = 0;
  *(_DWORD *)(a1 + 15632) = 0;
  *(_DWORD *)(a1 + 15648) = 0;
  *(_DWORD *)(a1 + 15664) = 0;
  *(_DWORD *)(a1 + 15680) = 0;
  *(_DWORD *)(a1 + 15696) = 0;
  *(_DWORD *)(a1 + 15712) = 0;
  *(_DWORD *)(a1 + 15728) = 0;
  *(_DWORD *)(a1 + 15744) = 0;
  *(_DWORD *)(a1 + 15760) = 0;
  *(_DWORD *)(a1 + 15776) = 0;
  *(_DWORD *)(a1 + 15792) = 0;
  *(_DWORD *)(a1 + 15808) = 0;
  *(_DWORD *)(a1 + 15824) = 0;
  *(_DWORD *)(a1 + 15840) = 0;
  *(_DWORD *)(a1 + 15856) = 0;
  *(_DWORD *)(a1 + 15872) = 0;
  *(_DWORD *)(a1 + 15888) = 0;
  *(_DWORD *)(a1 + 15904) = 0;
  *(_DWORD *)(a1 + 15920) = 0;
  *(_DWORD *)(a1 + 15936) = 0;
  *(_DWORD *)(a1 + 15952) = 0;
  *(_DWORD *)(a1 + 15968) = 0;
  *(_DWORD *)(a1 + 15984) = 0;
  *(_DWORD *)(a1 + 16000) = 0;
  *(_DWORD *)(a1 + 16016) = 0;
  *(_DWORD *)(a1 + 16864) = 0;
  *(_DWORD *)(a1 + 16880) = 0;
  *(_DWORD *)(a1 + 16896) = 0;
  *(_DWORD *)(a1 + 16912) = 0;
  *(_DWORD *)(a1 + 16944) = 0;
  *(_DWORD *)(a1 + 16976) = 0;
  *(_DWORD *)(a1 + 16992) = 0;
  *(_DWORD *)(a1 + 17008) = 0;
  *(_DWORD *)(a1 + 17056) = 0;
  *(_DWORD *)(a1 + 17072) = 0;
  *(_DWORD *)(a1 + 17088) = 0;
  *(_DWORD *)(a1 + 17104) = 0;
  *(_DWORD *)(a1 + 17120) = 0;
  *(_DWORD *)(a1 + 17136) = 0;
  *(_DWORD *)(a1 + 17152) = 0;
  *(_DWORD *)(a1 + 17168) = 0;
  *(_DWORD *)(a1 + 17184) = 0;
  *(_DWORD *)(a1 + 17200) = 0;
  *(_DWORD *)(a1 + 17216) = 0;
  *(_DWORD *)(a1 + 17360) = 0;
  *(_DWORD *)(a1 + 17392) = 0;
  *(_DWORD *)(a1 + 17408) = 0;
  *(_DWORD *)(a1 + 17424) = 0;
  *(_DWORD *)(a1 + 17488) = 0;
  *(_DWORD *)(a1 + 17504) = 0;
  *(_DWORD *)(a1 + 17552) = 0;
  *(_DWORD *)(a1 + 17568) = 0;
  *(_DWORD *)(a1 + 17584) = 0;
  *(_DWORD *)(a1 + 17600) = 0;
  *(_DWORD *)(a1 + 17616) = 0;
  *(_DWORD *)(a1 + 17680) = 0;
  *(_DWORD *)(a1 + 17696) = 0;
  *(_DWORD *)(a1 + 17760) = 0;
  *(_DWORD *)(a1 + 17776) = 0;
  *(_DWORD *)(a1 + 17792) = 0;
  *(_DWORD *)(a1 + 18032) = 0;
  *(_DWORD *)(a1 + 18048) = 0;
  *(_DWORD *)(a1 + 18064) = 0;
  *(_DWORD *)(a1 + 18080) = 0;
  *(_DWORD *)(a1 + 18096) = 0;
  *(_DWORD *)(a1 + 18720) = 0;
  *(_DWORD *)(a1 + 18736) = 0;
  *(_DWORD *)(a1 + 18752) = 0;
  *(_DWORD *)(a1 + 18768) = 0;
  *(_DWORD *)(a1 + 18784) = 0;
  *(_DWORD *)(a1 + 18800) = 0;
  *(_DWORD *)(a1 + 18816) = 0;
  *(_DWORD *)(a1 + 18832) = 0;
  *(_DWORD *)(a1 + 18848) = 0;
  *(_DWORD *)(a1 + 18864) = 0;
  *(_DWORD *)(a1 + 18880) = 0;
  *(_DWORD *)(a1 + 18896) = 0;
  *(_DWORD *)(a1 + 18912) = 0;
  *(_DWORD *)(a1 + 18928) = 0;
  *(_DWORD *)(a1 + 18944) = 0;
  *(_DWORD *)(a1 + 18960) = 0;
  *(_DWORD *)(a1 + 18976) = 0;
  *(_DWORD *)(a1 + 18992) = 0;
  *(_DWORD *)(a1 + 19008) = 0;
  *(_DWORD *)(a1 + 19024) = 0;
  *(_DWORD *)(a1 + 19040) = 0;
  *(_DWORD *)(a1 + 19056) = 0;
  *(_DWORD *)(a1 + 19072) = 0;
  *(_DWORD *)(a1 + 19088) = 0;
  *(_DWORD *)(a1 + 19104) = 0;
  *(_DWORD *)(a1 + 19120) = 0;
  *(_DWORD *)(a1 + 19136) = 0;
  *(_DWORD *)(a1 + 19152) = 0;
  *(_DWORD *)(a1 + 19168) = 0;
  *(_DWORD *)(a1 + 19184) = 0;
  *(_DWORD *)(a1 + 19200) = 0;
  *(_DWORD *)(a1 + 19216) = 0;
  *(_DWORD *)(a1 + 19232) = 0;
  *(_DWORD *)(a1 + 19248) = 0;
  *(_DWORD *)(a1 + 19264) = 0;
  *(_DWORD *)(a1 + 19280) = 0;
  *(_DWORD *)(a1 + 19296) = 0;
  *(_DWORD *)(a1 + 19312) = 0;
  *(_DWORD *)(a1 + 19328) = 0;
  *(_DWORD *)(a1 + 19344) = 0;
  *(_DWORD *)(a1 + 19360) = 0;
  *(_DWORD *)(a1 + 19376) = 0;
  *(_DWORD *)(a1 + 19392) = 0;
  *(_DWORD *)(a1 + 19408) = 0;
  *(_DWORD *)(a1 + 19424) = 0;
  *(_DWORD *)(a1 + 19440) = 0;
  *(_DWORD *)(a1 + 19456) = 0;
  *(_DWORD *)(a1 + 19472) = 0;
  *(_DWORD *)(a1 + 19488) = 0;
  *(_DWORD *)(a1 + 19504) = 0;
  *(_DWORD *)(a1 + 19520) = 0;
  *(_DWORD *)(a1 + 19536) = 0;
  *(_DWORD *)(a1 + 19552) = 0;
  *(_DWORD *)(a1 + 20064) = 0;
  *(_DWORD *)(a1 + 20080) = 0;
  *(_DWORD *)(a1 + 20144) = 0;
  *(_DWORD *)(a1 + 20160) = 0;
  *(_DWORD *)(a1 + 20176) = 0;
  *(_DWORD *)(a1 + 20208) = 0;
  *(_DWORD *)(a1 + 20224) = 0;
  *(_DWORD *)(a1 + 20240) = 0;
  *(_DWORD *)(a1 + 20272) = 0;
  *(_DWORD *)(a1 + 20288) = 0;
  *(_DWORD *)(a1 + 20304) = 0;
  *(_DWORD *)(a1 + 20352) = 0;
  *(_DWORD *)(a1 + 20368) = 0;
  *(_DWORD *)(a1 + 20384) = 0;
  *(_DWORD *)(a1 + 20416) = 0;
  *(_DWORD *)(a1 + 20432) = 0;
  *(_DWORD *)(a1 + 20448) = 0;
  *(_DWORD *)(a1 + 20560) = 0;
  *(_DWORD *)(a1 + 20576) = 0;
  *(_DWORD *)(a1 + 20592) = 0;
  *(_DWORD *)(a1 + 20608) = 0;
  *(_DWORD *)(a1 + 20624) = 0;
  *(_DWORD *)(a1 + 20640) = 0;
  *(_DWORD *)(a1 + 20656) = 0;
  *(_DWORD *)(a1 + 20672) = 0;
  *(_DWORD *)(a1 + 20928) = 0;
  *(_DWORD *)(a1 + 20944) = 0;
  *(_DWORD *)(a1 + 20960) = 0;
  *(_DWORD *)(a1 + 20992) = 0;
  *(_DWORD *)(a1 + 21008) = 0;
  *(_DWORD *)(a1 + 21024) = 0;
  *(_DWORD *)(a1 + 21040) = 0;
  *(_DWORD *)(a1 + 21056) = 0;
  *(_DWORD *)(a1 + 21168) = 0;
  *(_DWORD *)(a1 + 21184) = 0;
  *(_DWORD *)(a1 + 21200) = 0;
  *(_DWORD *)(a1 + 21216) = 0;
  *(_DWORD *)(a1 + 21232) = 0;
  *(_DWORD *)(a1 + 21248) = 0;
  *(_DWORD *)(a1 + 21264) = 0;
  *(_DWORD *)(a1 + 21280) = 0;
  *(_DWORD *)(a1 + 21312) = 0;
  *(_DWORD *)(a1 + 21360) = 0;
  *(_DWORD *)(a1 + 21376) = 0;
  *(_DWORD *)(a1 + 21424) = 0;
  *(_DWORD *)(a1 + 21440) = 0;
  *(_DWORD *)(a1 + 21456) = 0;
  *(_DWORD *)(a1 + 21472) = 0;
  *(_DWORD *)(a1 + 21488) = 0;
  *(_DWORD *)(a1 + 21504) = 0;
  *(_DWORD *)(a1 + 21520) = 0;
  *(_DWORD *)(a1 + 21536) = 0;
  *(_DWORD *)(a1 + 21552) = 0;
  *(_DWORD *)(a1 + 21584) = 0;
  *(_DWORD *)(a1 + 21600) = 0;
  *(_DWORD *)(a1 + 21664) = 0;
  *(_DWORD *)(a1 + 21680) = 0;
  *(_DWORD *)(a1 + 21696) = 0;
  *(_DWORD *)(a1 + 21712) = 0;
  *(_DWORD *)(a1 + 21728) = 0;
  *(_DWORD *)(a1 + 21744) = 0;
  *(_DWORD *)(a1 + 21760) = 0;
  *(_DWORD *)(a1 + 21776) = 0;
  *(_DWORD *)(a1 + 21904) = 0;
  *(_DWORD *)(a1 + 21920) = 0;
  *(_DWORD *)(a1 + 21936) = 0;
  *(_DWORD *)(a1 + 21952) = 0;
  *(_DWORD *)(a1 + 21968) = 0;
  *(_DWORD *)(a1 + 21984) = 0;
  *(_DWORD *)(a1 + 22000) = 0;
  *(_DWORD *)(a1 + 22016) = 0;
  *(_DWORD *)(a1 + 22032) = 0;
  *(_DWORD *)(a1 + 22048) = 0;
  *(_DWORD *)(a1 + 22128) = 0;
  *(_DWORD *)(a1 + 22144) = 0;
  *(_DWORD *)(a1 + 22160) = 0;
  *(_DWORD *)(a1 + 22432) = 0;
  *(_DWORD *)(a1 + 22448) = 0;
  *(_DWORD *)(a1 + 22464) = 0;
  *(_DWORD *)(a1 + 22480) = 0;
  *(_DWORD *)(a1 + 22496) = 0;
  *(_DWORD *)(a1 + 22512) = 0;
  *(_DWORD *)(a1 + 22528) = 0;
  *(_DWORD *)(a1 + 22544) = 0;
  *(_DWORD *)(a1 + 22560) = 0;
  *(_DWORD *)(a1 + 22576) = 0;
  *(_DWORD *)(a1 + 22592) = 0;
  *(_DWORD *)(a1 + 22608) = 0;
  *(_DWORD *)(a1 + 22624) = 0;
  *(_DWORD *)(a1 + 22640) = 0;
  *(_DWORD *)(a1 + 22656) = 0;
  *(_DWORD *)(a1 + 22672) = 0;
  *(_DWORD *)(a1 + 22688) = 0;
  *(_DWORD *)(a1 + 22704) = 0;
  *(_DWORD *)(a1 + 22720) = 0;
  *(_DWORD *)(a1 + 22736) = 0;
  *(_DWORD *)(a1 + 22752) = 0;
  *(_DWORD *)(a1 + 22768) = 0;
  *(_DWORD *)(a1 + 22784) = 0;
  *(_DWORD *)(a1 + 22800) = 0;
  *(_DWORD *)(a1 + 22816) = 0;
  *(_DWORD *)(a1 + 22832) = 0;
  *(_DWORD *)(a1 + 22848) = 0;
  *(_DWORD *)(a1 + 22864) = 0;
  *(_DWORD *)(a1 + 23600) = 0;
  *(_DWORD *)(a1 + 23616) = 0;
  *(_DWORD *)(a1 + 23632) = 0;
  *(_DWORD *)(a1 + 23648) = 0;
  *(_DWORD *)(a1 + 23664) = 0;
  *(_DWORD *)(a1 + 23680) = 0;
  *(_DWORD *)(a1 + 23696) = 0;
  *(_DWORD *)(a1 + 23712) = 0;
  *(_DWORD *)(a1 + 23728) = 0;
  *(_DWORD *)(a1 + 23744) = 0;
  *(_DWORD *)(a1 + 23760) = 0;
  *(_DWORD *)(a1 + 23776) = 0;
  *(_DWORD *)(a1 + 23792) = 0;
  *(_DWORD *)(a1 + 24080) = 0;
  *(_DWORD *)(a1 + 24096) = 0;
  *(_DWORD *)(a1 + 24112) = 0;
  *(_DWORD *)(a1 + 24128) = 0;
  *(_DWORD *)(a1 + 24144) = 0;
  *(_DWORD *)(a1 + 24160) = 0;
  *(_DWORD *)(a1 + 24176) = 0;
  *(_DWORD *)(a1 + 24192) = 0;
  *(_DWORD *)(a1 + 24208) = 0;
  *(_DWORD *)(a1 + 24224) = 0;
  *(_DWORD *)(a1 + 24240) = 0;
  *(_DWORD *)(a1 + 24256) = 0;
  *(_DWORD *)(a1 + 24272) = 0;
  *(_DWORD *)(a1 + 24544) = 0;
  *(_DWORD *)(a1 + 24560) = 0;
  *(_DWORD *)(a1 + 24576) = 0;
  *(_DWORD *)(a1 + 24592) = 0;
  *(_DWORD *)(a1 + 24640) = 0;
  *(_DWORD *)(a1 + 24656) = 0;
  *(_DWORD *)(a1 + 24672) = 0;
  *(_DWORD *)(a1 + 24688) = 0;
  *(_DWORD *)(a1 + 24704) = 0;
  *(_DWORD *)(a1 + 24720) = 0;
  *(_DWORD *)(a1 + 24736) = 0;
  *(_DWORD *)(a1 + 24752) = 0;
  *(_DWORD *)(a1 + 24768) = 0;
  *(_DWORD *)(a1 + 24784) = 0;
  *(_DWORD *)(a1 + 24800) = 0;
  *(_DWORD *)(a1 + 24816) = 0;
  *(_DWORD *)(a1 + 24832) = 0;
  *(_DWORD *)(a1 + 24848) = 0;
  *(_DWORD *)(a1 + 25264) = 0;
  *(_DWORD *)(a1 + 25280) = 0;
  *(_DWORD *)(a1 + 25296) = 0;
  *(_DWORD *)(a1 + 25312) = 0;
  *(_DWORD *)(a1 + 25328) = 0;
  *(_DWORD *)(a1 + 25344) = 0;
  *(_DWORD *)(a1 + 25440) = 0;
  *(_DWORD *)(a1 + 25664) = 0;
  *(_DWORD *)(a1 + 25680) = 0;
  *(_DWORD *)(a1 + 25696) = 0;
  *(_DWORD *)(a1 + 25712) = 0;
  *(_DWORD *)(a1 + 25728) = 0;
  *(_DWORD *)(a1 + 25744) = 0;
  *(_DWORD *)(a1 + 25760) = 0;
  *(_DWORD *)(a1 + 25776) = 0;
  *(_DWORD *)(a1 + 25792) = 0;
  *(_DWORD *)(a1 + 25808) = 0;
  *(_DWORD *)(a1 + 25824) = 0;
  *(_DWORD *)(a1 + 25840) = 0;
  *(_DWORD *)(a1 + 25856) = 0;
  *(_DWORD *)(a1 + 25872) = 0;
  *(_DWORD *)(a1 + 25888) = 0;
  *(_DWORD *)(a1 + 25904) = 0;
  *(_DWORD *)(a1 + 25920) = 0;
  *(_DWORD *)(a1 + 25936) = 0;
  *(_DWORD *)(a1 + 25952) = 0;
  *(_DWORD *)(a1 + 25968) = 0;
  *(_DWORD *)(a1 + 25984) = 0;
  *(_DWORD *)(a1 + 26000) = 0;
  *(_DWORD *)(a1 + 26016) = 0;
  *(_DWORD *)(a1 + 26032) = 0;
  *(_DWORD *)(a1 + 26048) = 0;
  *(_DWORD *)(a1 + 26064) = 0;
  *(_DWORD *)(a1 + 26080) = 0;
  *(_DWORD *)(a1 + 26096) = 0;
  *(_DWORD *)(a1 + 26112) = 0;
  *(_DWORD *)(a1 + 26128) = 0;
  *(_DWORD *)(a1 + 26144) = 0;
  *(_DWORD *)(a1 + 26160) = 0;
  *(_DWORD *)(a1 + 26176) = 0;
  *(_DWORD *)(a1 + 26192) = 0;
  *(_DWORD *)(a1 + 26208) = 0;
  *(_DWORD *)(a1 + 26224) = 0;
  *(_DWORD *)(a1 + 26240) = 0;
  *(_DWORD *)(a1 + 26256) = 0;
  *(_DWORD *)(a1 + 26272) = 0;
  *(_DWORD *)(a1 + 26288) = 0;
  *(_DWORD *)(a1 + 26304) = 0;
  *(_DWORD *)(a1 + 26320) = 0;
  *(_DWORD *)(a1 + 26336) = 0;
  *(_DWORD *)(a1 + 26352) = 0;
  *(_DWORD *)(a1 + 26368) = 0;
  *(_DWORD *)(a1 + 26384) = 0;
  *(_DWORD *)(a1 + 26400) = 0;
  *(_DWORD *)(a1 + 26416) = 0;
  *(_DWORD *)(a1 + 26432) = 0;
  *(_DWORD *)(a1 + 26448) = 0;
  *(_DWORD *)(a1 + 26464) = 0;
  *(_DWORD *)(a1 + 26480) = 0;
  *(_DWORD *)(a1 + 26496) = 0;
  *(_DWORD *)(a1 + 26512) = 0;
  *(_DWORD *)(a1 + 26528) = 0;
  *(_DWORD *)(a1 + 27376) = 0;
  *(_DWORD *)(a1 + 27392) = 0;
  *(_DWORD *)(a1 + 27408) = 0;
  *(_DWORD *)(a1 + 27424) = 0;
  *(_DWORD *)(a1 + 27456) = 0;
  *(_DWORD *)(a1 + 27488) = 0;
  *(_DWORD *)(a1 + 27504) = 0;
  *(_DWORD *)(a1 + 27520) = 0;
  *(_DWORD *)(a1 + 27568) = 0;
  *(_DWORD *)(a1 + 27584) = 0;
  *(_DWORD *)(a1 + 27600) = 0;
  *(_DWORD *)(a1 + 27616) = 0;
  *(_DWORD *)(a1 + 27632) = 0;
  *(_DWORD *)(a1 + 27648) = 0;
  *(_DWORD *)(a1 + 27664) = 0;
  *(_DWORD *)(a1 + 27680) = 0;
  *(_DWORD *)(a1 + 27696) = 0;
  *(_DWORD *)(a1 + 27712) = 0;
  *(_DWORD *)(a1 + 27728) = 0;
  *(_DWORD *)(a1 + 27872) = 0;
  *(_DWORD *)(a1 + 27904) = 0;
  *(_DWORD *)(a1 + 27920) = 0;
  *(_DWORD *)(a1 + 27936) = 0;
  *(_DWORD *)(a1 + 28000) = 0;
  *(_DWORD *)(a1 + 28016) = 0;
  *(_DWORD *)(a1 + 28064) = 0;
  *(_DWORD *)(a1 + 28080) = 0;
  *(_DWORD *)(a1 + 28096) = 0;
  *(_DWORD *)(a1 + 28112) = 0;
  *(_DWORD *)(a1 + 28128) = 0;
  *(_DWORD *)(a1 + 28192) = 0;
  *(_DWORD *)(a1 + 28208) = 0;
  *(_DWORD *)(a1 + 28272) = 0;
  *(_DWORD *)(a1 + 28288) = 0;
  *(_DWORD *)(a1 + 28304) = 0;
  *(_DWORD *)(a1 + 28544) = 0;
  *(_DWORD *)(a1 + 28560) = 0;
  *(_DWORD *)(a1 + 28576) = 0;
  *(_DWORD *)(a1 + 28592) = 0;
  *(_DWORD *)(a1 + 28608) = 0;
  *(_DWORD *)(a1 + 29232) = 0;
  *(_DWORD *)(a1 + 29248) = 0;
  *(_DWORD *)(a1 + 29264) = 0;
  *(_DWORD *)(a1 + 29280) = 0;
  *(_DWORD *)(a1 + 29296) = 0;
  *(_DWORD *)(a1 + 29312) = 0;
  *(_DWORD *)(a1 + 29328) = 0;
  *(_DWORD *)(a1 + 29344) = 0;
  *(_DWORD *)(a1 + 29360) = 0;
  *(_DWORD *)(a1 + 29376) = 0;
  *(_DWORD *)(a1 + 29392) = 0;
  *(_DWORD *)(a1 + 29408) = 0;
  *(_DWORD *)(a1 + 29424) = 0;
  *(_DWORD *)(a1 + 29440) = 0;
  *(_DWORD *)(a1 + 29456) = 0;
  *(_DWORD *)(a1 + 29472) = 0;
  *(_DWORD *)(a1 + 29488) = 0;
  *(_DWORD *)(a1 + 29504) = 0;
  *(_DWORD *)(a1 + 29520) = 0;
  *(_DWORD *)(a1 + 29536) = 0;
  *(_DWORD *)(a1 + 29552) = 0;
  *(_DWORD *)(a1 + 29568) = 0;
  *(_DWORD *)(a1 + 29584) = 0;
  *(_DWORD *)(a1 + 29600) = 0;
  *(_DWORD *)(a1 + 29616) = 0;
  *(_DWORD *)(a1 + 29632) = 0;
  *(_DWORD *)(a1 + 29648) = 0;
  *(_DWORD *)(a1 + 29664) = 0;
  *(_DWORD *)(a1 + 29680) = 0;
  *(_DWORD *)(a1 + 29696) = 0;
  *(_DWORD *)(a1 + 29712) = 0;
  *(_DWORD *)(a1 + 29728) = 0;
  *(_DWORD *)(a1 + 29744) = 0;
  *(_DWORD *)(a1 + 29760) = 0;
  *(_DWORD *)(a1 + 29776) = 0;
  *(_DWORD *)(a1 + 29792) = 0;
  *(_DWORD *)(a1 + 29808) = 0;
  *(_DWORD *)(a1 + 29824) = 0;
  *(_DWORD *)(a1 + 29840) = 0;
  *(_DWORD *)(a1 + 29856) = 0;
  *(_DWORD *)(a1 + 29872) = 0;
  *(_DWORD *)(a1 + 29888) = 0;
  *(_DWORD *)(a1 + 29904) = 0;
  *(_DWORD *)(a1 + 29920) = 0;
  *(_DWORD *)(a1 + 29936) = 0;
  *(_DWORD *)(a1 + 29952) = 0;
  *(_DWORD *)(a1 + 29968) = 0;
  *(_DWORD *)(a1 + 29984) = 0;
  *(_DWORD *)(a1 + 30000) = 0;
  *(_DWORD *)(a1 + 30016) = 0;
  *(_DWORD *)(a1 + 30032) = 0;
  *(_DWORD *)(a1 + 30048) = 0;
  *(_DWORD *)(a1 + 30064) = 0;
  *(_DWORD *)(a1 + 30576) = 0;
  *(_DWORD *)(a1 + 30592) = 0;
  *(_DWORD *)(a1 + 30656) = 0;
  *(_DWORD *)(a1 + 30672) = 0;
  *(_DWORD *)(a1 + 30688) = 0;
  *(_DWORD *)(a1 + 30720) = 0;
  *(_DWORD *)(a1 + 30736) = 0;
  *(_DWORD *)(a1 + 30752) = 0;
  *(_DWORD *)(a1 + 30784) = 0;
  *(_DWORD *)(a1 + 30800) = 0;
  *(_DWORD *)(a1 + 30816) = 0;
  *(_DWORD *)(a1 + 30864) = 0;
  *(_DWORD *)(a1 + 30880) = 0;
  *(_DWORD *)(a1 + 30896) = 0;
  *(_DWORD *)(a1 + 30928) = 0;
  *(_DWORD *)(a1 + 30944) = 0;
  *(_DWORD *)(a1 + 30960) = 0;
  *(_DWORD *)(a1 + 31072) = 0;
  *(_DWORD *)(a1 + 31088) = 0;
  *(_DWORD *)(a1 + 31104) = 0;
  *(_DWORD *)(a1 + 31120) = 0;
  *(_DWORD *)(a1 + 31136) = 0;
  *(_DWORD *)(a1 + 31152) = 0;
  *(_DWORD *)(a1 + 31168) = 0;
  *(_DWORD *)(a1 + 31184) = 0;
  *(_DWORD *)(a1 + 31440) = 0;
  *(_DWORD *)(a1 + 31456) = 0;
  *(_DWORD *)(a1 + 31472) = 0;
  *(_DWORD *)(a1 + 31504) = 0;
  *(_DWORD *)(a1 + 31520) = 0;
  *(_DWORD *)(a1 + 31536) = 0;
  *(_DWORD *)(a1 + 31552) = 0;
  *(_DWORD *)(a1 + 31568) = 0;
  *(_DWORD *)(a1 + 31680) = 0;
  *(_DWORD *)(a1 + 31696) = 0;
  *(_DWORD *)(a1 + 31712) = 0;
  *(_DWORD *)(a1 + 31728) = 0;
  *(_DWORD *)(a1 + 31744) = 0;
  *(_DWORD *)(a1 + 31760) = 0;
  *(_DWORD *)(a1 + 31776) = 0;
  *(_DWORD *)(a1 + 31792) = 0;
  *(_DWORD *)(a1 + 31824) = 0;
  *(_DWORD *)(a1 + 31872) = 0;
  *(_DWORD *)(a1 + 31888) = 0;
  *(_DWORD *)(a1 + 31936) = 0;
  *(_DWORD *)(a1 + 31952) = 0;
  *(_DWORD *)(a1 + 31968) = 0;
  *(_DWORD *)(a1 + 31984) = 0;
  *(_DWORD *)(a1 + 32000) = 0;
  *(_DWORD *)(a1 + 32016) = 0;
  *(_DWORD *)(a1 + 32032) = 0;
  *(_DWORD *)(a1 + 32048) = 0;
  *(_DWORD *)(a1 + 32064) = 0;
  *(_DWORD *)(a1 + 32096) = 0;
  *(_DWORD *)(a1 + 32112) = 0;
  *(_DWORD *)(a1 + 32176) = 0;
  *(_DWORD *)(a1 + 32192) = 0;
  *(_DWORD *)(a1 + 32208) = 0;
  *(_DWORD *)(a1 + 32224) = 0;
  *(_DWORD *)(a1 + 32240) = 0;
  *(_DWORD *)(a1 + 32256) = 0;
  *(_DWORD *)(a1 + 32272) = 0;
  *(_DWORD *)(a1 + 32288) = 0;
  *(_DWORD *)(a1 + 32416) = 0;
  *(_DWORD *)(a1 + 32432) = 0;
  *(_DWORD *)(a1 + 32448) = 0;
  *(_DWORD *)(a1 + 32464) = 0;
  *(_DWORD *)(a1 + 32480) = 0;
  *(_DWORD *)(a1 + 32496) = 0;
  *(_DWORD *)(a1 + 32512) = 0;
  *(_DWORD *)(a1 + 32528) = 0;
  *(_DWORD *)(a1 + 32544) = 0;
  *(_DWORD *)(a1 + 32560) = 0;
  *(_DWORD *)(a1 + 32640) = 0;
  *(_DWORD *)(a1 + 32656) = 0;
  *(_DWORD *)(a1 + 32672) = 0;
  *(_DWORD *)(a1 + 32944) = 0;
  *(_DWORD *)(a1 + 32960) = 0;
  *(_DWORD *)(a1 + 32976) = 0;
  *(_DWORD *)(a1 + 32992) = 0;
  *(_DWORD *)(a1 + 33008) = 0;
  *(_DWORD *)(a1 + 33024) = 0;
  *(_DWORD *)(a1 + 33040) = 0;
  *(_DWORD *)(a1 + 33056) = 0;
  *(_DWORD *)(a1 + 33072) = 0;
  *(_DWORD *)(a1 + 33088) = 0;
  *(_DWORD *)(a1 + 33104) = 0;
  *(_DWORD *)(a1 + 33120) = 0;
  *(_DWORD *)(a1 + 33136) = 0;
  *(_DWORD *)(a1 + 33152) = 0;
  *(_DWORD *)(a1 + 33168) = 0;
  *(_DWORD *)(a1 + 33184) = 0;
  *(_DWORD *)(a1 + 33200) = 0;
  *(_DWORD *)(a1 + 33216) = 0;
  *(_DWORD *)(a1 + 33232) = 0;
  *(_DWORD *)(a1 + 33248) = 0;
  *(_DWORD *)(a1 + 33264) = 0;
  *(_DWORD *)(a1 + 33280) = 0;
  *(_DWORD *)(a1 + 33296) = 0;
  *(_DWORD *)(a1 + 33312) = 0;
  *(_DWORD *)(a1 + 33328) = 0;
  *(_DWORD *)(a1 + 33344) = 0;
  *(_DWORD *)(a1 + 33360) = 0;
  *(_DWORD *)(a1 + 33376) = 0;
  *(_DWORD *)(a1 + 34112) = 0;
  *(_DWORD *)(a1 + 34128) = 0;
  *(_DWORD *)(a1 + 34144) = 0;
  *(_DWORD *)(a1 + 34160) = 0;
  *(_DWORD *)(a1 + 34176) = 0;
  *(_DWORD *)(a1 + 34192) = 0;
  *(_DWORD *)(a1 + 34208) = 0;
  *(_DWORD *)(a1 + 34224) = 0;
  *(_DWORD *)(a1 + 34240) = 0;
  *(_DWORD *)(a1 + 34256) = 0;
  *(_DWORD *)(a1 + 34272) = 0;
  *(_DWORD *)(a1 + 34288) = 0;
  *(_DWORD *)(a1 + 34304) = 0;
  *(_DWORD *)(a1 + 34592) = 0;
  *(_DWORD *)(a1 + 34608) = 0;
  *(_DWORD *)(a1 + 34624) = 0;
  *(_DWORD *)(a1 + 34640) = 0;
  *(_DWORD *)(a1 + 34656) = 0;
  *(_DWORD *)(a1 + 34672) = 0;
  *(_DWORD *)(a1 + 34688) = 0;
  *(_DWORD *)(a1 + 34704) = 0;
  *(_DWORD *)(a1 + 34720) = 0;
  *(_DWORD *)(a1 + 34736) = 0;
  *(_DWORD *)(a1 + 34752) = 0;
  *(_DWORD *)(a1 + 34768) = 0;
  *(_DWORD *)(a1 + 34784) = 0;
  *(_DWORD *)(a1 + 35056) = 0;
  *(_DWORD *)(a1 + 35072) = 0;
  *(_DWORD *)(a1 + 35088) = 0;
  *(_DWORD *)(a1 + 35104) = 0;
  *(_DWORD *)(a1 + 35152) = 0;
  *(_DWORD *)(a1 + 35168) = 0;
  *(_DWORD *)(a1 + 35184) = 0;
  *(_DWORD *)(a1 + 35200) = 0;
  *(_DWORD *)(a1 + 35216) = 0;
  *(_DWORD *)(a1 + 35232) = 0;
  *(_DWORD *)(a1 + 35248) = 0;
  *(_DWORD *)(a1 + 35264) = 0;
  *(_DWORD *)(a1 + 35280) = 0;
  *(_DWORD *)(a1 + 35296) = 0;
  *(_DWORD *)(a1 + 35312) = 0;
  *(_DWORD *)(a1 + 35328) = 0;
  *(_DWORD *)(a1 + 35344) = 0;
  *(_DWORD *)(a1 + 35360) = 0;
  *(_DWORD *)(a1 + 35776) = 0;
  *(_DWORD *)(a1 + 35792) = 0;
  *(_DWORD *)(a1 + 35808) = 0;
  *(_DWORD *)(a1 + 35824) = 0;
  *(_DWORD *)(a1 + 35840) = 0;
  *(_DWORD *)(a1 + 35856) = 0;
  *(_DWORD *)(a1 + 35952) = 0;
  *(_DWORD *)(a1 + 36176) = 0;
  *(_DWORD *)(a1 + 36192) = 0;
  *(_DWORD *)(a1 + 36208) = 0;
  *(_DWORD *)(a1 + 36224) = 0;
  *(_DWORD *)(a1 + 36240) = 0;
  *(_DWORD *)(a1 + 36256) = 0;
  *(_DWORD *)(a1 + 36272) = 0;
  *(_DWORD *)(a1 + 36288) = 0;
  *(_DWORD *)(a1 + 36304) = 0;
  *(_DWORD *)(a1 + 36320) = 0;
  *(_DWORD *)(a1 + 36336) = 0;
  *(_DWORD *)(a1 + 36352) = 0;
  *(_DWORD *)(a1 + 36368) = 0;
  *(_DWORD *)(a1 + 36384) = 0;
  *(_DWORD *)(a1 + 36400) = 0;
  *(_DWORD *)(a1 + 36416) = 0;
  *(_DWORD *)(a1 + 36432) = 0;
  *(_DWORD *)(a1 + 36448) = 0;
  *(_DWORD *)(a1 + 36464) = 0;
  *(_DWORD *)(a1 + 36480) = 0;
  *(_DWORD *)(a1 + 36496) = 0;
  *(_DWORD *)(a1 + 36512) = 0;
  *(_DWORD *)(a1 + 36528) = 0;
  *(_DWORD *)(a1 + 36544) = 0;
  *(_DWORD *)(a1 + 36560) = 0;
  *(_DWORD *)(a1 + 36576) = 0;
  *(_DWORD *)(a1 + 36592) = 0;
  *(_DWORD *)(a1 + 36608) = 0;
  *(_DWORD *)(a1 + 36624) = 0;
  *(_DWORD *)(a1 + 36640) = 0;
  *(_DWORD *)(a1 + 36656) = 0;
  *(_DWORD *)(a1 + 36672) = 0;
  *(_DWORD *)(a1 + 36688) = 0;
  *(_DWORD *)(a1 + 36704) = 0;
  *(_DWORD *)(a1 + 36720) = 0;
  *(_DWORD *)(a1 + 36736) = 0;
  *(_DWORD *)(a1 + 36752) = 0;
  *(_DWORD *)(a1 + 36768) = 0;
  *(_DWORD *)(a1 + 36784) = 0;
  *(_DWORD *)(a1 + 36800) = 0;
  *(_DWORD *)(a1 + 36816) = 0;
  *(_DWORD *)(a1 + 36832) = 0;
  *(_DWORD *)(a1 + 36848) = 0;
  *(_DWORD *)(a1 + 36864) = 0;
  *(_DWORD *)(a1 + 36880) = 0;
  *(_DWORD *)(a1 + 36896) = 0;
  *(_DWORD *)(a1 + 36912) = 0;
  *(_DWORD *)(a1 + 36928) = 0;
  *(_DWORD *)(a1 + 36944) = 0;
  *(_DWORD *)(a1 + 36960) = 0;
  *(_DWORD *)(a1 + 36976) = 0;
  *(_DWORD *)(a1 + 36992) = 0;
  *(_DWORD *)(a1 + 37008) = 0;
  *(_DWORD *)(a1 + 37024) = 0;
  *(_DWORD *)(a1 + 37040) = 0;
  *(_DWORD *)(a1 + 37888) = 0;
  *(_DWORD *)(a1 + 37904) = 0;
  *(_DWORD *)(a1 + 37920) = 0;
  *(_DWORD *)(a1 + 37936) = 0;
  *(_DWORD *)(a1 + 37968) = 0;
  *(_DWORD *)(a1 + 38000) = 0;
  *(_DWORD *)(a1 + 38016) = 0;
  *(_DWORD *)(a1 + 38032) = 0;
  *(_DWORD *)(a1 + 38080) = 0;
  *(_DWORD *)(a1 + 38096) = 0;
  *(_DWORD *)(a1 + 38112) = 0;
  *(_DWORD *)(a1 + 38128) = 0;
  *(_DWORD *)(a1 + 38144) = 0;
  *(_DWORD *)(a1 + 38160) = 0;
  *(_DWORD *)(a1 + 38176) = 0;
  *(_DWORD *)(a1 + 38192) = 0;
  *(_DWORD *)(a1 + 38208) = 0;
  *(_DWORD *)(a1 + 38224) = 0;
  *(_DWORD *)(a1 + 38240) = 0;
  *(_DWORD *)(a1 + 38384) = 0;
  *(_DWORD *)(a1 + 38416) = 0;
  *(_DWORD *)(a1 + 38432) = 0;
  *(_DWORD *)(a1 + 38448) = 0;
  *(_DWORD *)(a1 + 38512) = 0;
  *(_DWORD *)(a1 + 38528) = 0;
  *(_DWORD *)(a1 + 38576) = 0;
  *(_DWORD *)(a1 + 38592) = 0;
  *(_DWORD *)(a1 + 38608) = 0;
  *(_DWORD *)(a1 + 38624) = 0;
  *(_DWORD *)(a1 + 38640) = 0;
  *(_DWORD *)(a1 + 38704) = 0;
  *(_DWORD *)(a1 + 38720) = 0;
  *(_DWORD *)(a1 + 38784) = 0;
  *(_DWORD *)(a1 + 38800) = 0;
  *(_DWORD *)(a1 + 38816) = 0;
  *(_DWORD *)(a1 + 39056) = 0;
  *(_DWORD *)(a1 + 39072) = 0;
  *(_DWORD *)(a1 + 39088) = 0;
  *(_DWORD *)(a1 + 39104) = 0;
  *(_DWORD *)(a1 + 39120) = 0;
  *(_DWORD *)(a1 + 39744) = 0;
  *(_DWORD *)(a1 + 39760) = 0;
  *(_DWORD *)(a1 + 39776) = 0;
  *(_DWORD *)(a1 + 39792) = 0;
  *(_DWORD *)(a1 + 39808) = 0;
  *(_DWORD *)(a1 + 39824) = 0;
  *(_DWORD *)(a1 + 39840) = 0;
  *(_DWORD *)(a1 + 39856) = 0;
  *(_DWORD *)(a1 + 39872) = 0;
  *(_DWORD *)(a1 + 39888) = 0;
  *(_DWORD *)(a1 + 39904) = 0;
  *(_DWORD *)(a1 + 39920) = 0;
  *(_DWORD *)(a1 + 39936) = 0;
  *(_DWORD *)(a1 + 39952) = 0;
  *(_DWORD *)(a1 + 39968) = 0;
  *(_DWORD *)(a1 + 39984) = 0;
  *(_DWORD *)(a1 + 40000) = 0;
  *(_DWORD *)(a1 + 40016) = 0;
  *(_DWORD *)(a1 + 40032) = 0;
  *(_DWORD *)(a1 + 40048) = 0;
  *(_DWORD *)(a1 + 40064) = 0;
  *(_DWORD *)(a1 + 40080) = 0;
  *(_DWORD *)(a1 + 40096) = 0;
  *(_DWORD *)(a1 + 40112) = 0;
  *(_DWORD *)(a1 + 40128) = 0;
  *(_DWORD *)(a1 + 40144) = 0;
  *(_DWORD *)(a1 + 40160) = 0;
  *(_DWORD *)(a1 + 40176) = 0;
  *(_DWORD *)(a1 + 40192) = 0;
  *(_DWORD *)(a1 + 40208) = 0;
  *(_DWORD *)(a1 + 40224) = 0;
  *(_DWORD *)(a1 + 40240) = 0;
  *(_DWORD *)(a1 + 40256) = 0;
  *(_DWORD *)(a1 + 40272) = 0;
  *(_DWORD *)(a1 + 40288) = 0;
  *(_DWORD *)(a1 + 40304) = 0;
  *(_DWORD *)(a1 + 40320) = 0;
  *(_DWORD *)(a1 + 40336) = 0;
  *(_DWORD *)(a1 + 40352) = 0;
  *(_DWORD *)(a1 + 40368) = 0;
  *(_DWORD *)(a1 + 40384) = 0;
  *(_DWORD *)(a1 + 40400) = 0;
  *(_DWORD *)(a1 + 40416) = 0;
  *(_DWORD *)(a1 + 40432) = 0;
  *(_DWORD *)(a1 + 40448) = 0;
  *(_DWORD *)(a1 + 40464) = 0;
  *(_DWORD *)(a1 + 40480) = 0;
  *(_DWORD *)(a1 + 40496) = 0;
  *(_DWORD *)(a1 + 40512) = 0;
  *(_DWORD *)(a1 + 40528) = 0;
  *(_DWORD *)(a1 + 40544) = 0;
  *(_DWORD *)(a1 + 40560) = 0;
  *(_DWORD *)(a1 + 40576) = 0;
  *(_DWORD *)(a1 + 41088) = 0;
  *(_DWORD *)(a1 + 41104) = 0;
  *(_DWORD *)(a1 + 41168) = 0;
  *(_DWORD *)(a1 + 41184) = 0;
  *(_DWORD *)(a1 + 41200) = 0;
  *(_DWORD *)(a1 + 41232) = 0;
  *(_DWORD *)(a1 + 41248) = 0;
  *(_DWORD *)(a1 + 41264) = 0;
  *(_DWORD *)(a1 + 41296) = 0;
  *(_DWORD *)(a1 + 41312) = 0;
  *(_DWORD *)(a1 + 41328) = 0;
  *(_DWORD *)(a1 + 41376) = 0;
  *(_DWORD *)(a1 + 41392) = 0;
  *(_DWORD *)(a1 + 41408) = 0;
  *(_DWORD *)(a1 + 41440) = 0;
  *(_DWORD *)(a1 + 41456) = 0;
  *(_DWORD *)(a1 + 41472) = 0;
  *(_DWORD *)(a1 + 41584) = 0;
  *(_DWORD *)(a1 + 41600) = 0;
  *(_DWORD *)(a1 + 41616) = 0;
  *(_DWORD *)(a1 + 41632) = 0;
  *(_DWORD *)(a1 + 41648) = 0;
  *(_DWORD *)(a1 + 41664) = 0;
  *(_DWORD *)(a1 + 41680) = 0;
  *(_DWORD *)(a1 + 41696) = 0;
  *(_DWORD *)(a1 + 41952) = 0;
  *(_DWORD *)(a1 + 41968) = 0;
  *(_DWORD *)(a1 + 41984) = 0;
  *(_DWORD *)(a1 + 42016) = 0;
  *(_DWORD *)(a1 + 42032) = 0;
  *(_DWORD *)(a1 + 42048) = 0;
  *(_DWORD *)(a1 + 42064) = 0;
  *(_DWORD *)(a1 + 42080) = 0;
  *(_DWORD *)(a1 + 42192) = 0;
  *(_DWORD *)(a1 + 42208) = 0;
  *(_DWORD *)(a1 + 42224) = 0;
  *(_DWORD *)(a1 + 42240) = 0;
  *(_DWORD *)(a1 + 42256) = 0;
  *(_DWORD *)(a1 + 42272) = 0;
  *(_DWORD *)(a1 + 42288) = 0;
  *(_DWORD *)(a1 + 42304) = 0;
  *(_DWORD *)(a1 + 42336) = 0;
  *(_DWORD *)(a1 + 42384) = 0;
  *(_DWORD *)(a1 + 42400) = 0;
  *(_DWORD *)(a1 + 42448) = 0;
  *(_DWORD *)(a1 + 42464) = 0;
  *(_DWORD *)(a1 + 42480) = 0;
  *(_DWORD *)(a1 + 42496) = 0;
  *(_DWORD *)(a1 + 42512) = 0;
  *(_DWORD *)(a1 + 42528) = 0;
  *(_DWORD *)(a1 + 42544) = 0;
  *(_DWORD *)(a1 + 42560) = 0;
  *(_DWORD *)(a1 + 42576) = 0;
  *(_DWORD *)(a1 + 42608) = 0;
  *(_DWORD *)(a1 + 42624) = 0;
  *(_DWORD *)(a1 + 42688) = 0;
  *(_DWORD *)(a1 + 42704) = 0;
  *(_DWORD *)(a1 + 42720) = 0;
  *(_DWORD *)(a1 + 42736) = 0;
  *(_DWORD *)(a1 + 42752) = 0;
  *(_DWORD *)(a1 + 42768) = 0;
  *(_DWORD *)(a1 + 42784) = 0;
  *(_DWORD *)(a1 + 42800) = 0;
  *(_DWORD *)(a1 + 42928) = 0;
  *(_DWORD *)(a1 + 42944) = 0;
  *(_DWORD *)(a1 + 42960) = 0;
  *(_DWORD *)(a1 + 42976) = 0;
  *(_DWORD *)(a1 + 42992) = 0;
  *(_DWORD *)(a1 + 43008) = 0;
  *(_DWORD *)(a1 + 43024) = 0;
  *(_DWORD *)(a1 + 43040) = 0;
  *(_DWORD *)(a1 + 43056) = 0;
  *(_DWORD *)(a1 + 43072) = 0;
  *(_DWORD *)(a1 + 43152) = 0;
  *(_DWORD *)(a1 + 43168) = 0;
  *(_DWORD *)(a1 + 43184) = 0;
  *(_DWORD *)(a1 + 43456) = 0;
  *(_DWORD *)(a1 + 43472) = 0;
  *(_DWORD *)(a1 + 43488) = 0;
  *(_DWORD *)(a1 + 43504) = 0;
  *(_DWORD *)(a1 + 43520) = 0;
  *(_DWORD *)(a1 + 43536) = 0;
  *(_DWORD *)(a1 + 43552) = 0;
  *(_DWORD *)(a1 + 43568) = 0;
  *(_DWORD *)(a1 + 43584) = 0;
  *(_DWORD *)(a1 + 43600) = 0;
  *(_DWORD *)(a1 + 43616) = 0;
  *(_DWORD *)(a1 + 43632) = 0;
  *(_DWORD *)(a1 + 43648) = 0;
  *(_DWORD *)(a1 + 43664) = 0;
  *(_DWORD *)(a1 + 43680) = 0;
  *(_DWORD *)(a1 + 43696) = 0;
  *(_DWORD *)(a1 + 43712) = 0;
  *(_DWORD *)(a1 + 43728) = 0;
  *(_DWORD *)(a1 + 43744) = 0;
  *(_DWORD *)(a1 + 43760) = 0;
  *(_DWORD *)(a1 + 43776) = 0;
  *(_DWORD *)(a1 + 43792) = 0;
  *(_DWORD *)(a1 + 43808) = 0;
  *(_DWORD *)(a1 + 43824) = 0;
  *(_DWORD *)(a1 + 43840) = 0;
  *(_DWORD *)(a1 + 43856) = 0;
  *(_DWORD *)(a1 + 43872) = 0;
  *(_DWORD *)(a1 + 43888) = 0;
  *(_DWORD *)(a1 + 44624) = 0;
  *(_DWORD *)(a1 + 44640) = 0;
  *(_DWORD *)(a1 + 44656) = 0;
  *(_DWORD *)(a1 + 44672) = 0;
  *(_DWORD *)(a1 + 44688) = 0;
  *(_DWORD *)(a1 + 44704) = 0;
  *(_DWORD *)(a1 + 44720) = 0;
  *(_DWORD *)(a1 + 44736) = 0;
  *(_DWORD *)(a1 + 44752) = 0;
  *(_DWORD *)(a1 + 44768) = 0;
  *(_DWORD *)(a1 + 44784) = 0;
  *(_DWORD *)(a1 + 44800) = 0;
  *(_DWORD *)(a1 + 44816) = 0;
  *(_DWORD *)(a1 + 45104) = 0;
  *(_DWORD *)(a1 + 45120) = 0;
  *(_DWORD *)(a1 + 45136) = 0;
  *(_DWORD *)(a1 + 45152) = 0;
  *(_DWORD *)(a1 + 45168) = 0;
  *(_DWORD *)(a1 + 45184) = 0;
  *(_DWORD *)(a1 + 45200) = 0;
  *(_DWORD *)(a1 + 45216) = 0;
  *(_DWORD *)(a1 + 45232) = 0;
  *(_DWORD *)(a1 + 45248) = 0;
  *(_DWORD *)(a1 + 45264) = 0;
  *(_DWORD *)(a1 + 45280) = 0;
  *(_DWORD *)(a1 + 45296) = 0;
  *(_DWORD *)(a1 + 45568) = 0;
  *(_DWORD *)(a1 + 45584) = 0;
  *(_DWORD *)(a1 + 45600) = 0;
  *(_DWORD *)(a1 + 45616) = 0;
  *(_DWORD *)(a1 + 45664) = 0;
  *(_DWORD *)(a1 + 45680) = 0;
  *(_DWORD *)(a1 + 45696) = 0;
  *(_DWORD *)(a1 + 45712) = 0;
  *(_DWORD *)(a1 + 45728) = 0;
  *(_DWORD *)(a1 + 45744) = 0;
  *(_DWORD *)(a1 + 45760) = 0;
  *(_DWORD *)(a1 + 45776) = 0;
  *(_DWORD *)(a1 + 45792) = 0;
  *(_DWORD *)(a1 + 45808) = 0;
  *(_DWORD *)(a1 + 45824) = 0;
  *(_DWORD *)(a1 + 45840) = 0;
  *(_DWORD *)(a1 + 45856) = 0;
  *(_DWORD *)(a1 + 45872) = 0;
  *(_DWORD *)(a1 + 46288) = 0;
  *(_DWORD *)(a1 + 46304) = 0;
  *(_DWORD *)(a1 + 46320) = 0;
  *(_DWORD *)(a1 + 46336) = 0;
  *(_DWORD *)(a1 + 46352) = 0;
  *(_DWORD *)(a1 + 46368) = 0;
  *(_DWORD *)(a1 + 46464) = 0;
  *(_DWORD *)(a1 + 46688) = 0;
  *(_DWORD *)(a1 + 46704) = 0;
  *(_DWORD *)(a1 + 46720) = 0;
  *(_DWORD *)(a1 + 46736) = 0;
  *(_DWORD *)(a1 + 46752) = 0;
  *(_DWORD *)(a1 + 46768) = 0;
  *(_DWORD *)(a1 + 46784) = 0;
  *(_DWORD *)(a1 + 46800) = 0;
  *(_DWORD *)(a1 + 46816) = 0;
  *(_DWORD *)(a1 + 46832) = 0;
  *(_DWORD *)(a1 + 46848) = 0;
  *(_DWORD *)(a1 + 46864) = 0;
  *(_DWORD *)(a1 + 46880) = 0;
  *(_DWORD *)(a1 + 46896) = 0;
  *(_DWORD *)(a1 + 46912) = 0;
  *(_DWORD *)(a1 + 46928) = 0;
  *(_DWORD *)(a1 + 46944) = 0;
  *(_DWORD *)(a1 + 46960) = 0;
  *(_DWORD *)(a1 + 46976) = 0;
  *(_DWORD *)(a1 + 46992) = 0;
  *(_DWORD *)(a1 + 47008) = 0;
  *(_DWORD *)(a1 + 47024) = 0;
  *(_DWORD *)(a1 + 47040) = 0;
  *(_DWORD *)(a1 + 47056) = 0;
  *(_DWORD *)(a1 + 47072) = 0;
  *(_DWORD *)(a1 + 47088) = 0;
  *(_DWORD *)(a1 + 47104) = 0;
  *(_DWORD *)(a1 + 47120) = 0;
  *(_DWORD *)(a1 + 47136) = 0;
  *(_DWORD *)(a1 + 47152) = 0;
  *(_DWORD *)(a1 + 47168) = 0;
  *(_DWORD *)(a1 + 47184) = 0;
  *(_DWORD *)(a1 + 47200) = 0;
  *(_DWORD *)(a1 + 47216) = 0;
  *(_DWORD *)(a1 + 47232) = 0;
  *(_DWORD *)(a1 + 47248) = 0;
  *(_DWORD *)(a1 + 47264) = 0;
  *(_DWORD *)(a1 + 47280) = 0;
  *(_DWORD *)(a1 + 47296) = 0;
  *(_DWORD *)(a1 + 47312) = 0;
  *(_DWORD *)(a1 + 47328) = 0;
  *(_DWORD *)(a1 + 47344) = 0;
  *(_DWORD *)(a1 + 47360) = 0;
  *(_DWORD *)(a1 + 47376) = 0;
  *(_DWORD *)(a1 + 47392) = 0;
  *(_DWORD *)(a1 + 47408) = 0;
  *(_DWORD *)(a1 + 47424) = 0;
  *(_DWORD *)(a1 + 47440) = 0;
  *(_DWORD *)(a1 + 47456) = 0;
  *(_DWORD *)(a1 + 47472) = 0;
  *(_DWORD *)(a1 + 47488) = 0;
  *(_DWORD *)(a1 + 47504) = 0;
  *(_DWORD *)(a1 + 47520) = 0;
  *(_DWORD *)(a1 + 47536) = 0;
  *(_DWORD *)(a1 + 47552) = 0;
  *(_DWORD *)(a1 + 48400) = 0;
  *(_DWORD *)(a1 + 48416) = 0;
  *(_DWORD *)(a1 + 48432) = 0;
  *(_DWORD *)(a1 + 48448) = 0;
  *(_DWORD *)(a1 + 48480) = 0;
  *(_DWORD *)(a1 + 48512) = 0;
  *(_DWORD *)(a1 + 48528) = 0;
  *(_DWORD *)(a1 + 48544) = 0;
  *(_DWORD *)(a1 + 48592) = 0;
  *(_DWORD *)(a1 + 48608) = 0;
  *(_DWORD *)(a1 + 48624) = 0;
  *(_DWORD *)(a1 + 48640) = 0;
  *(_DWORD *)(a1 + 48656) = 0;
  *(_DWORD *)(a1 + 48672) = 0;
  *(_DWORD *)(a1 + 48688) = 0;
  *(_DWORD *)(a1 + 48704) = 0;
  *(_DWORD *)(a1 + 48720) = 0;
  *(_DWORD *)(a1 + 48736) = 0;
  *(_DWORD *)(a1 + 48752) = 0;
  *(_DWORD *)(a1 + 48896) = 0;
  *(_DWORD *)(a1 + 48928) = 0;
  *(_DWORD *)(a1 + 48944) = 0;
  *(_DWORD *)(a1 + 48960) = 0;
  *(_DWORD *)(a1 + 49024) = 0;
  *(_DWORD *)(a1 + 49040) = 0;
  *(_DWORD *)(a1 + 49088) = 0;
  *(_DWORD *)(a1 + 49104) = 0;
  *(_DWORD *)(a1 + 49120) = 0;
  *(_DWORD *)(a1 + 49136) = 0;
  *(_DWORD *)(a1 + 49152) = 0;
  *(_DWORD *)(a1 + 49216) = 0;
  *(_DWORD *)(a1 + 49232) = 0;
  *(_DWORD *)(a1 + 49296) = 0;
  *(_DWORD *)(a1 + 49312) = 0;
  *(_DWORD *)(a1 + 49328) = 0;
  *(_DWORD *)(a1 + 49568) = 0;
  *(_DWORD *)(a1 + 49584) = 0;
  *(_DWORD *)(a1 + 49600) = 0;
  *(_DWORD *)(a1 + 49616) = 0;
  *(_DWORD *)(a1 + 49632) = 0;
  *(_DWORD *)(a1 + 50256) = 0;
  *(_DWORD *)(a1 + 50272) = 0;
  *(_DWORD *)(a1 + 50288) = 0;
  *(_DWORD *)(a1 + 50304) = 0;
  *(_DWORD *)(a1 + 50320) = 0;
  *(_DWORD *)(a1 + 50336) = 0;
  *(_DWORD *)(a1 + 50352) = 0;
  *(_DWORD *)(a1 + 50368) = 0;
  *(_DWORD *)(a1 + 50384) = 0;
  *(_DWORD *)(a1 + 50400) = 0;
  *(_DWORD *)(a1 + 50416) = 0;
  *(_DWORD *)(a1 + 50432) = 0;
  *(_DWORD *)(a1 + 50448) = 0;
  *(_DWORD *)(a1 + 50464) = 0;
  *(_DWORD *)(a1 + 50480) = 0;
  *(_DWORD *)(a1 + 50496) = 0;
  *(_DWORD *)(a1 + 50512) = 0;
  *(_DWORD *)(a1 + 50528) = 0;
  *(_DWORD *)(a1 + 50544) = 0;
  *(_DWORD *)(a1 + 50560) = 0;
  *(_DWORD *)(a1 + 50576) = 0;
  *(_DWORD *)(a1 + 50592) = 0;
  *(_DWORD *)(a1 + 50608) = 0;
  *(_DWORD *)(a1 + 50624) = 0;
  *(_DWORD *)(a1 + 50640) = 0;
  *(_DWORD *)(a1 + 50656) = 0;
  *(_DWORD *)(a1 + 50672) = 0;
  *(_DWORD *)(a1 + 50688) = 0;
  *(_DWORD *)(a1 + 50704) = 0;
  *(_DWORD *)(a1 + 50720) = 0;
  *(_DWORD *)(a1 + 50736) = 0;
  *(_DWORD *)(a1 + 50752) = 0;
  *(_DWORD *)(a1 + 50768) = 0;
  *(_DWORD *)(a1 + 50784) = 0;
  *(_DWORD *)(a1 + 50800) = 0;
  *(_DWORD *)(a1 + 50816) = 0;
  *(_DWORD *)(a1 + 50832) = 0;
  *(_DWORD *)(a1 + 50848) = 0;
  *(_DWORD *)(a1 + 50864) = 0;
  *(_DWORD *)(a1 + 50880) = 0;
  *(_DWORD *)(a1 + 50896) = 0;
  *(_DWORD *)(a1 + 50912) = 0;
  *(_DWORD *)(a1 + 50928) = 0;
  *(_DWORD *)(a1 + 50944) = 0;
  *(_DWORD *)(a1 + 50960) = 0;
  *(_DWORD *)(a1 + 50976) = 0;
  *(_DWORD *)(a1 + 50992) = 0;
  *(_DWORD *)(a1 + 51008) = 0;
  *(_DWORD *)(a1 + 51024) = 0;
  *(_DWORD *)(a1 + 51040) = 0;
  *(_DWORD *)(a1 + 51056) = 0;
  *(_DWORD *)(a1 + 51072) = 0;
  *(_DWORD *)(a1 + 51088) = 0;
  *(_DWORD *)(a1 + 51600) = 0;
  *(_DWORD *)(a1 + 51616) = 0;
  *(_DWORD *)(a1 + 51680) = 0;
  *(_DWORD *)(a1 + 51696) = 0;
  *(_DWORD *)(a1 + 51712) = 0;
  *(_DWORD *)(a1 + 51744) = 0;
  *(_DWORD *)(a1 + 51760) = 0;
  *(_DWORD *)(a1 + 51776) = 0;
  *(_DWORD *)(a1 + 51808) = 0;
  *(_DWORD *)(a1 + 51824) = 0;
  *(_DWORD *)(a1 + 51840) = 0;
  *(_DWORD *)(a1 + 51888) = 0;
  *(_DWORD *)(a1 + 51904) = 0;
  *(_DWORD *)(a1 + 51920) = 0;
  *(_DWORD *)(a1 + 51952) = 0;
  *(_DWORD *)(a1 + 51968) = 0;
  *(_DWORD *)(a1 + 51984) = 0;
  *(_DWORD *)(a1 + 52096) = 0;
  *(_DWORD *)(a1 + 52112) = 0;
  *(_DWORD *)(a1 + 52128) = 0;
  *(_DWORD *)(a1 + 52144) = 0;
  *(_DWORD *)(a1 + 52160) = 0;
  *(_DWORD *)(a1 + 52176) = 0;
  *(_DWORD *)(a1 + 52192) = 0;
  *(_DWORD *)(a1 + 52208) = 0;
  *(_DWORD *)(a1 + 52464) = 0;
  *(_DWORD *)(a1 + 52480) = 0;
  *(_DWORD *)(a1 + 52496) = 0;
  *(_DWORD *)(a1 + 52528) = 0;
  *(_DWORD *)(a1 + 52544) = 0;
  *(_DWORD *)(a1 + 52560) = 0;
  *(_DWORD *)(a1 + 52576) = 0;
  *(_DWORD *)(a1 + 52592) = 0;
  *(_DWORD *)(a1 + 52704) = 0;
  *(_DWORD *)(a1 + 52720) = 0;
  *(_DWORD *)(a1 + 52736) = 0;
  *(_DWORD *)(a1 + 52752) = 0;
  *(_DWORD *)(a1 + 52768) = 0;
  *(_DWORD *)(a1 + 52784) = 0;
  *(_DWORD *)(a1 + 52800) = 0;
  *(_DWORD *)(a1 + 52816) = 0;
  *(_DWORD *)(a1 + 52848) = 0;
  *(_DWORD *)(a1 + 52896) = 0;
  *(_DWORD *)(a1 + 52912) = 0;
  *(_DWORD *)(a1 + 52960) = 0;
  *(_DWORD *)(a1 + 52976) = 0;
  *(_DWORD *)(a1 + 52992) = 0;
  *(_DWORD *)(a1 + 53008) = 0;
  *(_DWORD *)(a1 + 53024) = 0;
  *(_DWORD *)(a1 + 53040) = 0;
  *(_DWORD *)(a1 + 53056) = 0;
  *(_DWORD *)(a1 + 53072) = 0;
  *(_DWORD *)(a1 + 53088) = 0;
  *(_DWORD *)(a1 + 53120) = 0;
  *(_DWORD *)(a1 + 53136) = 0;
  *(_DWORD *)(a1 + 53200) = 0;
  *(_DWORD *)(a1 + 53216) = 0;
  *(_DWORD *)(a1 + 53232) = 0;
  *(_DWORD *)(a1 + 53248) = 0;
  *(_DWORD *)(a1 + 53264) = 0;
  *(_DWORD *)(a1 + 53280) = 0;
  *(_DWORD *)(a1 + 53296) = 0;
  *(_DWORD *)(a1 + 53312) = 0;
  *(_DWORD *)(a1 + 53440) = 0;
  *(_DWORD *)(a1 + 53456) = 0;
  *(_DWORD *)(a1 + 53472) = 0;
  *(_DWORD *)(a1 + 53488) = 0;
  *(_DWORD *)(a1 + 53504) = 0;
  *(_DWORD *)(a1 + 53520) = 0;
  *(_DWORD *)(a1 + 53536) = 0;
  *(_DWORD *)(a1 + 53552) = 0;
  *(_DWORD *)(a1 + 53568) = 0;
  *(_DWORD *)(a1 + 53584) = 0;
  *(_DWORD *)(a1 + 53664) = 0;
  *(_DWORD *)(a1 + 53680) = 0;
  *(_DWORD *)(a1 + 53696) = 0;
  *(_DWORD *)(a1 + 53968) = 0;
  *(_DWORD *)(a1 + 53984) = 0;
  *(_DWORD *)(a1 + 54000) = 0;
  *(_DWORD *)(a1 + 54016) = 0;
  *(_DWORD *)(a1 + 54032) = 0;
  *(_DWORD *)(a1 + 54048) = 0;
  *(_DWORD *)(a1 + 54064) = 0;
  *(_DWORD *)(a1 + 54080) = 0;
  *(_DWORD *)(a1 + 54096) = 0;
  *(_DWORD *)(a1 + 54112) = 0;
  *(_DWORD *)(a1 + 54128) = 0;
  *(_DWORD *)(a1 + 54144) = 0;
  *(_DWORD *)(a1 + 54160) = 0;
  *(_DWORD *)(a1 + 54176) = 0;
  *(_DWORD *)(a1 + 54192) = 0;
  *(_DWORD *)(a1 + 54208) = 0;
  *(_DWORD *)(a1 + 54224) = 0;
  *(_DWORD *)(a1 + 54240) = 0;
  *(_DWORD *)(a1 + 54256) = 0;
  *(_DWORD *)(a1 + 54272) = 0;
  *(_DWORD *)(a1 + 54288) = 0;
  *(_DWORD *)(a1 + 54304) = 0;
  *(_DWORD *)(a1 + 54320) = 0;
  *(_DWORD *)(a1 + 54336) = 0;
  *(_DWORD *)(a1 + 54352) = 0;
  *(_DWORD *)(a1 + 54368) = 0;
  *(_DWORD *)(a1 + 54384) = 0;
  *(_DWORD *)(a1 + 54400) = 0;
  *(_DWORD *)(a1 + 55136) = 0;
  *(_DWORD *)(a1 + 55152) = 0;
  *(_DWORD *)(a1 + 55168) = 0;
  *(_DWORD *)(a1 + 55184) = 0;
  *(_DWORD *)(a1 + 55200) = 0;
  *(_DWORD *)(a1 + 55216) = 0;
  *(_DWORD *)(a1 + 55232) = 0;
  *(_DWORD *)(a1 + 55248) = 0;
  *(_DWORD *)(a1 + 55264) = 0;
  *(_DWORD *)(a1 + 55280) = 0;
  *(_DWORD *)(a1 + 55296) = 0;
  *(_DWORD *)(a1 + 55312) = 0;
  *(_DWORD *)(a1 + 55328) = 0;
  *(_DWORD *)(a1 + 55616) = 0;
  *(_DWORD *)(a1 + 55632) = 0;
  *(_DWORD *)(a1 + 55648) = 0;
  *(_DWORD *)(a1 + 55664) = 0;
  *(_DWORD *)(a1 + 55680) = 0;
  *(_DWORD *)(a1 + 55696) = 0;
  *(_DWORD *)(a1 + 55712) = 0;
  *(_DWORD *)(a1 + 55728) = 0;
  *(_DWORD *)(a1 + 55744) = 0;
  *(_DWORD *)(a1 + 55760) = 0;
  *(_DWORD *)(a1 + 55776) = 0;
  *(_DWORD *)(a1 + 55792) = 0;
  *(_DWORD *)(a1 + 55808) = 0;
  *(_DWORD *)(a1 + 56080) = 0;
  *(_DWORD *)(a1 + 56096) = 0;
  *(_DWORD *)(a1 + 56112) = 0;
  *(_DWORD *)(a1 + 56128) = 0;
  *(_DWORD *)(a1 + 56176) = 0;
  *(_DWORD *)(a1 + 56192) = 0;
  *(_DWORD *)(a1 + 56208) = 0;
  *(_DWORD *)(a1 + 56224) = 0;
  *(_DWORD *)(a1 + 56240) = 0;
  *(_DWORD *)(a1 + 56256) = 0;
  *(_DWORD *)(a1 + 56272) = 0;
  *(_DWORD *)(a1 + 56288) = 0;
  *(_DWORD *)(a1 + 56304) = 0;
  *(_DWORD *)(a1 + 56320) = 0;
  *(_DWORD *)(a1 + 56336) = 0;
  *(_DWORD *)(a1 + 56352) = 0;
  *(_DWORD *)(a1 + 56368) = 0;
  *(_DWORD *)(a1 + 56384) = 0;
  *(_DWORD *)(a1 + 56800) = 0;
  *(_DWORD *)(a1 + 56816) = 0;
  *(_DWORD *)(a1 + 56832) = 0;
  *(_DWORD *)(a1 + 56848) = 0;
  *(_DWORD *)(a1 + 56864) = 0;
  *(_DWORD *)(a1 + 56880) = 0;
  *(_DWORD *)(a1 + 56976) = 0;
  *(_DWORD *)(a1 + 57200) = 0;
  *(_DWORD *)(a1 + 57216) = 0;
  *(_DWORD *)(a1 + 57232) = 0;
  *(_DWORD *)(a1 + 57248) = 0;
  *(_DWORD *)(a1 + 57264) = 0;
  *(_DWORD *)(a1 + 57280) = 0;
  *(_DWORD *)(a1 + 57296) = 0;
  *(_DWORD *)(a1 + 57312) = 0;
  *(_DWORD *)(a1 + 57328) = 0;
  *(_DWORD *)(a1 + 57344) = 0;
  *(_DWORD *)(a1 + 57360) = 0;
  *(_DWORD *)(a1 + 57376) = 0;
  *(_DWORD *)(a1 + 57392) = 0;
  *(_DWORD *)(a1 + 57408) = 0;
  *(_DWORD *)(a1 + 57424) = 0;
  *(_DWORD *)(a1 + 57440) = 0;
  *(_DWORD *)(a1 + 57456) = 0;
  *(_DWORD *)(a1 + 57472) = 0;
  *(_DWORD *)(a1 + 57488) = 0;
  *(_DWORD *)(a1 + 57504) = 0;
  *(_DWORD *)(a1 + 57520) = 0;
  *(_DWORD *)(a1 + 57536) = 0;
  *(_DWORD *)(a1 + 57552) = 0;
  *(_DWORD *)(a1 + 57568) = 0;
  *(_DWORD *)(a1 + 57584) = 0;
  *(_DWORD *)(a1 + 57600) = 0;
  *(_DWORD *)(a1 + 57616) = 0;
  *(_DWORD *)(a1 + 57632) = 0;
  *(_DWORD *)(a1 + 57648) = 0;
  *(_DWORD *)(a1 + 57664) = 0;
  *(_DWORD *)(a1 + 57680) = 0;
  *(_DWORD *)(a1 + 57696) = 0;
  *(_DWORD *)(a1 + 57712) = 0;
  *(_DWORD *)(a1 + 57728) = 0;
  *(_DWORD *)(a1 + 57744) = 0;
  *(_DWORD *)(a1 + 57760) = 0;
  *(_DWORD *)(a1 + 57776) = 0;
  *(_DWORD *)(a1 + 57792) = 0;
  *(_DWORD *)(a1 + 57808) = 0;
  *(_DWORD *)(a1 + 57824) = 0;
  *(_DWORD *)(a1 + 57840) = 0;
  *(_DWORD *)(a1 + 57856) = 0;
  *(_DWORD *)(a1 + 57872) = 0;
  *(_DWORD *)(a1 + 57888) = 0;
  *(_DWORD *)(a1 + 57904) = 0;
  *(_DWORD *)(a1 + 57920) = 0;
  *(_DWORD *)(a1 + 57936) = 0;
  *(_DWORD *)(a1 + 57952) = 0;
  *(_DWORD *)(a1 + 57968) = 0;
  *(_DWORD *)(a1 + 57984) = 0;
  *(_DWORD *)(a1 + 58000) = 0;
  *(_DWORD *)(a1 + 58016) = 0;
  *(_DWORD *)(a1 + 58032) = 0;
  *(_DWORD *)(a1 + 58048) = 0;
  *(_DWORD *)(a1 + 58064) = 0;
  *(_DWORD *)(a1 + 58912) = 0;
  *(_DWORD *)(a1 + 58928) = 0;
  *(_DWORD *)(a1 + 58944) = 0;
  *(_DWORD *)(a1 + 58960) = 0;
  *(_DWORD *)(a1 + 58992) = 0;
  *(_DWORD *)(a1 + 59024) = 0;
  *(_DWORD *)(a1 + 59040) = 0;
  *(_DWORD *)(a1 + 59056) = 0;
  *(_DWORD *)(a1 + 59104) = 0;
  *(_DWORD *)(a1 + 59120) = 0;
  *(_DWORD *)(a1 + 59136) = 0;
  *(_DWORD *)(a1 + 59152) = 0;
  *(_DWORD *)(a1 + 59168) = 0;
  *(_DWORD *)(a1 + 59184) = 0;
  *(_DWORD *)(a1 + 59200) = 0;
  *(_DWORD *)(a1 + 59216) = 0;
  *(_DWORD *)(a1 + 59232) = 0;
  *(_DWORD *)(a1 + 59248) = 0;
  *(_DWORD *)(a1 + 59264) = 0;
  *(_DWORD *)(a1 + 59408) = 0;
  *(_DWORD *)(a1 + 59440) = 0;
  *(_DWORD *)(a1 + 59456) = 0;
  *(_DWORD *)(a1 + 59472) = 0;
  *(_DWORD *)(a1 + 59536) = 0;
  *(_DWORD *)(a1 + 59552) = 0;
  *(_DWORD *)(a1 + 59600) = 0;
  *(_DWORD *)(a1 + 59616) = 0;
  *(_DWORD *)(a1 + 59632) = 0;
  *(_DWORD *)(a1 + 59648) = 0;
  *(_DWORD *)(a1 + 59664) = 0;
  *(_DWORD *)(a1 + 59728) = 0;
  *(_DWORD *)(a1 + 59744) = 0;
  *(_DWORD *)(a1 + 59808) = 0;
  *(_DWORD *)(a1 + 59824) = 0;
  *(_DWORD *)(a1 + 59840) = 0;
  *(_DWORD *)(a1 + 60080) = 0;
  *(_DWORD *)(a1 + 60096) = 0;
  *(_DWORD *)(a1 + 60112) = 0;
  *(_DWORD *)(a1 + 60128) = 0;
  *(_DWORD *)(a1 + 60144) = 0;
  *(_DWORD *)(a1 + 60768) = 0;
  *(_DWORD *)(a1 + 60784) = 0;
  *(_DWORD *)(a1 + 60800) = 0;
  *(_DWORD *)(a1 + 60816) = 0;
  *(_DWORD *)(a1 + 60832) = 0;
  *(_DWORD *)(a1 + 60848) = 0;
  *(_DWORD *)(a1 + 60864) = 0;
  *(_DWORD *)(a1 + 60880) = 0;
  *(_DWORD *)(a1 + 60896) = 0;
  *(_DWORD *)(a1 + 60912) = 0;
  *(_DWORD *)(a1 + 60928) = 0;
  *(_DWORD *)(a1 + 60944) = 0;
  *(_DWORD *)(a1 + 60960) = 0;
  *(_DWORD *)(a1 + 60976) = 0;
  *(_DWORD *)(a1 + 60992) = 0;
  *(_DWORD *)(a1 + 61008) = 0;
  *(_DWORD *)(a1 + 61024) = 0;
  *(_DWORD *)(a1 + 61040) = 0;
  *(_DWORD *)(a1 + 61056) = 0;
  *(_DWORD *)(a1 + 61072) = 0;
  *(_DWORD *)(a1 + 61088) = 0;
  *(_DWORD *)(a1 + 61104) = 0;
  *(_DWORD *)(a1 + 61120) = 0;
  *(_DWORD *)(a1 + 61136) = 0;
  *(_DWORD *)(a1 + 61152) = 0;
  *(_DWORD *)(a1 + 61168) = 0;
  *(_DWORD *)(a1 + 61184) = 0;
  *(_DWORD *)(a1 + 61200) = 0;
  *(_DWORD *)(a1 + 61216) = 0;
  *(_DWORD *)(a1 + 61232) = 0;
  *(_DWORD *)(a1 + 61248) = 0;
  *(_DWORD *)(a1 + 61264) = 0;
  *(_DWORD *)(a1 + 61280) = 0;
  *(_DWORD *)(a1 + 61296) = 0;
  *(_DWORD *)(a1 + 61312) = 0;
  *(_DWORD *)(a1 + 61328) = 0;
  *(_DWORD *)(a1 + 61344) = 0;
  *(_DWORD *)(a1 + 61360) = 0;
  *(_DWORD *)(a1 + 61376) = 0;
  *(_DWORD *)(a1 + 61392) = 0;
  *(_DWORD *)(a1 + 61408) = 0;
  *(_DWORD *)(a1 + 61424) = 0;
  *(_DWORD *)(a1 + 61440) = 0;
  *(_DWORD *)(a1 + 61456) = 0;
  *(_DWORD *)(a1 + 61472) = 0;
  *(_DWORD *)(a1 + 61488) = 0;
  *(_DWORD *)(a1 + 61504) = 0;
  *(_DWORD *)(a1 + 61520) = 0;
  *(_DWORD *)(a1 + 61536) = 0;
  *(_DWORD *)(a1 + 61552) = 0;
  *(_DWORD *)(a1 + 61568) = 0;
  *(_DWORD *)(a1 + 61584) = 0;
  *(_DWORD *)(a1 + 61600) = 0;
  *(_DWORD *)(a1 + 62112) = 0;
  *(_DWORD *)(a1 + 62128) = 0;
  *(_DWORD *)(a1 + 62192) = 0;
  *(_DWORD *)(a1 + 62208) = 0;
  *(_DWORD *)(a1 + 62224) = 0;
  *(_DWORD *)(a1 + 62256) = 0;
  *(_DWORD *)(a1 + 62272) = 0;
  *(_DWORD *)(a1 + 62288) = 0;
  *(_DWORD *)(a1 + 62320) = 0;
  *(_DWORD *)(a1 + 62336) = 0;
  *(_DWORD *)(a1 + 62352) = 0;
  *(_DWORD *)(a1 + 62400) = 0;
  *(_DWORD *)(a1 + 62416) = 0;
  *(_DWORD *)(a1 + 62432) = 0;
  *(_DWORD *)(a1 + 62464) = 0;
  *(_DWORD *)(a1 + 62480) = 0;
  *(_DWORD *)(a1 + 62496) = 0;
  *(_DWORD *)(a1 + 62608) = 0;
  *(_DWORD *)(a1 + 62624) = 0;
  *(_DWORD *)(a1 + 62640) = 0;
  *(_DWORD *)(a1 + 62656) = 0;
  *(_DWORD *)(a1 + 62672) = 0;
  *(_DWORD *)(a1 + 62688) = 0;
  *(_DWORD *)(a1 + 62704) = 0;
  *(_DWORD *)(a1 + 62720) = 0;
  *(_DWORD *)(a1 + 62976) = 0;
  *(_DWORD *)(a1 + 62992) = 0;
  *(_DWORD *)(a1 + 63008) = 0;
  *(_DWORD *)(a1 + 63040) = 0;
  *(_DWORD *)(a1 + 63056) = 0;
  *(_DWORD *)(a1 + 63072) = 0;
  *(_DWORD *)(a1 + 63088) = 0;
  *(_DWORD *)(a1 + 63104) = 0;
  *(_DWORD *)(a1 + 63216) = 0;
  *(_DWORD *)(a1 + 63232) = 0;
  *(_DWORD *)(a1 + 63248) = 0;
  *(_DWORD *)(a1 + 63264) = 0;
  *(_DWORD *)(a1 + 63280) = 0;
  *(_DWORD *)(a1 + 63296) = 0;
  *(_DWORD *)(a1 + 63312) = 0;
  *(_DWORD *)(a1 + 63328) = 0;
  *(_DWORD *)(a1 + 63360) = 0;
  *(_DWORD *)(a1 + 63408) = 0;
  *(_DWORD *)(a1 + 63424) = 0;
  *(_DWORD *)(a1 + 63472) = 0;
  *(_DWORD *)(a1 + 63488) = 0;
  *(_DWORD *)(a1 + 63504) = 0;
  *(_DWORD *)(a1 + 63520) = 0;
  *(_DWORD *)(a1 + 63536) = 0;
  *(_DWORD *)(a1 + 63552) = 0;
  *(_DWORD *)(a1 + 63568) = 0;
  *(_DWORD *)(a1 + 63584) = 0;
  *(_DWORD *)(a1 + 63600) = 0;
  *(_DWORD *)(a1 + 63632) = 0;
  *(_DWORD *)(a1 + 63648) = 0;
  *(_DWORD *)(a1 + 63712) = 0;
  *(_DWORD *)(a1 + 63728) = 0;
  *(_DWORD *)(a1 + 63744) = 0;
  *(_DWORD *)(a1 + 63760) = 0;
  *(_DWORD *)(a1 + 63776) = 0;
  *(_DWORD *)(a1 + 63792) = 0;
  *(_DWORD *)(a1 + 63808) = 0;
  *(_DWORD *)(a1 + 63824) = 0;
  *(_DWORD *)(a1 + 63952) = 0;
  *(_DWORD *)(a1 + 63968) = 0;
  *(_DWORD *)(a1 + 63984) = 0;
  *(_DWORD *)(a1 + 64000) = 0;
  *(_DWORD *)(a1 + 64016) = 0;
  *(_DWORD *)(a1 + 64032) = 0;
  *(_DWORD *)(a1 + 64048) = 0;
  *(_DWORD *)(a1 + 64064) = 0;
  *(_DWORD *)(a1 + 64080) = 0;
  *(_DWORD *)(a1 + 64096) = 0;
  *(_DWORD *)(a1 + 64176) = 0;
  *(_DWORD *)(a1 + 64192) = 0;
  *(_DWORD *)(a1 + 64208) = 0;
  *(_DWORD *)(a1 + 64480) = 0;
  *(_DWORD *)(a1 + 64496) = 0;
  *(_DWORD *)(a1 + 64512) = 0;
  *(_DWORD *)(a1 + 64528) = 0;
  *(_DWORD *)(a1 + 64544) = 0;
  *(_DWORD *)(a1 + 64560) = 0;
  *(_DWORD *)(a1 + 64576) = 0;
  *(_DWORD *)(a1 + 64592) = 0;
  *(_DWORD *)(a1 + 64608) = 0;
  *(_DWORD *)(a1 + 64624) = 0;
  *(_DWORD *)(a1 + 64640) = 0;
  *(_DWORD *)(a1 + 64656) = 0;
  *(_DWORD *)(a1 + 64672) = 0;
  *(_DWORD *)(a1 + 64688) = 0;
  *(_DWORD *)(a1 + 64704) = 0;
  *(_DWORD *)(a1 + 64720) = 0;
  *(_DWORD *)(a1 + 64736) = 0;
  *(_DWORD *)(a1 + 64752) = 0;
  *(_DWORD *)(a1 + 64768) = 0;
  *(_DWORD *)(a1 + 64784) = 0;
  *(_DWORD *)(a1 + 64800) = 0;
  *(_DWORD *)(a1 + 64816) = 0;
  *(_DWORD *)(a1 + 64832) = 0;
  *(_DWORD *)(a1 + 64848) = 0;
  *(_DWORD *)(a1 + 64864) = 0;
  *(_DWORD *)(a1 + 64880) = 0;
  *(_DWORD *)(a1 + 64896) = 0;
  *(_DWORD *)(a1 + 64912) = 0;
  *(_DWORD *)(a1 + 65648) = 0;
  *(_DWORD *)(a1 + 65664) = 0;
  *(_DWORD *)(a1 + 65680) = 0;
  *(_DWORD *)(a1 + 65696) = 0;
  *(_DWORD *)(a1 + 65712) = 0;
  *(_DWORD *)(a1 + 65728) = 0;
  *(_DWORD *)(a1 + 65744) = 0;
  *(_DWORD *)(a1 + 65760) = 0;
  *(_DWORD *)(a1 + 65776) = 0;
  *(_DWORD *)(a1 + 65792) = 0;
  *(_DWORD *)(a1 + 65808) = 0;
  *(_DWORD *)(a1 + 65824) = 0;
  *(_DWORD *)(a1 + 65840) = 0;
  *(_DWORD *)(a1 + 66128) = 0;
  *(_DWORD *)(a1 + 66144) = 0;
  *(_DWORD *)(a1 + 66160) = 0;
  *(_DWORD *)(a1 + 66176) = 0;
  *(_DWORD *)(a1 + 66192) = 0;
  *(_DWORD *)(a1 + 66208) = 0;
  *(_DWORD *)(a1 + 66224) = 0;
  *(_DWORD *)(a1 + 66240) = 0;
  *(_DWORD *)(a1 + 66256) = 0;
  *(_DWORD *)(a1 + 66272) = 0;
  *(_DWORD *)(a1 + 66288) = 0;
  *(_DWORD *)(a1 + 66304) = 0;
  *(_DWORD *)(a1 + 66320) = 0;
  *(_DWORD *)(a1 + 66592) = 0;
  *(_DWORD *)(a1 + 66608) = 0;
  *(_DWORD *)(a1 + 66624) = 0;
  *(_DWORD *)(a1 + 66640) = 0;
  *(_DWORD *)(a1 + 66688) = 0;
  *(_DWORD *)(a1 + 66704) = 0;
  *(_DWORD *)(a1 + 66720) = 0;
  *(_DWORD *)(a1 + 66736) = 0;
  *(_DWORD *)(a1 + 66752) = 0;
  *(_DWORD *)(a1 + 66768) = 0;
  *(_DWORD *)(a1 + 66784) = 0;
  *(_DWORD *)(a1 + 66800) = 0;
  *(_DWORD *)(a1 + 66816) = 0;
  *(_DWORD *)(a1 + 66832) = 0;
  *(_DWORD *)(a1 + 66848) = 0;
  *(_DWORD *)(a1 + 66864) = 0;
  *(_DWORD *)(a1 + 66880) = 0;
  *(_DWORD *)(a1 + 66896) = 0;
  *(_DWORD *)(a1 + 67312) = 0;
  *(_DWORD *)(a1 + 67328) = 0;
  *(_DWORD *)(a1 + 67344) = 0;
  *(_DWORD *)(a1 + 67360) = 0;
  *(_DWORD *)(a1 + 67376) = 0;
  *(_DWORD *)(a1 + 67392) = 0;
  *(_DWORD *)(a1 + 67488) = 0;
  *(_DWORD *)(a1 + 67712) = 0;
  *(_DWORD *)(a1 + 67728) = 0;
  *(_DWORD *)(a1 + 67744) = 0;
  *(_DWORD *)(a1 + 67760) = 0;
  *(_DWORD *)(a1 + 67776) = 0;
  *(_DWORD *)(a1 + 67792) = 0;
  *(_DWORD *)(a1 + 67808) = 0;
  *(_DWORD *)(a1 + 67824) = 0;
  *(_DWORD *)(a1 + 67840) = 0;
  *(_DWORD *)(a1 + 67856) = 0;
  *(_DWORD *)(a1 + 67872) = 0;
  *(_DWORD *)(a1 + 67888) = 0;
  *(_DWORD *)(a1 + 67904) = 0;
  *(_DWORD *)(a1 + 67920) = 0;
  *(_DWORD *)(a1 + 67936) = 0;
  *(_DWORD *)(a1 + 67952) = 0;
  *(_DWORD *)(a1 + 67968) = 0;
  *(_DWORD *)(a1 + 67984) = 0;
  *(_DWORD *)(a1 + 68000) = 0;
  *(_DWORD *)(a1 + 68016) = 0;
  *(_DWORD *)(a1 + 68032) = 0;
  *(_DWORD *)(a1 + 68048) = 0;
  *(_DWORD *)(a1 + 68064) = 0;
  *(_DWORD *)(a1 + 68080) = 0;
  *(_DWORD *)(a1 + 68096) = 0;
  *(_DWORD *)(a1 + 68112) = 0;
  *(_DWORD *)(a1 + 68128) = 0;
  *(_DWORD *)(a1 + 68144) = 0;
  *(_DWORD *)(a1 + 68160) = 0;
  *(_DWORD *)(a1 + 68176) = 0;
  *(_DWORD *)(a1 + 68192) = 0;
  *(_DWORD *)(a1 + 68208) = 0;
  *(_DWORD *)(a1 + 68224) = 0;
  *(_DWORD *)(a1 + 68240) = 0;
  *(_DWORD *)(a1 + 68256) = 0;
  *(_DWORD *)(a1 + 68272) = 0;
  *(_DWORD *)(a1 + 68288) = 0;
  *(_DWORD *)(a1 + 68304) = 0;
  *(_DWORD *)(a1 + 68320) = 0;
  *(_DWORD *)(a1 + 68336) = 0;
  *(_DWORD *)(a1 + 68352) = 0;
  *(_DWORD *)(a1 + 68368) = 0;
  *(_DWORD *)(a1 + 68384) = 0;
  *(_DWORD *)(a1 + 68400) = 0;
  *(_DWORD *)(a1 + 68416) = 0;
  *(_DWORD *)(a1 + 68432) = 0;
  *(_DWORD *)(a1 + 68448) = 0;
  *(_DWORD *)(a1 + 68464) = 0;
  *(_DWORD *)(a1 + 68480) = 0;
  *(_DWORD *)(a1 + 68496) = 0;
  *(_DWORD *)(a1 + 68512) = 0;
  *(_DWORD *)(a1 + 68528) = 0;
  *(_DWORD *)(a1 + 68544) = 0;
  *(_DWORD *)(a1 + 68560) = 0;
  *(_DWORD *)(a1 + 68576) = 0;
  *(_DWORD *)(a1 + 69424) = 0;
  *(_DWORD *)(a1 + 69440) = 0;
  *(_DWORD *)(a1 + 69456) = 0;
  *(_DWORD *)(a1 + 69472) = 0;
  *(_DWORD *)(a1 + 69504) = 0;
  *(_DWORD *)(a1 + 69536) = 0;
  *(_DWORD *)(a1 + 69552) = 0;
  *(_DWORD *)(a1 + 69568) = 0;
  *(_DWORD *)(a1 + 69616) = 0;
  *(_DWORD *)(a1 + 69632) = 0;
  *(_DWORD *)(a1 + 69648) = 0;
  *(_DWORD *)(a1 + 69664) = 0;
  *(_DWORD *)(a1 + 69680) = 0;
  *(_DWORD *)(a1 + 69696) = 0;
  *(_DWORD *)(a1 + 69712) = 0;
  *(_DWORD *)(a1 + 69728) = 0;
  *(_DWORD *)(a1 + 69744) = 0;
  *(_DWORD *)(a1 + 69760) = 0;
  *(_DWORD *)(a1 + 69776) = 0;
  *(_DWORD *)(a1 + 69920) = 0;
  *(_DWORD *)(a1 + 69952) = 0;
  *(_DWORD *)(a1 + 69968) = 0;
  *(_DWORD *)(a1 + 69984) = 0;
  *(_DWORD *)(a1 + 70048) = 0;
  *(_DWORD *)(a1 + 70064) = 0;
  *(_DWORD *)(a1 + 70112) = 0;
  *(_DWORD *)(a1 + 70128) = 0;
  *(_DWORD *)(a1 + 70144) = 0;
  *(_DWORD *)(a1 + 70160) = 0;
  *(_DWORD *)(a1 + 70176) = 0;
  *(_DWORD *)(a1 + 70240) = 0;
  *(_DWORD *)(a1 + 70256) = 0;
  *(_DWORD *)(a1 + 70320) = 0;
  *(_DWORD *)(a1 + 70336) = 0;
  *(_DWORD *)(a1 + 70352) = 0;
  *(_DWORD *)(a1 + 70592) = 0;
  *(_DWORD *)(a1 + 70608) = 0;
  *(_DWORD *)(a1 + 70624) = 0;
  *(_DWORD *)(a1 + 70640) = 0;
  *(_DWORD *)(a1 + 70656) = 0;
  *(_DWORD *)(a1 + 71280) = 0;
  *(_DWORD *)(a1 + 71296) = 0;
  *(_DWORD *)(a1 + 71312) = 0;
  *(_DWORD *)(a1 + 71328) = 0;
  *(_DWORD *)(a1 + 71344) = 0;
  *(_DWORD *)(a1 + 71360) = 0;
  *(_DWORD *)(a1 + 71376) = 0;
  *(_DWORD *)(a1 + 71392) = 0;
  *(_DWORD *)(a1 + 71408) = 0;
  *(_DWORD *)(a1 + 71424) = 0;
  *(_DWORD *)(a1 + 71440) = 0;
  *(_DWORD *)(a1 + 71456) = 0;
  *(_DWORD *)(a1 + 71472) = 0;
  *(_DWORD *)(a1 + 71488) = 0;
  *(_DWORD *)(a1 + 71504) = 0;
  *(_DWORD *)(a1 + 71520) = 0;
  *(_DWORD *)(a1 + 71536) = 0;
  *(_DWORD *)(a1 + 71552) = 0;
  *(_DWORD *)(a1 + 71568) = 0;
  *(_DWORD *)(a1 + 71584) = 0;
  *(_DWORD *)(a1 + 71600) = 0;
  *(_DWORD *)(a1 + 71616) = 0;
  *(_DWORD *)(a1 + 71632) = 0;
  *(_DWORD *)(a1 + 71648) = 0;
  *(_DWORD *)(a1 + 71664) = 0;
  *(_DWORD *)(a1 + 71680) = 0;
  *(_DWORD *)(a1 + 71696) = 0;
  *(_DWORD *)(a1 + 71712) = 0;
  *(_DWORD *)(a1 + 71728) = 0;
  *(_DWORD *)(a1 + 71744) = 0;
  *(_DWORD *)(a1 + 71760) = 0;
  *(_DWORD *)(a1 + 71776) = 0;
  *(_DWORD *)(a1 + 71792) = 0;
  *(_DWORD *)(a1 + 71808) = 0;
  *(_DWORD *)(a1 + 71824) = 0;
  *(_DWORD *)(a1 + 71840) = 0;
  *(_DWORD *)(a1 + 71856) = 0;
  *(_DWORD *)(a1 + 71872) = 0;
  *(_DWORD *)(a1 + 71888) = 0;
  *(_DWORD *)(a1 + 71904) = 0;
  *(_DWORD *)(a1 + 71920) = 0;
  *(_DWORD *)(a1 + 71936) = 0;
  *(_DWORD *)(a1 + 71952) = 0;
  *(_DWORD *)(a1 + 71968) = 0;
  *(_DWORD *)(a1 + 71984) = 0;
  *(_DWORD *)(a1 + 72000) = 0;
  *(_DWORD *)(a1 + 72016) = 0;
  *(_DWORD *)(a1 + 72032) = 0;
  *(_DWORD *)(a1 + 72048) = 0;
  *(_DWORD *)(a1 + 72064) = 0;
  *(_DWORD *)(a1 + 72080) = 0;
  *(_DWORD *)(a1 + 72096) = 0;
  *(_DWORD *)(a1 + 72112) = 0;
  *(_DWORD *)(a1 + 72624) = 0;
  *(_DWORD *)(a1 + 72640) = 0;
  *(_DWORD *)(a1 + 72704) = 0;
  *(_DWORD *)(a1 + 72720) = 0;
  *(_DWORD *)(a1 + 72736) = 0;
  *(_DWORD *)(a1 + 72768) = 0;
  *(_DWORD *)(a1 + 72784) = 0;
  *(_DWORD *)(a1 + 72800) = 0;
  *(_DWORD *)(a1 + 72832) = 0;
  *(_DWORD *)(a1 + 72848) = 0;
  *(_DWORD *)(a1 + 72864) = 0;
  *(_DWORD *)(a1 + 72912) = 0;
  *(_DWORD *)(a1 + 72928) = 0;
  *(_DWORD *)(a1 + 72944) = 0;
  *(_DWORD *)(a1 + 72976) = 0;
  *(_DWORD *)(a1 + 72992) = 0;
  *(_DWORD *)(a1 + 73008) = 0;
  *(_DWORD *)(a1 + 73120) = 0;
  *(_DWORD *)(a1 + 73136) = 0;
  *(_DWORD *)(a1 + 73152) = 0;
  *(_DWORD *)(a1 + 73168) = 0;
  *(_DWORD *)(a1 + 73184) = 0;
  *(_DWORD *)(a1 + 73200) = 0;
  *(_DWORD *)(a1 + 73216) = 0;
  *(_DWORD *)(a1 + 73232) = 0;
  *(_DWORD *)(a1 + 73488) = 0;
  *(_DWORD *)(a1 + 73504) = 0;
  *(_DWORD *)(a1 + 73520) = 0;
  *(_DWORD *)(a1 + 73552) = 0;
  *(_DWORD *)(a1 + 73568) = 0;
  *(_DWORD *)(a1 + 73584) = 0;
  *(_DWORD *)(a1 + 73600) = 0;
  *(_DWORD *)(a1 + 73616) = 0;
  *(_DWORD *)(a1 + 73728) = 0;
  *(_DWORD *)(a1 + 73744) = 0;
  *(_DWORD *)(a1 + 73760) = 0;
  *(_DWORD *)(a1 + 73776) = 0;
  *(_DWORD *)(a1 + 73792) = 0;
  *(_DWORD *)(a1 + 73808) = 0;
  *(_DWORD *)(a1 + 73824) = 0;
  *(_DWORD *)(a1 + 73840) = 0;
  *(_DWORD *)(a1 + 73872) = 0;
  *(_DWORD *)(a1 + 73920) = 0;
  *(_DWORD *)(a1 + 73936) = 0;
  *(_DWORD *)(a1 + 73984) = 0;
  *(_DWORD *)(a1 + 74000) = 0;
  *(_DWORD *)(a1 + 74016) = 0;
  *(_DWORD *)(a1 + 74032) = 0;
  *(_DWORD *)(a1 + 74048) = 0;
  *(_DWORD *)(a1 + 74064) = 0;
  *(_DWORD *)(a1 + 74080) = 0;
  *(_DWORD *)(a1 + 74096) = 0;
  *(_DWORD *)(a1 + 74112) = 0;
  *(_DWORD *)(a1 + 74144) = 0;
  *(_DWORD *)(a1 + 74160) = 0;
  *(_DWORD *)(a1 + 74224) = 0;
  *(_DWORD *)(a1 + 74240) = 0;
  *(_DWORD *)(a1 + 74256) = 0;
  *(_DWORD *)(a1 + 74272) = 0;
  *(_DWORD *)(a1 + 74288) = 0;
  *(_DWORD *)(a1 + 74304) = 0;
  *(_DWORD *)(a1 + 74320) = 0;
  *(_DWORD *)(a1 + 74336) = 0;
  *(_DWORD *)(a1 + 74464) = 0;
  *(_DWORD *)(a1 + 74480) = 0;
  *(_DWORD *)(a1 + 74496) = 0;
  *(_DWORD *)(a1 + 74512) = 0;
  *(_DWORD *)(a1 + 74528) = 0;
  *(_DWORD *)(a1 + 74544) = 0;
  *(_DWORD *)(a1 + 74560) = 0;
  *(_DWORD *)(a1 + 74576) = 0;
  *(_DWORD *)(a1 + 74592) = 0;
  *(_DWORD *)(a1 + 74608) = 0;
  *(_DWORD *)(a1 + 74688) = 0;
  *(_DWORD *)(a1 + 74704) = 0;
  *(_DWORD *)(a1 + 74720) = 0;
  *(_DWORD *)(a1 + 74992) = 0;
  *(_DWORD *)(a1 + 75008) = 0;
  *(_DWORD *)(a1 + 75024) = 0;
  *(_DWORD *)(a1 + 75040) = 0;
  *(_DWORD *)(a1 + 75056) = 0;
  *(_DWORD *)(a1 + 75072) = 0;
  *(_DWORD *)(a1 + 75088) = 0;
  *(_DWORD *)(a1 + 75104) = 0;
  *(_DWORD *)(a1 + 75120) = 0;
  *(_DWORD *)(a1 + 75136) = 0;
  *(_DWORD *)(a1 + 75152) = 0;
  *(_DWORD *)(a1 + 75168) = 0;
  *(_DWORD *)(a1 + 75184) = 0;
  *(_DWORD *)(a1 + 75200) = 0;
  *(_DWORD *)(a1 + 75216) = 0;
  *(_DWORD *)(a1 + 75232) = 0;
  *(_DWORD *)(a1 + 75248) = 0;
  *(_DWORD *)(a1 + 75264) = 0;
  *(_DWORD *)(a1 + 75280) = 0;
  *(_DWORD *)(a1 + 75296) = 0;
  *(_DWORD *)(a1 + 75312) = 0;
  *(_DWORD *)(a1 + 75328) = 0;
  *(_DWORD *)(a1 + 75344) = 0;
  *(_DWORD *)(a1 + 75360) = 0;
  *(_DWORD *)(a1 + 75376) = 0;
  *(_DWORD *)(a1 + 75392) = 0;
  *(_DWORD *)(a1 + 75408) = 0;
  *(_DWORD *)(a1 + 75424) = 0;
  *(_DWORD *)(a1 + 76160) = 0;
  *(_DWORD *)(a1 + 76176) = 0;
  *(_DWORD *)(a1 + 76192) = 0;
  *(_DWORD *)(a1 + 76208) = 0;
  *(_DWORD *)(a1 + 76224) = 0;
  *(_DWORD *)(a1 + 76240) = 0;
  *(_DWORD *)(a1 + 76256) = 0;
  *(_DWORD *)(a1 + 76272) = 0;
  *(_DWORD *)(a1 + 76288) = 0;
  *(_DWORD *)(a1 + 76304) = 0;
  *(_DWORD *)(a1 + 76320) = 0;
  *(_DWORD *)(a1 + 76336) = 0;
  *(_DWORD *)(a1 + 76352) = 0;
  *(_DWORD *)(a1 + 76640) = 0;
  *(_DWORD *)(a1 + 76656) = 0;
  *(_DWORD *)(a1 + 76672) = 0;
  *(_DWORD *)(a1 + 76688) = 0;
  *(_DWORD *)(a1 + 76704) = 0;
  *(_DWORD *)(a1 + 76720) = 0;
  *(_DWORD *)(a1 + 76736) = 0;
  *(_DWORD *)(a1 + 76752) = 0;
  *(_DWORD *)(a1 + 76768) = 0;
  *(_DWORD *)(a1 + 76784) = 0;
  *(_DWORD *)(a1 + 76800) = 0;
  *(_DWORD *)(a1 + 76816) = 0;
  *(_DWORD *)(a1 + 76832) = 0;
  *(_DWORD *)(a1 + 77104) = 0;
  *(_DWORD *)(a1 + 77120) = 0;
  *(_DWORD *)(a1 + 77136) = 0;
  *(_DWORD *)(a1 + 77152) = 0;
  *(_DWORD *)(a1 + 77200) = 0;
  *(_DWORD *)(a1 + 77216) = 0;
  *(_DWORD *)(a1 + 77232) = 0;
  *(_DWORD *)(a1 + 77248) = 0;
  *(_DWORD *)(a1 + 77264) = 0;
  *(_DWORD *)(a1 + 77280) = 0;
  *(_DWORD *)(a1 + 77296) = 0;
  *(_DWORD *)(a1 + 77312) = 0;
  *(_DWORD *)(a1 + 77328) = 0;
  *(_DWORD *)(a1 + 77344) = 0;
  *(_DWORD *)(a1 + 77360) = 0;
  *(_DWORD *)(a1 + 77376) = 0;
  *(_DWORD *)(a1 + 77392) = 0;
  *(_DWORD *)(a1 + 77408) = 0;
  *(_DWORD *)(a1 + 77824) = 0;
  *(_DWORD *)(a1 + 77840) = 0;
  *(_DWORD *)(a1 + 77856) = 0;
  *(_DWORD *)(a1 + 77872) = 0;
  *(_DWORD *)(a1 + 77888) = 0;
  *(_DWORD *)(a1 + 77904) = 0;
  *(_DWORD *)(a1 + 78000) = 0;
  *(_DWORD *)(a1 + 78224) = 0;
  *(_DWORD *)(a1 + 78240) = 0;
  *(_DWORD *)(a1 + 78256) = 0;
  *(_DWORD *)(a1 + 78272) = 0;
  *(_DWORD *)(a1 + 78288) = 0;
  *(_DWORD *)(a1 + 78304) = 0;
  *(_DWORD *)(a1 + 78320) = 0;
  *(_DWORD *)(a1 + 78336) = 0;
  *(_DWORD *)(a1 + 78352) = 0;
  *(_DWORD *)(a1 + 78368) = 0;
  *(_DWORD *)(a1 + 78384) = 0;
  *(_DWORD *)(a1 + 78400) = 0;
  *(_DWORD *)(a1 + 78416) = 0;
  *(_DWORD *)(a1 + 78432) = 0;
  *(_DWORD *)(a1 + 78448) = 0;
  *(_DWORD *)(a1 + 78464) = 0;
  *(_DWORD *)(a1 + 78480) = 0;
  *(_DWORD *)(a1 + 78496) = 0;
  *(_DWORD *)(a1 + 78512) = 0;
  *(_DWORD *)(a1 + 78528) = 0;
  *(_DWORD *)(a1 + 78544) = 0;
  *(_DWORD *)(a1 + 78560) = 0;
  *(_DWORD *)(a1 + 78576) = 0;
  *(_DWORD *)(a1 + 78592) = 0;
  *(_DWORD *)(a1 + 78608) = 0;
  *(_DWORD *)(a1 + 78624) = 0;
  *(_DWORD *)(a1 + 78640) = 0;
  *(_DWORD *)(a1 + 78656) = 0;
  *(_DWORD *)(a1 + 78672) = 0;
  *(_DWORD *)(a1 + 78688) = 0;
  *(_DWORD *)(a1 + 78704) = 0;
  *(_DWORD *)(a1 + 78720) = 0;
  *(_DWORD *)(a1 + 78736) = 0;
  *(_DWORD *)(a1 + 78752) = 0;
  *(_DWORD *)(a1 + 78768) = 0;
  *(_DWORD *)(a1 + 78784) = 0;
  *(_DWORD *)(a1 + 78800) = 0;
  *(_DWORD *)(a1 + 78816) = 0;
  *(_DWORD *)(a1 + 78832) = 0;
  *(_DWORD *)(a1 + 78848) = 0;
  *(_DWORD *)(a1 + 78864) = 0;
  *(_DWORD *)(a1 + 78880) = 0;
  *(_DWORD *)(a1 + 78896) = 0;
  *(_DWORD *)(a1 + 78912) = 0;
  *(_DWORD *)(a1 + 78928) = 0;
  *(_DWORD *)(a1 + 78944) = 0;
  *(_DWORD *)(a1 + 78960) = 0;
  *(_DWORD *)(a1 + 78976) = 0;
  *(_DWORD *)(a1 + 78992) = 0;
  *(_DWORD *)(a1 + 79008) = 0;
  *(_DWORD *)(a1 + 79024) = 0;
  *(_DWORD *)(a1 + 79040) = 0;
  *(_DWORD *)(a1 + 79056) = 0;
  *(_DWORD *)(a1 + 79072) = 0;
  *(_DWORD *)(a1 + 79088) = 0;
  *(_DWORD *)(a1 + 79936) = 0;
  *(_DWORD *)(a1 + 79952) = 0;
  *(_DWORD *)(a1 + 79968) = 0;
  *(_DWORD *)(a1 + 79984) = 0;
  *(_DWORD *)(a1 + 80016) = 0;
  *(_DWORD *)(a1 + 80048) = 0;
  *(_DWORD *)(a1 + 80064) = 0;
  *(_DWORD *)(a1 + 80080) = 0;
  *(_DWORD *)(a1 + 80128) = 0;
  *(_DWORD *)(a1 + 80144) = 0;
  *(_DWORD *)(a1 + 80160) = 0;
  *(_DWORD *)(a1 + 80176) = 0;
  *(_DWORD *)(a1 + 80192) = 0;
  *(_DWORD *)(a1 + 80208) = 0;
  *(_DWORD *)(a1 + 80224) = 0;
  *(_DWORD *)(a1 + 80240) = 0;
  *(_DWORD *)(a1 + 80256) = 0;
  *(_DWORD *)(a1 + 80272) = 0;
  *(_DWORD *)(a1 + 80288) = 0;
  *(_DWORD *)(a1 + 80432) = 0;
  *(_DWORD *)(a1 + 80464) = 0;
  *(_DWORD *)(a1 + 80480) = 0;
  *(_DWORD *)(a1 + 80496) = 0;
  *(_DWORD *)(a1 + 80560) = 0;
  *(_DWORD *)(a1 + 80576) = 0;
  *(_DWORD *)(a1 + 80624) = 0;
  *(_DWORD *)(a1 + 80640) = 0;
  *(_DWORD *)(a1 + 80656) = 0;
  *(_DWORD *)(a1 + 80672) = 0;
  *(_DWORD *)(a1 + 80688) = 0;
  *(_DWORD *)(a1 + 80752) = 0;
  *(_DWORD *)(a1 + 80768) = 0;
  *(_DWORD *)(a1 + 80832) = 0;
  *(_DWORD *)(a1 + 80848) = 0;
  *(_DWORD *)(a1 + 80864) = 0;
  *(_DWORD *)(a1 + 81104) = 0;
  *(_DWORD *)(a1 + 81120) = 0;
  *(_DWORD *)(a1 + 81136) = 0;
  *(_DWORD *)(a1 + 81152) = 0;
  *(_DWORD *)(a1 + 81168) = 0;
  *(_DWORD *)(a1 + 81792) = 0;
  *(_DWORD *)(a1 + 81808) = 0;
  *(_DWORD *)(a1 + 81824) = 0;
  *(_DWORD *)(a1 + 81840) = 0;
  *(_DWORD *)(a1 + 81856) = 0;
  *(_DWORD *)(a1 + 81872) = 0;
  *(_DWORD *)(a1 + 81888) = 0;
  *(_DWORD *)(a1 + 81904) = 0;
  *(_DWORD *)(a1 + 81920) = 0;
  *(_DWORD *)(a1 + 81936) = 0;
  *(_DWORD *)(a1 + 81952) = 0;
  *(_DWORD *)(a1 + 81968) = 0;
  *(_DWORD *)(a1 + 81984) = 0;
  *(_DWORD *)(a1 + 82000) = 0;
  *(_DWORD *)(a1 + 82016) = 0;
  *(_DWORD *)(a1 + 82032) = 0;
  *(_DWORD *)(a1 + 82048) = 0;
  *(_DWORD *)(a1 + 82064) = 0;
  *(_DWORD *)(a1 + 82080) = 0;
  *(_DWORD *)(a1 + 82096) = 0;
  *(_DWORD *)(a1 + 82112) = 0;
  *(_DWORD *)(a1 + 82128) = 0;
  *(_DWORD *)(a1 + 82144) = 0;
  *(_DWORD *)(a1 + 82160) = 0;
  *(_DWORD *)(a1 + 82176) = 0;
  *(_DWORD *)(a1 + 82192) = 0;
  *(_DWORD *)(a1 + 82208) = 0;
  *(_DWORD *)(a1 + 82224) = 0;
  *(_DWORD *)(a1 + 82240) = 0;
  *(_DWORD *)(a1 + 82256) = 0;
  *(_DWORD *)(a1 + 82272) = 0;
  *(_DWORD *)(a1 + 82288) = 0;
  *(_DWORD *)(a1 + 82304) = 0;
  *(_DWORD *)(a1 + 82320) = 0;
  *(_DWORD *)(a1 + 82336) = 0;
  *(_DWORD *)(a1 + 82352) = 0;
  *(_DWORD *)(a1 + 82368) = 0;
  *(_DWORD *)(a1 + 82384) = 0;
  *(_DWORD *)(a1 + 82400) = 0;
  *(_DWORD *)(a1 + 82416) = 0;
  *(_DWORD *)(a1 + 82432) = 0;
  *(_DWORD *)(a1 + 82448) = 0;
  *(_DWORD *)(a1 + 82464) = 0;
  *(_DWORD *)(a1 + 82480) = 0;
  *(_DWORD *)(a1 + 82496) = 0;
  *(_DWORD *)(a1 + 82512) = 0;
  *(_DWORD *)(a1 + 82528) = 0;
  *(_DWORD *)(a1 + 82544) = 0;
  *(_DWORD *)(a1 + 82560) = 0;
  *(_DWORD *)(a1 + 82576) = 0;
  *(_DWORD *)(a1 + 82592) = 0;
  *(_DWORD *)(a1 + 82608) = 0;
  *(_DWORD *)(a1 + 82624) = 0;
  *(_DWORD *)(a1 + 83136) = 0;
  *(_DWORD *)(a1 + 83152) = 0;
  *(_DWORD *)(a1 + 83216) = 0;
  *(_DWORD *)(a1 + 83232) = 0;
  *(_DWORD *)(a1 + 83248) = 0;
  *(_DWORD *)(a1 + 83280) = 0;
  *(_DWORD *)(a1 + 83296) = 0;
  *(_DWORD *)(a1 + 83312) = 0;
  *(_DWORD *)(a1 + 83344) = 0;
  *(_DWORD *)(a1 + 83360) = 0;
  *(_DWORD *)(a1 + 83376) = 0;
  *(_DWORD *)(a1 + 83424) = 0;
  *(_DWORD *)(a1 + 83440) = 0;
  *(_DWORD *)(a1 + 83456) = 0;
  *(_DWORD *)(a1 + 83488) = 0;
  *(_DWORD *)(a1 + 83504) = 0;
  *(_DWORD *)(a1 + 83520) = 0;
  *(_DWORD *)(a1 + 83632) = 0;
  *(_DWORD *)(a1 + 83648) = 0;
  *(_DWORD *)(a1 + 83664) = 0;
  *(_DWORD *)(a1 + 83680) = 0;
  *(_DWORD *)(a1 + 83696) = 0;
  *(_DWORD *)(a1 + 83712) = 0;
  *(_DWORD *)(a1 + 83728) = 0;
  *(_DWORD *)(a1 + 83744) = 0;
  *(_DWORD *)(a1 + 84000) = 0;
  *(_DWORD *)(a1 + 84016) = 0;
  *(_DWORD *)(a1 + 84032) = 0;
  *(_DWORD *)(a1 + 84064) = 0;
  *(_DWORD *)(a1 + 84080) = 0;
  *(_DWORD *)(a1 + 84096) = 0;
  *(_DWORD *)(a1 + 84112) = 0;
  *(_DWORD *)(a1 + 84128) = 0;
  *(_DWORD *)(a1 + 84240) = 0;
  *(_DWORD *)(a1 + 84256) = 0;
  *(_DWORD *)(a1 + 84272) = 0;
  *(_DWORD *)(a1 + 84288) = 0;
  *(_DWORD *)(a1 + 84320) = 0;
  *(_DWORD *)(a1 + 84336) = 0;
  *(_DWORD *)(a1 + 84352) = 0;
  *(_DWORD *)(a1 + 84368) = 0;
  *(_DWORD *)(a1 + 84384) = 0;
  *(_DWORD *)(a1 + 84432) = 0;
  *(_DWORD *)(a1 + 84528) = 0;
  *(_DWORD *)(a1 + 84576) = 0;
  *(_DWORD *)(a1 + 84592) = 0;
  *(_DWORD *)(a1 + 84608) = 0;
  *(_DWORD *)(a1 + 84624) = 0;
  *(_DWORD *)(a1 + 84672) = 0;
  *(_DWORD *)(a1 + 84688) = 0;
  *(_DWORD *)(a1 + 84704) = 0;
  *(_DWORD *)(a1 + 84720) = 0;
  *(_DWORD *)(a1 + 84736) = 0;
  *(_DWORD *)(a1 + 84752) = 0;
  *(_DWORD *)(a1 + 84768) = 0;
  *(_DWORD *)(a1 + 84784) = 0;
  *(_DWORD *)(a1 + 84832) = 0;
  *(_DWORD *)(a1 + 84848) = 0;
  *(_DWORD *)(a1 + 84864) = 0;
  *(_DWORD *)(a1 + 84880) = 0;
  *(_DWORD *)(a1 + 84896) = 0;
  *(_DWORD *)(a1 + 84912) = 0;
  *(_DWORD *)(a1 + 84928) = 0;
  *(_DWORD *)(a1 + 84944) = 0;
  *(_DWORD *)(a1 + 84960) = 0;
  *(_DWORD *)(a1 + 84976) = 0;
  *(_DWORD *)(a1 + 84992) = 0;
  *(_DWORD *)(a1 + 85008) = 0;
  *(_DWORD *)(a1 + 85024) = 0;
  *(_DWORD *)(a1 + 85040) = 0;
  *(_DWORD *)(a1 + 85056) = 0;
  *(_DWORD *)(a1 + 85072) = 0;
  *(_DWORD *)(a1 + 85088) = 0;
  *(_DWORD *)(a1 + 85104) = 0;
  *(_DWORD *)(a1 + 85120) = 0;
  *(_DWORD *)(a1 + 85584) = 0;
  *(_DWORD *)(a1 + 85600) = 0;
  *(_DWORD *)(a1 + 85616) = 0;
  *(_DWORD *)(a1 + 85632) = 0;
  *(_DWORD *)(a1 + 85648) = 0;
  *(_DWORD *)(a1 + 85664) = 0;
  *(_DWORD *)(a1 + 85680) = 0;
  *(_DWORD *)(a1 + 85696) = 0;
  *(_DWORD *)(a1 + 85712) = 0;
  *(_DWORD *)(a1 + 85728) = 0;
  *(_DWORD *)(a1 + 85904) = 0;
  *(_DWORD *)(a1 + 85920) = 0;
  *(_DWORD *)(a1 + 85936) = 0;
  *(_DWORD *)(a1 + 85952) = 0;
  *(_DWORD *)(a1 + 85968) = 0;
  *(_DWORD *)(a1 + 86096) = 0;
  *(_DWORD *)(a1 + 86112) = 0;
  *(_DWORD *)(a1 + 86128) = 0;
  *(_DWORD *)(a1 + 86144) = 0;
  *(_DWORD *)(a1 + 86160) = 0;
  *(_DWORD *)(a1 + 86176) = 0;
  *(_DWORD *)(a1 + 86192) = 0;
  *(_DWORD *)(a1 + 86208) = 0;
  *(_DWORD *)(a1 + 86224) = 0;
  *(_DWORD *)(a1 + 86240) = 0;
  *(_DWORD *)(a1 + 86256) = 0;
  *(_DWORD *)(a1 + 86272) = 0;
  *(_DWORD *)(a1 + 86656) = 0;
  *(_DWORD *)(a1 + 86672) = 0;
  *(_DWORD *)(a1 + 86688) = 0;
  *(_DWORD *)(a1 + 86704) = 0;
  *(_DWORD *)(a1 + 86720) = 0;
  *(_DWORD *)(a1 + 86736) = 0;
  *(_DWORD *)(a1 + 86752) = 0;
  *(_DWORD *)(a1 + 86768) = 0;
  *(_DWORD *)(a1 + 86784) = 0;
  *(_DWORD *)(a1 + 86800) = 0;
  *(_DWORD *)(a1 + 86976) = 0;
  *(_DWORD *)(a1 + 86992) = 0;
  *(_DWORD *)(a1 + 87008) = 0;
  *(_DWORD *)(a1 + 87024) = 0;
  *(_DWORD *)(a1 + 87040) = 0;
  *(_DWORD *)(a1 + 87168) = 0;
  *(_DWORD *)(a1 + 87184) = 0;
  *(_DWORD *)(a1 + 87200) = 0;
  *(_DWORD *)(a1 + 87216) = 0;
  *(_DWORD *)(a1 + 87232) = 0;
  *(_DWORD *)(a1 + 87248) = 0;
  *(_DWORD *)(a1 + 87264) = 0;
  *(_DWORD *)(a1 + 87280) = 0;
  *(_DWORD *)(a1 + 87296) = 0;
  *(_DWORD *)(a1 + 87312) = 0;
  *(_DWORD *)(a1 + 87328) = 0;
  *(_DWORD *)(a1 + 87344) = 0;
  *(_DWORD *)(a1 + 87360) = 0;
  *(_DWORD *)(a1 + 87376) = 0;
  *(_DWORD *)(a1 + 87392) = 0;
  *(_DWORD *)(a1 + 87408) = 0;
  *(_DWORD *)(a1 + 87424) = 0;
  *(_DWORD *)(a1 + 87440) = 0;
  *(_DWORD *)(a1 + 87456) = 0;
  *(_DWORD *)(a1 + 87472) = 0;
  *(_DWORD *)(a1 + 87488) = 0;
  *(_DWORD *)(a1 + 87504) = 0;
  *(_DWORD *)(a1 + 87520) = 0;
  *(_DWORD *)(a1 + 87536) = 0;
  *(_DWORD *)(a1 + 87552) = 0;
  *(_DWORD *)(a1 + 87568) = 0;
  *(_DWORD *)(a1 + 87584) = 0;
  *(_DWORD *)(a1 + 87600) = 0;
  *(_DWORD *)(a1 + 88400) = 0;
  *(_DWORD *)(a1 + 88416) = 0;
  *(_DWORD *)(a1 + 88432) = 0;
  *(_DWORD *)(a1 + 88448) = 0;
  *(_DWORD *)(a1 + 88464) = 0;
  *(_DWORD *)(a1 + 88480) = 0;
  *(_DWORD *)(a1 + 88496) = 0;
  *(_DWORD *)(a1 + 88512) = 0;
  *(_DWORD *)(a1 + 88528) = 0;
  *(_DWORD *)(a1 + 88544) = 0;
  *(_DWORD *)(a1 + 88560) = 0;
  *(_DWORD *)(a1 + 88576) = 0;
  *(_DWORD *)(a1 + 88592) = 0;
  *(_DWORD *)(a1 + 88608) = 0;
  *(_DWORD *)(a1 + 88624) = 0;
  *(_DWORD *)(a1 + 88640) = 0;
  *(_DWORD *)(a1 + 88656) = 0;
  *(_DWORD *)(a1 + 88672) = 0;
  *(_DWORD *)(a1 + 88688) = 0;
  *(_DWORD *)(a1 + 88704) = 0;
  *(_DWORD *)(a1 + 88896) = 0;
  *(_DWORD *)(a1 + 88912) = 0;
  *(_DWORD *)(a1 + 88928) = 0;
  *(_DWORD *)(a1 + 88944) = 0;
  *(_DWORD *)(a1 + 88960) = 0;
  *(_DWORD *)(a1 + 89088) = 0;
  *(_DWORD *)(a1 + 89104) = 0;
  *(_DWORD *)(a1 + 89120) = 0;
  *(_DWORD *)(a1 + 89136) = 0;
  *(_DWORD *)(a1 + 89152) = 0;
  *(_DWORD *)(a1 + 89168) = 0;
  *(_DWORD *)(a1 + 89184) = 0;
  *(_DWORD *)(a1 + 89200) = 0;
  *(_DWORD *)(a1 + 89216) = 0;
  *(_DWORD *)(a1 + 89232) = 0;
  *(_DWORD *)(a1 + 89248) = 0;
  *(_DWORD *)(a1 + 89264) = 0;
  *(_DWORD *)(a1 + 89280) = 0;
  *(_DWORD *)(a1 + 89296) = 0;
  *(_DWORD *)(a1 + 89680) = 0;
  *(_DWORD *)(a1 + 89696) = 0;
  *(_DWORD *)(a1 + 89712) = 0;
  *(_DWORD *)(a1 + 89728) = 0;
  *(_DWORD *)(a1 + 89744) = 0;
  *(_DWORD *)(a1 + 89760) = 0;
  *(_DWORD *)(a1 + 89776) = 0;
  *(_DWORD *)(a1 + 89792) = 0;
  *(_DWORD *)(a1 + 89808) = 0;
  *(_DWORD *)(a1 + 89824) = 0;
  *(_DWORD *)(a1 + 89840) = 0;
  *(_DWORD *)(a1 + 89856) = 0;
  *(_DWORD *)(a1 + 89872) = 0;
  *(_DWORD *)(a1 + 89888) = 0;
  *(_DWORD *)(a1 + 89904) = 0;
  *(_DWORD *)(a1 + 89920) = 0;
  *(_DWORD *)(a1 + 89936) = 0;
  *(_DWORD *)(a1 + 89952) = 0;
  v2 = (_QWORD *)(a1 + 91728);
  *(_DWORD *)(a1 + 89968) = 0;
  *(_DWORD *)(a1 + 89984) = 0;
  *(_DWORD *)(a1 + 90176) = 0;
  *(_DWORD *)(a1 + 90192) = 0;
  *(_DWORD *)(a1 + 90208) = 0;
  *(_DWORD *)(a1 + 90224) = 0;
  *(_DWORD *)(a1 + 90240) = 0;
  *(_DWORD *)(a1 + 90368) = 0;
  *(_DWORD *)(a1 + 90384) = 0;
  *(_DWORD *)(a1 + 90400) = 0;
  *(_DWORD *)(a1 + 90416) = 0;
  *(_DWORD *)(a1 + 90432) = 0;
  *(_DWORD *)(a1 + 90448) = 0;
  *(_DWORD *)(a1 + 90464) = 0;
  *(_DWORD *)(a1 + 90480) = 0;
  *(_DWORD *)(a1 + 90496) = 0;
  *(_DWORD *)(a1 + 90512) = 0;
  *(_DWORD *)(a1 + 90528) = 0;
  *(_DWORD *)(a1 + 90544) = 0;
  *(_DWORD *)(a1 + 90560) = 0;
  *(_DWORD *)(a1 + 90576) = 0;
  *(_DWORD *)(a1 + 90592) = 0;
  *(_DWORD *)(a1 + 90608) = 0;
  *(_DWORD *)(a1 + 90624) = 0;
  *(_DWORD *)(a1 + 90640) = 0;
  *(_DWORD *)(a1 + 90656) = 0;
  *(_DWORD *)(a1 + 90672) = 0;
  *(_DWORD *)(a1 + 90688) = 0;
  *(_DWORD *)(a1 + 90704) = 0;
  *(_DWORD *)(a1 + 90720) = 0;
  *(_DWORD *)(a1 + 90736) = 0;
  *(_DWORD *)(a1 + 90752) = 0;
  *(_DWORD *)(a1 + 90768) = 0;
  *(_DWORD *)(a1 + 90784) = 0;
  *(_DWORD *)(a1 + 90800) = 0;
  *(_DWORD *)(a1 + 90816) = 0;
  *(_DWORD *)(a1 + 90832) = 0;
  *(_DWORD *)(a1 + 90848) = 0;
  *(_DWORD *)(a1 + 90864) = 0;
  *(_DWORD *)(a1 + 90880) = 0;
  *(_DWORD *)(a1 + 90896) = 0;
  *(_DWORD *)(a1 + 90912) = 0;
  *(_DWORD *)(a1 + 90928) = 0;
  *(_DWORD *)(a1 + 90944) = 0;
  *(_DWORD *)(a1 + 90960) = 0;
  *(_DWORD *)(a1 + 90976) = 0;
  *(_DWORD *)(a1 + 90992) = 0;
  *(_DWORD *)(a1 + 91008) = 0;
  *(_DWORD *)(a1 + 91024) = 0;
  *(_DWORD *)(a1 + 91040) = 0;
  *(_DWORD *)(a1 + 91056) = 0;
  *(_DWORD *)(a1 + 91072) = 0;
  *(_DWORD *)(a1 + 91088) = 0;
  *(_DWORD *)(a1 + 91104) = 0;
  v3 = 64;
  v4 = 64;
  do
  {
    *v2 = 0;
    v2[1] = 0;
    v2[2] = 0;
    v2 += 8;
    *(v2 - 5) = 0;
    *(v2 - 4) = 0;
    *(v2 - 3) = 0;
    *(v2 - 2) = 0;
    *(v2 - 1) = 0;
    --v4;
  }
  while ( v4 );
  *(_DWORD *)(a1 + 95824) = 0;
  v5 = (_QWORD *)(a1 + 96928);
  *(_DWORD *)(a1 + 95828) = 1024;
  *(_DWORD *)(a1 + 95840) = 0;
  *(_QWORD *)(a1 + 95856) = 0;
  *(_DWORD *)(a1 + 95864) = 0;
  *(_QWORD *)(a1 + 95872) = 0;
  *(_DWORD *)(a1 + 95880) = 0;
  *(_DWORD *)(a1 + 95888) = 0;
  *(_DWORD *)(a1 + 95904) = 0;
  *(_DWORD *)(a1 + 95920) = 0;
  *(_DWORD *)(a1 + 95936) = 0;
  *(_DWORD *)(a1 + 95952) = 0;
  *(_DWORD *)(a1 + 95968) = 0;
  *(_DWORD *)(a1 + 95984) = 0;
  *(_DWORD *)(a1 + 96000) = 0;
  *(_DWORD *)(a1 + 96016) = 0;
  *(_DWORD *)(a1 + 96032) = 0;
  *(_DWORD *)(a1 + 96048) = 0;
  *(_DWORD *)(a1 + 96064) = 0;
  *(_DWORD *)(a1 + 96080) = 0;
  *(_DWORD *)(a1 + 96096) = 0;
  *(_DWORD *)(a1 + 96112) = 0;
  *(_DWORD *)(a1 + 96128) = 0;
  *(_DWORD *)(a1 + 96144) = 0;
  *(_DWORD *)(a1 + 96160) = 0;
  *(_DWORD *)(a1 + 96176) = 0;
  *(_DWORD *)(a1 + 96192) = 0;
  *(_DWORD *)(a1 + 96208) = 0;
  *(_DWORD *)(a1 + 96224) = 0;
  *(_DWORD *)(a1 + 96240) = 0;
  *(_DWORD *)(a1 + 96256) = 0;
  *(_DWORD *)(a1 + 96272) = 0;
  *(_DWORD *)(a1 + 96288) = 0;
  *(_DWORD *)(a1 + 96304) = 0;
  *(_DWORD *)(a1 + 96320) = 0;
  do
  {
    *v5 = 0;
    v5[1] = 0;
    v5[2] = 0;
    v5 += 8;
    *(v5 - 5) = 0;
    *(v5 - 4) = 0;
    *(v5 - 3) = 0;
    *(v5 - 2) = 0;
    *(v5 - 1) = 0;
    --v3;
  }
  while ( v3 );
  *(_DWORD *)(a1 + 101024) = 0;
  v6 = (_DWORD *)(a1 + 102800);
  *(_DWORD *)(a1 + 101028) = 1024;
  *(_DWORD *)(a1 + 101040) = 0;
  v7 = 0x80000;
  *(_QWORD *)(a1 + 101056) = 0;
  *(_DWORD *)(a1 + 101064) = 0;
  *(_DWORD *)(a1 + 101088) = 0;
  *(_DWORD *)(a1 + 101104) = 0;
  *(_DWORD *)(a1 + 101120) = 0;
  *(_DWORD *)(a1 + 101168) = 0;
  *(_DWORD *)(a1 + 101184) = 0;
  *(_DWORD *)(a1 + 101200) = 0;
  *(_DWORD *)(a1 + 101216) = 0;
  *(_DWORD *)(a1 + 101232) = 0;
  *(_DWORD *)(a1 + 101248) = 0;
  *(_DWORD *)(a1 + 101264) = 0;
  *(_DWORD *)(a1 + 101280) = 0;
  *(_DWORD *)(a1 + 101760) = 0;
  *(_DWORD *)(a1 + 101776) = 0;
  *(_DWORD *)(a1 + 101792) = 0;
  *(_DWORD *)(a1 + 101808) = 0;
  *(_DWORD *)(a1 + 101824) = 0;
  *(_DWORD *)(a1 + 101840) = 0;
  *(_DWORD *)(a1 + 101856) = 0;
  *(_DWORD *)(a1 + 101872) = 0;
  *(_DWORD *)(a1 + 101888) = 0;
  *(_DWORD *)(a1 + 101904) = 0;
  *(_DWORD *)(a1 + 101920) = 0;
  *(_DWORD *)(a1 + 101936) = 0;
  *(_DWORD *)(a1 + 101952) = 0;
  *(_DWORD *)(a1 + 101968) = 0;
  *(_DWORD *)(a1 + 101984) = 0;
  *(_DWORD *)(a1 + 102000) = 0;
  *(_DWORD *)(a1 + 102016) = 0;
  *(_DWORD *)(a1 + 102032) = 0;
  *(_DWORD *)(a1 + 102048) = 0;
  *(_DWORD *)(a1 + 102064) = 0;
  *(_DWORD *)(a1 + 102080) = 0;
  *(_DWORD *)(a1 + 102096) = 0;
  *(_DWORD *)(a1 + 102112) = 0;
  *(_DWORD *)(a1 + 102128) = 0;
  *(_DWORD *)(a1 + 102144) = 0;
  *(_DWORD *)(a1 + 102160) = 0;
  *(_DWORD *)(a1 + 102176) = 0;
  *(_DWORD *)(a1 + 102192) = 0;
  *(_DWORD *)(a1 + 102208) = 0;
  *(_DWORD *)(a1 + 102224) = 0;
  *(_DWORD *)(a1 + 102240) = 0;
  *(_DWORD *)(a1 + 102256) = 0;
  *(_DWORD *)(a1 + 102272) = 0;
  *(_DWORD *)(a1 + 102288) = 0;
  *(_DWORD *)(a1 + 102304) = 0;
  *(_DWORD *)(a1 + 102320) = 0;
  *(_DWORD *)(a1 + 102336) = 0;
  while ( v7 )
  {
    *v6++ = 0;
    --v7;
  }
  *(_DWORD *)(a1 + 2199952) = 0;
  v8 = (_DWORD *)(a1 + 2199968);
  *(_DWORD *)(a1 + 2199956) = 0x80000;
  for ( i = 0x80000; i; --i )
    *v8++ = 0;
  *(_DWORD *)(a1 + 4297120) = 0;
  *(_DWORD *)(a1 + 4297124) = 0x80000;
  *(_DWORD *)(a1 + 4297136) = 0;
  *(_QWORD *)(a1 + 4297152) = 0;
  *(_DWORD *)(a1 + 4297160) = 0;
  *(_DWORD *)(a1 + 4297168) = 0;
  *(_QWORD *)(a1 + 4297184) = 0;
  *(_DWORD *)(a1 + 4297192) = 0;
  *(_DWORD *)(a1 + 4297200) = 0;
  *(_DWORD *)(a1 + 4297216) = 0;
  *(_DWORD *)(a1 + 4297232) = 0;
  *(_DWORD *)(a1 + 4297248) = 0;
  *(_DWORD *)(a1 + 4297264) = 0;
  *(_DWORD *)(a1 + 4297280) = 0;
  *(_DWORD *)(a1 + 4297296) = 0;
  *(_DWORD *)(a1 + 4297312) = 0;
  *(_DWORD *)(a1 + 4297328) = 0;
  *(_DWORD *)(a1 + 4297344) = 0;
  *(_DWORD *)(a1 + 4297360) = 0;
  *(_DWORD *)(a1 + 4297376) = 0;
  v10 = (_DWORD *)(a1 + 4298096);
  *(_DWORD *)(a1 + 4297392) = 0;
  v11 = 0x80000;
  *(_DWORD *)(a1 + 4297408) = 0;
  v12 = 512;
  *(_DWORD *)(a1 + 4297424) = 0;
  *(_DWORD *)(a1 + 4297440) = 0;
  *(_DWORD *)(a1 + 4297456) = 0;
  *(_DWORD *)(a1 + 4297472) = 0;
  *(_DWORD *)(a1 + 4297488) = 0;
  *(_DWORD *)(a1 + 4297504) = 0;
  *(_DWORD *)(a1 + 4297520) = 0;
  *(_DWORD *)(a1 + 4297536) = 0;
  *(_DWORD *)(a1 + 4297552) = 0;
  *(_DWORD *)(a1 + 4297568) = 0;
  while ( v11 )
  {
    *v10++ = 0;
    --v11;
  }
  *(_DWORD *)(a1 + 6395248) = 0;
  v13 = (_QWORD *)(a1 + 6396640);
  *(_DWORD *)(a1 + 6395252) = 0x80000;
  v14 = 512;
  *(_DWORD *)(a1 + 6395264) = 0;
  *(_QWORD *)(a1 + 6395280) = 0;
  *(_DWORD *)(a1 + 6395288) = 0;
  *(_QWORD *)(a1 + 6395296) = 0;
  *(_DWORD *)(a1 + 6395304) = 0;
  *(_DWORD *)(a1 + 6395344) = 0;
  *(_DWORD *)(a1 + 6395360) = 0;
  *(_DWORD *)(a1 + 6395376) = 0;
  *(_DWORD *)(a1 + 6395600) = 0;
  *(_DWORD *)(a1 + 6395616) = 0;
  *(_DWORD *)(a1 + 6395632) = 0;
  *(_DWORD *)(a1 + 6395680) = 0;
  *(_DWORD *)(a1 + 6395728) = 0;
  *(_DWORD *)(a1 + 6395744) = 0;
  *(_DWORD *)(a1 + 6395760) = 0;
  *(_DWORD *)(a1 + 6395776) = 0;
  *(_DWORD *)(a1 + 6395792) = 0;
  *(_DWORD *)(a1 + 6395808) = 0;
  *(_DWORD *)(a1 + 6395824) = 0;
  *(_DWORD *)(a1 + 6395840) = 0;
  *(_DWORD *)(a1 + 6395856) = 0;
  *(_DWORD *)(a1 + 6395872) = 0;
  *(_DWORD *)(a1 + 6395888) = 0;
  *(_DWORD *)(a1 + 6395904) = 0;
  *(_DWORD *)(a1 + 6395920) = 0;
  *(_DWORD *)(a1 + 6395936) = 0;
  *(_DWORD *)(a1 + 6395952) = 0;
  *(_DWORD *)(a1 + 6395968) = 0;
  *(_DWORD *)(a1 + 6395984) = 0;
  *(_DWORD *)(a1 + 6396000) = 0;
  *(_DWORD *)(a1 + 6396016) = 0;
  *(_DWORD *)(a1 + 6396032) = 0;
  *(_DWORD *)(a1 + 6396048) = 0;
  *(_DWORD *)(a1 + 6396064) = 0;
  *(_DWORD *)(a1 + 6396080) = 0;
  *(_DWORD *)(a1 + 6396096) = 0;
  *(_DWORD *)(a1 + 6396112) = 0;
  do
  {
    *v13 = 0;
    v13[1] = 0;
    v13[2] = 0;
    v13 += 8;
    *(v13 - 5) = 0;
    *(v13 - 4) = 0;
    *(v13 - 3) = 0;
    *(v13 - 2) = 0;
    *(v13 - 1) = 0;
    --v14;
  }
  while ( v14 );
  *(_DWORD *)(a1 + 6429408) = 0;
  v15 = (_QWORD *)(a1 + 6430944);
  *(_DWORD *)(a1 + 6429412) = 0x2000;
  v16 = 512;
  *(_DWORD *)(a1 + 6429424) = 0;
  *(_QWORD *)(a1 + 6429440) = 0;
  *(_DWORD *)(a1 + 6429448) = 0;
  *(_QWORD *)(a1 + 6429456) = 0;
  *(_DWORD *)(a1 + 6429464) = 0;
  *(_DWORD *)(a1 + 6429504) = 0;
  *(_DWORD *)(a1 + 6429520) = 0;
  *(_DWORD *)(a1 + 6429536) = 0;
  *(_DWORD *)(a1 + 6429760) = 0;
  *(_DWORD *)(a1 + 6429776) = 0;
  *(_DWORD *)(a1 + 6429792) = 0;
  *(_DWORD *)(a1 + 6429840) = 0;
  *(_DWORD *)(a1 + 6429888) = 0;
  *(_DWORD *)(a1 + 6429904) = 0;
  *(_DWORD *)(a1 + 6429920) = 0;
  *(_DWORD *)(a1 + 6429936) = 0;
  *(_DWORD *)(a1 + 6429952) = 0;
  *(_DWORD *)(a1 + 6429968) = 0;
  *(_DWORD *)(a1 + 6429984) = 0;
  *(_DWORD *)(a1 + 6430000) = 0;
  *(_DWORD *)(a1 + 6430016) = 0;
  *(_DWORD *)(a1 + 6430032) = 0;
  *(_DWORD *)(a1 + 6430048) = 0;
  *(_DWORD *)(a1 + 6430064) = 0;
  *(_DWORD *)(a1 + 6430080) = 0;
  *(_DWORD *)(a1 + 6430096) = 0;
  *(_DWORD *)(a1 + 6430112) = 0;
  *(_DWORD *)(a1 + 6430128) = 0;
  *(_DWORD *)(a1 + 6430144) = 0;
  *(_DWORD *)(a1 + 6430160) = 0;
  *(_DWORD *)(a1 + 6430176) = 0;
  *(_DWORD *)(a1 + 6430192) = 0;
  *(_DWORD *)(a1 + 6430208) = 0;
  *(_DWORD *)(a1 + 6430224) = 0;
  *(_DWORD *)(a1 + 6430240) = 0;
  *(_DWORD *)(a1 + 6430256) = 0;
  *(_DWORD *)(a1 + 6430272) = 0;
  *(_DWORD *)(a1 + 6430288) = 0;
  *(_DWORD *)(a1 + 6430304) = 0;
  *(_DWORD *)(a1 + 6430320) = 0;
  *(_DWORD *)(a1 + 6430336) = 0;
  *(_DWORD *)(a1 + 6430352) = 0;
  *(_DWORD *)(a1 + 6430368) = 0;
  *(_DWORD *)(a1 + 6430384) = 0;
  *(_DWORD *)(a1 + 6430400) = 0;
  *(_DWORD *)(a1 + 6430416) = 0;
  *(_DWORD *)(a1 + 6430432) = 0;
  *(_DWORD *)(a1 + 6430448) = 0;
  do
  {
    *v15 = 0;
    v15[1] = 0;
    v15[2] = 0;
    v15 += 8;
    *(v15 - 5) = 0;
    *(v15 - 4) = 0;
    *(v15 - 3) = 0;
    *(v15 - 2) = 0;
    *(v15 - 1) = 0;
    --v16;
  }
  while ( v16 );
  *(_DWORD *)(a1 + 6463712) = 0;
  v17 = (_QWORD *)(a1 + 6463728);
  *(_DWORD *)(a1 + 6463716) = 0x2000;
  v18 = 512;
  do
  {
    *v17 = 0;
    v17[1] = 0;
    v17[2] = 0;
    v17 += 8;
    *(v17 - 5) = 0;
    *(v17 - 4) = 0;
    *(v17 - 3) = 0;
    *(v17 - 2) = 0;
    *(v17 - 1) = 0;
    --v18;
  }
  while ( v18 );
  *(_DWORD *)(a1 + 6496496) = 0;
  v19 = (_DWORD *)(a1 + 6497616);
  *(_DWORD *)(a1 + 6496500) = 0x2000;
  *(_DWORD *)(a1 + 6496512) = 0;
  v20 = 0x80000;
  *(_QWORD *)(a1 + 6496528) = 0;
  *(_DWORD *)(a1 + 6496536) = 0;
  *(_DWORD *)(a1 + 6496544) = 0;
  *(_QWORD *)(a1 + 6496560) = 0;
  *(_DWORD *)(a1 + 6496568) = 0;
  *(_DWORD *)(a1 + 6496576) = 0;
  *(_DWORD *)(a1 + 6496592) = 0;
  *(_DWORD *)(a1 + 6496608) = 0;
  *(_DWORD *)(a1 + 6496624) = 0;
  *(_DWORD *)(a1 + 6496640) = 0;
  *(_DWORD *)(a1 + 6496656) = 0;
  *(_DWORD *)(a1 + 6496672) = 0;
  *(_DWORD *)(a1 + 6496688) = 0;
  *(_DWORD *)(a1 + 6496704) = 0;
  *(_DWORD *)(a1 + 6496720) = 0;
  *(_DWORD *)(a1 + 6496736) = 0;
  *(_DWORD *)(a1 + 6496752) = 0;
  *(_DWORD *)(a1 + 6496768) = 0;
  *(_DWORD *)(a1 + 6496784) = 0;
  *(_DWORD *)(a1 + 6496800) = 0;
  *(_DWORD *)(a1 + 6496816) = 0;
  *(_DWORD *)(a1 + 6496832) = 0;
  *(_DWORD *)(a1 + 6496848) = 0;
  *(_DWORD *)(a1 + 6496864) = 0;
  *(_DWORD *)(a1 + 6496880) = 0;
  *(_DWORD *)(a1 + 6496896) = 0;
  *(_DWORD *)(a1 + 6496912) = 0;
  *(_DWORD *)(a1 + 6496928) = 0;
  *(_DWORD *)(a1 + 6496944) = 0;
  *(_DWORD *)(a1 + 6496960) = 0;
  *(_DWORD *)(a1 + 6496976) = 0;
  *(_DWORD *)(a1 + 6496992) = 0;
  *(_DWORD *)(a1 + 6497008) = 0;
  *(_DWORD *)(a1 + 6497024) = 0;
  *(_DWORD *)(a1 + 6497040) = 0;
  *(_DWORD *)(a1 + 6497056) = 0;
  *(_DWORD *)(a1 + 6497072) = 0;
  *(_DWORD *)(a1 + 6497088) = 0;
  *(_DWORD *)(a1 + 6497104) = 0;
  *(_DWORD *)(a1 + 6497120) = 0;
  *(_DWORD *)(a1 + 6497136) = 0;
  *(_DWORD *)(a1 + 6497152) = 0;
  while ( v20 )
  {
    *v19++ = 0;
    --v20;
  }
  *(_DWORD *)(a1 + 8594768) = 0;
  v21 = (_DWORD *)(a1 + 8594784);
  *(_DWORD *)(a1 + 8594772) = 0x80000;
  for ( j = 0x80000; j; --j )
    *v21++ = 0;
  *(_DWORD *)(a1 + 10691936) = 0;
  *(_DWORD *)(a1 + 10691940) = 0x80000;
  *(_DWORD *)(a1 + 10691952) = 0;
  *(_QWORD *)(a1 + 10691968) = 0;
  *(_DWORD *)(a1 + 10691976) = 0;
  *(_DWORD *)(a1 + 10691984) = 0;
  *(_QWORD *)(a1 + 10692000) = 0;
  *(_DWORD *)(a1 + 10692008) = 0;
  *(_DWORD *)(a1 + 10692048) = 0;
  *(_DWORD *)(a1 + 10692064) = 0;
  *(_DWORD *)(a1 + 10692080) = 0;
  *(_DWORD *)(a1 + 10692304) = 0;
  *(_DWORD *)(a1 + 10692320) = 0;
  *(_DWORD *)(a1 + 10692336) = 0;
  *(_DWORD *)(a1 + 10692384) = 0;
  *(_DWORD *)(a1 + 10692432) = 0;
  *(_DWORD *)(a1 + 10692448) = 0;
  *(_DWORD *)(a1 + 10692464) = 0;
  *(_DWORD *)(a1 + 10692480) = 0;
  *(_DWORD *)(a1 + 10692496) = 0;
  *(_DWORD *)(a1 + 10692512) = 0;
  *(_DWORD *)(a1 + 10692528) = 0;
  *(_DWORD *)(a1 + 10692544) = 0;
  *(_DWORD *)(a1 + 10692560) = 0;
  *(_DWORD *)(a1 + 10692576) = 0;
  *(_DWORD *)(a1 + 10692592) = 0;
  *(_DWORD *)(a1 + 10692608) = 0;
  *(_DWORD *)(a1 + 10692624) = 0;
  v23 = (_QWORD *)(a1 + 10693488);
  *(_DWORD *)(a1 + 10692640) = 0;
  v24 = 512;
  *(_DWORD *)(a1 + 10692656) = 0;
  *(_DWORD *)(a1 + 10692672) = 0;
  *(_DWORD *)(a1 + 10692688) = 0;
  *(_DWORD *)(a1 + 10692704) = 0;
  *(_DWORD *)(a1 + 10692720) = 0;
  *(_DWORD *)(a1 + 10692736) = 0;
  *(_DWORD *)(a1 + 10692752) = 0;
  *(_DWORD *)(a1 + 10692768) = 0;
  *(_DWORD *)(a1 + 10692784) = 0;
  *(_DWORD *)(a1 + 10692800) = 0;
  *(_DWORD *)(a1 + 10692816) = 0;
  *(_DWORD *)(a1 + 10692832) = 0;
  *(_DWORD *)(a1 + 10692848) = 0;
  *(_DWORD *)(a1 + 10692864) = 0;
  *(_DWORD *)(a1 + 10692880) = 0;
  *(_DWORD *)(a1 + 10692896) = 0;
  *(_DWORD *)(a1 + 10692912) = 0;
  *(_DWORD *)(a1 + 10692928) = 0;
  *(_DWORD *)(a1 + 10692944) = 0;
  *(_DWORD *)(a1 + 10692960) = 0;
  *(_DWORD *)(a1 + 10692976) = 0;
  *(_DWORD *)(a1 + 10692992) = 0;
  do
  {
    *v23 = 0;
    v23[1] = 0;
    v23[2] = 0;
    v23 += 8;
    *(v23 - 5) = 0;
    *(v23 - 4) = 0;
    *(v23 - 3) = 0;
    *(v23 - 2) = 0;
    *(v23 - 1) = 0;
    --v24;
  }
  while ( v24 );
  *(_DWORD *)(a1 + 10726256) = 0;
  result = (_QWORD *)(a1 + 10726272);
  *(_DWORD *)(a1 + 10726260) = 0x2000;
  do
  {
    *result = 0;
    result[1] = 0;
    result[2] = 0;
    result += 8;
    *(result - 5) = 0;
    *(result - 4) = 0;
    *(result - 3) = 0;
    *(result - 2) = 0;
    *(result - 1) = 0;
    --v12;
  }
  while ( v12 );
  *(_DWORD *)(a1 + 10759040) = 0;
  *(_DWORD *)(a1 + 10759044) = 0x2000;
  *(_DWORD *)(a1 + 10759056) = 0;
  *(_QWORD *)(a1 + 10759072) = 0;
  *(_DWORD *)(a1 + 10759080) = 0;
  *(_DWORD *)(a1 + 10759088) = 0;
  *(_QWORD *)(a1 + 10759104) = 0;
  *(_DWORD *)(a1 + 10759112) = 0;
  *(_DWORD *)(a1 + 10759120) = 0;
  *(_DWORD *)(a1 + 10759136) = 0;
  *(_DWORD *)(a1 + 10759152) = 0;
  *(_DWORD *)(a1 + 10759168) = 0;
  *(_DWORD *)(a1 + 10759184) = 0;
  *(_DWORD *)(a1 + 10759200) = 0;
  *(_DWORD *)(a1 + 10759216) = 0;
  *(_DWORD *)(a1 + 10759232) = 0;
  *(_DWORD *)(a1 + 10759248) = 0;
  *(_DWORD *)(a1 + 10759264) = 0;
  *(_DWORD *)(a1 + 10759280) = 0;
  *(_DWORD *)(a1 + 10759296) = 0;
  *(_DWORD *)(a1 + 10759312) = 0;
  *(_DWORD *)(a1 + 10759328) = 0;
  *(_DWORD *)(a1 + 10759344) = 0;
  return result;
}


// ==== sub_7FF91E0066B0 @ rva 0x3A66B0 ====
__int64 __fastcall sub_7FF91E0066B0(__int64 a1)
{
  _QWORD *v1; // rbx
  _DWORD **v2; // rcx
  __int64 result; // rax

  v1 = (_QWORD *)(a1 + 56);
  v2 = *(_DWORD ***)(a1 + 56);
  *v2[4] = 0;
  *v2[9] = 0;
  *v2[14] = 0;
  *v2[19] = 0;
  *v2[24] = 0;
  *v2[29] = 0;
  *v2[34] = 0;
  *v2[39] = 0;
  *v2[44] = 0;
  *v2[49] = 0;
  *v2[54] = 0;
  *v2[59] = 0;
  *v2[64] = 0;
  *v2[69] = 0;
  *v2[74] = 0;
  *v2[79] = 0;
  *v2[84] = 0;
  *v2[89] = 0;
  *v2[94] = 0;
  *v2[99] = 0;
  *v2[104] = 0;
  *v2[109] = 0;
  *v2[114] = 0;
  *v2[119] = 0;
  *v2[124] = 0;
  *v2[129] = 0;
  *v2[134] = 0;
  *v2[139] = 0;
  *v2[144] = 0;
  *v2[149] = 0;
  *v2[154] = 0;
  *v2[159] = 0;
  *v2[164] = 0;
  *v2[169] = 0;
  *v2[174] = 0;
  *v2[179] = 0;
  *v2[184] = 0;
  *v2[189] = 0;
  *v2[194] = 0;
  *v2[199] = 0;
  *v2[204] = 0;
  *v2[209] = 0;
  *v2[214] = 0;
  *v2[219] = 0;
  *v2[224] = 0;
  *v2[229] = 0;
  *v2[234] = 0;
  *v2[239] = 0;
  *v2[244] = 0;
  *v2[249] = 0;
  *v2[254] = 0;
  *v2[259] = 0;
  *v2[264] = 0;
  *v2[269] = 0;
  *v2[274] = 0;
  *v2[279] = 0;
  *v2[284] = 0;
  *v2[289] = 0;
  *v2[294] = 0;
  *v2[299] = 0;
  *v2[304] = 0;
  *v2[309] = 0;
  *v2[314] = 0;
  *v2[319] = 0;
  *v2[324] = 0;
  *v2[329] = 0;
  *v2[334] = 0;
  *v2[339] = 0;
  *v2[344] = 0;
  *v2[349] = 0;
  *v2[354] = 0;
  *v2[359] = 0;
  *v2[364] = 0;
  *v2[369] = 0;
  *v2[374] = 0;
  *v2[379] = 0;
  *v2[384] = 0;
  *v2[389] = 0;
  *v2[394] = 0;
  *v2[399] = 0;
  *v2[404] = 0;
  *v2[409] = 0;
  *v2[414] = 0;
  *v2[419] = 0;
  *v2[424] = 0;
  *v2[429] = 0;
  *v2[434] = 0;
  *v2[439] = 0;
  *v2[444] = 0;
  *v2[449] = 0;
  *v2[454] = 1065353216;
  *v2[459] = 1065353216;
  *v2[464] = 0;
  *v2[469] = 0;
  *v2[474] = 0;
  *v2[479] = 0;
  *v2[484] = 0;
  *v2[489] = 0;
  *v2[494] = 0;
  *v2[499] = 0;
  *v2[504] = 0;
  *v2[509] = 0;
  *v2[514] = 0;
  *v2[519] = 0;
  *v2[524] = 0;
  *v2[529] = 0;
  *v2[534] = 0;
  *v2[539] = 0;
  *v2[544] = 0;
  *v2[549] = 0;
  *v2[554] = 0;
  *v2[559] = 0;
  *v2[564] = 0;
  *v2[569] = 0;
  *v2[574] = 0;
  *v2[579] = 0;
  *v2[584] = 0;
  *v2[589] = 0;
  *v2[594] = 0;
  *v2[599] = 0;
  *v2[604] = 0;
  *v2[609] = 0;
  *v2[614] = 0;
  *v2[619] = 0;
  *v2[624] = 0;
  *v2[629] = 0;
  *v2[634] = 0;
  *v2[639] = 0;
  *v2[644] = 0;
  *v2[649] = 0;
  *v2[654] = 0;
  *v2[659] = 0;
  *v2[664] = 0;
  *v2[669] = 0;
  *v2[674] = 0;
  *v2[679] = 0;
  *v2[684] = 0;
  *v2[689] = 0;
  *v2[694] = 0;
  *v2[699] = 0;
  *v2[704] = 0;
  *v2[709] = 0;
  *v2[714] = 0;
  *v2[719] = 0;
  *v2[724] = 0;
  *v2[729] = 0;
  *v2[734] = 0;
  *v2[739] = 0;
  *v2[744] = 0;
  *v2[749] = 0;
  *v2[754] = 0;
  *v2[759] = 0;
  *v2[764] = 0;
  *v2[769] = 0;
  *v2[774] = 0;
  *v2[779] = 0;
  *v2[784] = 0;
  *v2[789] = 0;
  *v2[794] = 0;
  *v2[799] = 0;
  *v2[804] = 0;
  *v2[809] = 0;
  *v2[814] = 0;
  *v2[819] = 0;
  *v2[824] = 0;
  *v2[829] = 0;
  *v2[834] = 0;
  *v2[839] = 0;
  *v2[844] = 0;
  *v2[849] = 0;
  *v2[854] = 0;
  *v2[859] = 0;
  *v2[864] = 0;
  *v2[869] = 0;
  *v2[874] = 0;
  *v2[879] = 0;
  *v2[884] = 0;
  *v2[889] = 0;
  *v2[894] = 0;
  *v2[899] = 0;
  *v2[904] = 0;
  *v2[909] = 0;
  *v2[914] = 0;
  *v2[919] = 0;
  *v2[924] = 0;
  *v2[929] = 0;
  *v2[934] = 0;
  *v2[939] = 0;
  *v2[944] = 0;
  *v2[949] = 0;
  *v2[954] = 0;
  *v2[959] = 0;
  *v2[964] = 0;
  *v2[969] = 0;
  *v2[974] = 0;
  *v2[979] = 0;
  *v2[984] = 0;
  *v2[989] = 0;
  *v2[994] = 0;
  *v2[999] = 0;
  *v2[1004] = 1065353216;
  *v2[1009] = 1065353216;
  *v2[1014] = 0;
  *v2[1019] = 0;
  *v2[1024] = 0;
  *v2[1029] = 0;
  *v2[1034] = 0;
  *v2[1039] = 0;
  *v2[1044] = 0;
  *v2[1049] = 0;
  *v2[1054] = 0;
  *v2[1059] = 0;
  *v2[1064] = 0;
  *v2[1069] = 0;
  *v2[1074] = 0;
  *v2[1079] = 0;
  *v2[1084] = 0;
  *v2[1089] = 0;
  *v2[1094] = 0;
  *v2[1099] = 0;
  *v2[1104] = 0;
  *v2[1109] = 0;
  *v2[1114] = 0;
  *v2[1119] = 0;
  *v2[1124] = 0;
  *v2[1129] = 0;
  *v2[1134] = 0;
  *v2[1139] = 0;
  *v2[1144] = 0;
  *v2[1149] = 0;
  *v2[1154] = 0;
  *v2[1159] = 0;
  *v2[1164] = 0;
  *v2[1169] = 0;
  *v2[1174] = 0;
  *v2[1179] = 0;
  *v2[1184] = 0;
  *v2[1189] = 0;
  *v2[1194] = 0;
  *v2[1199] = 0;
  *v2[1204] = 0;
  *v2[1209] = 0;
  *v2[1214] = 0;
  *v2[1219] = 0;
  *v2[1224] = 0;
  *v2[1229] = 0;
  *v2[1234] = 0;
  *v2[1239] = 0;
  *v2[1244] = 0;
  *v2[1249] = 0;
  *v2[1254] = 0;
  *v2[1259] = 0;
  *v2[1264] = 0;
  *v2[1269] = 0;
  *v2[1274] = 0;
  *v2[1279] = 0;
  *v2[1284] = 0;
  *v2[1289] = 0;
  *v2[1294] = 0;
  *v2[1299] = 0;
  *v2[1304] = 0;
  *v2[1309] = 0;
  *v2[1314] = 0;
  *v2[1319] = 0;
  *v2[1324] = 0;
  *v2[1329] = 0;
  *v2[1334] = 0;
  *v2[1339] = 0;
  *v2[1344] = 0;
  *v2[1349] = 0;
  *v2[1354] = 0;
  *v2[1359] = 0;
  *v2[1364] = 0;
  *v2[1369] = 0;
  *v2[1374] = 0;
  *v2[1379] = 0;
  *v2[1384] = 0;
  *v2[1389] = 0;
  *v2[1394] = 0;
  *v2[1399] = 0;
  *v2[1404] = 0;
  *v2[1409] = 0;
  *v2[1414] = 0;
  *v2[1419] = 0;
  *v2[1424] = 0;
  *v2[1429] = 0;
  *v2[1434] = 0;
  *v2[1439] = 0;
  *v2[1444] = 0;
  *v2[1449] = 0;
  *v2[1454] = 0;
  *v2[1459] = 0;
  *v2[1464] = 0;
  *v2[1469] = 0;
  *v2[1474] = 0;
  *v2[1479] = 0;
  *v2[1484] = 0;
  *v2[1489] = 0;
  *v2[1494] = 0;
  *v2[1499] = 0;
  *v2[1504] = 0;
  *v2[1509] = 0;
  *v2[1514] = 0;
  *v2[1519] = 0;
  *v2[1524] = 0;
  *v2[1529] = 0;
  *v2[1534] = 0;
  *v2[1539] = 0;
  *v2[1544] = 0;
  *v2[1549] = 0;
  *v2[1554] = 1065353216;
  *v2[1559] = 1065353216;
  *v2[1564] = 0;
  *v2[1569] = 0;
  *v2[1574] = 0;
  *v2[1579] = 0;
  *v2[1584] = 0;
  *v2[1589] = 0;
  *v2[1594] = 0;
  *v2[1599] = 0;
  *v2[1604] = 0;
  *v2[1609] = 0;
  *v2[1614] = 0;
  *v2[1619] = 0;
  *v2[1624] = 0;
  *v2[1629] = 0;
  *v2[1634] = 0;
  *v2[1639] = 0;
  *v2[1644] = 0;
  *v2[1649] = 0;
  *v2[1654] = 0;
  *v2[1659] = 0;
  *v2[1664] = 0;
  *v2[1669] = 0;
  *v2[1674] = 0;
  *v2[1679] = 0;
  *v2[1684] = 0;
  *v2[1689] = 0;
  *v2[1694] = 0;
  *v2[1699] = 0;
  *v2[1704] = 0;
  *v2[1709] = 0;
  *v2[1714] = 0;
  *v2[1719] = 0;
  *v2[1724] = 0;
  *v2[1729] = 0;
  *v2[1734] = 0;
  *v2[1739] = 0;
  *v2[1744] = 0;
  *v2[1749] = 0;
  *v2[1754] = 0;
  *v2[1759] = 0;
  *v2[1764] = 0;
  *v2[1769] = 0;
  *v2[1774] = 0;
  *v2[1779] = 0;
  *v2[1784] = 0;
  *v2[1789] = 0;
  *v2[1794] = 0;
  *v2[1799] = 0;
  *v2[1804] = 0;
  *v2[1809] = 0;
  *v2[1814] = 0;
  *v2[1819] = 0;
  *v2[1824] = 0;
  *v2[1829] = 0;
  *v2[1834] = 0;
  *v2[1839] = 0;
  *v2[1844] = 0;
  *v2[1849] = 0;
  *v2[1854] = 0;
  *v2[1859] = 0;
  *v2[1864] = 0;
  *v2[1869] = 0;
  *v2[1874] = 0;
  *v2[1879] = 0;
  *v2[1884] = 0;
  *v2[1889] = 0;
  *v2[1894] = 0;
  *v2[1899] = 0;
  *v2[1904] = 0;
  *v2[1909] = 0;
  *v2[1914] = 0;
  *v2[1919] = 0;
  *v2[1924] = 0;
  *v2[1929] = 0;
  *v2[1934] = 0;
  *v2[1939] = 0;
  *v2[1944] = 0;
  *v2[1949] = 0;
  *v2[1954] = 0;
  *v2[1959] = 0;
  *v2[1964] = 0;
  *v2[1969] = 0;
  *v2[1974] = 0;
  *v2[1979] = 0;
  *v2[1984] = 0;
  *v2[1989] = 0;
  *v2[1994] = 0;
  *v2[1999] = 0;
  *v2[2004] = 0;
  *v2[2009] = 0;
  *v2[2014] = 0;
  *v2[2019] = 0;
  *v2[2024] = 0;
  *v2[2029] = 0;
  *v2[2034] = 0;
  *v2[2039] = 0;
  *v2[2044] = 0;
  *v2[2049] = 0;
  *v2[2054] = 0;
  *v2[2059] = 0;
  *v2[2064] = 0;
  *v2[2069] = 0;
  *v2[2074] = 0;
  *v2[2079] = 0;
  *v2[2084] = 0;
  *v2[2089] = 0;
  *v2[2094] = 0;
  *v2[2099] = 0;
  *v2[2104] = 1065353216;
  *v2[2109] = 1065353216;
  *v2[2114] = 0;
  *v2[2119] = 0;
  *v2[2124] = 0;
  *v2[2129] = 0;
  *v2[2134] = 0;
  *v2[2139] = 0;
  *v2[2144] = 0;
  *v2[2149] = 0;
  *v2[2154] = 0;
  *v2[2159] = 0;
  *v2[2164] = 0;
  *v2[2169] = 0;
  *v2[2174] = 0;
  *v2[2179] = 0;
  *v2[2184] = 0;
  *v2[2189] = 0;
  *v2[2194] = 0;
  *v2[2199] = 0;
  *v2[2204] = 0;
  *v2[2209] = 0;
  *v2[2214] = 0;
  *v2[2219] = 0;
  *v2[2224] = 0;
  *v2[2229] = 0;
  *v2[2234] = 0;
  *v2[2239] = 0;
  *v2[2244] = 0;
  *v2[2249] = 0;
  *v2[2254] = 0;
  *v2[2259] = 0;
  *v2[2264] = 0;
  *v2[2269] = 0;
  *v2[2274] = 0;
  *v2[2279] = 0;
  *v2[2284] = 0;
  *v2[2289] = 0;
  *v2[2294] = 0;
  *v2[2299] = 0;
  *v2[2304] = 0;
  *v2[2309] = 0;
  *v2[2314] = 0;
  *v2[2319] = 0;
  *v2[2324] = 0;
  *v2[2329] = 0;
  *v2[2334] = 0;
  *v2[2339] = 0;
  *v2[2344] = 0;
  *v2[2349] = 0;
  *v2[2354] = 0;
  *v2[2359] = 0;
  *v2[2364] = 0;
  *v2[2369] = 0;
  *v2[2374] = 0;
  *v2[2379] = 0;
  *v2[2384] = 0;
  *v2[2389] = 0;
  *v2[2394] = 0;
  *v2[2399] = 0;
  *v2[2404] = 0;
  *v2[2409] = 0;
  *v2[2414] = 0;
  *v2[2419] = 0;
  *v2[2424] = 0;
  *v2[2429] = 0;
  *v2[2434] = 0;
  *v2[2439] = 0;
  *v2[2444] = 0;
  *v2[2449] = 0;
  *v2[2454] = 0;
  *v2[2459] = 0;
  *v2[2464] = 0;
  *v2[2469] = 0;
  *v2[2474] = 0;
  *v2[2479] = 0;
  *v2[2484] = 0;
  *v2[2489] = 0;
  *v2[2494] = 0;
  *v2[2499] = 0;
  *v2[2504] = 0;
  *v2[2509] = 0;
  *v2[2514] = 0;
  *v2[2519] = 0;
  *v2[2524] = 0;
  *v2[2529] = 0;
  *v2[2534] = 0;
  *v2[2539] = 0;
  *v2[2544] = 0;
  *v2[2549] = 0;
  *v2[2554] = 0;
  *v2[2559] = 0;
  *v2[2564] = 0;
  *v2[2569] = 0;
  *v2[2574] = 0;
  *v2[2579] = 0;
  *v2[2584] = 0;
  *v2[2589] = 0;
  *v2[2594] = 0;
  *v2[2599] = 0;
  *v2[2604] = 0;
  *v2[2609] = 0;
  *v2[2614] = 0;
  *v2[2619] = 0;
  *v2[2624] = 0;
  *v2[2629] = 0;
  *v2[2634] = 0;
  *v2[2639] = 0;
  *v2[2644] = 0;
  *v2[2649] = 0;
  *v2[2654] = 1065353216;
  *v2[2659] = 1065353216;
  *v2[2664] = 0;
  *v2[2669] = 0;
  *v2[2674] = 0;
  *v2[2679] = 0;
  *v2[2684] = 0;
  *v2[2689] = 0;
  *v2[2694] = 0;
  *v2[2699] = 0;
  *v2[2704] = 0;
  *v2[2709] = 0;
  *v2[2714] = 0;
  *v2[2719] = 0;
  *v2[2724] = 0;
  *v2[2729] = 0;
  *v2[2734] = 0;
  *v2[2739] = 0;
  *v2[2744] = 0;
  *v2[2749] = 0;
  *v2[2754] = 0;
  *v2[2759] = 0;
  *v2[2764] = 0;
  *v2[2769] = 0;
  *v2[2774] = 0;
  *v2[2779] = 0;
  *v2[2784] = 0;
  *v2[2789] = 0;
  *v2[2794] = 0;
  *v2[2799] = 0;
  *v2[2804] = 0;
  *v2[2809] = 0;
  *v2[2814] = 0;
  *v2[2819] = 0;
  *v2[2824] = 0;
  *v2[2829] = 0;
  *v2[2834] = 0;
  *v2[2839] = 0;
  *v2[2844] = 0;
  *v2[2849] = 0;
  *v2[2854] = 0;
  *v2[2859] = 0;
  *v2[2864] = 0;
  *v2[2869] = 0;
  *v2[2874] = 0;
  *v2[2879] = 0;
  *v2[2884] = 0;
  *v2[2889] = 0;
  *v2[2894] = 0;
  *v2[2899] = 0;
  *v2[2904] = 0;
  *v2[2909] = 0;
  *v2[2914] = 0;
  *v2[2919] = 0;
  *v2[2924] = 0;
  *v2[2929] = 0;
  *v2[2934] = 0;
  *v2[2939] = 0;
  *v2[2944] = 0;
  *v2[2949] = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 590) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 591) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 592) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 593) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 594) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 595) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 596) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 597) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 598) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 599) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 600) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 601) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 602) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 603) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 604) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 605) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 606) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 607) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 608) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 609) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 610) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 611) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 612) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 613) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 614) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 615) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 616) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 617) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 618) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 619) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 620) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 621) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 622) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 623) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 624) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 625) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 626) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 627) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 628) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 629) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 630) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 631) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 632) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 633) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 634) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 635) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 636) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 637) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 638) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 639) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 640) + 32) = 1065353216;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 641) + 32) = 1065353216;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 642) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 643) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 644) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 645) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 646) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 647) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 648) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 649) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 650) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 651) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 652) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 653) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 654) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 655) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 656) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 657) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 658) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 659) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 660) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 661) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 662) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 663) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 664) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 665) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 666) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 667) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 668) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 669) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 670) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 671) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 672) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 673) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 674) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 675) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 676) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 677) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 678) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 679) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 680) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 681) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 682) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 683) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 684) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 685) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 686) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 687) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 688) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 689) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 690) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 691) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 692) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 693) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 694) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 695) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 696) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 697) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 698) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 699) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 700) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 701) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 702) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 703) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 704) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 705) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 706) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 707) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 708) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 709) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 710) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 711) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 712) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 713) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 714) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 715) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 716) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 717) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 718) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 719) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 720) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 721) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 722) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 723) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 724) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 725) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 726) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 727) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 728) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 729) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 730) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 731) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 732) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 733) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 734) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 735) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 736) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 737) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 738) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 739) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 740) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 741) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 742) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 743) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 744) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 745) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 746) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 747) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 748) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 749) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 750) + 32) = 1065353216;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 751) + 32) = 1065353216;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 752) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 753) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 754) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 755) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 756) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 757) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 758) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 759) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 760) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 761) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 762) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 763) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 764) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 765) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 766) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 767) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 768) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 769) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 770) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 771) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 772) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 773) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 774) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 775) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 776) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 777) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 778) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 779) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 780) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 781) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 782) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 783) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 784) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 785) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 786) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 787) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 788) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 789) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 790) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 791) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 792) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 793) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 794) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 795) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 796) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 797) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 798) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 799) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 800) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 801) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 802) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 803) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 804) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 805) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 806) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 807) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 808) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 809) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 810) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 811) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 812) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 813) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 814) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 815) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 816) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 817) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 818) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 819) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 820) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 821) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 822) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 823) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 824) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 825) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 826) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 827) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 828) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 829) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 830) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 831) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 832) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 833) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 834) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 835) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 836) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 837) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 838) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 839) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 840) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 841) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 842) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 843) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 844) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 845) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 846) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 847) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 848) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 849) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 850) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 851) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 852) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 853) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 854) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 855) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 856) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 857) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 858) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 859) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 860) + 32) = 1065353216;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 861) + 32) = 1065353216;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 862) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 863) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 864) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 865) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 866) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 867) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 868) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 869) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 870) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 871) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 872) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 873) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 874) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 875) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 876) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 877) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 878) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 879) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 880) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 881) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 882) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 883) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 884) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 885) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 886) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 887) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 888) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 889) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 890) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 891) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 892) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 893) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 894) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 895) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 896) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 897) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 898) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 899) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 900) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 901) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 902) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 903) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 904) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 905) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 906) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 907) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 908) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 909) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 910) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 911) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 912) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 913) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 914) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 915) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 916) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 917) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 918) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 919) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 920) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 921) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 922) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 923) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 924) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 925) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 926) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 927) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 928) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 929) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 930) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 931) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 932) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 933) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 934) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 935) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 936) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 937) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 938) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 939) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 940) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 941) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 942) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 943) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 944) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 945) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 946) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 947) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 948) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 949) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 950) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 951) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 952) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 953) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 954) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 955) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 956) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 957) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 958) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 959) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 960) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 961) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 962) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 963) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 964) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 965) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 966) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 967) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 968) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 969) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 970) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 971) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 972) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 973) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 974) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 975) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 976) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 977) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 978) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 979) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 980) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 981) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 982) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 983) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 984) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 985) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 986) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 987) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 988) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 989) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 990) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 991) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 992) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 993) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 994) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 995) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 996) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 997) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 998) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 999) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1000) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1001) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1002) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1003) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1004) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1005) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1006) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1007) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1008) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1009) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1010) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1011) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1012) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1013) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1014) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1015) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1016) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1017) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1018) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1019) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1020) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1021) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1022) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1023) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1024) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1025) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1026) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1027) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1028) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1029) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1030) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1031) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1032) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1033) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1034) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1035) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1036) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1037) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1038) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1039) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1040) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1041) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1042) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1043) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1044) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1045) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1046) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1047) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1048) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1049) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1050) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1051) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1052) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1053) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1054) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1055) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1056) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1057) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1058) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1059) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1060) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1061) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1062) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1063) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1064) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1065) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1066) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1067) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1068) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1069) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1070) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1071) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1072) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1073) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1074) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1075) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1076) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1077) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1078) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1079) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1080) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1081) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1082) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1083) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1084) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1085) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1086) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1087) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1088) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1089) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1090) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1091) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1092) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1093) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1094) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1095) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1096) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1097) + 32) = 1023410176;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1098) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1099) + 32) = 934159952;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1100) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1101) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1102) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1103) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1104) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1105) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1106) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1107) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1108) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1109) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1110) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1111) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1112) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1113) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1114) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1115) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1116) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1117) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1118) + 32) = 0;
  **(_DWORD **)(sub_7FF91DFE8120(v1, 1119) + 32) = 0;
  result = sub_7FF91DFE8120(v1, 1120);
  **(_DWORD **)(result + 32) = 1059706880;
  return result;
}


// ==== sub_7FF91E00B470 @ rva 0x3AB470 ====
__int64 __fastcall sub_7FF91E00B470(__int64 a1)
{
  __int64 result; // rax

  result = *(unsigned int *)(a1 + 160);
  if ( (int)result > 0 )
  {
    **(_DWORD **)(*(_QWORD *)(a1 + 136) + 16LL) = 0;
    result = *(unsigned int *)(a1 + 160);
  }
  if ( (int)result > 1 )
  {
    **(_DWORD **)(*(_QWORD *)(a1 + 136) + 40LL) = 0;
    result = *(unsigned int *)(a1 + 160);
  }
  if ( (int)result > 2 )
  {
    **(_DWORD **)(*(_QWORD *)(a1 + 136) + 64LL) = 0;
    result = *(unsigned int *)(a1 + 160);
  }
  if ( (int)result > 3 )
  {
    **(_DWORD **)(*(_QWORD *)(a1 + 136) + 88LL) = 0;
    result = *(unsigned int *)(a1 + 160);
  }
  if ( (int)result > 4 )
  {
    **(_DWORD **)(*(_QWORD *)(a1 + 136) + 112LL) = 0;
    result = *(unsigned int *)(a1 + 160);
  }
  if ( (int)result > 5 )
  {
    result = *(_QWORD *)(a1 + 136);
    **(_DWORD **)(result + 136) = 0;
  }
  return result;
}


// ==== sub_7FF91E00B520 @ rva 0x3AB520 ====
__int64 __fastcall sub_7FF91E00B520(_DWORD *a1)
{
  __int64 result; // rax
  _DWORD *v2; // rdi
  __int64 i; // rcx

  result = 0;
  v2 = a1 + 2689972;
  a1[2689968] = 0;
  a1[2689964] = 0;
  a1[2755508] = 0;
  for ( i = 0x10000; i; --i )
    *v2++ = 0;
  return result;
}


// ==== nullsub_977 @ rva 0x3AB550 ====
void nullsub_977()
{
  ;
}


// ==== sub_7FF91E00B560 @ rva 0x3AB560 ====
__int64 __fastcall sub_7FF91E00B560(__int64 a1, int a2, int a3)
{
  *(_DWORD *)(a1 + 4LL * a2 + 11022208) = a3;
  return a2;
}


// ==== sub_7FF91E00B570 @ rva 0x3AB570 ====
char sub_7FF91E00B570()
{
  return 0;
}


// ==== sub_7FF91E00B580 @ rva 0x3AB580 ====
__int64 __fastcall sub_7FF91E00B580(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  _QWORD *v6; // rcx

  v6 = *(_QWORD **)a1;
  if ( v6 )
  {
    if ( (unsigned __int64)(40 * ((*(_QWORD *)(a1 + 16) - (_QWORD)v6) / 40LL)) >= 0x1000 )
    {
      if ( (unsigned __int64)v6 - *(v6 - 1) - 8 > 0x1F )
        invalid_parameter_noinfo_noreturn();
      v6 = (_QWORD *)*(v6 - 1);
    }
    j_j_free(v6);
  }
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = a2 + 40 * a3;
  *(_QWORD *)(a1 + 16) = a2 + 40 * a4;
  return 5 * a4;
}


// ==== sub_7FF91E00B630 @ rva 0x3AB630 ====
__int64 __fastcall sub_7FF91E00B630(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  _QWORD *v6; // rcx

  v6 = *(_QWORD **)a1;
  if ( v6 )
  {
    if ( (unsigned __int64)(24 * ((*(_QWORD *)(a1 + 16) - (_QWORD)v6) / 24LL)) >= 0x1000 )
    {
      if ( (unsigned __int64)v6 - *(v6 - 1) - 8 > 0x1F )
        invalid_parameter_noinfo_noreturn();
      v6 = (_QWORD *)*(v6 - 1);
    }
    j_j_free(v6);
  }
  *(_QWORD *)a1 = a2;
  *(_QWORD *)(a1 + 8) = a2 + 24 * a3;
  *(_QWORD *)(a1 + 16) = a2 + 24 * a4;
  return 3 * a4;
}


// ==== sub_7FF91E00B6E0 @ rva 0x3AB6E0 ====
__int64 __fastcall sub_7FF91E00B6E0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91E00B6F0 @ rva 0x3AB6F0 ====
__int64 __fastcall sub_7FF91E00B6F0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91E00B700 @ rva 0x3AB700 ====
__int64 __fastcall sub_7FF91E00B700(_QWORD *a1, __int64 a2)
{
  __int64 v4; // rdi
  __int64 v5; // rsi

  v4 = (a1[1] - *a1) / 40LL;
  v5 = sub_7FF91E00B860(a1, a2);
  sub_7FF91E30DC00(v5, *a1, a1[1] - *a1);
  return sub_7FF91E00B580((__int64)a1, v5, v4, a2);
}


// ==== sub_7FF91E00B790 @ rva 0x3AB790 ====
__int64 __fastcall sub_7FF91E00B790(_QWORD *a1, __int64 a2)
{
  __int64 v4; // rdi
  __int64 v5; // rsi

  v4 = (a1[1] - *a1) / 24LL;
  v5 = sub_7FF91E00B8E0(a1, a2);
  sub_7FF91E30DC00(v5, *a1, a1[1] - *a1);
  return sub_7FF91E00B630((__int64)a1, v5, v4, a2);
}


// ==== ?_Xlen@?$vector@PEAXV?$allocator@PEAX@std@@@std@@IEBAXXZ_85 @ rva 0x3AB820 ====
void __noreturn std::vector<void *>::_Xlen()
{
  sub_7FF91E2A81A4("vector<T> too long");
}


// ==== ?_Xlen@?$vector@PEAXV?$allocator@PEAX@std@@@std@@IEBAXXZ_86 @ rva 0x3AB840 ====
void __noreturn std::vector<void *>::_Xlen()
{
  sub_7FF91E2A81A4("vector<T> too long");
}


// ==== sub_7FF91E00B860 @ rva 0x3AB860 ====
unsigned __int64 __fastcall sub_7FF91E00B860(__int64 a1, unsigned __int64 a2)
{
  unsigned __int64 result; // rax
  size_t v3; // rcx
  void *v4; // rax
  void *v5; // rcx

  result = 40 * a2;
  if ( a2 > 0x666666666666666LL )
  {
    result = -1;
LABEL_4:
    v3 = result + 39;
    if ( result + 39 < result )
      v3 = -1;
    v4 = operator new(v3);
    v5 = v4;
    if ( !v4 )
      invalid_parameter_noinfo_noreturn();
    result = ((unsigned __int64)v4 + 39) & 0xFFFFFFFFFFFFFFE0uLL;
    *(_QWORD *)(result - 8) = v5;
    return result;
  }
  if ( result >= 0x1000 )
    goto LABEL_4;
  if ( result )
    return (unsigned __int64)operator new(40 * a2);
  return result;
}


// ==== sub_7FF91E00B8E0 @ rva 0x3AB8E0 ====
unsigned __int64 __fastcall sub_7FF91E00B8E0(__int64 a1, unsigned __int64 a2)
{
  unsigned __int64 result; // rax
  size_t v3; // rcx
  void *v4; // rax
  void *v5; // rcx

  result = 24 * a2;
  if ( a2 > 0xAAAAAAAAAAAAAAALL )
  {
    result = -1;
LABEL_4:
    v3 = result + 39;
    if ( result + 39 < result )
      v3 = -1;
    v4 = operator new(v3);
    v5 = v4;
    if ( !v4 )
      invalid_parameter_noinfo_noreturn();
    result = ((unsigned __int64)v4 + 39) & 0xFFFFFFFFFFFFFFE0uLL;
    *(_QWORD *)(result - 8) = v5;
    return result;
  }
  if ( result >= 0x1000 )
    goto LABEL_4;
  if ( result )
    return (unsigned __int64)operator new(24 * a2);
  return result;
}


// ==== sub_7FF91E00B960 @ rva 0x3AB960 ====
void __fastcall sub_7FF91E00B960(__int64 a1, void *a2, __int64 a3)
{
  void *v3; // rax

  v3 = a2;
  if ( (unsigned __int64)(40 * a3) >= 0x1000 )
  {
    if ( (unsigned __int64)a2 - *((_QWORD *)a2 - 1) - 8 > 0x1F )
      invalid_parameter_noinfo_noreturn();
    v3 = *((void **)a2 - 1);
  }
  j_j_free(v3);
}


// ==== sub_7FF91E00B9B0 @ rva 0x3AB9B0 ====
void __fastcall sub_7FF91E00B9B0(__int64 a1, void *a2, __int64 a3)
{
  void *v3; // rax

  v3 = a2;
  if ( (unsigned __int64)(24 * a3) >= 0x1000 )
  {
    if ( (unsigned __int64)a2 - *((_QWORD *)a2 - 1) - 8 > 0x1F )
      invalid_parameter_noinfo_noreturn();
    v3 = *((void **)a2 - 1);
  }
  j_j_free(v3);
}


// ==== sub_7FF91E00BA00 @ rva 0x3ABA00 ====
__int64 __fastcall sub_7FF91E00BA00(__int64 a1, __int64 a2)
{
  __int64 v3; // rdx
  __int64 result; // rax

  v3 = *(_QWORD *)(a1 + 8);
  if ( *(_QWORD *)(a1 + 16) == v3 )
    return sub_7FF91DFE7F80(a1, v3, a2);
  *(_OWORD *)v3 = *(_OWORD *)a2;
  *(_OWORD *)(v3 + 16) = *(_OWORD *)(a2 + 16);
  *(_QWORD *)(v3 + 32) = *(_QWORD *)(a2 + 32);
  *(_QWORD *)(a1 + 8) += 40LL;
  return result;
}


// ==== sub_7FF91E00BA40 @ rva 0x3ABA40 ====
__int64 __fastcall sub_7FF91E00BA40(__int64 *a1, __int64 a2)
{
  __int64 v3; // rdx
  __int64 result; // rax

  v3 = a1[1];
  if ( a1[2] == v3 )
    return sub_7FF91DFE7CB0(a1, v3, a2);
  *(_OWORD *)v3 = *(_OWORD *)a2;
  *(_OWORD *)(v3 + 16) = *(_OWORD *)(a2 + 16);
  *(_QWORD *)(v3 + 32) = *(_QWORD *)(a2 + 32);
  a1[1] += 40;
  return result;
}


// ==== sub_7FF91E00BA80 @ rva 0x3ABA80 ====
__int64 __fastcall sub_7FF91E00BA80(_QWORD *a1)
{
  return (a1[1] - *a1) / 40LL;
}


// ==== sub_7FF91E00BAF0 @ rva 0x3ABAF0 ====
char *__fastcall sub_7FF91E00BAF0(int a1)
{
  return (char *)&unk_7FF91E5EC040 + 16 * a1;
}


// ==== sub_7FF91E00BB10 @ rva 0x3ABB10 ====
__int64 sub_7FF91E00BB10()
{
  return 0;
}


// ==== sub_7FF91E00BB40 @ rva 0x3ABB40 ====
const char *__fastcall sub_7FF91E00BB40(int a1, unsigned int a2)
{
  if ( a1 >= 4966 )
    return "ERR:PrmDbStr";
  sub_7FF91E00BAF0(a1);
  if ( sub_7FF91E00BAF0(a1)[12] )
    return (const char *)sub_7FF91E00C120((unsigned int)a1, a2);
  else
    return (const char *)sub_7FF91E00BBA0((unsigned int)a1, a2);
}


// ==== sub_7FF91E00BBA0 @ rva 0x3ABBA0 ====
int *__fastcall sub_7FF91E00BBA0(int a1, int a2)
{
  __int64 v2; // rdi
  char *v4; // rax
  char *v5; // r13
  __int64 v6; // rcx
  int v7; // ebx
  __int64 v8; // rdx
  const char *v9; // rdi
  char v10; // al
  signed __int64 v11; // rcx
  unsigned int v12; // eax
  char v13; // al
  int v14; // r14d
  char *v15; // rax
  int v16; // edx
  int v17; // esi
  __int64 v18; // rax
  int v19; // eax
  char *v20; // rdi
  signed int v21; // r15d
  int v22; // edx
  char v23; // al
  int v24; // eax
  int i; // eax
  unsigned int v26; // eax
  unsigned int v27; // r14d
  __int64 v28; // rcx
  char *v29; // rcx
  bool v30; // zf
  char *v31; // rcx
  int v32; // r15d
  char v33; // al
  char v34; // al
  int v35; // esi
  int v36; // r9d
  int v37; // r8d
  int *v38; // rdx
  char v39; // al
  int v40; // eax
  char *v41; // rdi
  signed int v42; // r13d
  int v43; // edx
  char v44; // al
  int v45; // eax
  int j; // eax
  unsigned int v47; // eax
  unsigned int v48; // r14d
  __int64 v49; // rcx
  char *v50; // rcx
  char *v51; // rdx
  __int64 v52; // rdi
  char v53; // cl
  char v55[16]; // [rsp+20h] [rbp-58h] BYREF

  v2 = a1;
  v4 = sub_7FF91E00BAF0(a1);
  v5 = v4;
  *(_QWORD *)v55 = v4;
  if ( a2 >= *(_DWORD *)v4 && a2 <= *((_DWORD *)v4 + 1) )
  {
    v6 = 2 * v2;
    v7 = 0;
    v8 = 0;
    v9 = (&off_7FF91E609B60)[2 * v2 + 1];
    while ( 1 )
    {
      v10 = (&off_7FF91E609B60)[v6][v8++];
      if ( v10 != aAscii[v8 - 1] )
        break;
      if ( v8 == 8 )
      {
        sub_7FF91DF6F020((int)&byte_7FF91E910DD0, (int)"%c", (unsigned int)(char)a2);
        return &byte_7FF91E910DD0;
      }
    }
    if ( strchr(v9, 2) )
    {
      v14 = 1;
      v15 = strchr(v9, 1);
      v16 = 0;
      if ( !v15 )
      {
        v17 = -1;
        v18 = *(unsigned __int8 *)v9;
        if ( *v9 != 2 )
        {
          v11 = (signed __int64)&byte_7FF91E910DD0;
          do
          {
            ++v9;
            if ( (_BYTE)v18 == 46 )
            {
              v17 = 0;
            }
            else
            {
              *(_BYTE *)v11 = v18;
              ++v16;
              v19 = v17 + 1;
              ++v11;
              if ( v17 < 0 )
                v19 = v17;
              v17 = v19;
            }
            LOBYTE(v18) = *v9;
          }
          while ( *v9 != 2 );
        }
        if ( (unsigned __int64)v16 < 0x20 )
        {
          *((_BYTE *)&byte_7FF91E910DD0 + v16) = 0;
          v20 = (char *)(v9 + 1);
          v21 = unknown_libname_7349(&byte_7FF91E910DD0);
          v22 = 0;
          v23 = *v20;
          if ( *v20 )
          {
            v11 = (signed __int64)&byte_7FF91E910DD0;
            do
            {
              ++v20;
              if ( v23 != 46 )
              {
                ++v22;
                *(_BYTE *)v11++ = v23;
              }
              v23 = *v20;
            }
            while ( *v20 );
          }
          if ( (unsigned __int64)v22 < 0x20 )
          {
            *((_BYTE *)&byte_7FF91E910DD0 + v22) = 0;
            v24 = unknown_libname_7349(&byte_7FF91E910DD0) - v21;
            if ( *((_DWORD *)v5 + 1) - *(_DWORD *)v5 > 0 )
              v21 += (a2 - *(_DWORD *)v5) * v24 / (*((_DWORD *)v5 + 1) - *(_DWORD *)v5);
            if ( v17 >= 0 )
            {
              for ( i = v17; i; --i )
                v14 *= 10;
              v26 = v21 / v14;
              v27 = v21 % v14;
              LODWORD(v28) = v27;
              do
              {
                --v17;
                v28 = (unsigned int)((int)v28 / 10);
              }
              while ( (_DWORD)v28 );
              if ( v17 )
              {
                v7 = v17;
                memset(v55, 48, (unsigned int)v17);
                v28 = 0;
              }
              if ( (unsigned __int64)v7 >= 0x10 )
                _report_rangecheckfailure_0(v28);
              v55[v7] = 0;
              sub_7FF91DF6F020((int)&byte_7FF91E910DD0, (int)"%d.", v26);
              v29 = (char *)&byte_7FF91E910DD0 - 1;
              do
                v30 = *++v29 == 0;
              while ( !v30 );
              strcpy(v29, v55);
              sub_7FF91DF6F020((int)v55, (int)"%d", v27);
              v31 = (char *)&byte_7FF91E910DD0 - 1;
              do
                v30 = *++v31 == 0;
              while ( !v30 );
              strcpy(v31, v55);
            }
            else
            {
              sub_7FF91DF6F020((int)&byte_7FF91E910DD0, (int)"%d", (unsigned int)v21);
            }
            return &byte_7FF91E910DD0;
          }
        }
LABEL_100:
        _report_rangecheckfailure_0(v11);
      }
      v32 = 0;
      if ( a2 )
      {
        v11 = 0;
        do
        {
          v33 = *v9;
          if ( *v9 == 2 )
            break;
          if ( v33 == 1 )
          {
            v16 = 0;
            v11 = 0;
            ++v32;
          }
          else
          {
            ++v16;
            *((_BYTE *)&byte_7FF91E910DD0 + v11++) = v33;
          }
          ++v9;
        }
        while ( v32 != a2 );
      }
      if ( (unsigned __int64)v16 >= 0x20 )
        goto LABEL_100;
      *((_BYTE *)&byte_7FF91E910DD0 + v16) = 0;
      if ( v32 != a2 )
      {
        v35 = -1;
        v36 = 0;
        v37 = 0;
        if ( (_BYTE)byte_7FF91E910DD0 )
        {
          v11 = 0;
          v38 = &byte_7FF91E910DD0;
          do
          {
            v39 = *((_BYTE *)&byte_7FF91E910DD0 + v11);
            ++v36;
            ++v11;
            if ( v39 == 46 )
            {
              v35 = 0;
            }
            else
            {
              *(_BYTE *)v38 = v39;
              ++v37;
              v40 = v35 + 1;
              v38 = (int *)((char *)v38 + 1);
              if ( v35 < 0 )
                v40 = v35;
              v35 = v40;
            }
          }
          while ( *((_BYTE *)&byte_7FF91E910DD0 + v11) );
        }
        if ( (unsigned __int64)v37 < 0x20 )
        {
          *((_BYTE *)&byte_7FF91E910DD0 + v37) = 0;
          v41 = (char *)(v9 + 1);
          v42 = unknown_libname_7349(&byte_7FF91E910DD0);
          v43 = 0;
          v44 = *v41;
          if ( *v41 )
          {
            v11 = (signed __int64)&byte_7FF91E910DD0;
            do
            {
              ++v41;
              if ( v44 != 46 )
              {
                ++v43;
                *(_BYTE *)v11++ = v44;
              }
              v44 = *v41;
            }
            while ( *v41 );
          }
          if ( (unsigned __int64)v43 < 0x20 )
          {
            *((_BYTE *)&byte_7FF91E910DD0 + v43) = 0;
            v45 = unknown_libname_7349(&byte_7FF91E910DD0) - v42;
            if ( *(_DWORD *)(*(_QWORD *)v55 + 4LL) - **(_DWORD **)v55 - v32 > 0 )
              v42 += (a2 - **(_DWORD **)v55 - v32) * v45 / (*(_DWORD *)(*(_QWORD *)v55 + 4LL) - **(_DWORD **)v55 - v32);
            if ( v35 >= 0 )
            {
              for ( j = v35; j; --j )
                v14 *= 10;
              v47 = v42 / v14;
              v48 = v42 % v14;
              LODWORD(v49) = v48;
              do
              {
                --v35;
                v49 = (unsigned int)((int)v49 / 10);
              }
              while ( (_DWORD)v49 );
              if ( v35 )
              {
                v7 = v35;
                memset(v55, 48, (unsigned int)v35);
                v49 = 0;
              }
              if ( (unsigned __int64)v7 >= 0x10 )
                _report_rangecheckfailure_0(v49);
              v55[v7] = 0;
              sub_7FF91DF6F020((int)&byte_7FF91E910DD0, (int)"%d.", v47);
              v50 = (char *)&byte_7FF91E910DD0 - 1;
              do
                v30 = *++v50 == 0;
              while ( !v30 );
              strcpy(v50, v55);
              sub_7FF91DF6F020((int)v55, (int)"%d", v48);
              v51 = (char *)&byte_7FF91E910DD0 - 1;
              do
                v30 = *++v51 == 0;
              while ( !v30 );
              v52 = 0;
              do
              {
                v53 = v55[v52];
                v51[v52++] = v53;
              }
              while ( v53 );
            }
            else
            {
              sub_7FF91DF6F020((int)&byte_7FF91E910DD0, (int)"%d", (unsigned int)v42);
            }
            return &byte_7FF91E910DD0;
          }
        }
        goto LABEL_100;
      }
      v34 = *v9;
      if ( *v9 != 1 )
      {
        v11 = (signed __int64)&byte_7FF91E910DD0;
        do
        {
          if ( (v34 & 0xFD) == 0 )
            break;
          ++v9;
          *(_BYTE *)v11 = v34;
          ++v7;
          ++v11;
          v34 = *v9;
        }
        while ( *v9 != 1 );
      }
    }
    else
    {
      v11 = 0;
      if ( a2 )
      {
        do
        {
          v12 = v11 + 1;
          if ( *v9 != 1 )
            v12 = v11;
          ++v9;
          v11 = v12;
        }
        while ( v12 != a2 );
      }
      v13 = *v9;
      if ( *v9 != 1 )
      {
        v11 = (char *)&byte_7FF91E910DD0 - v9;
        do
        {
          if ( !v13 )
            break;
          v9[v11] = v13;
          ++v7;
          v13 = *++v9;
        }
        while ( v13 != 1 );
      }
    }
    if ( (unsigned __int64)v7 < 0x20 )
    {
      *((_BYTE *)&byte_7FF91E910DD0 + v7) = 0;
      return &byte_7FF91E910DD0;
    }
    goto LABEL_100;
  }
  return (int *)"ERR:PrmDbStr";
}


// ==== sub_7FF91E00C120 @ rva 0x3AC120 ====
int *__fastcall sub_7FF91E00C120(int a1, unsigned int a2)
{
  __int64 v2; // rdi
  __int64 v3; // r12
  char *v4; // rax
  char *v5; // r13
  unsigned __int8 *v6; // rdi
  unsigned int v7; // esi
  char *v8; // rax
  signed __int64 v9; // rcx
  __int64 v10; // r9
  int v11; // ebp
  int v12; // edx
  __int64 v13; // rax
  int v14; // ebx
  int v15; // eax
  int v16; // eax
  unsigned __int8 *v17; // rdi
  __int64 v18; // r9
  int *v19; // rdx
  unsigned int v20; // ecx
  int j; // eax
  unsigned int v22; // eax
  unsigned int v23; // esi
  __int64 v24; // rcx
  char *v25; // rcx
  bool v26; // zf
  char *v27; // rcx
  int v28; // r15d
  __int64 v29; // rax
  char v30; // al
  int v31; // ebx
  __int64 v32; // r9
  int v33; // r8d
  int *v34; // rdx
  char v35; // al
  int v36; // eax
  int v37; // eax
  __int64 v38; // r9
  unsigned __int8 *v39; // rdi
  int v40; // r8d
  int *v41; // rdx
  int i; // eax
  unsigned int v43; // eax
  unsigned int v44; // esi
  __int64 v45; // rcx
  char *v46; // rcx
  char *v47; // rax
  __int64 v48; // rdx
  char v49; // cl
  char v51[16]; // [rsp+20h] [rbp-58h] BYREF

  v2 = a1;
  v3 = a2;
  v4 = sub_7FF91E00BAF0(a1);
  v5 = v4;
  *(_QWORD *)v51 = v4;
  if ( (unsigned int)v3 >= *(_DWORD *)v4 && (unsigned int)v3 <= *((_DWORD *)v4 + 1) )
  {
    v6 = (unsigned __int8 *)*(&off_7FF91E609B68 + 2 * v2);
    if ( strchr((const char *)v6, 2) )
    {
      v7 = 1;
      v8 = strchr((const char *)v6, 1);
      v11 = 0;
      v12 = 0;
      if ( v8 )
      {
        v28 = 0;
        if ( (_DWORD)v3 )
        {
          v29 = 0;
          do
          {
            v9 = *v6;
            if ( (_BYTE)v9 == 2 )
              break;
            if ( (_BYTE)v9 == 1 )
            {
              v12 = 0;
              v29 = 0;
              ++v28;
            }
            else
            {
              ++v12;
              *((_BYTE *)&byte_7FF91E910DF0 + v29++) = v9;
            }
            ++v6;
          }
          while ( v28 != (_DWORD)v3 );
        }
        if ( (unsigned __int64)v12 < 0x20 )
        {
          *((_BYTE *)&byte_7FF91E910DF0 + v12) = 0;
          if ( v28 == (_DWORD)v3 )
          {
            v30 = *v6;
            if ( *v6 != 1 )
            {
              v9 = (char *)&byte_7FF91E910DF0 - (char *)v6;
              do
              {
                if ( (v30 & 0xFD) == 0 )
                  break;
                v6[v9] = v30;
                ++v11;
                v30 = *++v6;
              }
              while ( v30 != 1 );
            }
            if ( (unsigned __int64)v11 < 0x20 )
            {
              *((_BYTE *)&byte_7FF91E910DF0 + v11) = 0;
              return &byte_7FF91E910DF0;
            }
          }
          else
          {
            v31 = -1;
            v32 = 0;
            v33 = 0;
            if ( (_BYTE)byte_7FF91E910DF0 )
            {
              v9 = 0;
              v34 = &byte_7FF91E910DF0;
              do
              {
                v35 = *((_BYTE *)&byte_7FF91E910DF0 + v9);
                v32 = (unsigned int)(v32 + 1);
                ++v9;
                if ( v35 == 46 )
                {
                  v31 = 0;
                }
                else
                {
                  *(_BYTE *)v34 = v35;
                  ++v33;
                  v36 = v31 + 1;
                  v34 = (int *)((char *)v34 + 1);
                  if ( v31 < 0 )
                    v36 = v31;
                  v31 = v36;
                }
              }
              while ( *((_BYTE *)&byte_7FF91E910DF0 + v9) );
            }
            if ( (unsigned __int64)v33 < 0x20 )
            {
              *((_BYTE *)&byte_7FF91E910DF0 + v33) = 0;
              v37 = sub_7FF91E34FFC4(&byte_7FF91E910DF0, 0, 10, v32);
              v9 = v6[1];
              v39 = v6 + 1;
              v40 = 0;
              if ( (_BYTE)v9 )
              {
                v41 = &byte_7FF91E910DF0;
                do
                {
                  ++v39;
                  if ( (_BYTE)v9 != 46 )
                  {
                    ++v40;
                    *(_BYTE *)v41 = v9;
                    v41 = (int *)((char *)v41 + 1);
                  }
                  v9 = *v39;
                }
                while ( (_BYTE)v9 );
              }
              if ( (unsigned __int64)v40 < 0x20 )
              {
                *((_BYTE *)&byte_7FF91E910DF0 + v40) = 0;
                v20 = (unsigned __int64)((unsigned int)sub_7FF91E34FFC4(&byte_7FF91E910DF0, 0, 10, v38) - v37)
                    * (v3 - v28)
                    / (unsigned int)(*(_DWORD *)(*(_QWORD *)v51 + 4LL) - **(_DWORD **)v51 - v28)
                    + v37;
                if ( v31 >= 0 )
                {
                  for ( i = v31; i; --i )
                    v7 *= 10;
                  v43 = v20 / v7;
                  v44 = v20 % v7;
                  LODWORD(v45) = v44;
                  do
                  {
                    --v31;
                    v45 = (unsigned int)((int)v45 / 10);
                  }
                  while ( (_DWORD)v45 );
                  if ( v31 )
                  {
                    v11 = v31;
                    memset(v51, 48, (unsigned int)v31);
                    v45 = 0;
                  }
                  if ( (unsigned __int64)v11 >= 0x10 )
                    _report_rangecheckfailure_0(v45);
                  v51[v11] = 0;
                  sub_7FF91DF6F020((int)&byte_7FF91E910DF0, (int)"%lu.", v43);
                  v46 = (char *)&byte_7FF91E910DF0 - 1;
                  do
                    v26 = *++v46 == 0;
                  while ( !v26 );
                  strcpy(v46, v51);
                  sub_7FF91DF6F020((int)v51, (int)"%lu", v44);
                  v47 = (char *)&byte_7FF91E910DF0 - 1;
                  do
                    v26 = *++v47 == 0;
                  while ( !v26 );
                  v48 = 0;
                  do
                  {
                    v49 = v51[v48];
                    v47[v48++] = v49;
                  }
                  while ( v49 );
                  return &byte_7FF91E910DF0;
                }
LABEL_64:
                sub_7FF91DF6F020((int)&byte_7FF91E910DF0, (int)"%lu", v20);
                return &byte_7FF91E910DF0;
              }
            }
          }
        }
      }
      else
      {
        v13 = *v6;
        v14 = -1;
        if ( *v6 != 2 )
        {
          v9 = (signed __int64)&byte_7FF91E910DF0;
          do
          {
            ++v6;
            if ( (_BYTE)v13 == 46 )
            {
              v14 = 0;
            }
            else
            {
              *(_BYTE *)v9 = v13;
              ++v12;
              v15 = v14 + 1;
              ++v9;
              if ( v14 < 0 )
                v15 = v14;
              v14 = v15;
            }
            LOBYTE(v13) = *v6;
          }
          while ( *v6 != 2 );
        }
        if ( (unsigned __int64)v12 < 0x20 )
        {
          *((_BYTE *)&byte_7FF91E910DF0 + v12) = 0;
          v16 = sub_7FF91E34FFC4(&byte_7FF91E910DF0, 0, 10, v10);
          v9 = v6[1];
          v17 = v6 + 1;
          v18 = 0;
          if ( (_BYTE)v9 )
          {
            v19 = &byte_7FF91E910DF0;
            do
            {
              ++v17;
              if ( (_BYTE)v9 != 46 )
              {
                v18 = (unsigned int)(v18 + 1);
                *(_BYTE *)v19 = v9;
                v19 = (int *)((char *)v19 + 1);
              }
              v9 = *v17;
            }
            while ( (_BYTE)v9 );
          }
          if ( (unsigned __int64)(int)v18 < 0x20 )
          {
            *((_BYTE *)&byte_7FF91E910DF0 + (int)v18) = 0;
            v20 = v16
                + v3
                * (unsigned __int64)((unsigned int)sub_7FF91E34FFC4(&byte_7FF91E910DF0, 0, 10, v18) - v16)
                / (unsigned int)(*((_DWORD *)v5 + 1) - *(_DWORD *)v5);
            if ( v14 >= 0 )
            {
              for ( j = v14; j; --j )
                v7 *= 10;
              v22 = v20 / v7;
              v23 = v20 % v7;
              LODWORD(v24) = v23;
              do
              {
                --v14;
                v24 = (unsigned int)((int)v24 / 10);
              }
              while ( (_DWORD)v24 );
              if ( v14 )
              {
                v11 = v14;
                memset(v51, 48, (unsigned int)v14);
                v24 = 0;
              }
              if ( (unsigned __int64)v11 >= 0x10 )
                _report_rangecheckfailure_0(v24);
              v51[v11] = 0;
              sub_7FF91DF6F020((int)&byte_7FF91E910DF0, (int)"%lu.", v22);
              v25 = (char *)&byte_7FF91E910DF0 - 1;
              do
                v26 = *++v25 == 0;
              while ( !v26 );
              strcpy(v25, v51);
              sub_7FF91DF6F020((int)v51, (int)"%lu", v23);
              v27 = (char *)&byte_7FF91E910DF0 - 1;
              do
                v26 = *++v27 == 0;
              while ( !v26 );
              strcpy(v27, v51);
              return &byte_7FF91E910DF0;
            }
            goto LABEL_64;
          }
        }
      }
      _report_rangecheckfailure_0(v9);
    }
  }
  return (int *)"ERR:PrmDbStr";
}


// ==== unknown_libname_1363 @ rva 0x3AC610 ====
// Microsoft VisualC v7/14 64bit runtime
void __fastcall unknown_libname_1363(_QWORD *a1)
{
  *a1 = 0;
  a1[1] = 0;
}


// ==== unknown_libname_1364 @ rva 0x3AC620 ====
// Microsoft VisualC v7/14 64bit runtime
void __fastcall unknown_libname_1364(_QWORD *a1)
{
  *a1 = 0;
  a1[1] = 0;
}


// ==== unknown_libname_1365 @ rva 0x3AC630 ====
// Microsoft VisualC v7/14 64bit runtime
void __fastcall unknown_libname_1365(_QWORD *a1)
{
  *a1 = 0;
  a1[1] = 0;
}


// ==== unknown_libname_1366 @ rva 0x3AC640 ====
// Microsoft VisualC v7/14 64bit runtime
void __fastcall unknown_libname_1366(_QWORD *a1)
{
  *a1 = 0;
  a1[1] = 0;
}


// ==== unknown_libname_1367 @ rva 0x3AC650 ====
// Microsoft VisualC v7/14 64bit runtime
void __fastcall unknown_libname_1367(_QWORD *a1)
{
  *a1 = 0;
  a1[1] = 0;
}


// ==== unknown_libname_1368 @ rva 0x3AC660 ====
// Microsoft VisualC v7/14 64bit runtime
void __fastcall unknown_libname_1368(_QWORD *a1)
{
  *a1 = 0;
  a1[1] = 0;
}


// ==== sub_7FF91E00C670 @ rva 0x3AC670 ====
// Hidden C++ exception states: #wind=5
__int64 __fastcall sub_7FF91E00C670(__int64 a1, int a2, int a3, __int64 a4)
{
  __int64 v5; // rdi
  int v7; // eax
  _DWORD *v8; // rdx
  _DWORD *v9; // r8
  int *v10; // rdx
  int v11; // ecx

  v5 = a2;
  *(_QWORD *)(a1 + 8) = a4;
  *(_QWORD *)a1 = &CPrmDSPJu60::`vftable';
  `eh vector constructor iterator'(
    (void *)(a1 + 16),
    0x10u,
    8u,
    (void (*)(void *))unknown_libname_1366,
    sub_7FF91E00C9E0);
  `eh vector constructor iterator'(
    (void *)(a1 + 144),
    0x10u,
    8u,
    (void (*)(void *))unknown_libname_1364,
    sub_7FF91E00C920);
  `eh vector constructor iterator'(
    (void *)(a1 + 272),
    0x10u,
    8u,
    (void (*)(void *))unknown_libname_1368,
    sub_7FF91E00CAA0);
  `eh vector constructor iterator'(
    (void *)(a1 + 400),
    0x10u,
    8u,
    (void (*)(void *))unknown_libname_1367,
    sub_7FF91E00CA40);
  `eh vector constructor iterator'(
    (void *)(a1 + 528),
    0x10u,
    8u,
    (void (*)(void *))unknown_libname_1365,
    sub_7FF91E00C980);
  `eh vector constructor iterator'(
    (void *)(a1 + 656),
    0x10u,
    8u,
    (void (*)(void *))unknown_libname_1363,
    sub_7FF91E00C8C0);
  v7 = 0;
  *(_QWORD *)(a1 + 784) = 0;
  *(_QWORD *)(a1 + 792) = 0;
  *(_QWORD *)(a1 + 800) = 0;
  *(_QWORD *)(a1 + 808) = 0;
  *(_QWORD *)(a1 + 816) = 0;
  *(_QWORD *)(a1 + 824) = 0;
  *(_QWORD *)(a1 + 832) = 0;
  *(_QWORD *)(a1 + 840) = 0;
  *(_QWORD *)(a1 + 848) = 0;
  *(_QWORD *)(a1 + 856) = 0;
  *(_QWORD *)(a1 + 864) = 0;
  *(_QWORD *)(a1 + 872) = 0;
  *(_QWORD *)(a1 + 880) = 0;
  *(_QWORD *)(a1 + 888) = 0;
  *(_QWORD *)(a1 + 896) = 0;
  *(_QWORD *)(a1 + 904) = 0;
  *(_QWORD *)(a1 + 912) = 0;
  *(_QWORD *)(a1 + 920) = 0;
  *(_QWORD *)(a1 + 928) = 0;
  *(_QWORD *)(a1 + 936) = 0;
  *(_DWORD *)(a1 + 1612) = v5;
  *(_DWORD *)(a1 + 1616) = a3;
  if ( (int)v5 <= a3 )
  {
    v8 = (_DWORD *)(a1 + 4 * (v5 + 405));
    do
    {
      *v8 = 0;
      LODWORD(v5) = v5 + 1;
      ++v8;
    }
    while ( (int)v5 <= *(_DWORD *)(a1 + 1616) );
  }
  v9 = (_DWORD *)(a1 + 4728);
  v10 = (int *)(a1 + 1656);
  do
  {
    v11 = 4 * v7;
    if ( 4 * v7 > 255 )
      v11 = 255;
    *(v10 - 1) = v11;
    *v10 = v7;
    v10[1] = 64;
    *(v9 - 1) = v7;
    *v9 = 255;
    ++v7;
    v10 += 3;
    v9 += 2;
  }
  while ( v7 < 256 );
  return a1;
}


// ==== sub_7FF91E00C8C0 @ rva 0x3AC8C0 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91E00C8C0(_QWORD *a1)
{
  volatile signed __int32 *v1; // rbx

  v1 = (volatile signed __int32 *)a1[1];
  if ( v1 && _InterlockedExchangeAdd(v1 + 2, 0xFFFFFFFF) == 1 )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 8LL))(v1);
    if ( _InterlockedExchangeAdd(v1 + 3, 0xFFFFFFFF) == 1 )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
  }
}


// ==== sub_7FF91E00C920 @ rva 0x3AC920 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91E00C920(_QWORD *a1)
{
  volatile signed __int32 *v1; // rbx

  v1 = (volatile signed __int32 *)a1[1];
  if ( v1 && _InterlockedExchangeAdd(v1 + 2, 0xFFFFFFFF) == 1 )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 8LL))(v1);
    if ( _InterlockedExchangeAdd(v1 + 3, 0xFFFFFFFF) == 1 )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
  }
}


// ==== sub_7FF91E00C980 @ rva 0x3AC980 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91E00C980(_QWORD *a1)
{
  volatile signed __int32 *v1; // rbx

  v1 = (volatile signed __int32 *)a1[1];
  if ( v1 && _InterlockedExchangeAdd(v1 + 2, 0xFFFFFFFF) == 1 )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 8LL))(v1);
    if ( _InterlockedExchangeAdd(v1 + 3, 0xFFFFFFFF) == 1 )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
  }
}


// ==== sub_7FF91E00C9E0 @ rva 0x3AC9E0 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91E00C9E0(_QWORD *a1)
{
  volatile signed __int32 *v1; // rbx

  v1 = (volatile signed __int32 *)a1[1];
  if ( v1 && _InterlockedExchangeAdd(v1 + 2, 0xFFFFFFFF) == 1 )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 8LL))(v1);
    if ( _InterlockedExchangeAdd(v1 + 3, 0xFFFFFFFF) == 1 )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
  }
}


// ==== sub_7FF91E00CA40 @ rva 0x3ACA40 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91E00CA40(_QWORD *a1)
{
  volatile signed __int32 *v1; // rbx

  v1 = (volatile signed __int32 *)a1[1];
  if ( v1 && _InterlockedExchangeAdd(v1 + 2, 0xFFFFFFFF) == 1 )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 8LL))(v1);
    if ( _InterlockedExchangeAdd(v1 + 3, 0xFFFFFFFF) == 1 )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
  }
}


// ==== sub_7FF91E00CAA0 @ rva 0x3ACAA0 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91E00CAA0(_QWORD *a1)
{
  volatile signed __int32 *v1; // rbx

  v1 = (volatile signed __int32 *)a1[1];
  if ( v1 && _InterlockedExchangeAdd(v1 + 2, 0xFFFFFFFF) == 1 )
  {
    (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 8LL))(v1);
    if ( _InterlockedExchangeAdd(v1 + 3, 0xFFFFFFFF) == 1 )
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
  }
}


// ==== sub_7FF91E00CB00 @ rva 0x3ACB00 ====
__int64 __fastcall sub_7FF91E00CB00(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 41));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 96LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00CB80 @ rva 0x3ACB80 ====
__int64 __fastcall sub_7FF91E00CB80(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rbx
  __int64 result; // rax
  _QWORD *v8; // rdi
  int v9; // ebx
  _QWORD *v10; // rdi

  v3 = *(int *)(a1 + 1612);
  result = *(unsigned int *)(a1 + 1616);
  if ( (int)v3 <= (int)result )
  {
    v8 = (_QWORD *)(a1 + 16 * (v3 + 33));
    do
    {
      if ( *v8 )
        (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v8 + 176LL))(*v8, a2, a3);
      result = *(unsigned int *)(a1 + 1616);
      LODWORD(v3) = v3 + 1;
      v8 += 2;
    }
    while ( (int)v3 <= (int)result );
    v9 = *(_DWORD *)(a1 + 1612);
    if ( v9 <= (int)result )
    {
      v10 = (_QWORD *)(a1 + 16 * (v9 + 33LL));
      do
      {
        if ( *v10 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v10 + 192LL))(*v10, a2, a3);
        ++v9;
        v10 += 2;
      }
      while ( v9 <= *(_DWORD *)(a1 + 1616) );
    }
  }
  return result;
}


// ==== sub_7FF91E00CC40 @ rva 0x3ACC40 ====
__int64 __fastcall sub_7FF91E00CC40(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rbx
  __int64 result; // rax
  _QWORD *v8; // rdi
  int v9; // ebx
  _QWORD *v10; // rdi

  v3 = *(int *)(a1 + 1612);
  result = *(unsigned int *)(a1 + 1616);
  if ( (int)v3 <= (int)result )
  {
    v8 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v8 )
        (*(void (__fastcall **)(_QWORD, _QWORD, __int64))(*(_QWORD *)*v8 + 80LL))(*v8, a2, 128);
      result = *(unsigned int *)(a1 + 1616);
      LODWORD(v3) = v3 + 1;
      v8 += 2;
    }
    while ( (int)v3 <= (int)result );
    v9 = *(_DWORD *)(a1 + 1612);
    if ( v9 <= (int)result )
    {
      v10 = (_QWORD *)(a1 + 16 * (v9 + 25LL));
      do
      {
        if ( *v10 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v10 + 328LL))(*v10, a2, a3);
        ++v9;
        v10 += 2;
      }
      while ( v9 <= *(_DWORD *)(a1 + 1616) );
    }
  }
  return result;
}


// ==== sub_7FF91E00CD20 @ rva 0x3ACD20 ====
__int64 __fastcall sub_7FF91E00CD20(__int64 a1)
{
  __int64 v1; // rbx
  __int64 result; // rax
  _QWORD *v4; // rsi
  int v5; // ebx
  _QWORD *v6; // rsi
  int v7; // ebx
  _QWORD *v8; // rsi
  int v9; // ebx
  _QWORD *v10; // rsi
  int v11; // ebx
  _QWORD *v12; // rsi
  int v13; // ebx
  _QWORD *v14; // rsi

  v1 = *(int *)(a1 + 1612);
  result = *(unsigned int *)(a1 + 1616);
  if ( (int)v1 <= (int)result )
  {
    v4 = (_QWORD *)(a1 + 16 * (v1 + 17));
    do
    {
      if ( *v4 )
        (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v4 + 112LL))(*v4, 1);
      result = *(unsigned int *)(a1 + 1616);
      LODWORD(v1) = v1 + 1;
      v4 += 2;
    }
    while ( (int)v1 <= (int)result );
    v5 = *(_DWORD *)(a1 + 1612);
    if ( v5 <= (int)result )
    {
      v6 = (_QWORD *)(a1 + 16 * (v5 + 33LL));
      do
      {
        if ( *v6 )
          (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v6 + 144LL))(*v6, 1);
        result = *(unsigned int *)(a1 + 1616);
        ++v5;
        v6 += 2;
      }
      while ( v5 <= (int)result );
      v7 = *(_DWORD *)(a1 + 1612);
      if ( v7 <= (int)result )
      {
        v8 = (_QWORD *)(a1 + 16 * (v7 + 33LL));
        do
        {
          if ( *v8 )
            (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v8 + 120LL))(*v8, 1);
          result = *(unsigned int *)(a1 + 1616);
          ++v7;
          v8 += 2;
        }
        while ( v7 <= (int)result );
        v9 = *(_DWORD *)(a1 + 1612);
        if ( v9 <= (int)result )
        {
          v10 = (_QWORD *)(a1 + 16 * (v9 + 41LL));
          do
          {
            if ( *v10 )
              (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v10 + 8LL))(*v10, 1);
            result = *(unsigned int *)(a1 + 1616);
            ++v9;
            v10 += 2;
          }
          while ( v9 <= (int)result );
          v11 = *(_DWORD *)(a1 + 1612);
          if ( v11 <= (int)result )
          {
            v12 = (_QWORD *)(a1 + 16 * (v11 + 25LL));
            do
            {
              if ( *v12 )
                (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v12 + 304LL))(*v12, 1);
              result = *(unsigned int *)(a1 + 1616);
              ++v11;
              v12 += 2;
            }
            while ( v11 <= (int)result );
            v13 = *(_DWORD *)(a1 + 1612);
            if ( v13 <= (int)result )
            {
              v14 = (_QWORD *)(a1 + 16 * (v13 + 25LL));
              do
              {
                if ( *v14 )
                  result = (*(__int64 (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v14 + 312LL))(*v14, 1);
                ++v13;
                v14 += 2;
              }
              while ( v13 <= *(_DWORD *)(a1 + 1616) );
            }
          }
        }
      }
    }
  }
  return result;
}


// ==== sub_7FF91E00CED0 @ rva 0x3ACED0 ====
__int64 __fastcall sub_7FF91E00CED0(__int64 a1)
{
  __int64 (__fastcall ***v1)(_QWORD, __int64); // rcx
  __int64 result; // rax

  v1 = *(__int64 (__fastcall ****)(_QWORD, __int64))(a1 + 784);
  if ( v1 )
    return (**v1)(v1, 1);
  return result;
}


// ==== sub_7FF91E00CEF0 @ rva 0x3ACEF0 ====
__int64 __fastcall sub_7FF91E00CEF0(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 result; // rax

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 1));
    do
    {
      if ( *v3 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v3 + 128LL))(*v3, 1);
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00CF60 @ rva 0x3ACF60 ====
__int64 __fastcall sub_7FF91E00CF60(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 (__fastcall ***v4)(_QWORD, __int64); // rcx
  __int64 result; // rax
  __int64 v6; // rcx

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 33));
    do
    {
      v4 = (__int64 (__fastcall ***)(_QWORD, __int64))*(v3 - 64);
      if ( v4 )
        result = (**v4)(v4, 1);
      v6 = *(v3 - 16);
      if ( v6 )
        result = (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v6 + 104LL))(v6, 1);
      if ( *v3 )
      {
        (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v3 + 40LL))(*v3, 1);
        result = (**(__int64 (__fastcall ***)(_QWORD, __int64))*v3)(*v3, 1);
      }
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00D000 @ rva 0x3AD000 ====
__int64 __fastcall sub_7FF91E00D000(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 result; // rax

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 17));
    do
    {
      if ( *v3 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(*(_QWORD *)*v3 + 112LL))(*v3, 1, 1);
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== nullsub_978 @ rva 0x3AD070 ====
void nullsub_978()
{
  ;
}


// ==== nullsub_979 @ rva 0x3AD080 ====
void nullsub_979()
{
  ;
}


// ==== nullsub_980 @ rva 0x3AD090 ====
void nullsub_980()
{
  ;
}


// ==== sub_7FF91E00D0A0 @ rva 0x3AD0A0 ====
void __fastcall sub_7FF91E00D0A0(__int64 a1)
{
  __int64 v1; // rdx
  _DWORD *v2; // r8

  *(_QWORD *)(a1 + 944) = 10;
  *(_QWORD *)(a1 + 952) = 0;
  *(_QWORD *)(a1 + 960) = 0;
  *(_QWORD *)(a1 + 968) = 0;
  *(_QWORD *)(a1 + 976) = 0;
  *(_QWORD *)(a1 + 984) = 0;
  *(_QWORD *)(a1 + 992) = 0;
  *(_QWORD *)(a1 + 1000) = 0;
  *(_QWORD *)(a1 + 1008) = 0;
  *(_QWORD *)(a1 + 1016) = 0;
  *(_QWORD *)(a1 + 1024) = 0;
  *(_QWORD *)(a1 + 1032) = 0;
  *(_QWORD *)(a1 + 1040) = 0;
  *(_QWORD *)(a1 + 1048) = 0;
  *(_QWORD *)(a1 + 1096) = 0;
  *(_QWORD *)(a1 + 1104) = 0;
  *(_QWORD *)(a1 + 1112) = 0;
  *(_QWORD *)(a1 + 1120) = 0;
  *(_QWORD *)(a1 + 1128) = 0;
  *(_QWORD *)(a1 + 1136) = 0;
  *(_QWORD *)(a1 + 1144) = 0;
  *(_QWORD *)(a1 + 1152) = 0;
  *(_QWORD *)(a1 + 1160) = 0;
  *(_QWORD *)(a1 + 1176) = 0;
  *(_DWORD *)(a1 + 1184) = 0;
  *(_DWORD *)(a1 + 1224) = 0;
  *(_QWORD *)(a1 + 1240) = 0;
  *(_DWORD *)(a1 + 1248) = 0;
  *(_QWORD *)(a1 + 1260) = 0;
  *(_DWORD *)(a1 + 1268) = 0;
  *(_QWORD *)(a1 + 1280) = 0;
  *(_QWORD *)(a1 + 1288) = 0;
  *(_DWORD *)(a1 + 1312) = 0;
  *(_DWORD *)(a1 + 1056) = 1280;
  *(_DWORD *)(a1 + 1060) = 12;
  *(_DWORD *)(a1 + 1064) = 12;
  *(_DWORD *)(a1 + 1068) = 12;
  *(_DWORD *)(a1 + 1072) = 12;
  *(_DWORD *)(a1 + 1076) = 12;
  *(_DWORD *)(a1 + 1080) = 12;
  *(_DWORD *)(a1 + 1084) = 12;
  *(_QWORD *)(a1 + 1088) = 12;
  *(_QWORD *)(a1 + 1168) = 127;
  *(_QWORD *)(a1 + 1188) = 1;
  *(_DWORD *)(a1 + 1196) = 1;
  *(_DWORD *)(a1 + 1200) = 1;
  *(_QWORD *)(a1 + 1204) = 1;
  *(_DWORD *)(a1 + 1212) = 1;
  *(_QWORD *)(a1 + 1216) = 1;
  *(_DWORD *)(a1 + 1228) = 128;
  *(_QWORD *)(a1 + 1232) = 128;
  *(_QWORD *)(a1 + 1252) = 1;
  *(_QWORD *)(a1 + 1272) = 255;
  *(_QWORD *)(a1 + 1296) = 255;
  *(_QWORD *)(a1 + 1304) = 128;
  *(_QWORD *)(a1 + 1316) = 255;
  *(_QWORD *)(a1 + 1324) = 128;
  *(_QWORD *)(a1 + 1332) = 0;
  *(_QWORD *)(a1 + 1340) = 0;
  *(_QWORD *)(a1 + 1348) = 0;
  *(_QWORD *)(a1 + 1356) = 0;
  *(_QWORD *)(a1 + 1364) = 128;
  *(_QWORD *)(a1 + 1372) = 0;
  *(_QWORD *)(a1 + 1380) = 0;
  *(_QWORD *)(a1 + 1388) = 0;
  *(_QWORD *)(a1 + 1396) = 0;
  *(_QWORD *)(a1 + 1404) = 0;
  *(_QWORD *)(a1 + 1412) = 0;
  *(_QWORD *)(a1 + 1420) = 0;
  *(_QWORD *)(a1 + 1428) = 0;
  *(_DWORD *)(a1 + 1436) = 0;
  *(_QWORD *)(a1 + 1440) = 128;
  *(_DWORD *)(a1 + 1448) = 255;
  *(_QWORD *)(a1 + 1452) = 255;
  *(_QWORD *)(a1 + 1460) = 0;
  *(_QWORD *)(a1 + 1468) = 0;
  *(_QWORD *)(a1 + 1476) = 128;
  *(_QWORD *)(a1 + 1484) = 2;
  *(_QWORD *)(a1 + 1492) = 0;
  *(_QWORD *)(a1 + 1500) = 1065353216;
  *(_QWORD *)(a1 + 1508) = 50;
  *(_DWORD *)(a1 + 1516) = 14;
  *(_QWORD *)(a1 + 1520) = 255;
  *(_QWORD *)(a1 + 1528) = 0;
  *(_QWORD *)(a1 + 1536) = 14;
  *(_DWORD *)(a1 + 1544) = 0;
  *(_QWORD *)(a1 + 1548) = 14;
  *(_DWORD *)(a1 + 1556) = 64;
  *(_DWORD *)(a1 + 1560) = 128;
  *(_QWORD *)(a1 + 1564) = 128;
  *(_QWORD *)(a1 + 1572) = 0;
  *(_DWORD *)(a1 + 1580) = 0;
  *(_DWORD *)(a1 + 1584) = 64;
  *(_QWORD *)(a1 + 1588) = 128;
  *(_DWORD *)(a1 + 1596) = 0;
  *(_DWORD *)(a1 + 1600) = 14;
  *(_DWORD *)(a1 + 1604) = 10;
  *(_DWORD *)(a1 + 1608) = 255;
  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v2 = (_DWORD *)(a1 + 1620 + 4 * v1);
    do
    {
      *v2++ = 0;
      LODWORD(v1) = v1 + 1;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
}


// ==== sub_7FF91E00D430 @ rva 0x3AD430 ====
__int64 __fastcall sub_7FF91E00D430(__int64 a1)
{
  __int64 v2; // rcx
  __int64 result; // rax

  v2 = *(_QWORD *)(a1 + 928);
  if ( v2 )
  {
    (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v2 + 24LL))(v2, 1);
    return (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(**(_QWORD **)(a1 + 928) + 32LL))(
             *(_QWORD *)(a1 + 928),
             1,
             1);
  }
  return result;
}


// ==== sub_7FF91E00D480 @ rva 0x3AD480 ====
__int64 __fastcall sub_7FF91E00D480(__int64 a1)
{
  __int64 v2; // rcx
  __int64 result; // rax

  v2 = *(_QWORD *)(a1 + 912);
  if ( v2 )
  {
    (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v2 + 32LL))(v2, 1, 2);
    return (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(**(_QWORD **)(a1 + 912) + 24LL))(
             *(_QWORD *)(a1 + 912),
             1,
             1);
  }
  return result;
}


// ==== sub_7FF91E00D4D0 @ rva 0x3AD4D0 ====
__int64 __fastcall sub_7FF91E00D4D0(__int64 a1)
{
  __int64 v2; // rcx
  __int64 result; // rax

  v2 = *(_QWORD *)(a1 + 912);
  if ( v2 )
  {
    (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v2 + 32LL))(v2, 1);
    return (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(**(_QWORD **)(a1 + 912) + 24LL))(
             *(_QWORD *)(a1 + 912),
             1,
             1);
  }
  return result;
}


// ==== sub_7FF91E00D520 @ rva 0x3AD520 ====
__int64 __fastcall sub_7FF91E00D520(__int64 a1)
{
  __int64 v2; // rcx
  __int64 result; // rax

  v2 = *(_QWORD *)(a1 + 912);
  if ( v2 )
  {
    (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v2 + 32LL))(v2, 1, 1);
    return (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(**(_QWORD **)(a1 + 912) + 24LL))(
             *(_QWORD *)(a1 + 912),
             1,
             1);
  }
  return result;
}


// ==== nullsub_981 @ rva 0x3AD570 ====
void nullsub_981()
{
  ;
}


// ==== nullsub_982 @ rva 0x3AD580 ====
void nullsub_982()
{
  ;
}


// ==== sub_7FF91E00D590 @ rva 0x3AD590 ====
__int64 __fastcall sub_7FF91E00D590(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 v4; // rcx
  __int64 result; // rax
  __int64 v6; // rcx

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 25));
    do
    {
      v4 = *(v3 - 16);
      if ( v4 )
        result = (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v4 + 72LL))(v4, 1);
      if ( *v3 )
      {
        (*(void (__fastcall **)(_QWORD, __int64, __int64))(*(_QWORD *)*v3 + 136LL))(*v3, 1, 1);
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(*(_QWORD *)*v3 + 176LL))(*v3, 1, 1);
      }
      v6 = v3[16];
      if ( v6 )
      {
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 72LL))(v6, 1, 1);
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(*(_QWORD *)v3[16] + 104LL))(v3[16], 1, 1);
      }
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00D650 @ rva 0x3AD650 ====
char sub_7FF91E00D650()
{
  return 0;
}


// ==== sub_7FF91E00D660 @ rva 0x3AD660 ====
__int64 __fastcall sub_7FF91E00D660(__int64 a1)
{
  __int64 v2; // rcx
  __int64 result; // rax
  __int64 (__fastcall ***v4)(_QWORD); // rcx
  __int64 v5; // rcx

  v2 = *(_QWORD *)(a1 + 864);
  if ( v2 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
  result = *(int *)(a1 + 1472);
  switch ( *(_DWORD *)(a1 + 1472) )
  {
    case 0:
      v4 = *(__int64 (__fastcall ****)(_QWORD))(a1 + 880);
      if ( v4 )
        goto LABEL_5;
      break;
    case 1:
      v4 = *(__int64 (__fastcall ****)(_QWORD))(a1 + 896);
      if ( v4 )
LABEL_5:
        result = (**v4)(v4);
      break;
    case 2:
    case 3:
    case 4:
      v5 = *(_QWORD *)(a1 + 912);
      goto LABEL_10;
    case 5:
      v5 = *(_QWORD *)(a1 + 928);
LABEL_10:
      if ( v5 )
        result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v5 + 16LL))(v5);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E00D710 @ rva 0x3AD710 ====
__int64 __fastcall sub_7FF91E00D710(__int64 a1, unsigned int a2)
{
  __int64 (__fastcall ***v4)(_QWORD, _QWORD); // rcx
  __int64 result; // rax
  __int64 v6; // rcx

  if ( *(_DWORD *)(a1 + 1472) == 2 || *(_DWORD *)(a1 + 1472) == 3 || *(_DWORD *)(a1 + 1472) == 4 )
  {
    v4 = *(__int64 (__fastcall ****)(_QWORD, _QWORD))(a1 + 912);
  }
  else
  {
    if ( *(_DWORD *)(a1 + 1472) != 5 )
      goto LABEL_9;
    v4 = *(__int64 (__fastcall ****)(_QWORD, _QWORD))(a1 + 928);
  }
  if ( v4 )
    result = (**v4)(v4, 0);
LABEL_9:
  v6 = *(_QWORD *)(a1 + 864);
  if ( v6 )
    return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v6 + 16LL))(v6, a2);
  return result;
}


// ==== sub_7FF91E00D780 @ rva 0x3AD780 ====
__int64 __fastcall sub_7FF91E00D780(__int64 a1)
{
  __int64 v2; // rcx
  __int64 result; // rax
  __int64 v4; // rcx

  if ( *(_DWORD *)(a1 + 1472) == 2 || *(_DWORD *)(a1 + 1472) == 3 || *(_DWORD *)(a1 + 1472) == 4 )
  {
    v2 = *(_QWORD *)(a1 + 912);
  }
  else
  {
    if ( *(_DWORD *)(a1 + 1472) != 5 )
      goto LABEL_9;
    v2 = *(_QWORD *)(a1 + 928);
  }
  if ( v2 )
    result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v2 + 8LL))(v2);
LABEL_9:
  v4 = *(_QWORD *)(a1 + 864);
  if ( v4 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 24LL))(v4);
  return result;
}


// ==== sub_7FF91E00D7E0 @ rva 0x3AD7E0 ====
__int64 __fastcall sub_7FF91E00D7E0(__int64 a1)
{
  __int64 v2; // rbx
  _QWORD *v3; // rsi
  int v4; // eax
  int v5; // ebx
  _QWORD *v6; // rsi
  int v7; // eax
  int v8; // ebx
  _QWORD *v9; // rsi
  __int64 v10; // rcx
  __int64 result; // rax
  __int64 (__fastcall ***v12)(_QWORD); // rcx
  __int64 v13; // rcx

  v2 = *(int *)(a1 + 1612);
  if ( (int)v2 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v2 + 9));
    do
    {
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 16LL))(*v3);
      v4 = *(_DWORD *)(a1 + 1616);
      v3 += 2;
      LODWORD(v2) = v2 + 1;
    }
    while ( (int)v2 <= v4 );
    v5 = *(_DWORD *)(a1 + 1612);
    if ( v5 <= v4 )
    {
      v6 = (_QWORD *)(a1 + 16 * (v5 + 25LL));
      do
      {
        if ( *v6 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v6 + 16LL))(*v6);
        v7 = *(_DWORD *)(a1 + 1616);
        ++v5;
        v6 += 2;
      }
      while ( v5 <= v7 );
      v8 = *(_DWORD *)(a1 + 1612);
      if ( v8 <= v7 )
      {
        v9 = (_QWORD *)(a1 + 16 * (v8 + 25LL));
        do
        {
          if ( *v9 )
            (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v9 + 40LL))(*v9);
          ++v8;
          v9 += 2;
        }
        while ( v8 <= *(_DWORD *)(a1 + 1616) );
      }
    }
  }
  v10 = *(_QWORD *)(a1 + 864);
  if ( v10 )
    (*(void (__fastcall **)(__int64))(*(_QWORD *)v10 + 32LL))(v10);
  result = *(int *)(a1 + 1472);
  switch ( *(_DWORD *)(a1 + 1472) )
  {
    case 0:
      v12 = *(__int64 (__fastcall ****)(_QWORD))(a1 + 880);
      if ( v12 )
        goto LABEL_18;
      break;
    case 1:
      v12 = *(__int64 (__fastcall ****)(_QWORD))(a1 + 896);
      if ( v12 )
LABEL_18:
        result = (**v12)(v12);
      break;
    case 2:
    case 3:
    case 4:
      v13 = *(_QWORD *)(a1 + 912);
      goto LABEL_23;
    case 5:
      v13 = *(_QWORD *)(a1 + 928);
LABEL_23:
      if ( v13 )
        result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v13 + 16LL))(v13);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E00D950 @ rva 0x3AD950 ====
__int64 __fastcall sub_7FF91E00D950(__int64 a1)
{
  __int64 v1; // rbx
  _QWORD *v3; // rsi
  __int64 result; // rax
  int v5; // edx
  int v6; // ebx
  _QWORD *v7; // rsi
  int v8; // ebx
  _QWORD *v9; // rsi
  __int64 (__fastcall ***v10)(_QWORD, _QWORD); // rcx
  __int64 v11; // rcx

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 9));
    do
    {
      result = (**(__int64 (__fastcall ***)(_QWORD, _QWORD))*v3)(*v3, 0);
      v5 = *(_DWORD *)(a1 + 1616);
      v3 += 2;
      LODWORD(v1) = v1 + 1;
    }
    while ( (int)v1 <= v5 );
    v6 = *(_DWORD *)(a1 + 1612);
    if ( v6 <= v5 )
    {
      v7 = (_QWORD *)(a1 + 16 * (v6 + 25LL));
      do
      {
        if ( *v7 )
        {
          result = (**(__int64 (__fastcall ***)(_QWORD, _QWORD))*v7)(*v7, 0);
          v5 = *(_DWORD *)(a1 + 1616);
        }
        ++v6;
        v7 += 2;
      }
      while ( v6 <= v5 );
      v8 = *(_DWORD *)(a1 + 1612);
      if ( v8 <= v5 )
      {
        v9 = (_QWORD *)(a1 + 16 * (v8 + 25LL));
        do
        {
          if ( *v9 )
          {
            result = (*(__int64 (__fastcall **)(_QWORD, _QWORD))(*(_QWORD *)*v9 + 24LL))(*v9, 0);
            v5 = *(_DWORD *)(a1 + 1616);
          }
          ++v8;
          v9 += 2;
        }
        while ( v8 <= v5 );
      }
    }
  }
  if ( *(_DWORD *)(a1 + 1472) == 2 || *(_DWORD *)(a1 + 1472) == 3 || *(_DWORD *)(a1 + 1472) == 4 )
  {
    v10 = *(__int64 (__fastcall ****)(_QWORD, _QWORD))(a1 + 912);
  }
  else
  {
    if ( *(_DWORD *)(a1 + 1472) != 5 )
      goto LABEL_22;
    v10 = *(__int64 (__fastcall ****)(_QWORD, _QWORD))(a1 + 928);
  }
  if ( v10 )
    result = (**v10)(v10, 0);
LABEL_22:
  v11 = *(_QWORD *)(a1 + 864);
  if ( v11 )
    return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v11 + 16LL))(v11, 0);
  return result;
}


// ==== sub_7FF91E00DA80 @ rva 0x3ADA80 ====
__int64 __fastcall sub_7FF91E00DA80(__int64 a1)
{
  __int64 result; // rax
  __int64 v2; // rbx
  _QWORD *v4; // rsi
  int v5; // ebx
  _QWORD *v6; // rsi
  int v7; // ebx
  _QWORD *v8; // rsi
  __int64 v9; // rcx
  __int64 v10; // rcx

  result = *(unsigned int *)(a1 + 1616);
  v2 = *(int *)(a1 + 1612);
  if ( (int)v2 <= (int)result )
  {
    v4 = (_QWORD *)(a1 + 16 * (v2 + 9));
    do
    {
      (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v4 + 8LL))(*v4);
      result = *(unsigned int *)(a1 + 1616);
      v4 += 2;
      LODWORD(v2) = v2 + 1;
    }
    while ( (int)v2 <= (int)result );
    v5 = *(_DWORD *)(a1 + 1612);
    if ( v5 <= (int)result )
    {
      v6 = (_QWORD *)(a1 + 16 * (v5 + 25LL));
      do
      {
        if ( *v6 )
          (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v6 + 8LL))(*v6);
        result = *(unsigned int *)(a1 + 1616);
        ++v5;
        v6 += 2;
      }
      while ( v5 <= (int)result );
      v7 = *(_DWORD *)(a1 + 1612);
      if ( v7 <= (int)result )
      {
        v8 = (_QWORD *)(a1 + 16 * (v7 + 25LL));
        do
        {
          if ( *v8 )
            result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v8 + 32LL))(*v8);
          ++v7;
          v8 += 2;
        }
        while ( v7 <= *(_DWORD *)(a1 + 1616) );
      }
    }
  }
  if ( *(_DWORD *)(a1 + 1472) == 2 || *(_DWORD *)(a1 + 1472) == 3 || *(_DWORD *)(a1 + 1472) == 4 )
  {
    v9 = *(_QWORD *)(a1 + 912);
  }
  else
  {
    if ( *(_DWORD *)(a1 + 1472) != 5 )
      goto LABEL_22;
    v9 = *(_QWORD *)(a1 + 928);
  }
  if ( v9 )
    result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v9 + 8LL))(v9);
LABEL_22:
  v10 = *(_QWORD *)(a1 + 864);
  if ( v10 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v10 + 24LL))(v10);
  return result;
}


// ==== sub_7FF91E00DBA0 @ rva 0x3ADBA0 ====
__int64 __fastcall sub_7FF91E00DBA0(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 result; // rax

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 25));
    do
    {
      if ( *v3 )
        result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 16LL))(*v3);
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00DC00 @ rva 0x3ADC00 ====
__int64 __fastcall sub_7FF91E00DC00(__int64 a1, unsigned int a2)
{
  __int64 v2; // rbx
  unsigned int v3; // esi
  int v4; // r8d
  __int64 (__fastcall ****v7)(_QWORD, _QWORD); // rdi
  bool v8; // zf
  __int64 (__fastcall ***v9)(_QWORD, _QWORD); // rcx
  __int64 result; // rax

  v2 = *(int *)(a1 + 1612);
  v3 = 0;
  v4 = *(_DWORD *)(a1 + 1616);
  if ( (int)v2 <= v4 )
  {
    v7 = (__int64 (__fastcall ****)(_QWORD, _QWORD))(a1 + 16 * (v2 + 25));
    v8 = (_DWORD)v2 == v4;
    do
    {
      v9 = *v7;
      if ( v8 )
        v3 = a2;
      if ( v9 )
      {
        result = (**v9)(v9, v3);
        v4 = *(_DWORD *)(a1 + 1616);
      }
      LODWORD(v2) = v2 + 1;
      v7 += 2;
      v8 = (_DWORD)v2 == v4;
    }
    while ( (int)v2 <= v4 );
  }
  return result;
}


// ==== sub_7FF91E00DC90 @ rva 0x3ADC90 ====
__int64 __fastcall sub_7FF91E00DC90(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 result; // rax

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 25));
    do
    {
      if ( *v3 )
        result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 8LL))(*v3);
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00DCF0 @ rva 0x3ADCF0 ====
__int64 __fastcall sub_7FF91E00DCF0(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 result; // rax

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 25));
    do
    {
      if ( *v3 )
        result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 40LL))(*v3);
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00DD50 @ rva 0x3ADD50 ====
__int64 __fastcall sub_7FF91E00DD50(__int64 a1, unsigned int a2)
{
  __int64 v2; // rbx
  unsigned int v3; // esi
  int v4; // r8d
  __int64 *v7; // rdi
  bool v8; // zf
  __int64 v9; // rcx
  __int64 result; // rax

  v2 = *(int *)(a1 + 1612);
  v3 = 0;
  v4 = *(_DWORD *)(a1 + 1616);
  if ( (int)v2 <= v4 )
  {
    v7 = (__int64 *)(a1 + 16 * (v2 + 25));
    v8 = (_DWORD)v2 == v4;
    do
    {
      v9 = *v7;
      if ( v8 )
        v3 = a2;
      if ( v9 )
      {
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v9 + 24LL))(v9, v3);
        v4 = *(_DWORD *)(a1 + 1616);
      }
      LODWORD(v2) = v2 + 1;
      v7 += 2;
      v8 = (_DWORD)v2 == v4;
    }
    while ( (int)v2 <= v4 );
  }
  return result;
}


// ==== sub_7FF91E00DDE0 @ rva 0x3ADDE0 ====
__int64 __fastcall sub_7FF91E00DDE0(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 result; // rax

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 25));
    do
    {
      if ( *v3 )
        result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 32LL))(*v3);
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00DE40 @ rva 0x3ADE40 ====
__int64 __fastcall sub_7FF91E00DE40(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rbx
  __int64 result; // rax
  _QWORD *v8; // rsi
  int v9; // ebx
  _QWORD *v10; // rsi
  int v11; // ebx
  _QWORD *v12; // rsi
  int v13; // ebx
  _QWORD *v14; // rsi
  int v15; // ebx
  _QWORD *v16; // rsi

  v3 = *(int *)(a1 + 1612);
  result = *(unsigned int *)(a1 + 1616);
  if ( (int)v3 <= (int)result )
  {
    v8 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v8 )
        (*(void (__fastcall **)(_QWORD, _QWORD, __int64))(*(_QWORD *)*v8 + 80LL))(*v8, a2, 128);
      result = *(unsigned int *)(a1 + 1616);
      LODWORD(v3) = v3 + 1;
      v8 += 2;
    }
    while ( (int)v3 <= (int)result );
    v9 = *(_DWORD *)(a1 + 1612);
    if ( v9 <= (int)result )
    {
      v10 = (_QWORD *)(a1 + 16 * (v9 + 25LL));
      do
      {
        if ( *v10 )
          (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v10 + 328LL))(*v10, a2, a3);
        result = *(unsigned int *)(a1 + 1616);
        ++v9;
        v10 += 2;
      }
      while ( v9 <= (int)result );
      v11 = *(_DWORD *)(a1 + 1612);
      if ( v11 <= (int)result )
      {
        v12 = (_QWORD *)(a1 + 16 * (v11 + 33LL));
        do
        {
          if ( *v12 )
            (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v12 + 176LL))(*v12, a2, a3);
          result = *(unsigned int *)(a1 + 1616);
          ++v11;
          v12 += 2;
        }
        while ( v11 <= (int)result );
        v13 = *(_DWORD *)(a1 + 1612);
        if ( v13 <= (int)result )
        {
          v14 = (_QWORD *)(a1 + 16 * (v13 + 33LL));
          do
          {
            if ( *v14 )
              (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v14 + 192LL))(*v14, a2, a3);
            result = *(unsigned int *)(a1 + 1616);
            ++v13;
            v14 += 2;
          }
          while ( v13 <= (int)result );
          v15 = *(_DWORD *)(a1 + 1612);
          if ( v15 <= (int)result )
          {
            v16 = (_QWORD *)(a1 + 16 * (v15 + 41LL));
            do
            {
              if ( *v16 )
                result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v16 + 96LL))(*v16, a2, a3);
              ++v15;
              v16 += 2;
            }
            while ( v15 <= *(_DWORD *)(a1 + 1616) );
          }
        }
      }
    }
  }
  return result;
}


// ==== sub_7FF91E00DFC0 @ rva 0x3ADFC0 ====
__int64 __fastcall sub_7FF91E00DFC0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 41));
    do
    {
      if ( *v7 )
        result = (**(__int64 (__fastcall ***)(_QWORD, _QWORD, _QWORD))*v7)(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00E040 @ rva 0x3AE040 ====
__int64 __fastcall sub_7FF91E00E040(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rbx
  __int64 result; // rax
  _QWORD *v8; // rdi
  int v9; // ebx
  _QWORD *v10; // rdi

  v3 = *(int *)(a1 + 1612);
  result = *(unsigned int *)(a1 + 1616);
  if ( (int)v3 <= (int)result )
  {
    v8 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v8 )
        (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v8 + 120LL))(*v8, a2, a3);
      result = *(unsigned int *)(a1 + 1616);
      LODWORD(v3) = v3 + 1;
      v8 += 2;
    }
    while ( (int)v3 <= (int)result );
    v9 = *(_DWORD *)(a1 + 1612);
    if ( v9 <= (int)result )
    {
      v10 = (_QWORD *)(a1 + 16 * (v9 + 33LL));
      do
      {
        if ( *v10 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v10 + 56LL))(*v10, a2, a3);
        ++v9;
        v10 += 2;
      }
      while ( v9 <= *(_DWORD *)(a1 + 1616) );
    }
  }
  return result;
}


// ==== sub_7FF91E00E100 @ rva 0x3AE100 ====
__int64 __fastcall sub_7FF91E00E100(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rbx
  __int64 result; // rax
  _QWORD *v8; // rdi
  int v9; // ebx
  _QWORD *v10; // rdi

  v3 = *(int *)(a1 + 1612);
  result = *(unsigned int *)(a1 + 1616);
  if ( (int)v3 <= (int)result )
  {
    v8 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v8 )
        (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v8 + 112LL))(*v8, a2, a3);
      result = *(unsigned int *)(a1 + 1616);
      LODWORD(v3) = v3 + 1;
      v8 += 2;
    }
    while ( (int)v3 <= (int)result );
    v9 = *(_DWORD *)(a1 + 1612);
    if ( v9 <= (int)result )
    {
      v10 = (_QWORD *)(a1 + 16 * (v9 + 33LL));
      do
      {
        if ( *v10 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v10 + 48LL))(*v10, a2, a3);
        ++v9;
        v10 += 2;
      }
      while ( v9 <= *(_DWORD *)(a1 + 1616) );
    }
  }
  return result;
}


// ==== sub_7FF91E00E1C0 @ rva 0x3AE1C0 ====
__int64 __fastcall sub_7FF91E00E1C0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 33));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 64LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00E240 @ rva 0x3AE240 ====
__int64 __fastcall sub_7FF91E00E240(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 128LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== nullsub_11 @ rva 0x3AE2C0 ====
void nullsub_11()
{
  ;
}


// ==== nullsub_983 @ rva 0x3AE2D0 ====
void nullsub_983()
{
  ;
}


// ==== nullsub_984 @ rva 0x3AE2E0 ====
void nullsub_984()
{
  ;
}


// ==== nullsub_985 @ rva 0x3AE2F0 ====
void nullsub_985()
{
  ;
}


// ==== nullsub_12 @ rva 0x3AE300 ====
void nullsub_12()
{
  ;
}


// ==== nullsub_13 @ rva 0x3AE310 ====
void nullsub_13()
{
  ;
}


// ==== sub_7FF91E00E320 @ rva 0x3AE320 ====
__int64 __fastcall sub_7FF91E00E320(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 96LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== nullsub_986 @ rva 0x3AE3A0 ====
void nullsub_986()
{
  ;
}


// ==== sub_7FF91E00E3B0 @ rva 0x3AE3B0 ====
__int64 __fastcall sub_7FF91E00E3B0(__int64 a1)
{
  __int64 v1; // rcx
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 272);
  if ( v1 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 32LL))(v1);
  return result;
}


// ==== sub_7FF91E00E3D0 @ rva 0x3AE3D0 ====
__int64 __fastcall sub_7FF91E00E3D0(__int64 a1)
{
  __int64 v1; // rcx
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 288);
  if ( v1 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 32LL))(v1);
  return result;
}


// ==== sub_7FF91E00E3F0 @ rva 0x3AE3F0 ====
__int64 __fastcall sub_7FF91E00E3F0(__int64 a1)
{
  __int64 v1; // rcx
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 304);
  if ( v1 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 32LL))(v1);
  return result;
}


// ==== sub_7FF91E00E410 @ rva 0x3AE410 ====
__int64 __fastcall sub_7FF91E00E410(__int64 a1)
{
  __int64 v1; // rcx
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 320);
  if ( v1 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 32LL))(v1);
  return result;
}


// ==== sub_7FF91E00E430 @ rva 0x3AE430 ====
__int64 __fastcall sub_7FF91E00E430(__int64 a1)
{
  __int64 v1; // rcx
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 336);
  if ( v1 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 32LL))(v1);
  return result;
}


// ==== sub_7FF91E00E450 @ rva 0x3AE450 ====
__int64 __fastcall sub_7FF91E00E450(__int64 a1)
{
  __int64 v1; // rcx
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 352);
  if ( v1 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 32LL))(v1);
  return result;
}


// ==== sub_7FF91E00E470 @ rva 0x3AE470 ====
__int64 __fastcall sub_7FF91E00E470(__int64 a1)
{
  __int64 v1; // rcx
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 368);
  if ( v1 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 32LL))(v1);
  return result;
}


// ==== sub_7FF91E00E490 @ rva 0x3AE490 ====
__int64 __fastcall sub_7FF91E00E490(__int64 a1)
{
  __int64 v1; // rcx
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 384);
  if ( v1 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 32LL))(v1);
  return result;
}


// ==== nullsub_14 @ rva 0x3AE4B0 ====
void nullsub_14()
{
  ;
}


// ==== nullsub_15 @ rva 0x3AE4C0 ====
void nullsub_15()
{
  ;
}


// ==== nullsub_16 @ rva 0x3AE4D0 ====
void nullsub_16()
{
  ;
}


// ==== nullsub_17 @ rva 0x3AE4E0 ====
void nullsub_17()
{
  ;
}


// ==== nullsub_18 @ rva 0x3AE4F0 ====
void nullsub_18()
{
  ;
}


// ==== nullsub_19 @ rva 0x3AE500 ====
void nullsub_19()
{
  ;
}


// ==== nullsub_20 @ rva 0x3AE510 ====
void nullsub_20()
{
  ;
}


// ==== nullsub_21 @ rva 0x3AE520 ====
void nullsub_21()
{
  ;
}


// ==== nullsub_22 @ rva 0x3AE530 ====
void nullsub_22()
{
  ;
}


// ==== nullsub_23 @ rva 0x3AE540 ====
void nullsub_23()
{
  ;
}


// ==== nullsub_24 @ rva 0x3AE550 ====
void nullsub_24()
{
  ;
}


// ==== sub_7FF91E00E560 @ rva 0x3AE560 ====
__int64 __fastcall sub_7FF91E00E560(__int64 a1, __int64 a2, int a3)
{
  __int64 result; // rax
  unsigned int v5; // edi
  __int64 v7; // rcx
  int v8; // r8d
  __int64 v9; // rsi
  __int64 v10; // rcx
  __int64 v11; // rcx
  __int64 v12; // rcx
  int v13; // r8d
  __int64 v14; // rcx
  __int64 (__fastcall ***v15)(_QWORD, __int64, __int64); // rcx
  __int64 v16; // r8
  int v17; // esi
  __int64 v18; // rcx

  result = *(int *)(a1 + 1472);
  v5 = a2;
  switch ( *(_DWORD *)(a1 + 1472) )
  {
    case 0:
      v7 = *(_QWORD *)(a1 + 864);
      v8 = 0;
      result = 255;
      if ( a3 >= 0 )
        v8 = a3;
      if ( v8 > 255 )
        v8 = 255;
      v9 = v8;
      if ( v7 )
        result = (*(__int64 (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)v7 + 8LL))(
                   v7,
                   a2,
                   *(unsigned int *)(a1 + 12LL * v8 + 1652));
      v10 = *(_QWORD *)(a1 + 880);
      if ( v10 )
      {
        result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v10 + 8LL))(
                   v10,
                   v5,
                   *(unsigned int *)(a1 + 12 * v9 + 1656));
        v11 = *(_QWORD *)(a1 + 880);
        goto LABEL_18;
      }
      break;
    case 1:
      v12 = *(_QWORD *)(a1 + 864);
      v13 = 0;
      result = 255;
      if ( a3 >= 0 )
        v13 = a3;
      if ( v13 > 255 )
        v13 = 255;
      v9 = v13;
      if ( v12 )
        result = (*(__int64 (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)v12 + 8LL))(
                   v12,
                   a2,
                   *(unsigned int *)(a1 + 12LL * v13 + 1652));
      v14 = *(_QWORD *)(a1 + 896);
      if ( v14 )
      {
        result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v14 + 8LL))(
                   v14,
                   v5,
                   *(unsigned int *)(a1 + 12 * v9 + 1656));
        v11 = *(_QWORD *)(a1 + 896);
LABEL_18:
        if ( v11 )
          result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v11 + 16LL))(
                     v11,
                     v5,
                     *(unsigned int *)(a1 + 12 * v9 + 1660));
      }
      break;
    case 2:
    case 3:
    case 4:
      result = sub_7FF91E011980(a1);
      break;
    case 5:
      v15 = *(__int64 (__fastcall ****)(_QWORD, __int64, __int64))(a1 + 864);
      v16 = 0;
      result = 255;
      v17 = 0;
      if ( a3 >= 0 )
        v17 = a3;
      if ( v17 > 255 )
        v17 = 255;
      if ( v15 )
      {
        LOBYTE(v16) = v17 > 0;
        result = (**v15)(v15, a2, v16);
      }
      v18 = *(_QWORD *)(a1 + 928);
      if ( v18 )
        result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v18 + 40LL))(
                   v18,
                   v5,
                   (unsigned int)v17);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E00E720 @ rva 0x3AE720 ====
__int64 __fastcall sub_7FF91E00E720(__int64 a1)
{
  __int64 result; // rax
  __int64 v2; // rcx
  __int64 v3; // rcx
  __int64 v4; // rcx

  result = *(int *)(a1 + 1472);
  switch ( *(_DWORD *)(a1 + 1472) )
  {
    case 0:
      v2 = *(_QWORD *)(a1 + 880);
      if ( v2 )
        goto LABEL_3;
      break;
    case 1:
      v2 = *(_QWORD *)(a1 + 896);
      if ( v2 )
LABEL_3:
        result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v2 + 24LL))(v2);
      break;
    case 2:
    case 3:
    case 4:
      v3 = *(_QWORD *)(a1 + 912);
      if ( v3 )
        result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v3 + 40LL))(v3);
      break;
    case 5:
      v4 = *(_QWORD *)(a1 + 928);
      if ( v4 )
        result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v4 + 48LL))(v4);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E00E7B0 @ rva 0x3AE7B0 ====
__int64 __fastcall sub_7FF91E00E7B0(__int64 *a1, __int64 a2, int a3)
{
  __int64 v3; // rax

  v3 = *a1;
  *((_DWORD *)a1 + 368) = a3;
  return (*(__int64 (**)(void))(v3 + 128))();
}


// ==== sub_7FF91E00E7D0 @ rva 0x3AE7D0 ====
__int64 __fastcall sub_7FF91E00E7D0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 9));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 32LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00E850 @ rva 0x3AE850 ====
__int64 __fastcall sub_7FF91E00E850(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 9));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 40LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00E8D0 @ rva 0x3AE8D0 ====
__int64 __fastcall sub_7FF91E00E8D0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 9));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 56LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00E950 @ rva 0x3AE950 ====
__int64 __fastcall sub_7FF91E00E950(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 9));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 48LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00E9D0 @ rva 0x3AE9D0 ====
__int64 __fastcall sub_7FF91E00E9D0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 9));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 64LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00EA50 @ rva 0x3AEA50 ====
__int64 __fastcall sub_7FF91E00EA50(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 9));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 72LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00EAD0 @ rva 0x3AEAD0 ====
__int64 __fastcall sub_7FF91E00EAD0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 9));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 88LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00EB50 @ rva 0x3AEB50 ====
__int64 __fastcall sub_7FF91E00EB50(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 9));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 80LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00EBD0 @ rva 0x3AEBD0 ====
__int64 __fastcall sub_7FF91E00EBD0(__int64 a1)
{
  __int64 (__fastcall ***v1)(_QWORD); // rcx
  __int64 result; // rax

  v1 = *(__int64 (__fastcall ****)(_QWORD))(a1 + 832);
  if ( v1 )
    return (**v1)(v1);
  return result;
}


// ==== nullsub_25 @ rva 0x3AEBF0 ====
void nullsub_25()
{
  ;
}


// ==== nullsub_987 @ rva 0x3AEC00 ====
void nullsub_987()
{
  ;
}


// ==== nullsub_988 @ rva 0x3AEC10 ====
void nullsub_988()
{
  ;
}


// ==== nullsub_989 @ rva 0x3AEC20 ====
void nullsub_989()
{
  ;
}


// ==== nullsub_26 @ rva 0x3AEC30 ====
void nullsub_26()
{
  ;
}


// ==== nullsub_27 @ rva 0x3AEC40 ====
void nullsub_27()
{
  ;
}


// ==== nullsub_990 @ rva 0x3AEC50 ====
void nullsub_990()
{
  ;
}


// ==== sub_7FF91E00EC60 @ rva 0x3AEC60 ====
__int64 __fastcall sub_7FF91E00EC60(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v4; // edi
  __int64 v6; // rcx
  __int64 v7; // rcx

  v4 = a2;
  if ( a3 )
  {
    if ( !*(_DWORD *)(a1 + 1620) )
    {
      v6 = *(_QWORD *)(a1 + 272);
      if ( v6 )
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 128LL))(v6, a2, 1);
    }
  }
  else
  {
    v7 = *(_QWORD *)(a1 + 272);
    if ( v7 )
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 136LL))(v7, a2, 1);
  }
  return sub_7FF91E011BB0(a1, v4, a3, 0);
}


// ==== sub_7FF91E00ECE0 @ rva 0x3AECE0 ====
__int64 __fastcall sub_7FF91E00ECE0(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v4; // edi
  __int64 v6; // rcx
  __int64 v7; // rcx

  v4 = a2;
  if ( a3 )
  {
    if ( !*(_DWORD *)(a1 + 1624) )
    {
      v6 = *(_QWORD *)(a1 + 288);
      if ( v6 )
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 128LL))(v6, a2, 1);
    }
  }
  else
  {
    v7 = *(_QWORD *)(a1 + 288);
    if ( v7 )
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 136LL))(v7, a2, 1);
  }
  return sub_7FF91E011BB0(a1, v4, a3, 1);
}


// ==== sub_7FF91E00ED60 @ rva 0x3AED60 ====
__int64 __fastcall sub_7FF91E00ED60(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v4; // edi
  __int64 v6; // rcx
  __int64 v7; // rcx

  v4 = a2;
  if ( a3 )
  {
    if ( !*(_DWORD *)(a1 + 1628) )
    {
      v6 = *(_QWORD *)(a1 + 304);
      if ( v6 )
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 128LL))(v6, a2, 1);
    }
  }
  else
  {
    v7 = *(_QWORD *)(a1 + 304);
    if ( v7 )
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 136LL))(v7, a2, 1);
  }
  return sub_7FF91E011BB0(a1, v4, a3, 2);
}


// ==== sub_7FF91E00EDE0 @ rva 0x3AEDE0 ====
__int64 __fastcall sub_7FF91E00EDE0(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v4; // edi
  __int64 v6; // rcx
  __int64 v7; // rcx

  v4 = a2;
  if ( a3 )
  {
    if ( !*(_DWORD *)(a1 + 1632) )
    {
      v6 = *(_QWORD *)(a1 + 320);
      if ( v6 )
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 128LL))(v6, a2, 1);
    }
  }
  else
  {
    v7 = *(_QWORD *)(a1 + 320);
    if ( v7 )
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 136LL))(v7, a2, 1);
  }
  return sub_7FF91E011BB0(a1, v4, a3, 3);
}


// ==== sub_7FF91E00EE60 @ rva 0x3AEE60 ====
__int64 __fastcall sub_7FF91E00EE60(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v4; // edi
  __int64 v6; // rcx
  __int64 v7; // rcx

  v4 = a2;
  if ( a3 )
  {
    if ( !*(_DWORD *)(a1 + 1636) )
    {
      v6 = *(_QWORD *)(a1 + 336);
      if ( v6 )
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 128LL))(v6, a2, 1);
    }
  }
  else
  {
    v7 = *(_QWORD *)(a1 + 336);
    if ( v7 )
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 136LL))(v7, a2, 1);
  }
  return sub_7FF91E011BB0(a1, v4, a3, 4);
}


// ==== sub_7FF91E00EEE0 @ rva 0x3AEEE0 ====
__int64 __fastcall sub_7FF91E00EEE0(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v4; // edi
  __int64 v6; // rcx
  __int64 v7; // rcx

  v4 = a2;
  if ( a3 )
  {
    if ( !*(_DWORD *)(a1 + 1640) )
    {
      v6 = *(_QWORD *)(a1 + 352);
      if ( v6 )
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 128LL))(v6, a2, 1);
    }
  }
  else
  {
    v7 = *(_QWORD *)(a1 + 352);
    if ( v7 )
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 136LL))(v7, a2, 1);
  }
  return sub_7FF91E011BB0(a1, v4, a3, 5);
}


// ==== sub_7FF91E00EF60 @ rva 0x3AEF60 ====
__int64 __fastcall sub_7FF91E00EF60(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v4; // edi
  __int64 v6; // rcx
  __int64 v7; // rcx

  v4 = a2;
  if ( a3 )
  {
    if ( !*(_DWORD *)(a1 + 1644) )
    {
      v6 = *(_QWORD *)(a1 + 368);
      if ( v6 )
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 128LL))(v6, a2, 1);
    }
  }
  else
  {
    v7 = *(_QWORD *)(a1 + 368);
    if ( v7 )
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 136LL))(v7, a2, 1);
  }
  return sub_7FF91E011BB0(a1, v4, a3, 6);
}


// ==== sub_7FF91E00EFE0 @ rva 0x3AEFE0 ====
__int64 __fastcall sub_7FF91E00EFE0(__int64 a1, __int64 a2, unsigned int a3)
{
  unsigned int v4; // edi
  __int64 v6; // rcx
  __int64 v7; // rcx

  v4 = a2;
  if ( a3 )
  {
    if ( !*(_DWORD *)(a1 + 1648) )
    {
      v6 = *(_QWORD *)(a1 + 384);
      if ( v6 )
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 128LL))(v6, a2, 1);
    }
  }
  else
  {
    v7 = *(_QWORD *)(a1 + 384);
    if ( v7 )
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 136LL))(v7, a2, 1);
  }
  return sub_7FF91E011BB0(a1, v4, a3, 7);
}


// ==== nullsub_991 @ rva 0x3AF060 ====
void nullsub_991()
{
  ;
}


// ==== nullsub_992 @ rva 0x3AF070 ====
void nullsub_992()
{
  ;
}


// ==== nullsub_993 @ rva 0x3AF080 ====
void nullsub_993()
{
  ;
}


// ==== sub_7FF91E00F090 @ rva 0x3AF090 ====
__int64 __fastcall sub_7FF91E00F090(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 41));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 48LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F110 @ rva 0x3AF110 ====
__int64 __fastcall sub_7FF91E00F110(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 41));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 40LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== nullsub_994 @ rva 0x3AF190 ====
void nullsub_994()
{
  ;
}


// ==== nullsub_995 @ rva 0x3AF1A0 ====
void nullsub_995()
{
  ;
}


// ==== sub_7FF91E00F1B0 @ rva 0x3AF1B0 ====
__int64 __fastcall sub_7FF91E00F1B0(__int64 a1, __int64 a2, int a3)
{
  *(_DWORD *)(a1 + 1348) = a3;
  return sub_7FF91E011F40();
}


// ==== nullsub_996 @ rva 0x3AF1C0 ====
void nullsub_996()
{
  ;
}


// ==== sub_7FF91E00F1D0 @ rva 0x3AF1D0 ====
__int64 __fastcall sub_7FF91E00F1D0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 1));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 48LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F250 @ rva 0x3AF250 ====
__int64 __fastcall sub_7FF91E00F250(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 9));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 24LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F2D0 @ rva 0x3AF2D0 ====
__int64 __fastcall sub_7FF91E00F2D0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 1));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 16LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F350 @ rva 0x3AF350 ====
__int64 __fastcall sub_7FF91E00F350(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 1));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 24LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F3D0 @ rva 0x3AF3D0 ====
__int64 __fastcall sub_7FF91E00F3D0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 1));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 40LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F450 @ rva 0x3AF450 ====
__int64 __fastcall sub_7FF91E00F450(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 1));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 56LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== nullsub_997 @ rva 0x3AF4D0 ====
void nullsub_997()
{
  ;
}


// ==== nullsub_998 @ rva 0x3AF4E0 ====
void nullsub_998()
{
  ;
}


// ==== nullsub_999 @ rva 0x3AF4F0 ====
void nullsub_999()
{
  ;
}


// ==== nullsub_1000 @ rva 0x3AF500 ====
void nullsub_1000()
{
  ;
}


// ==== sub_7FF91E00F510 @ rva 0x3AF510 ====
__int64 __fastcall sub_7FF91E00F510(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 48LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F590 @ rva 0x3AF590 ====
__int64 __fastcall sub_7FF91E00F590(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 56LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F610 @ rva 0x3AF610 ====
__int64 __fastcall sub_7FF91E00F610(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 264LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F690 @ rva 0x3AF690 ====
__int64 __fastcall sub_7FF91E00F690(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 240LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F710 @ rva 0x3AF710 ====
__int64 __fastcall sub_7FF91E00F710(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 248LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F790 @ rva 0x3AF790 ====
__int64 __fastcall sub_7FF91E00F790(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 256LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F810 @ rva 0x3AF810 ====
__int64 __fastcall sub_7FF91E00F810(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rbx
  __int64 result; // rax
  _QWORD *v8; // rdi
  int v9; // ebx
  _QWORD *v10; // rdi

  v3 = *(int *)(a1 + 1612);
  result = *(unsigned int *)(a1 + 1616);
  if ( (int)v3 <= (int)result )
  {
    v8 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v8 )
        (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v8 + 160LL))(*v8, a2, a3);
      result = *(unsigned int *)(a1 + 1616);
      LODWORD(v3) = v3 + 1;
      v8 += 2;
    }
    while ( (int)v3 <= (int)result );
    v9 = *(_DWORD *)(a1 + 1612);
    if ( v9 <= (int)result )
    {
      v10 = (_QWORD *)(a1 + 16 * (v9 + 33LL));
      do
      {
        if ( *v10 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v10 + 88LL))(*v10, a2, a3);
        ++v9;
        v10 += 2;
      }
      while ( v9 <= *(_DWORD *)(a1 + 1616) );
    }
  }
  return result;
}


// ==== sub_7FF91E00F8D0 @ rva 0x3AF8D0 ====
__int64 __fastcall sub_7FF91E00F8D0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 64LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F950 @ rva 0x3AF950 ====
__int64 __fastcall sub_7FF91E00F950(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 33));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 96LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00F9D0 @ rva 0x3AF9D0 ====
__int64 __fastcall sub_7FF91E00F9D0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 168LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00FA50 @ rva 0x3AFA50 ====
__int64 __fastcall sub_7FF91E00FA50(__int64 a1)
{
  __int64 v1; // rcx
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 848);
  if ( v1 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 8LL))(v1);
  return result;
}


// ==== sub_7FF91E00FA70 @ rva 0x3AFA70 ====
__int64 __fastcall sub_7FF91E00FA70(__int64 a1, unsigned int a2, int a3)
{
  *(_DWORD *)(a1 + 1352) = a3;
  sub_7FF91E011E70();
  return sub_7FF91E011F40(a1, a2);
}


// ==== nullsub_1001 @ rva 0x3AFAA0 ====
void nullsub_1001()
{
  ;
}


// ==== nullsub_1002 @ rva 0x3AFAB0 ====
void nullsub_1002()
{
  ;
}


// ==== nullsub_1003 @ rva 0x3AFAC0 ====
void nullsub_1003()
{
  ;
}


// ==== nullsub_1004 @ rva 0x3AFAD0 ====
void nullsub_1004()
{
  ;
}


// ==== nullsub_1005 @ rva 0x3AFAE0 ====
void nullsub_1005()
{
  ;
}


// ==== nullsub_1006 @ rva 0x3AFAF0 ====
void nullsub_1006()
{
  ;
}


// ==== nullsub_1007 @ rva 0x3AFB00 ====
void nullsub_1007()
{
  ;
}


// ==== nullsub_1008 @ rva 0x3AFB10 ====
void nullsub_1008()
{
  ;
}


// ==== nullsub_1009 @ rva 0x3AFB20 ====
void nullsub_1009()
{
  ;
}


// ==== nullsub_1010 @ rva 0x3AFB30 ====
void nullsub_1010()
{
  ;
}


// ==== nullsub_1011 @ rva 0x3AFB40 ====
void nullsub_1011()
{
  ;
}


// ==== nullsub_1012 @ rva 0x3AFB50 ====
void nullsub_1012()
{
  ;
}


// ==== nullsub_1013 @ rva 0x3AFB60 ====
void nullsub_1013()
{
  ;
}


// ==== nullsub_1014 @ rva 0x3AFB70 ====
void nullsub_1014()
{
  ;
}


// ==== nullsub_1015 @ rva 0x3AFB80 ====
void nullsub_1015()
{
  ;
}


// ==== sub_7FF91E00FB90 @ rva 0x3AFB90 ====
__int64 __fastcall sub_7FF91E00FB90(__int64 a1, __int64 a2, __int64 a3)
{
  return sub_7FF91E011DD0(a1, a2, a3, 0);
}


// ==== sub_7FF91E00FBA0 @ rva 0x3AFBA0 ====
__int64 __fastcall sub_7FF91E00FBA0(__int64 a1, __int64 a2, __int64 a3)
{
  return sub_7FF91E011DD0(a1, a2, a3, 1);
}


// ==== sub_7FF91E00FBB0 @ rva 0x3AFBB0 ====
__int64 __fastcall sub_7FF91E00FBB0(__int64 a1, __int64 a2, __int64 a3)
{
  return sub_7FF91E011DD0(a1, a2, a3, 2);
}


// ==== sub_7FF91E00FBC0 @ rva 0x3AFBC0 ====
__int64 __fastcall sub_7FF91E00FBC0(__int64 a1, __int64 a2, __int64 a3)
{
  return sub_7FF91E011DD0(a1, a2, a3, 3);
}


// ==== sub_7FF91E00FBD0 @ rva 0x3AFBD0 ====
__int64 __fastcall sub_7FF91E00FBD0(__int64 a1, __int64 a2, __int64 a3)
{
  return sub_7FF91E011DD0(a1, a2, a3, 4);
}


// ==== sub_7FF91E00FBE0 @ rva 0x3AFBE0 ====
__int64 __fastcall sub_7FF91E00FBE0(__int64 a1, __int64 a2, __int64 a3)
{
  return sub_7FF91E011DD0(a1, a2, a3, 5);
}


// ==== sub_7FF91E00FBF0 @ rva 0x3AFBF0 ====
__int64 __fastcall sub_7FF91E00FBF0(__int64 a1, __int64 a2, __int64 a3)
{
  return sub_7FF91E011DD0(a1, a2, a3, 6);
}


// ==== sub_7FF91E00FC00 @ rva 0x3AFC00 ====
__int64 __fastcall sub_7FF91E00FC00(__int64 a1, __int64 a2, __int64 a3)
{
  return sub_7FF91E011DD0(a1, a2, a3, 7);
}


// ==== sub_7FF91E00FC10 @ rva 0x3AFC10 ====
__int64 __fastcall sub_7FF91E00FC10(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 56LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00FC90 @ rva 0x3AFC90 ====
__int64 __fastcall sub_7FF91E00FC90(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 192LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00FD10 @ rva 0x3AFD10 ====
__int64 __fastcall sub_7FF91E00FD10(__int64 a1)
{
  __int64 (__fastcall ***v1)(_QWORD); // rcx
  __int64 result; // rax

  v1 = *(__int64 (__fastcall ****)(_QWORD))(a1 + 816);
  if ( v1 )
    return (**v1)(v1);
  return result;
}


// ==== nullsub_1016 @ rva 0x3AFD30 ====
void nullsub_1016()
{
  ;
}


// ==== sub_7FF91E00FD40 @ rva 0x3AFD40 ====
__int64 __fastcall sub_7FF91E00FD40(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rbx
  __int64 result; // rax
  _QWORD *v8; // rdi
  int v9; // ebx
  _QWORD *v10; // rdi

  v3 = *(int *)(a1 + 1612);
  result = *(unsigned int *)(a1 + 1616);
  if ( (int)v3 <= (int)result )
  {
    v8 = (_QWORD *)(a1 + 16 * (v3 + 25));
    do
    {
      if ( *v8 )
        (*(void (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v8 + 152LL))(*v8, a2, a3);
      result = *(unsigned int *)(a1 + 1616);
      LODWORD(v3) = v3 + 1;
      v8 += 2;
    }
    while ( (int)v3 <= (int)result );
    v9 = *(_DWORD *)(a1 + 1612);
    if ( v9 <= (int)result )
    {
      v10 = (_QWORD *)(a1 + 16 * (v9 + 33LL));
      do
      {
        if ( *v10 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v10 + 80LL))(*v10, a2, a3);
        ++v9;
        v10 += 2;
      }
      while ( v9 <= *(_DWORD *)(a1 + 1616) );
    }
  }
  return result;
}


// ==== nullsub_1017 @ rva 0x3AFE00 ====
void nullsub_1017()
{
  ;
}


// ==== sub_7FF91E00FE10 @ rva 0x3AFE10 ====
__int64 __fastcall sub_7FF91E00FE10(_DWORD *a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  __int64 result; // rax
  _QWORD *v8; // rbx
  __int64 v9; // rdi
  _QWORD *v10; // rbx

  v3 = (int)a1[403];
  result = (unsigned int)a1[404];
  if ( (int)v3 <= (int)result )
  {
    v8 = &a1[4 * v3 + 68];
    do
    {
      if ( *v8 )
        (**(void (__fastcall ***)(_QWORD, _QWORD, _QWORD))*v8)(*v8, a2, a3);
      result = (unsigned int)a1[404];
      LODWORD(v3) = v3 + 1;
      v8 += 2;
    }
    while ( (int)v3 <= (int)result );
  }
  if ( a1[338] || a1[337] != 1 )
  {
    v9 = (int)a1[403];
    if ( (int)v9 <= (int)result )
    {
      v10 = &a1[4 * v9 + 68];
      do
      {
        if ( *v10 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, bool))(*(_QWORD *)*v10 + 8LL))(*v10, a2, a3 != 0);
        LODWORD(v9) = v9 + 1;
        v10 += 2;
      }
      while ( (int)v9 <= a1[404] );
    }
  }
  return result;
}


// ==== nullsub_1018 @ rva 0x3AFEE0 ====
void nullsub_1018()
{
  ;
}


// ==== nullsub_1019 @ rva 0x3AFEF0 ====
void nullsub_1019()
{
  ;
}


// ==== nullsub_1020 @ rva 0x3AFF00 ====
void nullsub_1020()
{
  ;
}


// ==== nullsub_1021 @ rva 0x3AFF10 ====
void nullsub_1021()
{
  ;
}


// ==== nullsub_1022 @ rva 0x3AFF20 ====
void nullsub_1022()
{
  ;
}


// ==== nullsub_1023 @ rva 0x3AFF30 ====
void nullsub_1023()
{
  ;
}


// ==== nullsub_1024 @ rva 0x3AFF40 ====
void nullsub_1024()
{
  ;
}


// ==== nullsub_1025 @ rva 0x3AFF50 ====
void nullsub_1025()
{
  ;
}


// ==== sub_7FF91E00FF60 @ rva 0x3AFF60 ====
__int64 __fastcall sub_7FF91E00FF60(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 0, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E00FFD0 @ rva 0x3AFFD0 ====
__int64 __fastcall sub_7FF91E00FFD0(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 1, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E010040 @ rva 0x3B0040 ====
__int64 __fastcall sub_7FF91E010040(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 2, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E0100B0 @ rva 0x3B00B0 ====
__int64 __fastcall sub_7FF91E0100B0(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 3, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E010120 @ rva 0x3B0120 ====
__int64 __fastcall sub_7FF91E010120(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 4, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E010190 @ rva 0x3B0190 ====
__int64 __fastcall sub_7FF91E010190(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 5, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E010200 @ rva 0x3B0200 ====
__int64 __fastcall sub_7FF91E010200(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 6, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E010270 @ rva 0x3B0270 ====
__int64 __fastcall sub_7FF91E010270(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 7, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E0102E0 @ rva 0x3B02E0 ====
__int64 __fastcall sub_7FF91E0102E0(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 8, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E010350 @ rva 0x3B0350 ====
__int64 __fastcall sub_7FF91E010350(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 9, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E0103C0 @ rva 0x3B03C0 ====
__int64 __fastcall sub_7FF91E0103C0(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 10, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E010430 @ rva 0x3B0430 ====
__int64 __fastcall sub_7FF91E010430(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v6 + 104LL))(*v6, 11, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E0104A0 @ rva 0x3B04A0 ====
__int64 __fastcall sub_7FF91E0104A0(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD))(*(_QWORD *)*v6 + 96LL))(*v6, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E010510 @ rva 0x3B0510 ====
__int64 __fastcall sub_7FF91E010510(__int64 a1, __int64 a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v6; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v6 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v6 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD))(*(_QWORD *)*v6 + 88LL))(*v6, a3);
      LODWORD(v3) = v3 + 1;
      v6 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E010580 @ rva 0x3B0580 ====
__int64 __fastcall sub_7FF91E010580(float *a1, __int64 a2, int a3)
{
  float v3; // xmm2_4
  __int64 result; // rax
  float v5; // [rsp+10h] [rbp+10h]

  if ( !(_DWORD)a2 )
  {
    v5 = a1[375];
    v3 = (float)a3;
    if ( a3 <= 0 )
      return (*(__int64 (__fastcall **)(float *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2600LL))(
               a1,
               0,
               COERCE_UNSIGNED_INT((float)((float)(v3 * v5) * 0.0099999998) + v5));
    else
      return (*(__int64 (__fastcall **)(float *, __int64, _QWORD))(*(_QWORD *)a1 + 2600LL))(
               a1,
               a2,
               COERCE_UNSIGNED_INT((float)((float)((float)(1.0 - v5) * v3) * 0.0099999998) + v5));
  }
  return result;
}


// ==== sub_7FF91E010600 @ rva 0x3B0600 ====
__int64 __fastcall sub_7FF91E010600(unsigned int *a1, int a2, unsigned int a3)
{
  __int64 result; // rax
  __int64 v5; // r8
  unsigned int v6; // ecx

  result = a3;
  if ( !a2 )
  {
    v5 = a1[320];
    if ( (_DWORD)result )
    {
      if ( (int)result <= 0 )
        v6 = a1[320];
      else
        v6 = 255 - v5;
      v5 = (unsigned int)((int)(result * v6) / 100 + v5);
    }
    return (*(__int64 (__fastcall **)(unsigned int *, _QWORD, __int64))(*(_QWORD *)a1 + 2160LL))(a1, 0, v5);
  }
  return result;
}


// ==== sub_7FF91E010650 @ rva 0x3B0650 ====
__int64 __fastcall sub_7FF91E010650(unsigned int *a1, int a2, unsigned int a3)
{
  __int64 result; // rax
  __int64 v5; // r8
  unsigned int v6; // ecx

  result = a3;
  if ( !a2 )
  {
    v5 = a1[319];
    if ( (_DWORD)result )
    {
      if ( (int)result <= 0 )
        v6 = a1[319];
      else
        v6 = 255 - v5;
      v5 = (unsigned int)((int)(result * v6) / 100 + v5);
    }
    return (*(__int64 (__fastcall **)(unsigned int *, _QWORD, __int64))(*(_QWORD *)a1 + 2152LL))(a1, 0, v5);
  }
  return result;
}


// ==== sub_7FF91E0106A0 @ rva 0x3B06A0 ====
__int64 __fastcall sub_7FF91E0106A0(unsigned int *a1, int a2, unsigned int a3)
{
  __int64 result; // rax
  __int64 v5; // r8
  unsigned int v6; // ecx

  result = a3;
  if ( !a2 )
  {
    v5 = a1[311];
    if ( (_DWORD)result )
    {
      if ( (int)result <= 0 )
        v6 = a1[311];
      else
        v6 = 255 - v5;
      v5 = (unsigned int)((int)(result * v6) / 100 + v5);
    }
    return (*(__int64 (__fastcall **)(unsigned int *, _QWORD, __int64))(*(_QWORD *)a1 + 2088LL))(a1, 0, v5);
  }
  return result;
}


// ==== sub_7FF91E0106F0 @ rva 0x3B06F0 ====
__int64 __fastcall sub_7FF91E0106F0(unsigned int *a1, int a2, unsigned int a3)
{
  __int64 result; // rax
  __int64 v5; // r8
  unsigned int v6; // ecx

  result = a3;
  if ( !a2 )
  {
    v5 = a1[336];
    if ( (_DWORD)result )
    {
      if ( (int)result <= 0 )
        v6 = a1[336];
      else
        v6 = 255 - v5;
      v5 = (unsigned int)((int)(result * v6) / 100 + v5);
    }
    return (*(__int64 (__fastcall **)(unsigned int *, _QWORD, __int64))(*(_QWORD *)a1 + 2288LL))(a1, 0, v5);
  }
  return result;
}


// ==== sub_7FF91E010740 @ rva 0x3B0740 ====
__int64 __fastcall sub_7FF91E010740(unsigned int *a1, int a2, unsigned int a3)
{
  __int64 result; // rax
  __int64 v5; // r8
  unsigned int v6; // ecx

  result = a3;
  if ( !a2 )
  {
    v5 = a1[332];
    if ( (_DWORD)result )
    {
      if ( (int)result <= 0 )
        v6 = a1[332];
      else
        v6 = 255 - v5;
      v5 = (unsigned int)((int)(result * v6) / 100 + v5);
    }
    return (*(__int64 (__fastcall **)(unsigned int *, _QWORD, __int64))(*(_QWORD *)a1 + 2256LL))(a1, 0, v5);
  }
  return result;
}


// ==== nullsub_1026 @ rva 0x3B0790 ====
void nullsub_1026()
{
  ;
}


// ==== sub_7FF91E0107A0 @ rva 0x3B07A0 ====
void __fastcall sub_7FF91E0107A0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1440) = a2;
}


// ==== sub_7FF91E0107B0 @ rva 0x3B07B0 ====
void __fastcall sub_7FF91E0107B0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1436) = a2;
}


// ==== sub_7FF91E0107C0 @ rva 0x3B07C0 ====
void __fastcall sub_7FF91E0107C0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1444) = a2;
}


// ==== sub_7FF91E0107D0 @ rva 0x3B07D0 ====
void __fastcall sub_7FF91E0107D0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1356) = a2;
}


// ==== sub_7FF91E0107E0 @ rva 0x3B07E0 ====
void __fastcall sub_7FF91E0107E0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1452) = a2;
}


// ==== sub_7FF91E0107F0 @ rva 0x3B07F0 ====
void __fastcall sub_7FF91E0107F0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1448) = a2;
}


// ==== sub_7FF91E010800 @ rva 0x3B0800 ====
void __fastcall sub_7FF91E010800(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1544) = a2;
}


// ==== sub_7FF91E010810 @ rva 0x3B0810 ====
void __fastcall sub_7FF91E010810(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1556) = a2;
}


// ==== sub_7FF91E010820 @ rva 0x3B0820 ====
void __fastcall sub_7FF91E010820(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1560) = a2;
}


// ==== sub_7FF91E010830 @ rva 0x3B0830 ====
void __fastcall sub_7FF91E010830(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1552) = a2;
}


// ==== sub_7FF91E010840 @ rva 0x3B0840 ====
void __fastcall sub_7FF91E010840(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1548) = a2;
}


// ==== sub_7FF91E010850 @ rva 0x3B0850 ====
void __fastcall sub_7FF91E010850(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1540) = a2;
}


// ==== sub_7FF91E010860 @ rva 0x3B0860 ====
void __fastcall sub_7FF91E010860(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1244) = a2;
}


// ==== sub_7FF91E010870 @ rva 0x3B0870 ====
void __fastcall sub_7FF91E010870(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1012) = a2;
}


// ==== sub_7FF91E010880 @ rva 0x3B0880 ====
void __fastcall sub_7FF91E010880(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1060) = a2;
}


// ==== sub_7FF91E010890 @ rva 0x3B0890 ====
void __fastcall sub_7FF91E010890(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1064) = a2;
}


// ==== sub_7FF91E0108A0 @ rva 0x3B08A0 ====
void __fastcall sub_7FF91E0108A0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1068) = a2;
}


// ==== sub_7FF91E0108B0 @ rva 0x3B08B0 ====
void __fastcall sub_7FF91E0108B0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1072) = a2;
}


// ==== sub_7FF91E0108C0 @ rva 0x3B08C0 ====
void __fastcall sub_7FF91E0108C0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1076) = a2;
}


// ==== sub_7FF91E0108D0 @ rva 0x3B08D0 ====
void __fastcall sub_7FF91E0108D0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1080) = a2;
}


// ==== sub_7FF91E0108E0 @ rva 0x3B08E0 ====
void __fastcall sub_7FF91E0108E0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1084) = a2;
}


// ==== sub_7FF91E0108F0 @ rva 0x3B08F0 ====
void __fastcall sub_7FF91E0108F0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1088) = a2;
}


// ==== sub_7FF91E010900 @ rva 0x3B0900 ====
void __fastcall sub_7FF91E010900(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1520) = a2;
}


// ==== sub_7FF91E010910 @ rva 0x3B0910 ====
void __fastcall sub_7FF91E010910(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1512) = a2;
}


// ==== sub_7FF91E010920 @ rva 0x3B0920 ====
void __fastcall sub_7FF91E010920(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1532) = a2;
}


// ==== sub_7FF91E010930 @ rva 0x3B0930 ====
void __fastcall sub_7FF91E010930(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1536) = a2;
}


// ==== sub_7FF91E010940 @ rva 0x3B0940 ====
void __fastcall sub_7FF91E010940(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1336) = a2;
}


// ==== sub_7FF91E010950 @ rva 0x3B0950 ====
void __fastcall sub_7FF91E010950(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1524) = a2;
}


// ==== sub_7FF91E010960 @ rva 0x3B0960 ====
void __fastcall sub_7FF91E010960(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1528) = a2;
}


// ==== sub_7FF91E010970 @ rva 0x3B0970 ====
void __fastcall sub_7FF91E010970(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1516) = a2;
}


// ==== sub_7FF91E010980 @ rva 0x3B0980 ====
void __fastcall sub_7FF91E010980(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1508) = a2;
}


// ==== sub_7FF91E010990 @ rva 0x3B0990 ====
void __fastcall sub_7FF91E010990(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1340) = a2;
}


// ==== sub_7FF91E0109A0 @ rva 0x3B09A0 ====
void __fastcall sub_7FF91E0109A0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1480) = a2;
}


// ==== sub_7FF91E0109B0 @ rva 0x3B09B0 ====
void __fastcall sub_7FF91E0109B0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1328) = a2;
}


// ==== sub_7FF91E0109C0 @ rva 0x3B09C0 ====
void __fastcall sub_7FF91E0109C0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1476) = a2;
}


// ==== sub_7FF91E0109D0 @ rva 0x3B09D0 ====
void __fastcall sub_7FF91E0109D0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1472) = a2;
}


// ==== sub_7FF91E0109E0 @ rva 0x3B09E0 ====
void __fastcall sub_7FF91E0109E0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1288) = a2;
}


// ==== sub_7FF91E0109F0 @ rva 0x3B09F0 ====
void __fastcall sub_7FF91E0109F0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1292) = a2;
}


// ==== sub_7FF91E010A00 @ rva 0x3B0A00 ====
void __fastcall sub_7FF91E010A00(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1300) = a2;
}


// ==== sub_7FF91E010A10 @ rva 0x3B0A10 ====
void __fastcall sub_7FF91E010A10(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1296) = a2;
}


// ==== sub_7FF91E010A20 @ rva 0x3B0A20 ====
void __fastcall sub_7FF91E010A20(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1308) = a2;
}


// ==== sub_7FF91E010A30 @ rva 0x3B0A30 ====
void __fastcall sub_7FF91E010A30(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1312) = a2;
}


// ==== sub_7FF91E010A40 @ rva 0x3B0A40 ====
void __fastcall sub_7FF91E010A40(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1320) = a2;
}


// ==== sub_7FF91E010A50 @ rva 0x3B0A50 ====
void __fastcall sub_7FF91E010A50(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1316) = a2;
}


// ==== sub_7FF91E010A60 @ rva 0x3B0A60 ====
void __fastcall sub_7FF91E010A60(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1168) = a2;
}


// ==== sub_7FF91E010A70 @ rva 0x3B0A70 ====
void __fastcall sub_7FF91E010A70(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1576) = a2;
}


// ==== sub_7FF91E010A80 @ rva 0x3B0A80 ====
void __fastcall sub_7FF91E010A80(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1584) = a2;
}


// ==== sub_7FF91E010A90 @ rva 0x3B0A90 ====
void __fastcall sub_7FF91E010A90(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1588) = a2;
}


// ==== sub_7FF91E010AA0 @ rva 0x3B0AA0 ====
void __fastcall sub_7FF91E010AA0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1580) = a2;
}


// ==== sub_7FF91E010AB0 @ rva 0x3B0AB0 ====
void __fastcall sub_7FF91E010AB0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1564) = a2;
}


// ==== sub_7FF91E010AC0 @ rva 0x3B0AC0 ====
void __fastcall sub_7FF91E010AC0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1568) = a2;
}


// ==== sub_7FF91E010AD0 @ rva 0x3B0AD0 ====
void __fastcall sub_7FF91E010AD0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1572) = a2;
}


// ==== sub_7FF91E010AE0 @ rva 0x3B0AE0 ====
void __fastcall sub_7FF91E010AE0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1092) = a2;
}


// ==== sub_7FF91E010AF0 @ rva 0x3B0AF0 ====
void __fastcall sub_7FF91E010AF0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1096) = a2;
}


// ==== sub_7FF91E010B00 @ rva 0x3B0B00 ====
void __fastcall sub_7FF91E010B00(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1100) = a2;
}


// ==== sub_7FF91E010B10 @ rva 0x3B0B10 ====
void __fastcall sub_7FF91E010B10(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1104) = a2;
}


// ==== sub_7FF91E010B20 @ rva 0x3B0B20 ====
void __fastcall sub_7FF91E010B20(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1108) = a2;
}


// ==== sub_7FF91E010B30 @ rva 0x3B0B30 ====
void __fastcall sub_7FF91E010B30(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1112) = a2;
}


// ==== sub_7FF91E010B40 @ rva 0x3B0B40 ====
void __fastcall sub_7FF91E010B40(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1116) = a2;
}


// ==== sub_7FF91E010B50 @ rva 0x3B0B50 ====
void __fastcall sub_7FF91E010B50(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1120) = a2;
}


// ==== sub_7FF91E010B60 @ rva 0x3B0B60 ====
void __fastcall sub_7FF91E010B60(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1180) = a2;
}


// ==== sub_7FF91E010B70 @ rva 0x3B0B70 ====
void __fastcall sub_7FF91E010B70(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1172) = a2;
}


// ==== sub_7FF91E010B80 @ rva 0x3B0B80 ====
void __fastcall sub_7FF91E010B80(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1176) = a2;
}


// ==== sub_7FF91E010B90 @ rva 0x3B0B90 ====
void __fastcall sub_7FF91E010B90(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1280) = a2;
}


// ==== sub_7FF91E010BA0 @ rva 0x3B0BA0 ====
void __fastcall sub_7FF91E010BA0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1468) = a2;
}


// ==== sub_7FF91E010BB0 @ rva 0x3B0BB0 ====
void __fastcall sub_7FF91E010BB0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1020) = a2;
}


// ==== sub_7FF91E010BC0 @ rva 0x3B0BC0 ====
void __fastcall sub_7FF91E010BC0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1368) = a2;
}


// ==== sub_7FF91E010BD0 @ rva 0x3B0BD0 ====
void __fastcall sub_7FF91E010BD0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1348) = a2;
}


// ==== sub_7FF91E010BE0 @ rva 0x3B0BE0 ====
void __fastcall sub_7FF91E010BE0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1432) = a2;
}


// ==== sub_7FF91E010BF0 @ rva 0x3B0BF0 ====
void __fastcall sub_7FF91E010BF0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1220) = a2;
}


// ==== sub_7FF91E010C00 @ rva 0x3B0C00 ====
void __fastcall sub_7FF91E010C00(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1464) = a2;
}


// ==== sub_7FF91E010C10 @ rva 0x3B0C10 ====
void __fastcall sub_7FF91E010C10(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1224) = a2;
}


// ==== sub_7FF91E010C20 @ rva 0x3B0C20 ====
void __fastcall sub_7FF91E010C20(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1492) = a2;
}


// ==== sub_7FF91E010C30 @ rva 0x3B0C30 ====
void __fastcall sub_7FF91E010C30(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1056) = a2;
}


// ==== sub_7FF91E010C40 @ rva 0x3B0C40 ====
void __fastcall sub_7FF91E010C40(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1236) = a2;
}


// ==== sub_7FF91E010C50 @ rva 0x3B0C50 ====
void __fastcall sub_7FF91E010C50(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1212) = a2;
}


// ==== sub_7FF91E010C60 @ rva 0x3B0C60 ====
void __fastcall sub_7FF91E010C60(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1216) = a2;
}


// ==== sub_7FF91E010C70 @ rva 0x3B0C70 ====
void __fastcall sub_7FF91E010C70(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1204) = a2;
}


// ==== sub_7FF91E010C80 @ rva 0x3B0C80 ====
void __fastcall sub_7FF91E010C80(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1208) = a2;
}


// ==== sub_7FF91E010C90 @ rva 0x3B0C90 ====
void __fastcall sub_7FF91E010C90(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 944) = a2;
}


// ==== sub_7FF91E010CA0 @ rva 0x3B0CA0 ====
void __fastcall sub_7FF91E010CA0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 948) = a2;
}


// ==== sub_7FF91E010CB0 @ rva 0x3B0CB0 ====
void __fastcall sub_7FF91E010CB0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1268) = a2;
}


// ==== sub_7FF91E010CC0 @ rva 0x3B0CC0 ====
void __fastcall sub_7FF91E010CC0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1256) = a2;
}


// ==== sub_7FF91E010CD0 @ rva 0x3B0CD0 ====
void __fastcall sub_7FF91E010CD0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1260) = a2;
}


// ==== sub_7FF91E010CE0 @ rva 0x3B0CE0 ====
void __fastcall sub_7FF91E010CE0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1264) = a2;
}


// ==== sub_7FF91E010CF0 @ rva 0x3B0CF0 ====
void __fastcall sub_7FF91E010CF0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1164) = a2;
}


// ==== sub_7FF91E010D00 @ rva 0x3B0D00 ====
void __fastcall sub_7FF91E010D00(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1248) = a2;
}


// ==== sub_7FF91E010D10 @ rva 0x3B0D10 ====
void __fastcall sub_7FF91E010D10(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1460) = a2;
}


// ==== sub_7FF91E010D20 @ rva 0x3B0D20 ====
void __fastcall sub_7FF91E010D20(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1456) = a2;
}


// ==== sub_7FF91E010D30 @ rva 0x3B0D30 ====
void __fastcall sub_7FF91E010D30(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1156) = a2;
}


// ==== sub_7FF91E010D40 @ rva 0x3B0D40 ====
void __fastcall sub_7FF91E010D40(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1352) = a2;
}


// ==== sub_7FF91E010D50 @ rva 0x3B0D50 ====
void __fastcall sub_7FF91E010D50(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1428) = a2;
}


// ==== sub_7FF91E010D60 @ rva 0x3B0D60 ====
void __fastcall sub_7FF91E010D60(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1424) = a2;
}


// ==== sub_7FF91E010D70 @ rva 0x3B0D70 ====
void __fastcall sub_7FF91E010D70(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1420) = a2;
}


// ==== sub_7FF91E010D80 @ rva 0x3B0D80 ====
void __fastcall sub_7FF91E010D80(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1416) = a2;
}


// ==== sub_7FF91E010D90 @ rva 0x3B0D90 ====
void __fastcall sub_7FF91E010D90(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1388) = a2;
}


// ==== sub_7FF91E010DA0 @ rva 0x3B0DA0 ====
void __fastcall sub_7FF91E010DA0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1372) = a2;
}


// ==== sub_7FF91E010DB0 @ rva 0x3B0DB0 ====
void __fastcall sub_7FF91E010DB0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1384) = a2;
}


// ==== sub_7FF91E010DC0 @ rva 0x3B0DC0 ====
void __fastcall sub_7FF91E010DC0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1380) = a2;
}


// ==== sub_7FF91E010DD0 @ rva 0x3B0DD0 ====
void __fastcall sub_7FF91E010DD0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1376) = a2;
}


// ==== sub_7FF91E010DE0 @ rva 0x3B0DE0 ====
void __fastcall sub_7FF91E010DE0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1392) = a2;
}


// ==== sub_7FF91E010DF0 @ rva 0x3B0DF0 ====
void __fastcall sub_7FF91E010DF0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1400) = a2;
}


// ==== sub_7FF91E010E00 @ rva 0x3B0E00 ====
void __fastcall sub_7FF91E010E00(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1396) = a2;
}


// ==== sub_7FF91E010E10 @ rva 0x3B0E10 ====
void __fastcall sub_7FF91E010E10(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1404) = a2;
}


// ==== sub_7FF91E010E20 @ rva 0x3B0E20 ====
void __fastcall sub_7FF91E010E20(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1412) = a2;
}


// ==== sub_7FF91E010E30 @ rva 0x3B0E30 ====
void __fastcall sub_7FF91E010E30(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1408) = a2;
}


// ==== sub_7FF91E010E40 @ rva 0x3B0E40 ====
void __fastcall sub_7FF91E010E40(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1124) = a2;
}


// ==== sub_7FF91E010E50 @ rva 0x3B0E50 ====
void __fastcall sub_7FF91E010E50(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1128) = a2;
}


// ==== sub_7FF91E010E60 @ rva 0x3B0E60 ====
void __fastcall sub_7FF91E010E60(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1132) = a2;
}


// ==== sub_7FF91E010E70 @ rva 0x3B0E70 ====
void __fastcall sub_7FF91E010E70(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1136) = a2;
}


// ==== sub_7FF91E010E80 @ rva 0x3B0E80 ====
void __fastcall sub_7FF91E010E80(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1140) = a2;
}


// ==== sub_7FF91E010E90 @ rva 0x3B0E90 ====
void __fastcall sub_7FF91E010E90(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1144) = a2;
}


// ==== sub_7FF91E010EA0 @ rva 0x3B0EA0 ====
void __fastcall sub_7FF91E010EA0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1148) = a2;
}


// ==== sub_7FF91E010EB0 @ rva 0x3B0EB0 ====
void __fastcall sub_7FF91E010EB0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1152) = a2;
}


// ==== sub_7FF91E010EC0 @ rva 0x3B0EC0 ====
void __fastcall sub_7FF91E010EC0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1252) = a2;
}


// ==== sub_7FF91E010ED0 @ rva 0x3B0ED0 ====
void __fastcall sub_7FF91E010ED0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1228) = a2;
}


// ==== sub_7FF91E010EE0 @ rva 0x3B0EE0 ====
void __fastcall sub_7FF91E010EE0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1364) = a2;
}


// ==== sub_7FF91E010EF0 @ rva 0x3B0EF0 ====
void __fastcall sub_7FF91E010EF0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1184) = a2;
}


// ==== sub_7FF91E010F00 @ rva 0x3B0F00 ====
void __fastcall sub_7FF91E010F00(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1160) = a2;
}


// ==== sub_7FF91E010F10 @ rva 0x3B0F10 ====
void __fastcall sub_7FF91E010F10(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1016) = a2;
}


// ==== sub_7FF91E010F20 @ rva 0x3B0F20 ====
void __fastcall sub_7FF91E010F20(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1344) = a2;
}


// ==== sub_7FF91E010F30 @ rva 0x3B0F30 ====
void __fastcall sub_7FF91E010F30(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1604) = a2;
}


// ==== sub_7FF91E010F40 @ rva 0x3B0F40 ====
void __fastcall sub_7FF91E010F40(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1608) = a2;
}


// ==== sub_7FF91E010F50 @ rva 0x3B0F50 ====
void __fastcall sub_7FF91E010F50(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1596) = a2;
}


// ==== sub_7FF91E010F60 @ rva 0x3B0F60 ====
void __fastcall sub_7FF91E010F60(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1332) = a2;
}


// ==== sub_7FF91E010F70 @ rva 0x3B0F70 ====
void __fastcall sub_7FF91E010F70(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1600) = a2;
}


// ==== sub_7FF91E010F80 @ rva 0x3B0F80 ====
void __fastcall sub_7FF91E010F80(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1592) = a2;
}


// ==== sub_7FF91E010F90 @ rva 0x3B0F90 ====
void __fastcall sub_7FF91E010F90(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1488) = a2;
}


// ==== sub_7FF91E010FA0 @ rva 0x3B0FA0 ====
void __fastcall sub_7FF91E010FA0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1484) = a2;
}


// ==== sub_7FF91E010FB0 @ rva 0x3B0FB0 ====
void __fastcall sub_7FF91E010FB0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 960) = a2;
}


// ==== sub_7FF91E010FC0 @ rva 0x3B0FC0 ====
void __fastcall sub_7FF91E010FC0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 964) = a2;
}


// ==== sub_7FF91E010FD0 @ rva 0x3B0FD0 ====
void __fastcall sub_7FF91E010FD0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 968) = a2;
}


// ==== sub_7FF91E010FE0 @ rva 0x3B0FE0 ====
void __fastcall sub_7FF91E010FE0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 972) = a2;
}


// ==== sub_7FF91E010FF0 @ rva 0x3B0FF0 ====
void __fastcall sub_7FF91E010FF0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 976) = a2;
}


// ==== sub_7FF91E011000 @ rva 0x3B1000 ====
void __fastcall sub_7FF91E011000(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 980) = a2;
}


// ==== sub_7FF91E011010 @ rva 0x3B1010 ====
void __fastcall sub_7FF91E011010(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 984) = a2;
}


// ==== sub_7FF91E011020 @ rva 0x3B1020 ====
void __fastcall sub_7FF91E011020(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 988) = a2;
}


// ==== sub_7FF91E011030 @ rva 0x3B1030 ====
void __fastcall sub_7FF91E011030(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 992) = a2;
}


// ==== sub_7FF91E011040 @ rva 0x3B1040 ====
void __fastcall sub_7FF91E011040(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 996) = a2;
}


// ==== sub_7FF91E011050 @ rva 0x3B1050 ====
void __fastcall sub_7FF91E011050(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1000) = a2;
}


// ==== sub_7FF91E011060 @ rva 0x3B1060 ====
void __fastcall sub_7FF91E011060(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1004) = a2;
}


// ==== sub_7FF91E011070 @ rva 0x3B1070 ====
void __fastcall sub_7FF91E011070(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 956) = a2;
}


// ==== sub_7FF91E011080 @ rva 0x3B1080 ====
void __fastcall sub_7FF91E011080(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 952) = a2;
}


// ==== sub_7FF91E011090 @ rva 0x3B1090 ====
void __fastcall sub_7FF91E011090(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1024) = a2;
}


// ==== sub_7FF91E0110A0 @ rva 0x3B10A0 ====
void __fastcall sub_7FF91E0110A0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1028) = a2;
}


// ==== sub_7FF91E0110B0 @ rva 0x3B10B0 ====
void __fastcall sub_7FF91E0110B0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1032) = a2;
}


// ==== sub_7FF91E0110C0 @ rva 0x3B10C0 ====
void __fastcall sub_7FF91E0110C0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1036) = a2;
}


// ==== sub_7FF91E0110D0 @ rva 0x3B10D0 ====
void __fastcall sub_7FF91E0110D0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1040) = a2;
}


// ==== sub_7FF91E0110E0 @ rva 0x3B10E0 ====
void __fastcall sub_7FF91E0110E0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1044) = a2;
}


// ==== sub_7FF91E0110F0 @ rva 0x3B10F0 ====
void __fastcall sub_7FF91E0110F0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1048) = a2;
}


// ==== sub_7FF91E011100 @ rva 0x3B1100 ====
void __fastcall sub_7FF91E011100(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1008) = a2;
}


// ==== sub_7FF91E011110 @ rva 0x3B1110 ====
void __fastcall sub_7FF91E011110(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1360) = a2;
}


// ==== sub_7FF91E011120 @ rva 0x3B1120 ====
void __fastcall sub_7FF91E011120(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1324) = a2;
}


// ==== sub_7FF91E011130 @ rva 0x3B1130 ====
void __fastcall sub_7FF91E011130(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1196) = a2;
}


// ==== sub_7FF91E011140 @ rva 0x3B1140 ====
void __fastcall sub_7FF91E011140(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1200) = a2;
}


// ==== sub_7FF91E011150 @ rva 0x3B1150 ====
void __fastcall sub_7FF91E011150(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1188) = a2;
}


// ==== sub_7FF91E011160 @ rva 0x3B1160 ====
void __fastcall sub_7FF91E011160(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1192) = a2;
}


// ==== sub_7FF91E011170 @ rva 0x3B1170 ====
void __fastcall sub_7FF91E011170(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1272) = a2;
}


// ==== sub_7FF91E011180 @ rva 0x3B1180 ====
void __fastcall sub_7FF91E011180(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1500) = a2;
}


// ==== sub_7FF91E011190 @ rva 0x3B1190 ====
void __fastcall sub_7FF91E011190(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1284) = a2;
}


// ==== sub_7FF91E0111A0 @ rva 0x3B11A0 ====
void __fastcall sub_7FF91E0111A0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1304) = a2;
}


// ==== sub_7FF91E0111B0 @ rva 0x3B11B0 ====
void __fastcall sub_7FF91E0111B0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1232) = a2;
}


// ==== sub_7FF91E0111C0 @ rva 0x3B11C0 ====
void __fastcall sub_7FF91E0111C0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1276) = a2;
}


// ==== sub_7FF91E0111D0 @ rva 0x3B11D0 ====
void __fastcall sub_7FF91E0111D0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1504) = a2;
}


// ==== sub_7FF91E0111E0 @ rva 0x3B11E0 ====
void __fastcall sub_7FF91E0111E0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1496) = a2;
}


// ==== sub_7FF91E0111F0 @ rva 0x3B11F0 ====
void __fastcall sub_7FF91E0111F0(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1052) = a2;
}


// ==== sub_7FF91E011200 @ rva 0x3B1200 ====
void __fastcall sub_7FF91E011200(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 1240) = a2;
}


// ==== nullsub_1027 @ rva 0x3B1210 ====
void nullsub_1027()
{
  ;
}


// ==== sub_7FF91E011220 @ rva 0x3B1220 ====
__int64 __fastcall sub_7FF91E011220(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 1));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 32LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E0112A0 @ rva 0x3B12A0 ====
__int64 __fastcall sub_7FF91E0112A0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 41));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 64LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== nullsub_1028 @ rva 0x3B1320 ====
void nullsub_1028()
{
  ;
}


// ==== nullsub_1029 @ rva 0x3B1330 ====
void nullsub_1029()
{
  ;
}


// ==== nullsub_1030 @ rva 0x3B1340 ====
void nullsub_1030()
{
  ;
}


// ==== nullsub_1031 @ rva 0x3B1350 ====
void nullsub_1031()
{
  ;
}


// ==== sub_7FF91E011360 @ rva 0x3B1360 ====
__int64 __fastcall sub_7FF91E011360(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 33));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 8LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E0113E0 @ rva 0x3B13E0 ====
__int64 __fastcall sub_7FF91E0113E0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 33));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 16LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E011460 @ rva 0x3B1460 ====
__int64 __fastcall sub_7FF91E011460(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 33));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 152LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E0114E0 @ rva 0x3B14E0 ====
__int64 __fastcall sub_7FF91E0114E0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 33));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 160LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E011560 @ rva 0x3B1560 ====
__int64 __fastcall sub_7FF91E011560(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 33));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 128LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E0115E0 @ rva 0x3B15E0 ====
__int64 __fastcall sub_7FF91E0115E0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 33));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 24LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E011660 @ rva 0x3B1660 ====
__int64 __fastcall sub_7FF91E011660(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 41));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 72LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E0116E0 @ rva 0x3B16E0 ====
__int64 __fastcall sub_7FF91E0116E0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v3; // rdi
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 33));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v7 + 216LL))(*v7, a2, a3);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E011760 @ rva 0x3B1760 ====
__int64 __fastcall sub_7FF91E011760(__int64 a1)
{
  __int64 v1; // rcx
  __int64 result; // rax

  v1 = *(_QWORD *)(a1 + 832);
  if ( v1 )
    return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v1 + 8LL))(v1);
  return result;
}


// ==== sub_7FF91E011780 @ rva 0x3B1780 ====
__int64 __fastcall sub_7FF91E011780(__int64 a1, __int64 a2)
{
  return (*(__int64 (__fastcall **)(__int64, __int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 112LL))(a1, a2, 0, 0);
}


// ==== nullsub_1032 @ rva 0x3B1790 ====
void nullsub_1032()
{
  ;
}


// ==== nullsub_1033 @ rva 0x3B17A0 ====
void nullsub_1033()
{
  ;
}


// ==== sub_7FF91E0117B0 @ rva 0x3B17B0 ====
__int64 __fastcall sub_7FF91E0117B0(unsigned int *a1, unsigned int a2)
{
  sub_7FF91E0124E0();
  (*(void (__fastcall **)(unsigned int *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2552LL))(a1, a2, a1[369]);
  return (*(__int64 (__fastcall **)(unsigned int *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2256LL))(a1, a2, a1[332]);
}


// ==== sub_7FF91E011800 @ rva 0x3B1800 ====
__int64 __fastcall sub_7FF91E011800(__int64 a1, unsigned int a2, int a3)
{
  int v4; // ecx

  if ( !a3 )
    return a2;
  if ( a3 <= 0 )
    v4 = a3 * a2;
  else
    v4 = a3 * (255 - a2);
  return a2 + v4 / 100;
}


// ==== nullsub_1034 @ rva 0x3B18B0 ====
void nullsub_1034()
{
  ;
}


// ==== nullsub_1035 @ rva 0x3B18C0 ====
void nullsub_1035()
{
  ;
}


// ==== sub_7FF91E0118F0 @ rva 0x3B18F0 ====
__int64 __fastcall sub_7FF91E0118F0(__int64 a1, __int64 a2, int a3)
{
  unsigned int v3; // r9d
  __int64 result; // rax
  int v5; // ebx
  unsigned int v7; // edi
  __int64 (__fastcall ***v8)(_QWORD, __int64, _QWORD); // rcx
  __int64 v9; // rcx

  v3 = 0;
  result = 255;
  v5 = 0;
  v7 = a2;
  v8 = *(__int64 (__fastcall ****)(_QWORD, __int64, _QWORD))(a1 + 864);
  if ( a3 >= 0 )
    v5 = a3;
  if ( v5 > 255 )
    v5 = 255;
  if ( v8 )
  {
    LOBYTE(v3) = v5 > 0;
    result = (**v8)(v8, a2, v3);
  }
  v9 = *(_QWORD *)(a1 + 928);
  if ( v9 )
    return (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v9 + 40LL))(v9, v7, (unsigned int)v5);
  return result;
}


// ==== sub_7FF91E011980 @ rva 0x3B1980 ====
__int64 __fastcall sub_7FF91E011980(__int64 a1, unsigned int a2, int a3)
{
  __int64 result; // rax
  unsigned int v5; // edx
  __int64 (__fastcall ***v7)(_QWORD, _QWORD, _QWORD); // rcx
  int v8; // edi
  __int64 v9; // rcx
  __int64 v10; // rcx

  result = 255;
  v5 = 0;
  v7 = *(__int64 (__fastcall ****)(_QWORD, _QWORD, _QWORD))(a1 + 864);
  v8 = 0;
  if ( a3 >= 0 )
    v8 = a3;
  if ( v8 > 255 )
    v8 = 255;
  if ( v7 )
  {
    LOBYTE(v5) = v8 > 0;
    result = (**v7)(v7, a2, v5);
  }
  v9 = *(_QWORD *)(a1 + 912);
  if ( v9 )
  {
    result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v9 + 48LL))(
               v9,
               a2,
               *(unsigned int *)(a1 + 8LL * v8 + 4724));
    v10 = *(_QWORD *)(a1 + 912);
    if ( v10 )
      return (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v10 + 56LL))(
               v10,
               a2,
               *(unsigned int *)(a1 + 8LL * v8 + 4728));
  }
  return result;
}


// ==== sub_7FF91E011A30 @ rva 0x3B1A30 ====
__int64 __fastcall sub_7FF91E011A30(__int64 a1, __int64 a2, int a3)
{
  __int64 result; // rax
  unsigned int v5; // esi
  __int64 v6; // rcx
  __int64 v7; // rbx
  __int64 v8; // rcx
  __int64 v9; // rcx

  result = 0;
  v5 = a2;
  if ( a3 >= 0 )
    result = (unsigned int)a3;
  if ( (int)result > 255 )
    result = 255;
  v6 = *(_QWORD *)(a1 + 864);
  v7 = (int)result;
  if ( v6 )
    result = (*(__int64 (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)v6 + 8LL))(
               v6,
               a2,
               *(unsigned int *)(a1 + 12LL * (int)result + 1652));
  v8 = *(_QWORD *)(a1 + 896);
  if ( v8 )
  {
    result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v8 + 8LL))(
               v8,
               v5,
               *(unsigned int *)(a1 + 12 * v7 + 1656));
    v9 = *(_QWORD *)(a1 + 896);
    if ( v9 )
      return (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v9 + 16LL))(
               v9,
               v5,
               *(unsigned int *)(a1 + 12 * v7 + 1660));
  }
  return result;
}


// ==== sub_7FF91E011AF0 @ rva 0x3B1AF0 ====
__int64 __fastcall sub_7FF91E011AF0(__int64 a1, __int64 a2, int a3)
{
  __int64 result; // rax
  unsigned int v5; // esi
  __int64 v6; // rcx
  __int64 v7; // rbx
  __int64 v8; // rcx
  __int64 v9; // rcx

  result = 0;
  v5 = a2;
  if ( a3 >= 0 )
    result = (unsigned int)a3;
  if ( (int)result > 255 )
    result = 255;
  v6 = *(_QWORD *)(a1 + 864);
  v7 = (int)result;
  if ( v6 )
    result = (*(__int64 (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)v6 + 8LL))(
               v6,
               a2,
               *(unsigned int *)(a1 + 12LL * (int)result + 1652));
  v8 = *(_QWORD *)(a1 + 880);
  if ( v8 )
  {
    result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v8 + 8LL))(
               v8,
               v5,
               *(unsigned int *)(a1 + 12 * v7 + 1656));
    v9 = *(_QWORD *)(a1 + 880);
    if ( v9 )
      return (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v9 + 16LL))(
               v9,
               v5,
               *(unsigned int *)(a1 + 12 * v7 + 1660));
  }
  return result;
}


// ==== sub_7FF91E011BB0 @ rva 0x3B1BB0 ====
__int64 __fastcall sub_7FF91E011BB0(__int64 a1, __int64 a2, unsigned int a3, int a4)
{
  __int64 v4; // rbx
  unsigned int v6; // ebp
  __int64 v8; // rcx
  __int64 v9; // rcx
  __int64 v10; // rcx
  __int64 v11; // rcx
  __int64 v12; // r8
  unsigned int v13; // r14d
  __int64 v14; // rdi
  __int64 v15; // r8
  __int64 result; // rax
  _DWORD *v17; // rcx
  _QWORD *v18; // rbx

  v4 = a4;
  v6 = a2;
  if ( !a3 )
  {
    v11 = *(_QWORD *)(a1 + 16 * (a4 + 17LL));
    if ( !v11 )
      goto LABEL_12;
    v12 = 0;
    goto LABEL_11;
  }
  v8 = *(_QWORD *)(a1 + 16 * (a4 + 41LL));
  if ( v8 )
  {
    (*(void (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)v8 + 24LL))(v8, a2, 0);
    v9 = *(_QWORD *)(a1 + 16 * (v4 + 41));
    if ( v9 )
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v9 + 16LL))(v9, v6, a3);
  }
  v10 = *(_QWORD *)(a1 + 16 * (v4 + 33));
  if ( v10 )
    (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v10 + 208LL))(v10, v6, a3);
  v11 = *(_QWORD *)(a1 + 16 * (v4 + 17));
  if ( v11 )
  {
    v12 = 1;
    a2 = v6;
LABEL_11:
    (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v11 + 40LL))(v11, a2, v12);
  }
LABEL_12:
  *(_DWORD *)(a1 + 4 * v4 + 1620) = a3;
  v13 = 0;
  v14 = *(int *)(a1 + 1612);
  v15 = *(int *)(a1 + 1616);
  result = v14;
  if ( v14 <= v15 )
  {
    v17 = (_DWORD *)(a1 + 1620 + 4 * v14);
    while ( !*v17 )
    {
      ++result;
      ++v17;
      if ( result > v15 )
        goto LABEL_18;
    }
    v13 = 1;
  }
LABEL_18:
  if ( (int)v14 <= (int)v15 )
  {
    v18 = (_QWORD *)(a1 + 16 * (*(int *)(a1 + 1612) + 1LL));
    do
    {
      if ( *v18 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v18 + 136LL))(*v18, v6, v13);
      LODWORD(v14) = v14 + 1;
      v18 += 2;
    }
    while ( (int)v14 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== nullsub_1036 @ rva 0x3B1D50 ====
void nullsub_1036()
{
  ;
}


// ==== sub_7FF91E011D60 @ rva 0x3B1D60 ====
__int64 __fastcall sub_7FF91E011D60(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 result; // rax

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 1));
    do
    {
      if ( *v3 )
        result = (*(__int64 (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v3 + 152LL))(*v3, 1);
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E011DD0 @ rva 0x3B1DD0 ====
__int64 __fastcall sub_7FF91E011DD0(__int64 a1, __int64 a2, int a3, int a4)
{
  __int64 v5; // rdi
  unsigned int v6; // ebp
  __int64 v8; // rcx
  __int64 result; // rax
  __int64 v10; // rcx
  __int64 v11; // rcx

  v5 = a4;
  v6 = a2;
  if ( !*(_DWORD *)(a1 + 1348) || *(_DWORD *)(a1 + 1352) )
  {
    result = 2 * (a4 + 41LL);
    v11 = *(_QWORD *)(a1 + 16 * (a4 + 41LL));
    if ( v11 )
      return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)v11 + 24LL))(v11);
  }
  else
  {
    if ( a3 )
    {
      v8 = *(_QWORD *)(a1 + 16 * (a4 + 41LL));
      if ( v8 )
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v8 + 24LL))(v8, a2, 1);
    }
    result = 2 * (v5 + 17);
    v10 = *(_QWORD *)(a1 + 16 * (v5 + 17));
    if ( v10 )
      return (*(__int64 (__fastcall **)(__int64, _QWORD, bool))(*(_QWORD *)v10 + 8LL))(v10, v6, a3 == 0);
  }
  return result;
}


// ==== sub_7FF91E011E70 @ rva 0x3B1E70 ====
_OWORD *__fastcall sub_7FF91E011E70(__int64 a1, unsigned int a2, int a3)
{
  _OWORD *result; // rax
  _OWORD *v5; // rcx
  __int64 v6; // rdi
  _QWORD *v8; // rbx
  char *v9; // rsi
  _OWORD v10[2]; // [rsp+20h] [rbp-68h] BYREF
  _OWORD v11[2]; // [rsp+40h] [rbp-48h] BYREF

  result = v11;
  v5 = v10;
  v11[0] = 0;
  v6 = *(int *)(a1 + 1612);
  if ( a3 != 2 )
    v5 = v11;
  v11[1] = 0;
  v10[0] = xmmword_7FF91E621170;
  v10[1] = xmmword_7FF91E621160;
  if ( (int)v6 <= *(_DWORD *)(a1 + 1616) )
  {
    v8 = (_QWORD *)(a1 + 16 * (v6 + 25));
    v9 = (char *)v5 + 4 * v6;
    do
    {
      if ( *v8 )
        result = (_OWORD *)(*(__int64 (__fastcall **)(_QWORD, _QWORD))(*(_QWORD *)*v8 + 72LL))(*v8, a2);
      LODWORD(v6) = v6 + 1;
      v8 += 2;
      v9 += 4;
    }
    while ( (int)v6 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E011F40 @ rva 0x3B1F40 ====
__int64 __fastcall sub_7FF91E011F40(_DWORD *a1, unsigned int a2)
{
  __int64 v2; // rbx
  unsigned int v3; // r14d
  bool v4; // zf
  int v6; // ecx
  BOOL v7; // r15d
  _QWORD *v9; // rsi
  __int64 result; // rax
  _QWORD *v11; // rsi
  _QWORD *v12; // rsi
  _QWORD *v13; // rsi

  v2 = (int)a1[403];
  v3 = 0;
  v4 = a1[337] == 1;
  v6 = a1[404];
  v7 = v4;
  if ( a1[338] == 1 )
  {
    if ( (int)v2 <= v6 )
    {
      v12 = &a1[4 * v2 + 68];
      do
      {
        if ( *v12 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, BOOL))(*(_QWORD *)*v12 + 16LL))(*v12, a2, v7);
        v6 = a1[404];
        LODWORD(v2) = v2 + 1;
        v12 += 2;
      }
      while ( (int)v2 <= v6 );
      LODWORD(v2) = a1[403];
    }
    LOBYTE(v3) = a1[336] != 0;
    if ( (int)v2 <= v6 )
    {
      v13 = &a1[4 * (int)v2 + 68];
      do
      {
        if ( *v13 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v13 + 8LL))(*v13, a2, v3);
        LODWORD(v2) = v2 + 1;
        v13 += 2;
      }
      while ( (int)v2 <= a1[404] );
    }
  }
  else
  {
    if ( (int)v2 <= v6 )
    {
      v9 = &a1[4 * v2 + 68];
      do
      {
        if ( *v9 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v9 + 16LL))(*v9, a2, 0);
        v6 = a1[404];
        LODWORD(v2) = v2 + 1;
        v9 += 2;
      }
      while ( (int)v2 <= v6 );
      LODWORD(v2) = a1[403];
    }
    LOBYTE(v3) = a1[336] != 0;
    if ( (int)v2 <= v6 )
    {
      v11 = &a1[4 * (int)v2 + 68];
      do
      {
        if ( *v11 )
          result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, _QWORD))(*(_QWORD *)*v11 + 8LL))(*v11, a2, v3);
        LODWORD(v2) = v2 + 1;
        v11 += 2;
      }
      while ( (int)v2 <= a1[404] );
    }
  }
  return result;
}


// ==== sub_7FF91E0120A0 @ rva 0x3B20A0 ====
__int64 __fastcall sub_7FF91E0120A0(__int64 a1, unsigned int a2, int a3)
{
  __int64 v3; // rdi
  BOOL v6; // ebp
  _QWORD *v7; // rbx
  __int64 result; // rax

  v3 = *(int *)(a1 + 1612);
  v6 = a3 != 0;
  if ( (int)v3 <= *(_DWORD *)(a1 + 1616) )
  {
    v7 = (_QWORD *)(a1 + 16 * (v3 + 17));
    do
    {
      if ( *v7 )
        result = (*(__int64 (__fastcall **)(_QWORD, _QWORD, BOOL))(*(_QWORD *)*v7 + 8LL))(*v7, a2, v6);
      LODWORD(v3) = v3 + 1;
      v7 += 2;
    }
    while ( (int)v3 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E012120 @ rva 0x3B2120 ====
__int64 __fastcall sub_7FF91E012120(int *a1)
{
  __int64 v1; // rbx
  int v3; // eax
  int *v4; // rsi
  int *v5; // rsi
  char *v6; // rbp
  int *v7; // rsi
  __int64 v8; // rbx
  int v9; // eax
  __int64 v10; // rbp
  int *v11; // rsi
  __int8 *v12; // rbp
  int *v13; // rsi
  __int128 v15; // [rsp+20h] [rbp-58h] BYREF
  __int128 v16; // [rsp+30h] [rbp-48h]
  __m128i si128; // [rsp+40h] [rbp-38h] BYREF
  __m128i v18; // [rsp+50h] [rbp-28h]

  v1 = a1[403];
  v3 = a1[404];
  if ( (int)v1 <= v3 )
  {
    v4 = &a1[4 * v1 + 4];
    do
    {
      if ( *(_QWORD *)v4 )
      {
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v4 + 168LL))(*(_QWORD *)v4);
        if ( *(_QWORD *)v4 )
          (*(void (__fastcall **)(_QWORD, __int64, __int64))(**(_QWORD **)v4 + 8LL))(*(_QWORD *)v4, 1, 1);
      }
      v3 = a1[404];
      LODWORD(v1) = v1 + 1;
      v4 += 4;
    }
    while ( (int)v1 <= v3 );
    LODWORD(v1) = a1[403];
    if ( (int)v1 <= v3 )
    {
      v5 = &a1[4 * (int)v1 + 36];
      do
      {
        if ( *(_QWORD *)v5 )
          (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v5 + 104LL))(*(_QWORD *)v5);
        v3 = a1[404];
        LODWORD(v1) = v1 + 1;
        v5 += 4;
      }
      while ( (int)v1 <= v3 );
      LODWORD(v1) = a1[403];
    }
  }
  v15 = xmmword_7FF91E621140;
  v16 = xmmword_7FF91E621190;
  if ( (int)v1 <= v3 )
  {
    v6 = (char *)&v15 + 4 * (int)v1;
    v7 = &a1[4 * (int)v1 + 100];
    do
    {
      if ( *(_QWORD *)v7 )
      {
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v7 + 336LL))(*(_QWORD *)v7);
        (*(void (__fastcall **)(_QWORD, __int64))(**(_QWORD **)v7 + 320LL))(*(_QWORD *)v7, 1);
      }
      LODWORD(v1) = v1 + 1;
      v7 += 4;
      v6 += 4;
    }
    while ( (int)v1 <= a1[404] );
  }
  sub_7FF91E011E70((__int64)a1, 1u, a1[338]);
  v8 = a1[403];
  v9 = a1[404];
  v15 = xmmword_7FF91E621150;
  v16 = xmmword_7FF91E621130;
  si128 = _mm_load_si128((const __m128i *)&xmmword_7FF91E621110);
  v18 = _mm_load_si128((const __m128i *)&xmmword_7FF91E621120);
  if ( (int)v8 <= v9 )
  {
    v10 = v8;
    v11 = &a1[4 * v8 + 132];
    do
    {
      if ( *(_QWORD *)v11 )
      {
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v11 + 200LL))(*(_QWORD *)v11);
        (*(void (__fastcall **)(_QWORD, __int64, __int64))(**(_QWORD **)v11 + 224LL))(*(_QWORD *)v11, 1, 128);
        (*(void (__fastcall **)(_QWORD, __int64))(**(_QWORD **)v11 + 168LL))(*(_QWORD *)v11, 1);
        (*(void (__fastcall **)(_QWORD, __int64, _QWORD))(**(_QWORD **)v11 + 184LL))(
          *(_QWORD *)v11,
          1,
          si128.m128i_u32[v10]);
      }
      v9 = a1[404];
      LODWORD(v8) = v8 + 1;
      v11 += 4;
      ++v10;
    }
    while ( (int)v8 <= v9 );
    LODWORD(v8) = a1[403];
  }
  si128 = (__m128i)xmmword_7FF91E6211A0;
  v18 = (__m128i)xmmword_7FF91E621180;
  if ( (int)v8 <= v9 )
  {
    v12 = &si128.m128i_i8[4 * (int)v8];
    v13 = &a1[4 * (int)v8 + 164];
    do
    {
      if ( *(_QWORD *)v13 )
      {
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v13 + 56LL))(*(_QWORD *)v13);
        (*(void (__fastcall **)(_QWORD, __int64, __int64))(**(_QWORD **)v13 + 80LL))(*(_QWORD *)v13, 1, 200);
        (*(void (__fastcall **)(_QWORD, __int64))(**(_QWORD **)v13 + 24LL))(*(_QWORD *)v13, 1);
        (*(void (__fastcall **)(_QWORD, __int64))(**(_QWORD **)v13 + 88LL))(*(_QWORD *)v13, 1);
      }
      LODWORD(v8) = v8 + 1;
      v13 += 4;
      v12 += 4;
    }
    while ( (int)v8 <= a1[404] );
  }
  sub_7FF91E0124E0(a1);
  return (*(__int64 (__fastcall **)(int *))(*(_QWORD *)a1 + 136LL))(a1);
}


// ==== sub_7FF91E012400 @ rva 0x3B2400 ====
__int64 __fastcall sub_7FF91E012400(__int64 a1)
{
  __int64 v1; // rdi
  char *v3; // rsi
  _QWORD *v4; // rbx
  __int64 result; // rax
  _OWORD v6[2]; // [rsp+20h] [rbp-38h] BYREF

  v1 = *(int *)(a1 + 1612);
  v6[0] = xmmword_7FF91E6211A0;
  v6[1] = xmmword_7FF91E621180;
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (char *)v6 + 4 * v1;
    v4 = (_QWORD *)(a1 + 16 * (v1 + 41));
    do
    {
      if ( *v4 )
      {
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v4 + 56LL))(*v4);
        (*(void (__fastcall **)(_QWORD, __int64, __int64))(*(_QWORD *)*v4 + 80LL))(*v4, 1, 200);
        (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v4 + 24LL))(*v4, 1);
        result = (*(__int64 (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v4 + 88LL))(*v4, 1);
      }
      LODWORD(v1) = v1 + 1;
      v4 += 2;
      v3 += 4;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E0124E0 @ rva 0x3B24E0 ====
__int64 __fastcall sub_7FF91E0124E0(__int64 a1)
{
  __int64 result; // rax
  __int64 v3; // rcx
  __int64 v4; // r8
  __int64 v5; // rcx

  result = *(int *)(a1 + 1472);
  switch ( *(_DWORD *)(a1 + 1472) )
  {
    case 2:
      v3 = *(_QWORD *)(a1 + 912);
      if ( v3 )
      {
        v4 = 0;
        goto LABEL_4;
      }
      break;
    case 3:
      v3 = *(_QWORD *)(a1 + 912);
      if ( v3 )
      {
        v4 = 1;
        goto LABEL_4;
      }
      break;
    case 4:
      v3 = *(_QWORD *)(a1 + 912);
      if ( v3 )
      {
        v4 = 2;
LABEL_4:
        (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v3 + 32LL))(v3, 1, v4);
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(**(_QWORD **)(a1 + 912) + 24LL))(
                   *(_QWORD *)(a1 + 912),
                   1,
                   1);
      }
      break;
    case 5:
      v5 = *(_QWORD *)(a1 + 928);
      if ( v5 )
      {
        (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v5 + 24LL))(v5, 1);
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(**(_QWORD **)(a1 + 928) + 32LL))(
                   *(_QWORD *)(a1 + 928),
                   1,
                   1);
      }
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E0125C0 @ rva 0x3B25C0 ====
__int64 __fastcall sub_7FF91E0125C0(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 result; // rax

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 9));
    do
    {
      if ( *v3 )
        result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 104LL))(*v3);
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E012620 @ rva 0x3B2620 ====
__int64 __fastcall sub_7FF91E012620(__int64 a1)
{
  __int64 v2; // rdi
  _QWORD *v3; // rbx
  __int64 v4; // rsi
  __int64 result; // rax
  _OWORD v6[2]; // [rsp+40h] [rbp-38h]

  v2 = *(int *)(a1 + 1612);
  v6[0] = _mm_load_si128((const __m128i *)&xmmword_7FF91E621110);
  v6[1] = _mm_load_si128((const __m128i *)&xmmword_7FF91E621120);
  if ( (int)v2 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v2 + 33));
    v4 = 4 * v2;
    do
    {
      if ( *v3 )
      {
        (*(void (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 200LL))(*v3);
        (*(void (__fastcall **)(_QWORD, __int64, __int64))(*(_QWORD *)*v3 + 224LL))(*v3, 1, 128);
        (*(void (__fastcall **)(_QWORD, __int64))(*(_QWORD *)*v3 + 168LL))(*v3, 1);
        result = (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(*(_QWORD *)*v3 + 184LL))(
                   *v3,
                   1,
                   *(unsigned int *)((char *)v6 + v4));
      }
      LODWORD(v2) = v2 + 1;
      v3 += 2;
      v4 += 4;
    }
    while ( (int)v2 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== sub_7FF91E012730 @ rva 0x3B2730 ====
__int64 __fastcall sub_7FF91E012730(__int64 a1)
{
  __int64 v1; // rdi
  _QWORD *v3; // rbx
  __int64 result; // rax

  v1 = *(int *)(a1 + 1612);
  if ( (int)v1 <= *(_DWORD *)(a1 + 1616) )
  {
    v3 = (_QWORD *)(a1 + 16 * (v1 + 1));
    do
    {
      if ( *v3 )
      {
        result = (*(__int64 (__fastcall **)(_QWORD))(*(_QWORD *)*v3 + 168LL))(*v3);
        if ( *v3 )
          result = (*(__int64 (__fastcall **)(_QWORD, __int64, __int64))(*(_QWORD *)*v3 + 8LL))(*v3, 1, 1);
      }
      LODWORD(v1) = v1 + 1;
      v3 += 2;
    }
    while ( (int)v1 <= *(_DWORD *)(a1 + 1616) );
  }
  return result;
}


// ==== nullsub_1037 @ rva 0x3B27B0 ====
void nullsub_1037()
{
  ;
}


// ==== sub_7FF91E0127C0 @ rva 0x3B27C0 ====
_OWORD *__fastcall sub_7FF91E0127C0(int *a1)
{
  __int64 v1; // rdi
  char *v3; // rsi
  int *v4; // rbx
  _OWORD v6[2]; // [rsp+20h] [rbp-38h] BYREF

  v1 = a1[403];
  v6[0] = xmmword_7FF91E621140;
  v6[1] = xmmword_7FF91E621190;
  if ( (int)v1 <= a1[404] )
  {
    v3 = (char *)v6 + 4 * v1;
    v4 = &a1[4 * v1 + 100];
    do
    {
      if ( *(_QWORD *)v4 )
      {
        (*(void (__fastcall **)(_QWORD))(**(_QWORD **)v4 + 336LL))(*(_QWORD *)v4);
        (*(void (__fastcall **)(_QWORD, __int64))(**(_QWORD **)v4 + 320LL))(*(_QWORD *)v4, 1);
      }
      LODWORD(v1) = v1 + 1;
      v4 += 4;
      v3 += 4;
    }
    while ( (int)v1 <= a1[404] );
  }
  return sub_7FF91E011E70((__int64)a1, 1u, a1[338]);
}


// ==== sub_7FF91E012890 @ rva 0x3B2890 ====
_QWORD *__fastcall sub_7FF91E012890(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60AmpVoice>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012F20(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012900 @ rva 0x3B2900 ====
_QWORD *__fastcall sub_7FF91E012900(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60EfxCe>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012F30(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012970 @ rva 0x3B2970 ====
_QWORD *__fastcall sub_7FF91E012970(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60EfxCh>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012F40(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E0129E0 @ rva 0x3B29E0 ====
_QWORD *__fastcall sub_7FF91E0129E0(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60EfxCmn>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012F50(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012A50 @ rva 0x3B2A50 ====
_QWORD *__fastcall sub_7FF91E012A50(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60EfxDs>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012F60(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012AC0 @ rva 0x3B2AC0 ====
_QWORD *__fastcall sub_7FF91E012AC0(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60EfxOd>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012F70(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012B30 @ rva 0x3B2B30 ====
_QWORD *__fastcall sub_7FF91E012B30(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60EnvVoice>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012F80(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012BA0 @ rva 0x3B2BA0 ====
_QWORD *__fastcall sub_7FF91E012BA0(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60FltVoice>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012F90(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012C10 @ rva 0x3B2C10 ====
_QWORD *__fastcall sub_7FF91E012C10(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60LfoVoice>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012FA0(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012C80 @ rva 0x3B2C80 ====
_QWORD *__fastcall sub_7FF91E012C80(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60Mst>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012FB0(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012CF0 @ rva 0x3B2CF0 ====
_QWORD *__fastcall sub_7FF91E012CF0(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60Noise>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012FC0(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012D60 @ rva 0x3B2D60 ====
_QWORD *__fastcall sub_7FF91E012D60(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60OscVoice>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012FD0(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012DD0 @ rva 0x3B2DD0 ====
_QWORD *__fastcall sub_7FF91E012DD0(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60PatchLev>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012FE0(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012E40 @ rva 0x3B2E40 ====
_QWORD *__fastcall sub_7FF91E012E40(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60VoiceCmn>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E012FF0(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012EB0 @ rva 0x3B2EB0 ====
_QWORD *__fastcall sub_7FF91E012EB0(_QWORD *a1, __int64 a2)
{
  _DWORD *v4; // rax
  _QWORD *result; // rax

  *a1 = 0;
  try
  {
    v4 = operator new(0x18u);
    if ( v4 )
    {
      v4[2] = 1;
      v4[3] = 1;
      *(_QWORD *)v4 = &boost::detail::sp_counted_impl_p<CDSPJu60VoiceMix>::`vftable';
      *((_QWORD *)v4 + 2) = a2;
    }
    *a1 = v4;
    result = a1;
  }
  catch ( ... )
  {
    sub_7FF91E013000(a2);
    throw;
  }
  return result;
}


// ==== sub_7FF91E012F20 @ rva 0x3B2F20 ====
void __fastcall sub_7FF91E012F20(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012F30 @ rva 0x3B2F30 ====
void __fastcall sub_7FF91E012F30(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012F40 @ rva 0x3B2F40 ====
void __fastcall sub_7FF91E012F40(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012F50 @ rva 0x3B2F50 ====
void __fastcall sub_7FF91E012F50(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012F60 @ rva 0x3B2F60 ====
void __fastcall sub_7FF91E012F60(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012F70 @ rva 0x3B2F70 ====
void __fastcall sub_7FF91E012F70(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012F80 @ rva 0x3B2F80 ====
void __fastcall sub_7FF91E012F80(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012F90 @ rva 0x3B2F90 ====
void __fastcall sub_7FF91E012F90(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012FA0 @ rva 0x3B2FA0 ====
void __fastcall sub_7FF91E012FA0(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012FB0 @ rva 0x3B2FB0 ====
void __fastcall sub_7FF91E012FB0(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012FC0 @ rva 0x3B2FC0 ====
void __fastcall sub_7FF91E012FC0(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012FD0 @ rva 0x3B2FD0 ====
void __fastcall sub_7FF91E012FD0(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012FE0 @ rva 0x3B2FE0 ====
void __fastcall sub_7FF91E012FE0(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E012FF0 @ rva 0x3B2FF0 ====
void __fastcall sub_7FF91E012FF0(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E013000 @ rva 0x3B3000 ====
void __fastcall sub_7FF91E013000(void *Block)
{
  j_j_free(Block);
}


// ==== sub_7FF91E013010 @ rva 0x3B3010 ====
// Hidden C++ exception states: #wind=2
__int64 __fastcall sub_7FF91E013010(__int64 a1, int a2, int a3, __int64 a4)
{
  sub_7FF91E00C670(a1, a2, a3, a4);
  *(_QWORD *)a1 = &CPrmDSPSystem8Dly<CPrmDSPJu60>::`vftable';
  *(_DWORD *)(a1 + 6776) = 0;
  sub_7FF91DFBFAB0(a1 + 6784, a4);
  *(_QWORD *)(a1 + 6784) = &sCDSPSystem8DlyDly::`vftable';
  sub_7FF91DFC2450(a1 + 6976, a4);
  *(_QWORD *)(a1 + 6976) = &sCDSPSystem8DlyPan::`vftable';
  sub_7FF91DFBDA40(a1 + 7184, a4);
  *(_QWORD *)(a1 + 7184) = &sCDSPSystem8DlyCh::`vftable';
  sub_7FF91DFBDA40(a1 + 7400, a4);
  *(_QWORD *)(a1 + 7400) = &sCDSPSystem8DlyCh::`vftable';
  sub_7FF91DFBEAD0(a1 + 7616, a4);
  *(_QWORD *)(a1 + 7616) = &sCDSPSystem8DlyFlSt::`vftable';
  sub_7FF91DFC0830(a1 + 7824, a4);
  *(_QWORD *)(a1 + 7824) = &sCDSPSystem8DlyMfx1::`vftable';
  (**(void (__fastcall ***)(__int64))(a1 + 6784))(a1 + 6784);
  (**(void (__fastcall ***)(__int64))(a1 + 6976))(a1 + 6976);
  (**(void (__fastcall ***)(__int64))(a1 + 7184))(a1 + 7184);
  (**(void (__fastcall ***)(__int64))(a1 + 7400))(a1 + 7400);
  (**(void (__fastcall ***)(__int64))(a1 + 7616))(a1 + 7616);
  (**(void (__fastcall ***)(__int64))(a1 + 7824))(a1 + 7824);
  *(_QWORD *)a1 = &CPrmDSPRev<CPrmDSPSystem8Dly<CPrmDSPJu60>>::`vftable';
  sub_7FF91E021110(a1 + 8176, a4);
  return a1;
}


// ==== sub_7FF91E0131A0 @ rva 0x3B31A0 ====
// Hidden C++ exception states: #wind=1
__int64 __fastcall sub_7FF91E0131A0(__int64 a1, int a2, int a3, __int64 a4)
{
  sub_7FF91E00C670(a1, a2, a3, a4);
  *(_QWORD *)a1 = &CPrmDSPSystem8Dly<CPrmDSPJu60>::`vftable';
  *(_DWORD *)(a1 + 6776) = 0;
  sub_7FF91DFBFAB0(a1 + 6784, a4);
  *(_QWORD *)(a1 + 6784) = &sCDSPSystem8DlyDly::`vftable';
  sub_7FF91DFC2450(a1 + 6976, a4);
  *(_QWORD *)(a1 + 6976) = &sCDSPSystem8DlyPan::`vftable';
  sub_7FF91DFBDA40(a1 + 7184, a4);
  *(_QWORD *)(a1 + 7184) = &sCDSPSystem8DlyCh::`vftable';
  sub_7FF91DFBDA40(a1 + 7400, a4);
  *(_QWORD *)(a1 + 7400) = &sCDSPSystem8DlyCh::`vftable';
  sub_7FF91DFBEAD0(a1 + 7616, a4);
  *(_QWORD *)(a1 + 7616) = &sCDSPSystem8DlyFlSt::`vftable';
  sub_7FF91DFC0830(a1 + 7824, a4);
  *(_QWORD *)(a1 + 7824) = &sCDSPSystem8DlyMfx1::`vftable';
  (**(void (__fastcall ***)(__int64))(a1 + 6784))(a1 + 6784);
  (**(void (__fastcall ***)(__int64))(a1 + 6976))(a1 + 6976);
  (**(void (__fastcall ***)(__int64))(a1 + 7184))(a1 + 7184);
  (**(void (__fastcall ***)(__int64))(a1 + 7400))(a1 + 7400);
  (**(void (__fastcall ***)(__int64))(a1 + 7616))(a1 + 7616);
  (**(void (__fastcall ***)(__int64))(a1 + 7824))(a1 + 7824);
  return a1;
}


// ==== sub_7FF91E013320 @ rva 0x3B3320 ====
// Hidden C++ exception states: #wind=45
_QWORD *__fastcall sub_7FF91E013320(__int64 a1, int a2, int a3, __int64 a4)
{
  __int64 v5; // r13
  _QWORD *v7; // rbx
  __int64 v8; // rbx
  void *v9; // rax
  __int64 v10; // r15
  volatile signed __int32 **v11; // rax
  volatile signed __int32 *v12; // rdx
  volatile signed __int32 *v13; // rsi
  volatile signed __int32 *v14; // rsi
  void *v15; // rax
  __int64 v16; // r15
  volatile signed __int32 **v17; // rax
  volatile signed __int32 *v18; // rdx
  volatile signed __int32 *v19; // rsi
  volatile signed __int32 *v20; // rsi
  void *v21; // rax
  __int64 v22; // r15
  volatile signed __int32 **v23; // rax
  volatile signed __int32 *v24; // rdx
  volatile signed __int32 *v25; // rsi
  volatile signed __int32 *v26; // rsi
  void *v27; // rax
  __int64 v28; // r15
  volatile signed __int32 **v29; // rax
  volatile signed __int32 *v30; // rdx
  volatile signed __int32 *v31; // rsi
  volatile signed __int32 *v32; // rsi
  void *v33; // rax
  __int64 v34; // r15
  volatile signed __int32 **v35; // rax
  volatile signed __int32 *v36; // rdx
  volatile signed __int32 *v37; // rsi
  volatile signed __int32 *v38; // rcx
  void *v39; // rax
  __int64 v40; // r15
  volatile signed __int32 **v41; // rax
  volatile signed __int32 *v42; // rdx
  volatile signed __int32 *v43; // rsi
  volatile signed __int32 *v44; // rcx
  void *v45; // rax
  __int64 v46; // r15
  volatile signed __int32 **v47; // rax
  volatile signed __int32 *v48; // rsi
  volatile signed __int32 *v49; // rcx
  void *v50; // rax
  __int64 v51; // r15
  volatile signed __int32 **v52; // rax
  volatile signed __int32 *v53; // rsi
  volatile signed __int32 *v54; // rdx
  void *v55; // rax
  __int64 v56; // r15
  volatile signed __int32 **v57; // rax
  volatile signed __int32 *v58; // rdx
  volatile signed __int32 *v59; // rsi
  volatile signed __int32 *v60; // rcx
  void *v61; // rax
  __int64 v62; // r15
  volatile signed __int32 **v63; // rax
  volatile signed __int32 *v64; // rdx
  volatile signed __int32 *v65; // rsi
  volatile signed __int32 *v66; // rdx
  void *v67; // rax
  __int64 v68; // r15
  __int64 *v69; // rax
  __int64 v70; // rdx
  volatile signed __int32 *v71; // rsi
  __int64 v72; // rcx
  __int64 v73; // rcx
  void *v74; // rax
  __int64 v75; // rdi
  __int64 *v76; // rax
  __int64 v77; // rdx
  __int64 v78; // rdx
  __int64 v79; // rdx
  void *v80; // rax
  __int64 v81; // rdi
  __int64 *v82; // rax
  __int64 v83; // rdx
  __int64 v84; // rcx
  __int64 v85; // rcx
  void *v86; // rax
  __int64 v87; // rdi
  __int64 *v88; // rax
  __int64 v89; // rdx
  __int64 v90; // rdx
  __int64 v91; // rdx
  void *v92; // rax
  __int64 v93; // rdi
  __int64 *v94; // rax
  __int64 v95; // rdx
  __int64 v96; // rcx
  __int64 v97; // rcx
  volatile signed __int32 *v99; // [rsp+38h] [rbp-D0h] BYREF
  __int64 v100; // [rsp+40h] [rbp-C8h]
  volatile signed __int32 *v101; // [rsp+48h] [rbp-C0h] BYREF
  __int64 v102; // [rsp+50h] [rbp-B8h]
  volatile signed __int32 *v103; // [rsp+58h] [rbp-B0h] BYREF
  __int64 v104; // [rsp+60h] [rbp-A8h]
  volatile signed __int32 *v105; // [rsp+68h] [rbp-A0h] BYREF
  __int64 v106; // [rsp+70h] [rbp-98h]
  __int64 v107; // [rsp+78h] [rbp-90h] BYREF
  __int64 v108; // [rsp+80h] [rbp-88h]
  __int64 v109; // [rsp+88h] [rbp-80h]
  volatile signed __int32 *v110; // [rsp+90h] [rbp-78h] BYREF
  __int64 v111; // [rsp+98h] [rbp-70h]
  volatile signed __int32 *v112; // [rsp+A0h] [rbp-68h] BYREF
  __int64 v113; // [rsp+A8h] [rbp-60h] BYREF
  __int64 v114; // [rsp+B0h] [rbp-58h]
  __int64 v115; // [rsp+B8h] [rbp-50h] BYREF
  __int64 v116; // [rsp+C0h] [rbp-48h]
  __int64 v117; // [rsp+C8h] [rbp-40h] BYREF
  __int64 v118; // [rsp+D0h] [rbp-38h]
  __int64 v119; // [rsp+D8h] [rbp-30h] BYREF
  __int64 v120; // [rsp+E0h] [rbp-28h]
  __int64 v121; // [rsp+E8h] [rbp-20h]
  volatile signed __int32 *v122; // [rsp+F0h] [rbp-18h]
  __int64 v123; // [rsp+F8h] [rbp-10h]
  volatile signed __int32 *v124; // [rsp+100h] [rbp-8h]
  __int64 v125; // [rsp+108h] [rbp+0h]
  volatile signed __int32 *v126; // [rsp+110h] [rbp+8h]
  __int64 v127; // [rsp+118h] [rbp+10h]
  volatile signed __int32 *v128; // [rsp+120h] [rbp+18h]
  volatile signed __int32 *v129; // [rsp+128h] [rbp+20h] BYREF
  volatile signed __int32 *v130; // [rsp+130h] [rbp+28h] BYREF
  volatile signed __int32 *v131; // [rsp+138h] [rbp+30h] BYREF
  volatile signed __int32 *v132; // [rsp+140h] [rbp+38h] BYREF
  volatile signed __int32 *v133; // [rsp+148h] [rbp+40h] BYREF
  volatile signed __int32 *v134; // [rsp+150h] [rbp+48h] BYREF
  volatile signed __int32 *v135; // [rsp+158h] [rbp+50h] BYREF
  volatile signed __int32 *v136; // [rsp+160h] [rbp+58h] BYREF
  volatile signed __int32 *v137; // [rsp+168h] [rbp+60h] BYREF
  volatile signed __int32 *v138; // [rsp+170h] [rbp+68h] BYREF
  volatile signed __int32 *v139; // [rsp+178h] [rbp+70h] BYREF
  volatile signed __int32 *v140; // [rsp+180h] [rbp+78h] BYREF
  volatile signed __int32 *v141; // [rsp+188h] [rbp+80h] BYREF
  volatile signed __int32 *v142; // [rsp+190h] [rbp+88h] BYREF
  _QWORD v143[2]; // [rsp+198h] [rbp+90h] BYREF
  __int64 v144; // [rsp+1A8h] [rbp+A0h]
  void *v145; // [rsp+1B0h] [rbp+A8h]
  __int64 v146; // [rsp+1B8h] [rbp+B0h]
  void *v147; // [rsp+1C0h] [rbp+B8h]
  __int64 v148; // [rsp+1C8h] [rbp+C0h]
  void *v149; // [rsp+1D0h] [rbp+C8h]
  __int64 v150; // [rsp+1D8h] [rbp+D0h]
  void *v151; // [rsp+1E0h] [rbp+D8h]
  __int64 v152; // [rsp+1E8h] [rbp+E0h]
  __int64 v153; // [rsp+1F0h] [rbp+E8h]
  __int64 v154; // [rsp+1F8h] [rbp+F0h]
  __int64 v155; // [rsp+200h] [rbp+F8h]
  __int64 v156; // [rsp+208h] [rbp+100h]
  __int64 v157; // [rsp+210h] [rbp+108h]

  v148 = -2;
  v5 = a2;
  sub_7FF91E00C670(a1, a2, a3, a4);
  *(_QWORD *)a1 = &CPrmDSPSystem8Dly<CPrmDSPJu60>::`vftable';
  *(_DWORD *)(a1 + 6776) = 0;
  sub_7FF91DFBFAB0(a1 + 6784, a4);
  *(_QWORD *)(a1 + 6784) = &sCDSPSystem8DlyDly::`vftable';
  sub_7FF91DFC2450(a1 + 6976, a4);
  *(_QWORD *)(a1 + 6976) = &sCDSPSystem8DlyPan::`vftable';
  sub_7FF91DFBDA40(a1 + 7184, a4);
  *(_QWORD *)(a1 + 7184) = &sCDSPSystem8DlyCh::`vftable';
  sub_7FF91DFBDA40(a1 + 7400, a4);
  *(_QWORD *)(a1 + 7400) = &sCDSPSystem8DlyCh::`vftable';
  sub_7FF91DFBEAD0(a1 + 7616, a4);
  *(_QWORD *)(a1 + 7616) = &sCDSPSystem8DlyFlSt::`vftable';
  sub_7FF91DFC0830(a1 + 7824, a4);
  *(_QWORD *)(a1 + 7824) = &sCDSPSystem8DlyMfx1::`vftable';
  (**(void (__fastcall ***)(__int64))(a1 + 6784))(a1 + 6784);
  (**(void (__fastcall ***)(__int64))(a1 + 6976))(a1 + 6976);
  (**(void (__fastcall ***)(__int64))(a1 + 7184))(a1 + 7184);
  (**(void (__fastcall ***)(__int64))(a1 + 7400))(a1 + 7400);
  (**(void (__fastcall ***)(__int64))(a1 + 7616))(a1 + 7616);
  (**(void (__fastcall ***)(__int64))(a1 + 7824))(a1 + 7824);
  v7 = (_QWORD *)a1;
  *(_QWORD *)a1 = &CPrmDSPRev<CPrmDSPSystem8Dly<CPrmDSPJu60>>::`vftable';
  sub_7FF91E021110(a1 + 8176, a4);
  *(_QWORD *)a1 = &CPrmDSPJu60Plugin::`vftable';
  if ( (int)v5 <= a3 )
  {
    v8 = 16 * v5 + a1 + 152;
    do
    {
      v9 = operator new(0x78u);
      v147 = v9;
      if ( v9 )
        v10 = sub_7FF91DFB9F70((__int64)v9, v5, a4);
      else
        v10 = 0;
      v121 = v10;
      v122 = nullptr;
      v11 = (volatile signed __int32 **)sub_7FF91E012C10(&v136, v10);
      v12 = v122;
      v122 = *v11;
      *v11 = v12;
      v13 = v136;
      if ( v136 )
      {
        if ( _InterlockedExchangeAdd(v136 + 2, 0xFFFFFFFF) == 1 )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 8LL))(v13);
          if ( _InterlockedExchangeAdd(v13 + 3, 0xFFFFFFFF) == 1 )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v13 + 16LL))(v13);
        }
      }
      sub_7FF91DF6D8E0();
      v146 = v121;
      v121 = *(_QWORD *)(v8 - 136);
      *(_QWORD *)(v8 - 136) = v146;
      v14 = *(volatile signed __int32 **)(v8 - 128);
      *(_QWORD *)(v8 - 128) = v122;
      v122 = v14;
      if ( v14 )
      {
        if ( _InterlockedExchangeAdd(v14 + 2, 0xFFFFFFFF) == 1 )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 8LL))(v14);
          if ( _InterlockedExchangeAdd(v14 + 3, 0xFFFFFFFF) == 1 )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v14 + 16LL))(v14);
        }
      }
      v15 = operator new(0x70u);
      v145 = v15;
      if ( v15 )
        v16 = sub_7FF91DFB8180((__int64)v15, v5, a4);
      else
        v16 = 0;
      v123 = v16;
      v124 = nullptr;
      v17 = (volatile signed __int32 **)sub_7FF91E012B30(&v137, v16);
      v18 = v124;
      v124 = *v17;
      *v17 = v18;
      v19 = v137;
      if ( v137 )
      {
        if ( _InterlockedExchangeAdd(v137 + 2, 0xFFFFFFFF) == 1 )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 8LL))(v19);
          if ( _InterlockedExchangeAdd(v19 + 3, 0xFFFFFFFF) == 1 )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v19 + 16LL))(v19);
        }
      }
      sub_7FF91DF6D8E0();
      v144 = v123;
      v123 = *(_QWORD *)(v8 - 8);
      *(_QWORD *)(v8 - 8) = v144;
      v20 = *(volatile signed __int32 **)v8;
      *(_QWORD *)v8 = v124;
      v124 = v20;
      if ( v20 )
      {
        if ( _InterlockedExchangeAdd(v20 + 2, 0xFFFFFFFF) == 1 )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 8LL))(v20);
          if ( _InterlockedExchangeAdd(v20 + 3, 0xFFFFFFFF) == 1 )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v20 + 16LL))(v20);
        }
      }
      v21 = operator new(0x90u);
      v143[1] = v21;
      if ( v21 )
        v22 = sub_7FF91DFBC8C0((__int64)v21, v5, a4);
      else
        v22 = 0;
      v125 = v22;
      v126 = nullptr;
      v23 = (volatile signed __int32 **)sub_7FF91E012E40(&v138, v22);
      v24 = v126;
      v126 = *v23;
      *v23 = v24;
      v25 = v138;
      if ( v138 )
      {
        if ( _InterlockedExchangeAdd(v138 + 2, 0xFFFFFFFF) == 1 )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 8LL))(v25);
          if ( _InterlockedExchangeAdd(v25 + 3, 0xFFFFFFFF) == 1 )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v25 + 16LL))(v25);
        }
      }
      sub_7FF91DF6D8E0();
      v157 = v125;
      v125 = *(_QWORD *)(v8 + 120);
      *(_QWORD *)(v8 + 120) = v157;
      v26 = *(volatile signed __int32 **)(v8 + 128);
      *(_QWORD *)(v8 + 128) = v126;
      v126 = v26;
      if ( v26 )
      {
        if ( _InterlockedExchangeAdd(v26 + 2, 0xFFFFFFFF) == 1 )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v26 + 8LL))(v26);
          if ( _InterlockedExchangeAdd(v26 + 3, 0xFFFFFFFF) == 1 )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v26 + 16LL))(v26);
        }
      }
      v27 = operator new(0x8B0u);
      v151 = v27;
      if ( v27 )
        v28 = sub_7FF91DFBB100((__int64)v27, v5, a4);
      else
        v28 = 0;
      v127 = v28;
      v128 = nullptr;
      v29 = (volatile signed __int32 **)sub_7FF91E012D60(&v139, v28);
      v30 = v128;
      v128 = *v29;
      *v29 = v30;
      v31 = v139;
      if ( v139 )
      {
        if ( _InterlockedExchangeAdd(v139 + 2, 0xFFFFFFFF) == 1 )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v31 + 8LL))(v31);
          if ( _InterlockedExchangeAdd(v31 + 3, 0xFFFFFFFF) == 1 )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v31 + 16LL))(v31);
        }
      }
      sub_7FF91DF6D8E0();
      v152 = v127;
      v127 = *(_QWORD *)(v8 + 248);
      *(_QWORD *)(v8 + 248) = v152;
      v32 = *(volatile signed __int32 **)(v8 + 256);
      *(_QWORD *)(v8 + 256) = v128;
      v128 = v32;
      if ( v32 )
      {
        if ( _InterlockedExchangeAdd(v32 + 2, 0xFFFFFFFF) == 1 )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v32 + 8LL))(v32);
          if ( _InterlockedExchangeAdd(v32 + 3, 0xFFFFFFFF) == 1 )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v32 + 16LL))(v32);
        }
      }
      v33 = operator new(0x8A0u);
      v149 = v33;
      if ( v33 )
        v34 = sub_7FF91DFB8AF0((__int64)v33, v5, a4);
      else
        v34 = 0;
      v104 = v34;
      v105 = nullptr;
      v35 = (volatile signed __int32 **)sub_7FF91E012BA0(&v140, v34);
      v36 = v105;
      v105 = *v35;
      *v35 = v36;
      v37 = v140;
      if ( v140 )
      {
        if ( _InterlockedExchangeAdd(v140 + 2, 0xFFFFFFFF) == 1 )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v37 + 8LL))(v37);
          if ( _InterlockedExchangeAdd(v37 + 3, 0xFFFFFFFF) == 1 )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v37 + 16LL))(v37);
        }
      }
      sub_7FF91DF6D8E0();
      v150 = v104;
      v104 = *(_QWORD *)(v8 + 376);
      *(_QWORD *)(v8 + 376) = v150;
      v38 = *(volatile signed __int32 **)(v8 + 384);
      *(_QWORD *)(v8 + 384) = v105;
      v105 = v38;
      sub_7FF91DF5D340(&v105);
      v39 = operator new(0x478u);
      if ( v39 )
        v40 = sub_7FF91DFB5B20((__int64)v39, v5, a4);
      else
        v40 = 0;
      v102 = v40;
      v103 = nullptr;
      v41 = (volatile signed __int32 **)sub_7FF91E012890(&v135, v40);
      v42 = v103;
      v103 = *v41;
      *v41 = v42;
      v43 = v135;
      if ( v135 )
      {
        if ( _InterlockedExchangeAdd(v135 + 2, 0xFFFFFFFF) == 1 )
        {
          (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v43 + 8LL))(v43);
          if ( _InterlockedExchangeAdd(v43 + 3, 0xFFFFFFFF) == 1 )
            (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v43 + 16LL))(v43);
        }
      }
      sub_7FF91DF6D8E0();
      v153 = v102;
      v102 = *(_QWORD *)(v8 + 504);
      *(_QWORD *)(v8 + 504) = v153;
      v44 = *(volatile signed __int32 **)(v8 + 512);
      *(_QWORD *)(v8 + 512) = v103;
      v103 = v44;
      sub_7FF91DF5D340(&v103);
      LODWORD(v5) = v5 + 1;
      v8 += 16;
    }
    while ( (int)v5 <= a3 );
    v7 = (_QWORD *)a1;
  }
  v45 = operator new(0x18u);
  if ( v45 )
    v46 = sub_7FF91DFBB0A0((__int64)v45, a4);
  else
    v46 = 0;
  v100 = v46;
  v101 = nullptr;
  v47 = (volatile signed __int32 **)sub_7FF91E012CF0(&v141, v46);
  v101 = *v47;
  *v47 = nullptr;
  v48 = v141;
  if ( v141 )
  {
    if ( _InterlockedExchangeAdd(v141 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v48 + 8LL))(v48);
      if ( _InterlockedExchangeAdd(v48 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v48 + 16LL))(v48);
    }
  }
  sub_7FF91DF6D8E0();
  v154 = v100;
  v100 = v7[98];
  v7[98] = v154;
  v49 = (volatile signed __int32 *)v7[99];
  v7[99] = v101;
  v101 = v49;
  sub_7FF91DF5D340(&v101);
  v50 = operator new(0x28u);
  if ( v50 )
    v51 = sub_7FF91DFBD1E0((__int64)v50, a4, a3);
  else
    v51 = 0;
  v99 = nullptr;
  v52 = (volatile signed __int32 **)sub_7FF91E012EB0(&v142, v51);
  v99 = *v52;
  *v52 = nullptr;
  v53 = v142;
  if ( v142 )
  {
    if ( _InterlockedExchangeAdd(v142 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v53 + 8LL))(v53);
      if ( _InterlockedExchangeAdd(v53 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v53 + 16LL))(v53);
    }
  }
  sub_7FF91DF6D8E0();
  v155 = v51;
  v7[100] = v51;
  v54 = (volatile signed __int32 *)v7[101];
  v7[101] = v99;
  v99 = v54;
  sub_7FF91DF5D340(&v99);
  v55 = operator new(0x18u);
  if ( v55 )
    v56 = sub_7FF91DFBC840((__int64)v55, a4);
  else
    v56 = 0;
  v111 = v56;
  v112 = nullptr;
  v57 = (volatile signed __int32 **)sub_7FF91E012DD0(v143, v56);
  v58 = v112;
  v112 = *v57;
  *v57 = v58;
  v59 = (volatile signed __int32 *)v143[0];
  if ( v143[0] )
  {
    if ( _InterlockedExchangeAdd((volatile signed __int32 *)(v143[0] + 8LL), 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v59 + 8LL))(v59);
      if ( _InterlockedExchangeAdd(v59 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v59 + 16LL))(v59);
    }
  }
  sub_7FF91DF6D8E0();
  v156 = v111;
  v111 = v7[102];
  v7[102] = v156;
  v60 = (volatile signed __int32 *)v7[103];
  v7[103] = v112;
  v112 = v60;
  sub_7FF91DF5D340(&v112);
  v61 = operator new(0x20u);
  if ( v61 )
    v62 = sub_7FF91DFBAEC0((__int64)v61, a4);
  else
    v62 = 0;
  v109 = v62;
  v110 = nullptr;
  v63 = (volatile signed __int32 **)sub_7FF91E012C80(&v129, v62);
  v64 = v110;
  v110 = *v63;
  *v63 = v64;
  v65 = v129;
  if ( v129 )
  {
    if ( _InterlockedExchangeAdd(v129 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v65 + 8LL))(v65);
      if ( _InterlockedExchangeAdd(v65 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v65 + 16LL))(v65);
    }
  }
  sub_7FF91DF6D8E0();
  v106 = v109;
  v109 = v7[104];
  v7[104] = v106;
  v66 = (volatile signed __int32 *)v7[105];
  v7[105] = v110;
  v110 = v66;
  sub_7FF91DF5D340(&v110);
  v67 = operator new(0x20u);
  if ( v67 )
    v68 = sub_7FF91DFB7D30((__int64)v67, a4);
  else
    v68 = 0;
  v113 = v68;
  v114 = 0;
  v69 = sub_7FF91E0129E0(&v130, v68);
  v70 = v114;
  v114 = *v69;
  *v69 = v70;
  v71 = v130;
  if ( v130 )
  {
    if ( _InterlockedExchangeAdd(v130 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v71 + 8LL))(v71);
      if ( _InterlockedExchangeAdd(v71 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v71 + 16LL))(v71);
    }
  }
  sub_7FF91DF6D8E0();
  v72 = v113;
  v113 = v7[108];
  v7[108] = v72;
  v73 = v7[109];
  v7[109] = v114;
  v114 = v73;
  sub_7FF91E014200(&v113);
  v74 = operator new(0x30u);
  v106 = (__int64)v74;
  if ( v74 )
    v75 = sub_7FF91DFB7F80((__int64)v74, a4);
  else
    v75 = 0;
  v115 = v75;
  v116 = 0;
  v76 = sub_7FF91E012AC0(&v131, v75);
  v77 = v116;
  v116 = *v76;
  *v76 = v77;
  sub_7FF91DF5D340(&v131);
  sub_7FF91DF6D8E0();
  v78 = v115;
  v115 = v7[110];
  v7[110] = v78;
  v79 = v7[111];
  v7[111] = v116;
  v116 = v79;
  sub_7FF91E014260(&v115);
  v80 = operator new(0x28u);
  v106 = (__int64)v80;
  if ( v80 )
    v81 = sub_7FF91DFB7EA0((__int64)v80, a4);
  else
    v81 = 0;
  v117 = v81;
  v118 = 0;
  v82 = sub_7FF91E012A50(&v132, v81);
  v83 = v118;
  v118 = *v82;
  *v82 = v83;
  sub_7FF91DF5D340(&v132);
  sub_7FF91DF6D8E0();
  v84 = v117;
  v117 = v7[112];
  v7[112] = v84;
  v85 = v7[113];
  v7[113] = v118;
  v118 = v85;
  sub_7FF91E014260(&v117);
  v86 = operator new(0x48u);
  v106 = (__int64)v86;
  if ( v86 )
    v87 = sub_7FF91DFB7650((__int64)v86, a4);
  else
    v87 = 0;
  v107 = v87;
  v108 = 0;
  v88 = sub_7FF91E012970(&v133, v87);
  v89 = v108;
  v108 = *v88;
  *v88 = v89;
  sub_7FF91DF5D340(&v133);
  sub_7FF91DF6D8E0();
  v90 = v107;
  v107 = v7[114];
  v7[114] = v90;
  v91 = v7[115];
  v7[115] = v108;
  v108 = v91;
  sub_7FF91E0141A0(&v107);
  v92 = operator new(0x30u);
  v106 = (__int64)v92;
  if ( v92 )
    v93 = sub_7FF91DFB71E0((__int64)v92, a4);
  else
    v93 = 0;
  v119 = v93;
  v120 = 0;
  v94 = sub_7FF91E012900(&v134, v93);
  v95 = v120;
  v120 = *v94;
  *v94 = v95;
  sub_7FF91DF5D340(&v134);
  sub_7FF91DF6D8E0();
  v96 = v119;
  v119 = v7[116];
  v7[116] = v96;
  v97 = v7[117];
  v7[117] = v120;
  v120 = v97;
  sub_7FF91E014140(&v119);
  return v7;
}


// ==== sub_7FF91E014120 @ rva 0x3B4120 ====
// attributes: thunk
__int64 sub_7FF91E014120()
{
  return sub_7FF91E0142C0();
}


// ==== sub_7FF91E014130 @ rva 0x3B4130 ====
// attributes: thunk
__int64 sub_7FF91E014130()
{
  return sub_7FF91E0142C0();
}


// ==== sub_7FF91E014140 @ rva 0x3B4140 ====
// Hidden C++ exception states: #wind=1
__int64 __fastcall sub_7FF91E014140(__int64 a1)
{
  volatile signed __int32 *v1; // rbx
  __int64 result; // rax

  v1 = *(volatile signed __int32 **)(a1 + 8);
  if ( v1 )
  {
    result = (unsigned int)_InterlockedExchangeAdd(v1 + 2, 0xFFFFFFFF);
    if ( (_DWORD)result == 1 )
    {
      result = (*(__int64 (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 8LL))(v1);
      if ( _InterlockedExchangeAdd(v1 + 3, 0xFFFFFFFF) == 1 )
        return (*(__int64 (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
    }
  }
  return result;
}


// ==== sub_7FF91E0141A0 @ rva 0x3B41A0 ====
// Hidden C++ exception states: #wind=1
__int64 __fastcall sub_7FF91E0141A0(__int64 a1)
{
  volatile signed __int32 *v1; // rbx
  __int64 result; // rax

  v1 = *(volatile signed __int32 **)(a1 + 8);
  if ( v1 )
  {
    result = (unsigned int)_InterlockedExchangeAdd(v1 + 2, 0xFFFFFFFF);
    if ( (_DWORD)result == 1 )
    {
      result = (*(__int64 (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 8LL))(v1);
      if ( _InterlockedExchangeAdd(v1 + 3, 0xFFFFFFFF) == 1 )
        return (*(__int64 (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
    }
  }
  return result;
}


// ==== sub_7FF91E014200 @ rva 0x3B4200 ====
// Hidden C++ exception states: #wind=1
__int64 __fastcall sub_7FF91E014200(__int64 a1)
{
  volatile signed __int32 *v1; // rbx
  __int64 result; // rax

  v1 = *(volatile signed __int32 **)(a1 + 8);
  if ( v1 )
  {
    result = (unsigned int)_InterlockedExchangeAdd(v1 + 2, 0xFFFFFFFF);
    if ( (_DWORD)result == 1 )
    {
      result = (*(__int64 (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 8LL))(v1);
      if ( _InterlockedExchangeAdd(v1 + 3, 0xFFFFFFFF) == 1 )
        return (*(__int64 (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
    }
  }
  return result;
}


// ==== sub_7FF91E014260 @ rva 0x3B4260 ====
// Hidden C++ exception states: #wind=1
__int64 __fastcall sub_7FF91E014260(__int64 a1)
{
  volatile signed __int32 *v1; // rbx
  __int64 result; // rax

  v1 = *(volatile signed __int32 **)(a1 + 8);
  if ( v1 )
  {
    result = (unsigned int)_InterlockedExchangeAdd(v1 + 2, 0xFFFFFFFF);
    if ( (_DWORD)result == 1 )
    {
      result = (*(__int64 (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 8LL))(v1);
      if ( _InterlockedExchangeAdd(v1 + 3, 0xFFFFFFFF) == 1 )
        return (*(__int64 (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v1 + 16LL))(v1);
    }
  }
  return result;
}


// ==== sub_7FF91E0142C0 @ rva 0x3B42C0 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91E0142C0(_QWORD *a1)
{
  volatile signed __int32 *v2; // rsi
  volatile signed __int32 *v3; // rsi
  volatile signed __int32 *v4; // rsi
  volatile signed __int32 *v5; // rsi
  volatile signed __int32 *v6; // rsi
  volatile signed __int32 *v7; // rsi
  volatile signed __int32 *v8; // rsi
  volatile signed __int32 *v9; // rsi
  volatile signed __int32 *v10; // rsi
  volatile signed __int32 *v11; // rsi

  v2 = (volatile signed __int32 *)a1[117];
  if ( v2 )
  {
    if ( _InterlockedExchangeAdd(v2 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 8LL))(v2);
      if ( _InterlockedExchangeAdd(v2 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v2 + 16LL))(v2);
    }
  }
  v3 = (volatile signed __int32 *)a1[115];
  if ( v3 )
  {
    if ( _InterlockedExchangeAdd(v3 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 8LL))(v3);
      if ( _InterlockedExchangeAdd(v3 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v3 + 16LL))(v3);
    }
  }
  v4 = (volatile signed __int32 *)a1[113];
  if ( v4 )
  {
    if ( _InterlockedExchangeAdd(v4 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 8LL))(v4);
      if ( _InterlockedExchangeAdd(v4 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v4 + 16LL))(v4);
    }
  }
  v5 = (volatile signed __int32 *)a1[111];
  if ( v5 )
  {
    if ( _InterlockedExchangeAdd(v5 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 8LL))(v5);
      if ( _InterlockedExchangeAdd(v5 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v5 + 16LL))(v5);
    }
  }
  v6 = (volatile signed __int32 *)a1[109];
  if ( v6 )
  {
    if ( _InterlockedExchangeAdd(v6 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 8LL))(v6);
      if ( _InterlockedExchangeAdd(v6 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v6 + 16LL))(v6);
    }
  }
  v7 = (volatile signed __int32 *)a1[107];
  if ( v7 )
  {
    if ( _InterlockedExchangeAdd(v7 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 8LL))(v7);
      if ( _InterlockedExchangeAdd(v7 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v7 + 16LL))(v7);
    }
  }
  v8 = (volatile signed __int32 *)a1[105];
  if ( v8 )
  {
    if ( _InterlockedExchangeAdd(v8 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 8LL))(v8);
      if ( _InterlockedExchangeAdd(v8 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v8 + 16LL))(v8);
    }
  }
  v9 = (volatile signed __int32 *)a1[103];
  if ( v9 )
  {
    if ( _InterlockedExchangeAdd(v9 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 8LL))(v9);
      if ( _InterlockedExchangeAdd(v9 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v9 + 16LL))(v9);
    }
  }
  v10 = (volatile signed __int32 *)a1[101];
  if ( v10 )
  {
    if ( _InterlockedExchangeAdd(v10 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 8LL))(v10);
      if ( _InterlockedExchangeAdd(v10 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v10 + 16LL))(v10);
    }
  }
  v11 = (volatile signed __int32 *)a1[99];
  if ( v11 )
  {
    if ( _InterlockedExchangeAdd(v11 + 2, 0xFFFFFFFF) == 1 )
    {
      (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 8LL))(v11);
      if ( _InterlockedExchangeAdd(v11 + 3, 0xFFFFFFFF) == 1 )
        (*(void (__fastcall **)(volatile signed __int32 *))(*(_QWORD *)v11 + 16LL))(v11);
    }
  }
  `eh vector destructor iterator'(a1 + 82, 0x10u, 8u, (void (*)(void *))sub_7FF91E00C8C0);
  `eh vector destructor iterator'(a1 + 66, 0x10u, 8u, (void (*)(void *))sub_7FF91E00C980);
  `eh vector destructor iterator'(a1 + 50, 0x10u, 8u, (void (*)(void *))sub_7FF91E00CA40);
  `eh vector destructor iterator'(a1 + 34, 0x10u, 8u, (void (*)(void *))sub_7FF91E00CAA0);
  `eh vector destructor iterator'(a1 + 18, 0x10u, 8u, (void (*)(void *))sub_7FF91E00C920);
  `eh vector destructor iterator'(a1 + 2, 0x10u, 8u, (void (*)(void *))sub_7FF91E00C9E0);
}


// ==== sub_7FF91E0145D0 @ rva 0x3B45D0 ====
_QWORD *__fastcall sub_7FF91E0145D0(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E014600 @ rva 0x3B4600 ====
_QWORD *__fastcall sub_7FF91E014600(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E014630 @ rva 0x3B4630 ====
_QWORD *__fastcall sub_7FF91E014630(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E014660 @ rva 0x3B4660 ====
_QWORD *__fastcall sub_7FF91E014660(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E014690 @ rva 0x3B4690 ====
_QWORD *__fastcall sub_7FF91E014690(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E0146C0 @ rva 0x3B46C0 ====
_QWORD *__fastcall sub_7FF91E0146C0(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E0146F0 @ rva 0x3B46F0 ====
_QWORD *__fastcall sub_7FF91E0146F0(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E014720 @ rva 0x3B4720 ====
_QWORD *__fastcall sub_7FF91E014720(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E014750 @ rva 0x3B4750 ====
_QWORD *__fastcall sub_7FF91E014750(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E014780 @ rva 0x3B4780 ====
_QWORD *__fastcall sub_7FF91E014780(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E0147B0 @ rva 0x3B47B0 ====
_QWORD *__fastcall sub_7FF91E0147B0(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E0147E0 @ rva 0x3B47E0 ====
_QWORD *__fastcall sub_7FF91E0147E0(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E014810 @ rva 0x3B4810 ====
_QWORD *__fastcall sub_7FF91E014810(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E014840 @ rva 0x3B4840 ====
_QWORD *__fastcall sub_7FF91E014840(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E014870 @ rva 0x3B4870 ====
_QWORD *__fastcall sub_7FF91E014870(_QWORD *a1, char a2)
{
  *a1 = &boost::detail::sp_counted_base::`vftable';
  if ( (a2 & 1) != 0 )
    j_j_free(a1);
  return a1;
}


// ==== sub_7FF91E0148A0 @ rva 0x3B48A0 ====
__int64 __fastcall sub_7FF91E0148A0(__int64 *a1, __int64 a2)
{
  __int64 v2; // rsi
  int v3; // edi
  __int64 (__fastcall *v5)(__int64 *, __int64, __int64); // rax
  unsigned int v6; // eax
  unsigned int v7; // eax
  __int64 v8; // rsi
  unsigned int v9; // eax
  __int64 v10; // rsi
  unsigned int v11; // eax
  __int64 v12; // rsi
  unsigned int v13; // eax
  __int64 v14; // rsi
  unsigned int v15; // eax
  __int64 v16; // rsi
  unsigned int v17; // eax
  __int64 v18; // rsi
  unsigned int v19; // eax
  __int64 v20; // rsi
  unsigned int v21; // eax
  __int64 v22; // rsi
  unsigned int v23; // eax
  __int64 v24; // rsi
  unsigned int v25; // eax
  __int64 v26; // rsi
  unsigned int v27; // eax
  __int64 v28; // rsi
  unsigned int v29; // eax
  __int64 v30; // rsi
  unsigned int v31; // eax
  __int64 v32; // rsi
  unsigned int v33; // eax
  __int64 v34; // rsi
  unsigned int v35; // eax
  __int64 v36; // rsi
  unsigned int v37; // eax
  __int64 v38; // rsi
  unsigned int v39; // eax
  __int64 v40; // rsi
  unsigned int v41; // eax
  __int64 v42; // rsi
  unsigned int v43; // eax
  __int64 v44; // rsi
  unsigned int v45; // eax
  __int64 v46; // rsi
  unsigned int v47; // eax
  __int64 v48; // rsi
  unsigned int v49; // eax
  __int64 v50; // rsi
  unsigned int v51; // eax
  __int64 v52; // rsi
  unsigned int v53; // eax
  __int64 v54; // rsi
  unsigned int v55; // eax
  __int64 v56; // rsi
  unsigned int v57; // eax
  __int64 v58; // rsi
  unsigned int v59; // eax
  __int64 v60; // rsi
  unsigned int v61; // eax
  __int64 v62; // rsi
  unsigned int v63; // eax
  __int64 v64; // rsi
  unsigned int v65; // eax
  __int64 v66; // rsi
  unsigned int v67; // eax
  __int64 v68; // rsi
  unsigned int v69; // eax
  __int64 v70; // rsi
  unsigned int v71; // eax
  __int64 v72; // rsi
  unsigned int v73; // eax
  __int64 v74; // rsi
  unsigned int v75; // eax
  __int64 v76; // rsi
  unsigned int v77; // eax
  __int64 v78; // rsi
  unsigned int v79; // eax
  __int64 v80; // rsi
  unsigned int v81; // eax
  __int64 v82; // rsi
  unsigned int v83; // eax
  __int64 v84; // rsi
  unsigned int v85; // eax
  __int64 v86; // rsi
  unsigned int v87; // eax
  __int64 v88; // rsi
  unsigned int v89; // eax
  __int64 v90; // rsi
  unsigned int v91; // eax
  __int64 v92; // rsi
  unsigned int v93; // eax
  __int64 v94; // rsi
  unsigned int v95; // eax
  __int64 v96; // rsi
  unsigned int v97; // eax
  __int64 v98; // rsi
  unsigned int v99; // eax
  __int64 v100; // rsi
  unsigned int v101; // eax
  __int64 v102; // rsi
  unsigned int v103; // eax
  __int64 v104; // rsi
  unsigned int v105; // eax
  __int64 v106; // rsi
  unsigned int v107; // eax
  __int64 v108; // rsi
  unsigned int v109; // eax
  __int64 v110; // rsi
  unsigned int v111; // eax
  __int64 v112; // rsi
  unsigned int v113; // eax
  __int64 v114; // rsi
  unsigned int v115; // eax
  __int64 v116; // rsi
  unsigned int v117; // eax
  __int64 v118; // rsi
  unsigned int v119; // eax
  __int64 v120; // rsi
  unsigned int v121; // eax
  __int64 v122; // rsi
  unsigned int v123; // eax
  __int64 v124; // rsi
  unsigned int v125; // eax
  __int64 v126; // rsi
  unsigned int v127; // eax
  __int64 v128; // rsi
  unsigned int v129; // eax
  __int64 v130; // rsi
  unsigned int v131; // eax
  __int64 v132; // rsi
  unsigned int v133; // eax
  __int64 v134; // rsi
  unsigned int v135; // eax
  __int64 v136; // rsi
  unsigned int v137; // eax
  __int64 v138; // rsi
  unsigned int v139; // eax
  __int64 v140; // rsi
  unsigned int v141; // eax
  __int64 v142; // rsi
  unsigned int v143; // eax
  __int64 v144; // rsi
  unsigned int v145; // eax
  __int64 v146; // rsi
  unsigned int v147; // eax
  __int64 v148; // rsi
  unsigned int v149; // eax
  __int64 v150; // rsi
  unsigned int v151; // eax
  __int64 v152; // rsi
  unsigned int v153; // eax
  __int64 v154; // rsi
  unsigned int v155; // eax
  __int64 v156; // rsi
  unsigned int v157; // eax
  __int64 v158; // rsi
  unsigned int v159; // eax
  __int64 v160; // rsi
  unsigned int v161; // eax
  __int64 v162; // rsi
  unsigned int v163; // eax
  __int64 v164; // rsi
  unsigned int v165; // eax
  __int64 v166; // rsi
  unsigned int v167; // eax
  __int64 v168; // rsi
  unsigned int v169; // eax
  __int64 v170; // rsi
  unsigned int v171; // eax
  __int64 v172; // rsi
  unsigned int v173; // eax
  __int64 v174; // rsi
  unsigned int v175; // eax
  __int64 v176; // rsi
  unsigned int v177; // eax
  __int64 v178; // rsi
  unsigned int v179; // eax
  __int64 v180; // rsi
  unsigned int v181; // eax
  __int64 v182; // rsi
  unsigned int v183; // eax
  __int64 v184; // rsi
  unsigned int v185; // eax
  __int64 v186; // rsi
  unsigned int v187; // eax
  __int64 v188; // rsi
  unsigned int v189; // eax
  __int64 v190; // rsi
  unsigned int v191; // eax
  __int64 v192; // rsi
  unsigned int v193; // eax
  __int64 v194; // rsi
  unsigned int v195; // eax
  __int64 v196; // rsi
  unsigned int v197; // eax
  __int64 v198; // rsi
  unsigned int v199; // eax
  __int64 v200; // rsi
  unsigned int v201; // eax
  __int64 v202; // rsi
  unsigned int v203; // eax
  __int64 v204; // rsi
  unsigned int v205; // eax
  __int64 v206; // rsi
  unsigned int v207; // eax
  __int64 v208; // rsi
  unsigned int v209; // eax
  __int64 v210; // rsi
  unsigned int v211; // eax
  __int64 v212; // rsi
  unsigned int v213; // eax
  __int64 v214; // rsi
  unsigned int v215; // eax
  __int64 v216; // rsi
  unsigned int v217; // eax
  __int64 v218; // rsi
  unsigned int v219; // eax
  __int64 v220; // rsi
  unsigned int v221; // eax
  __int64 v222; // rsi
  unsigned int v223; // eax
  __int64 v224; // rsi
  unsigned int v225; // eax
  __int64 v226; // rsi
  unsigned int v227; // eax
  __int64 v228; // rsi
  unsigned int v229; // eax
  __int64 v230; // rsi
  unsigned int v231; // eax
  __int64 v232; // rsi
  unsigned int v233; // eax
  __int64 v234; // rsi
  unsigned int v235; // eax
  __int64 v236; // rsi
  unsigned int v237; // eax
  __int64 v238; // rsi
  unsigned int v239; // eax
  __int64 v240; // rsi
  unsigned int v241; // eax
  __int64 v242; // rsi
  unsigned int v243; // eax
  __int64 v244; // rsi
  unsigned int v245; // eax
  __int64 v246; // rsi
  unsigned int v247; // eax
  __int64 v248; // rsi
  unsigned int v249; // eax
  __int64 v250; // rsi
  unsigned int v251; // eax
  __int64 v252; // rsi
  unsigned int v253; // eax
  __int64 v254; // rsi
  unsigned int v255; // eax
  __int64 v256; // rsi
  unsigned int v257; // eax
  __int64 v258; // rsi
  unsigned int v259; // eax
  __int64 v260; // rsi
  unsigned int v261; // eax
  __int64 v262; // rsi
  unsigned int v263; // eax
  __int64 v264; // rsi
  unsigned int v265; // eax
  __int64 v266; // rsi
  unsigned int v267; // eax
  __int64 v268; // rsi
  unsigned int v269; // eax
  __int64 v270; // rsi
  unsigned int v271; // eax
  __int64 v272; // rsi
  unsigned int v273; // eax
  __int64 v274; // rsi
  unsigned int v275; // eax
  __int64 v276; // rsi
  unsigned int v277; // eax
  __int64 v278; // rsi
  unsigned int v279; // eax
  __int64 v280; // rsi
  unsigned int v281; // eax
  __int64 v282; // rsi
  unsigned int v283; // eax
  __int64 v284; // rsi
  unsigned int v285; // eax
  __int64 v286; // rsi
  unsigned int v287; // eax
  __int64 v288; // rsi
  unsigned int v289; // eax
  __int64 v290; // rsi
  unsigned int v291; // eax
  __int64 v292; // rsi
  unsigned int v293; // eax
  __int64 v294; // rsi
  unsigned int v295; // eax
  __int64 v296; // rsi
  unsigned int v297; // eax
  __int64 v298; // rsi
  unsigned int v299; // eax
  __int64 v300; // rsi
  unsigned int v301; // eax
  __int64 v302; // rsi
  unsigned int v303; // eax
  __int64 v304; // rsi
  unsigned int v305; // eax
  __int64 v306; // rsi
  unsigned int v307; // eax
  __int64 v308; // rsi
  unsigned int v309; // eax
  __int64 v310; // rsi
  unsigned int v311; // eax
  __int64 v312; // rsi
  unsigned int v313; // eax
  __int64 v314; // rsi
  unsigned int v315; // eax
  __int64 v316; // rsi
  unsigned int v317; // eax
  __int64 v318; // rsi
  unsigned int v319; // eax
  __int64 v320; // rsi
  unsigned int v321; // eax
  __int64 v322; // rsi
  unsigned int v323; // eax
  __int64 v324; // rsi
  unsigned int v325; // eax
  __int64 v326; // rsi
  unsigned int v327; // eax
  __int64 v328; // rsi
  unsigned int v329; // eax
  __int64 v330; // rsi
  unsigned int v331; // eax
  __int64 v332; // rsi
  unsigned int v333; // eax
  __int64 v334; // rsi
  unsigned int v335; // eax

  v2 = *a1;
  v3 = a2;
  v5 = *(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104);
  if ( (_DWORD)a2 )
  {
    v7 = v5(a1, 0, 20);
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v2 + 88))(a1, 20, 1, v7);
  }
  else
  {
    v6 = v5(a1, a2, 20);
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v2 + 80))(a1, 20, v6);
  }
  v8 = *a1;
  v9 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 128);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v8 + 88))(a1, 128, 1, v9);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v8 + 80))(a1, 128, v9);
  v10 = *a1;
  v11 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 129);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v10 + 88))(a1, 129, 1, v11);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v10 + 80))(a1, 129, v11);
  v12 = *a1;
  v13 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 130);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v12 + 88))(a1, 130, 1, v13);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v12 + 80))(a1, 130, v13);
  v14 = *a1;
  v15 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 131);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v14 + 88))(a1, 131, 1, v15);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v14 + 80))(a1, 131, v15);
  v16 = *a1;
  v17 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 132);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v16 + 88))(a1, 132, 1, v17);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v16 + 80))(a1, 132, v17);
  v18 = *a1;
  v19 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 133);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v18 + 88))(a1, 133, 1, v19);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v18 + 80))(a1, 133, v19);
  v20 = *a1;
  v21 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 134);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v20 + 88))(a1, 134, 1, v21);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v20 + 80))(a1, 134, v21);
  v22 = *a1;
  v23 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 135);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v22 + 88))(a1, 135, 1, v23);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v22 + 80))(a1, 135, v23);
  v24 = *a1;
  v25 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 136);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v24 + 88))(a1, 136, 1, v25);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v24 + 80))(a1, 136, v25);
  v26 = *a1;
  v27 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 137);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v26 + 88))(a1, 137, 1, v27);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v26 + 80))(a1, 137, v27);
  v28 = *a1;
  v29 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 138);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v28 + 88))(a1, 138, 1, v29);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v28 + 80))(a1, 138, v29);
  v30 = *a1;
  v31 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 139);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v30 + 88))(a1, 139, 1, v31);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v30 + 80))(a1, 139, v31);
  v32 = *a1;
  v33 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 140);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v32 + 88))(a1, 140, 1, v33);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v32 + 80))(a1, 140, v33);
  v34 = *a1;
  v35 = (*(__int64 (__fastcall **)(__int64 *, _QWORD, __int64))(*a1 + 104))(a1, 0, 141);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v34 + 88))(a1, 141, 1, v35);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v34 + 80))(a1, 141, v35);
  v36 = *a1;
  v37 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 1, 189);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v36 + 88))(a1, 189, 1, v37);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v36 + 80))(a1, 189, v37);
  v38 = *a1;
  v39 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 1, 196);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v38 + 88))(a1, 196, 1, v39);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v38 + 80))(a1, 196, v39);
  v40 = *a1;
  v41 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 1, 254);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v40 + 88))(a1, 254, 1, v41);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v40 + 80))(a1, 254, v41);
  v42 = *a1;
  v43 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 1, 312);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v42 + 88))(a1, 312, 1, v43);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v42 + 80))(a1, 312, v43);
  v44 = *a1;
  v45 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 1, 313);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v44 + 88))(a1, 313, 1, v45);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v44 + 80))(a1, 313, v45);
  v46 = *a1;
  v47 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 1, 314);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v46 + 88))(a1, 314, 1, v47);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v46 + 80))(a1, 314, v47);
  v48 = *a1;
  v49 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 1, 315);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v48 + 88))(a1, 315, 1, v49);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v48 + 80))(a1, 315, v49);
  v50 = *a1;
  v51 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 1, 316);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v50 + 88))(a1, 316, 1, v51);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v50 + 80))(a1, 316, v51);
  v52 = *a1;
  v53 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 1, 317);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v52 + 88))(a1, 317, 1, v53);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v52 + 80))(a1, 317, v53);
  v54 = *a1;
  v55 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 1, 318);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v54 + 88))(a1, 318, 1, v55);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v54 + 80))(a1, 318, v55);
  v56 = *a1;
  v57 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 373);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v56 + 88))(a1, 373, 1, v57);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v56 + 80))(a1, 373, v57);
  v58 = *a1;
  v59 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 375);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v58 + 88))(a1, 375, 1, v59);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v58 + 80))(a1, 375, v59);
  v60 = *a1;
  v61 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 433);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v60 + 88))(a1, 433, 1, v61);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v60 + 80))(a1, 433, v61);
  v62 = *a1;
  v63 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 434);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v62 + 88))(a1, 434, 1, v63);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v62 + 80))(a1, 434, v63);
  v64 = *a1;
  v65 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 435);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v64 + 88))(a1, 435, 1, v65);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v64 + 80))(a1, 435, v65);
  v66 = *a1;
  v67 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 436);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v66 + 88))(a1, 436, 1, v67);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v66 + 80))(a1, 436, v67);
  v68 = *a1;
  v69 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 437);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v68 + 88))(a1, 437, 1, v69);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v68 + 80))(a1, 437, v69);
  v70 = *a1;
  v71 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 438);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v70 + 88))(a1, 438, 1, v71);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v70 + 80))(a1, 438, v71);
  v72 = *a1;
  v73 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 439);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v72 + 88))(a1, 439, 1, v73);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v72 + 80))(a1, 439, v73);
  v74 = *a1;
  v75 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 440);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v74 + 88))(a1, 440, 1, v75);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v74 + 80))(a1, 440, v75);
  v76 = *a1;
  v77 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 450);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v76 + 88))(a1, 450, 1, v77);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v76 + 80))(a1, 450, v77);
  v78 = *a1;
  v79 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 451);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v78 + 88))(a1, 451, 1, v79);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v78 + 80))(a1, 451, v79);
  v80 = *a1;
  v81 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 452);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v80 + 88))(a1, 452, 1, v81);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v80 + 80))(a1, 452, v81);
  v82 = *a1;
  v83 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 453);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v82 + 88))(a1, 453, 1, v83);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v82 + 80))(a1, 453, v83);
  v84 = *a1;
  v85 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 454);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v84 + 88))(a1, 454, 1, v85);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v84 + 80))(a1, 454, v85);
  v86 = *a1;
  v87 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 455);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v86 + 88))(a1, 455, 1, v87);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v86 + 80))(a1, 455, v87);
  v88 = *a1;
  v89 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 456);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v88 + 88))(a1, 456, 1, v89);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v88 + 80))(a1, 456, v89);
  v90 = *a1;
  v91 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 457);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v90 + 88))(a1, 457, 1, v91);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v90 + 80))(a1, 457, v91);
  v92 = *a1;
  v93 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 467);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v92 + 88))(a1, 467, 1, v93);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v92 + 80))(a1, 467, v93);
  v94 = *a1;
  v95 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 468);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v94 + 88))(a1, 468, 1, v95);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v94 + 80))(a1, 468, v95);
  v96 = *a1;
  v97 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 469);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v96 + 88))(a1, 469, 1, v97);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v96 + 80))(a1, 469, v97);
  v98 = *a1;
  v99 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 470);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v98 + 88))(a1, 470, 1, v99);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v98 + 80))(a1, 470, v99);
  v100 = *a1;
  v101 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 471);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v100 + 88))(a1, 471, 1, v101);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v100 + 80))(a1, 471, v101);
  v102 = *a1;
  v103 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 472);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v102 + 88))(a1, 472, 1, v103);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v102 + 80))(a1, 472, v103);
  v104 = *a1;
  v105 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 473);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v104 + 88))(a1, 473, 1, v105);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v104 + 80))(a1, 473, v105);
  v106 = *a1;
  v107 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 474);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v106 + 88))(a1, 474, 1, v107);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v106 + 80))(a1, 474, v107);
  v108 = *a1;
  v109 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 484);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v108 + 88))(a1, 484, 1, v109);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v108 + 80))(a1, 484, v109);
  v110 = *a1;
  v111 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 493);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v110 + 88))(a1, 493, 1, v111);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v110 + 80))(a1, 493, v111);
  v112 = *a1;
  v113 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 495);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v112 + 88))(a1, 495, 1, v113);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v112 + 80))(a1, 495, v113);
  v114 = *a1;
  v115 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 498);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v114 + 88))(a1, 498, 1, v115);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v114 + 80))(a1, 498, v115);
  v116 = *a1;
  v117 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 553);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v116 + 88))(a1, 553, 1, v117);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v116 + 80))(a1, 553, v117);
  v118 = *a1;
  v119 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 554);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v118 + 88))(a1, 554, 1, v119);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v118 + 80))(a1, 554, v119);
  v120 = *a1;
  v121 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 2, 555);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v120 + 88))(a1, 555, 1, v121);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v120 + 80))(a1, 555, v121);
  v122 = *a1;
  v123 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 3, 614);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v122 + 88))(a1, 614, 1, v123);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v122 + 80))(a1, 614, v123);
  v124 = *a1;
  v125 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 3, 657);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v124 + 88))(a1, 657, 1, v125);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v124 + 80))(a1, 657, v125);
  v126 = *a1;
  v127 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 3, 665);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v126 + 88))(a1, 665, 1, v127);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v126 + 80))(a1, 665, v127);
  v128 = *a1;
  v129 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 3, 668);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v128 + 88))(a1, 668, 1, v129);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v128 + 80))(a1, 668, v129);
  v130 = *a1;
  v131 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 3, 669);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v130 + 88))(a1, 669, 1, v131);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v130 + 80))(a1, 669, v131);
  v132 = *a1;
  v133 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 3, 699);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v132 + 88))(a1, 699, 1, v133);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v132 + 80))(a1, 699, v133);
  v134 = *a1;
  v135 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 3, 707);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v134 + 88))(a1, 707, 1, v135);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v134 + 80))(a1, 707, v135);
  v136 = *a1;
  v137 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 3, 710);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v136 + 88))(a1, 710, 1, v137);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v136 + 80))(a1, 710, v137);
  v138 = *a1;
  v139 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 3, 711);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v138 + 88))(a1, 711, 1, v139);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v138 + 80))(a1, 711, v139);
  v140 = *a1;
  v141 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 751);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v140 + 88))(a1, 751, 1, v141);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v140 + 80))(a1, 751, v141);
  v142 = *a1;
  v143 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 752);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v142 + 88))(a1, 752, 1, v143);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v142 + 80))(a1, 752, v143);
  v144 = *a1;
  v145 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 753);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v144 + 88))(a1, 753, 1, v145);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v144 + 80))(a1, 753, v145);
  v146 = *a1;
  v147 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 754);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v146 + 88))(a1, 754, 1, v147);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v146 + 80))(a1, 754, v147);
  v148 = *a1;
  v149 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 756);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v148 + 88))(a1, 756, 1, v149);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v148 + 80))(a1, 756, v149);
  v150 = *a1;
  v151 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 757);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v150 + 88))(a1, 757, 1, v151);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v150 + 80))(a1, 757, v151);
  v152 = *a1;
  v153 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 758);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v152 + 88))(a1, 758, 1, v153);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v152 + 80))(a1, 758, v153);
  v154 = *a1;
  v155 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 759);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v154 + 88))(a1, 759, 1, v155);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v154 + 80))(a1, 759, v155);
  v156 = *a1;
  v157 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 760);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v156 + 88))(a1, 760, 1, v157);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v156 + 80))(a1, 760, v157);
  v158 = *a1;
  v159 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 770);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v158 + 88))(a1, 770, 1, v159);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v158 + 80))(a1, 770, v159);
  v160 = *a1;
  v161 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 771);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v160 + 88))(a1, 771, 1, v161);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v160 + 80))(a1, 771, v161);
  v162 = *a1;
  v163 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 772);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v162 + 88))(a1, 772, 1, v163);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v162 + 80))(a1, 772, v163);
  v164 = *a1;
  v165 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 773);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v164 + 88))(a1, 773, 1, v165);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v164 + 80))(a1, 773, v165);
  v166 = *a1;
  v167 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 779);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v166 + 88))(a1, 779, 1, v167);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v166 + 80))(a1, 779, v167);
  v168 = *a1;
  v169 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 781);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v168 + 88))(a1, 781, 1, v169);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v168 + 80))(a1, 781, v169);
  v170 = *a1;
  v171 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 782);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v170 + 88))(a1, 782, 1, v171);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v170 + 80))(a1, 782, v171);
  v172 = *a1;
  v173 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 783);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v172 + 88))(a1, 783, 1, v173);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v172 + 80))(a1, 783, v173);
  v174 = *a1;
  v175 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 784);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v174 + 88))(a1, 784, 1, v175);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v174 + 80))(a1, 784, v175);
  v176 = *a1;
  v177 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 785);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v176 + 88))(a1, 785, 1, v177);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v176 + 80))(a1, 785, v177);
  v178 = *a1;
  v179 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 786);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v178 + 88))(a1, 786, 1, v179);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v178 + 80))(a1, 786, v179);
  v180 = *a1;
  v181 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 787);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v180 + 88))(a1, 787, 1, v181);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v180 + 80))(a1, 787, v181);
  v182 = *a1;
  v183 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 788);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v182 + 88))(a1, 788, 1, v183);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v182 + 80))(a1, 788, v183);
  v184 = *a1;
  v185 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 789);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v184 + 88))(a1, 789, 1, v185);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v184 + 80))(a1, 789, v185);
  v186 = *a1;
  v187 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 790);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v186 + 88))(a1, 790, 1, v187);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v186 + 80))(a1, 790, v187);
  v188 = *a1;
  v189 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 791);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v188 + 88))(a1, 791, 1, v189);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v188 + 80))(a1, 791, v189);
  v190 = *a1;
  v191 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 792);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v190 + 88))(a1, 792, 1, v191);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v190 + 80))(a1, 792, v191);
  v192 = *a1;
  v193 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 793);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v192 + 88))(a1, 793, 1, v193);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v192 + 80))(a1, 793, v193);
  v194 = *a1;
  v195 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 794);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v194 + 88))(a1, 794, 1, v195);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v194 + 80))(a1, 794, v195);
  v196 = *a1;
  v197 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 795);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v196 + 88))(a1, 795, 1, v197);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v196 + 80))(a1, 795, v197);
  v198 = *a1;
  v199 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 796);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v198 + 88))(a1, 796, 1, v199);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v198 + 80))(a1, 796, v199);
  v200 = *a1;
  v201 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 797);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v200 + 88))(a1, 797, 1, v201);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v200 + 80))(a1, 797, v201);
  v202 = *a1;
  v203 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 798);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v202 + 88))(a1, 798, 1, v203);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v202 + 80))(a1, 798, v203);
  v204 = *a1;
  v205 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 799);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v204 + 88))(a1, 799, 1, v205);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v204 + 80))(a1, 799, v205);
  v206 = *a1;
  v207 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 800);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v206 + 88))(a1, 800, 1, v207);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v206 + 80))(a1, 800, v207);
  v208 = *a1;
  v209 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 801);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v208 + 88))(a1, 801, 1, v209);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v208 + 80))(a1, 801, v209);
  v210 = *a1;
  v211 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 803);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v210 + 88))(a1, 803, 1, v211);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v210 + 80))(a1, 803, v211);
  v212 = *a1;
  v213 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 810);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v212 + 88))(a1, 810, 1, v213);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v212 + 80))(a1, 810, v213);
  v214 = *a1;
  v215 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 830);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v214 + 88))(a1, 830, 1, v215);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v214 + 80))(a1, 830, v215);
  v216 = *a1;
  v217 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 838);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v216 + 88))(a1, 838, 1, v217);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v216 + 80))(a1, 838, v217);
  v218 = *a1;
  v219 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 839);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v218 + 88))(a1, 839, 1, v219);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v218 + 80))(a1, 839, v219);
  v220 = *a1;
  v221 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 840);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v220 + 88))(a1, 840, 1, v221);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v220 + 80))(a1, 840, v221);
  v222 = *a1;
  v223 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 841);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v222 + 88))(a1, 841, 1, v223);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v222 + 80))(a1, 841, v223);
  v224 = *a1;
  v225 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 842);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v224 + 88))(a1, 842, 1, v225);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v224 + 80))(a1, 842, v225);
  v226 = *a1;
  v227 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 843);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v226 + 88))(a1, 843, 1, v227);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v226 + 80))(a1, 843, v227);
  v228 = *a1;
  v229 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 844);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v228 + 88))(a1, 844, 1, v229);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v228 + 80))(a1, 844, v229);
  v230 = *a1;
  v231 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 845);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v230 + 88))(a1, 845, 1, v231);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v230 + 80))(a1, 845, v231);
  v232 = *a1;
  v233 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 846);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v232 + 88))(a1, 846, 1, v233);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v232 + 80))(a1, 846, v233);
  v234 = *a1;
  v235 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 847);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v234 + 88))(a1, 847, 1, v235);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v234 + 80))(a1, 847, v235);
  v236 = *a1;
  v237 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 848);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v236 + 88))(a1, 848, 1, v237);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v236 + 80))(a1, 848, v237);
  v238 = *a1;
  v239 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 849);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v238 + 88))(a1, 849, 1, v239);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v238 + 80))(a1, 849, v239);
  v240 = *a1;
  v241 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 850);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v240 + 88))(a1, 850, 1, v241);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v240 + 80))(a1, 850, v241);
  v242 = *a1;
  v243 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 851);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v242 + 88))(a1, 851, 1, v243);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v242 + 80))(a1, 851, v243);
  v244 = *a1;
  v245 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 852);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v244 + 88))(a1, 852, 1, v245);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v244 + 80))(a1, 852, v245);
  v246 = *a1;
  v247 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 853);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v246 + 88))(a1, 853, 1, v247);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v246 + 80))(a1, 853, v247);
  v248 = *a1;
  v249 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 855);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v248 + 88))(a1, 855, 1, v249);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v248 + 80))(a1, 855, v249);
  v250 = *a1;
  v251 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 856);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v250 + 88))(a1, 856, 1, v251);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v250 + 80))(a1, 856, v251);
  v252 = *a1;
  v253 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 857);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v252 + 88))(a1, 857, 1, v253);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v252 + 80))(a1, 857, v253);
  v254 = *a1;
  v255 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 858);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v254 + 88))(a1, 858, 1, v255);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v254 + 80))(a1, 858, v255);
  v256 = *a1;
  v257 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 859);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v256 + 88))(a1, 859, 1, v257);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v256 + 80))(a1, 859, v257);
  v258 = *a1;
  v259 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 860);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v258 + 88))(a1, 860, 1, v259);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v258 + 80))(a1, 860, v259);
  v260 = *a1;
  v261 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 861);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v260 + 88))(a1, 861, 1, v261);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v260 + 80))(a1, 861, v261);
  v262 = *a1;
  v263 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 863);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v262 + 88))(a1, 863, 1, v263);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v262 + 80))(a1, 863, v263);
  v264 = *a1;
  v265 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 871);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v264 + 88))(a1, 871, 1, v265);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v264 + 80))(a1, 871, v265);
  v266 = *a1;
  v267 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 873);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v266 + 88))(a1, 873, 1, v267);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v266 + 80))(a1, 873, v267);
  v268 = *a1;
  v269 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 874);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v268 + 88))(a1, 874, 1, v269);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v268 + 80))(a1, 874, v269);
  v270 = *a1;
  v271 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 875);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v270 + 88))(a1, 875, 1, v271);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v270 + 80))(a1, 875, v271);
  v272 = *a1;
  v273 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 876);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v272 + 88))(a1, 876, 1, v273);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v272 + 80))(a1, 876, v273);
  v274 = *a1;
  v275 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 4, 877);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v274 + 88))(a1, 877, 1, v275);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v274 + 80))(a1, 877, v275);
  v276 = *a1;
  v277 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 878);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v276 + 88))(a1, 878, 1, v277);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v276 + 80))(a1, 878, v277);
  v278 = *a1;
  v279 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1028);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v278 + 88))(a1, 1028, 1, v279);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v278 + 80))(a1, 1028, v279);
  v280 = *a1;
  v281 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1029);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v280 + 88))(a1, 1029, 1, v281);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v280 + 80))(a1, 1029, v281);
  v282 = *a1;
  v283 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1058);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v282 + 88))(a1, 1058, 1, v283);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v282 + 80))(a1, 1058, v283);
  v284 = *a1;
  v285 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1178);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v284 + 88))(a1, 1178, 1, v285);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v284 + 80))(a1, 1178, v285);
  v286 = *a1;
  v287 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1179);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v286 + 88))(a1, 1179, 1, v287);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v286 + 80))(a1, 1179, v287);
  v288 = *a1;
  v289 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1180);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v288 + 88))(a1, 1180, 1, v289);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v288 + 80))(a1, 1180, v289);
  v290 = *a1;
  v291 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1181);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v290 + 88))(a1, 1181, 1, v291);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v290 + 80))(a1, 1181, v291);
  v292 = *a1;
  v293 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1182);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v292 + 88))(a1, 1182, 1, v293);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v292 + 80))(a1, 1182, v293);
  v294 = *a1;
  v295 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1183);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v294 + 88))(a1, 1183, 1, v295);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v294 + 80))(a1, 1183, v295);
  v296 = *a1;
  v297 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1184);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v296 + 88))(a1, 1184, 1, v297);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v296 + 80))(a1, 1184, v297);
  v298 = *a1;
  v299 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1185);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v298 + 88))(a1, 1185, 1, v299);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v298 + 80))(a1, 1185, v299);
  v300 = *a1;
  v301 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1210);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v300 + 88))(a1, 1210, 1, v301);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v300 + 80))(a1, 1210, v301);
  v302 = *a1;
  v303 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1211);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v302 + 88))(a1, 1211, 1, v303);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v302 + 80))(a1, 1211, v303);
  v304 = *a1;
  v305 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1212);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v304 + 88))(a1, 1212, 1, v305);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v304 + 80))(a1, 1212, v305);
  v306 = *a1;
  v307 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1213);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v306 + 88))(a1, 1213, 1, v307);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v306 + 80))(a1, 1213, v307);
  v308 = *a1;
  v309 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1214);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v308 + 88))(a1, 1214, 1, v309);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v308 + 80))(a1, 1214, v309);
  v310 = *a1;
  v311 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1215);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v310 + 88))(a1, 1215, 1, v311);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v310 + 80))(a1, 1215, v311);
  v312 = *a1;
  v313 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1242);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v312 + 88))(a1, 1242, 1, v313);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v312 + 80))(a1, 1242, v313);
  v314 = *a1;
  v315 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1243);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v314 + 88))(a1, 1243, 1, v315);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v314 + 80))(a1, 1243, v315);
  v316 = *a1;
  v317 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1244);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v316 + 88))(a1, 1244, 1, v317);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v316 + 80))(a1, 1244, v317);
  v318 = *a1;
  v319 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1245);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v318 + 88))(a1, 1245, 1, v319);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v318 + 80))(a1, 1245, v319);
  v320 = *a1;
  v321 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1246);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v320 + 88))(a1, 1246, 1, v321);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v320 + 80))(a1, 1246, v321);
  v322 = *a1;
  v323 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1247);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v322 + 88))(a1, 1247, 1, v323);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v322 + 80))(a1, 1247, v323);
  v324 = *a1;
  v325 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1248);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v324 + 88))(a1, 1248, 1, v325);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v324 + 80))(a1, 1248, v325);
  v326 = *a1;
  v327 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1323);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v326 + 88))(a1, 1323, 1, v327);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v326 + 80))(a1, 1323, v327);
  v328 = *a1;
  v329 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1324);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v328 + 88))(a1, 1324, 1, v329);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v328 + 80))(a1, 1324, v329);
  v330 = *a1;
  v331 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1325);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v330 + 88))(a1, 1325, 1, v331);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v330 + 80))(a1, 1325, v331);
  v332 = *a1;
  v333 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1326);
  if ( v3 )
    (*(void (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v332 + 88))(a1, 1326, 1, v333);
  else
    (*(void (__fastcall **)(__int64 *, __int64, _QWORD))(v332 + 80))(a1, 1326, v333);
  v334 = *a1;
  v335 = (*(__int64 (__fastcall **)(__int64 *, __int64, __int64))(*a1 + 104))(a1, 5, 1327);
  if ( v3 )
    return (*(__int64 (__fastcall **)(__int64 *, __int64, __int64, _QWORD))(v334 + 88))(a1, 1327, 1, v335);
  else
    return (*(__int64 (__fastcall **)(__int64 *, __int64, _QWORD))(v334 + 80))(a1, 1327, v335);
}


// ==== sub_7FF91E016C30 @ rva 0x3B6C30 ====
__int64 sub_7FF91E016C30()
{
  return 0;
}


// ==== sub_7FF91E016C40 @ rva 0x3B6C40 ====
__int64 __fastcall sub_7FF91E016C40(_DWORD *a1, __int64 a2, int a3, _DWORD *a4)
{
  unsigned int v4; // edx
  __int64 result; // rax
  int v6; // r8d
  int v7; // r8d
  int v8; // r8d

  v4 = 0;
  if ( a3 > 312 )
  {
    if ( a3 > 614 )
    {
      if ( a3 > 1028 )
      {
        if ( a3 > 1323 )
        {
          v6 = a3 - 1324;
          if ( v6 )
          {
            v7 = v6 - 1;
            if ( !v7 )
            {
              *a4 = a1[400];
              return 1;
            }
            v8 = v7 - 1;
            if ( !v8 )
            {
              *a4 = a1[401];
              return 1;
            }
            if ( v8 == 1 )
            {
              *a4 = a1[402];
              return 1;
            }
          }
          else
          {
            v4 = 1;
            *a4 = a1[399];
          }
          return v4;
        }
        else if ( a3 == 1323 )
        {
          *a4 = a1[398];
          return 1;
        }
        else
        {
          switch ( a3 )
          {
            case 1029:
              *a4 = a1[375];
              result = 1;
              break;
            case 1058:
              *a4 = a1[376];
              result = 1;
              break;
            case 1178:
              *a4 = a1[377];
              result = 1;
              break;
            case 1179:
              *a4 = a1[378];
              result = 1;
              break;
            case 1180:
              *a4 = a1[379];
              result = 1;
              break;
            case 1181:
              *a4 = a1[380];
              result = 1;
              break;
            case 1182:
              *a4 = a1[381];
              result = 1;
              break;
            case 1183:
              *a4 = a1[382];
              result = 1;
              break;
            case 1184:
              *a4 = a1[383];
              result = 1;
              break;
            case 1185:
              *a4 = a1[384];
              result = 1;
              break;
            case 1210:
              *a4 = a1[385];
              result = 1;
              break;
            case 1211:
              *a4 = a1[386];
              result = 1;
              break;
            case 1212:
              *a4 = a1[387];
              result = 1;
              break;
            case 1213:
              *a4 = a1[388];
              result = 1;
              break;
            case 1214:
              *a4 = a1[389];
              result = 1;
              break;
            case 1215:
              *a4 = a1[390];
              result = 1;
              break;
            case 1242:
              *a4 = a1[391];
              result = 1;
              break;
            case 1243:
              *a4 = a1[392];
              result = 1;
              break;
            case 1244:
              *a4 = a1[393];
              result = 1;
              break;
            case 1245:
              *a4 = a1[394];
              result = 1;
              break;
            case 1246:
              *a4 = a1[395];
              result = 1;
              break;
            case 1247:
              *a4 = a1[396];
              result = 1;
              break;
            case 1248:
              *a4 = a1[397];
              result = 1;
              break;
            default:
              return v4;
          }
        }
      }
      else if ( a3 == 1028 )
      {
        *a4 = a1[374];
        return 1;
      }
      else
      {
        switch ( a3 )
        {
          case 657:
            *a4 = a1[297];
            result = 1;
            break;
          case 665:
            *a4 = a1[298];
            result = 1;
            break;
          case 668:
            *a4 = a1[299];
            result = 1;
            break;
          case 669:
            *a4 = a1[300];
            result = 1;
            break;
          case 699:
            *a4 = a1[301];
            result = 1;
            break;
          case 707:
            *a4 = a1[302];
            result = 1;
            break;
          case 710:
            *a4 = a1[303];
            result = 1;
            break;
          case 711:
            *a4 = a1[304];
            result = 1;
            break;
          case 751:
            *a4 = a1[305];
            result = 1;
            break;
          case 752:
            *a4 = a1[306];
            result = 1;
            break;
          case 753:
            *a4 = a1[307];
            result = 1;
            break;
          case 754:
            *a4 = a1[308];
            result = 1;
            break;
          case 756:
            *a4 = a1[309];
            result = 1;
            break;
          case 757:
            *a4 = a1[310];
            result = 1;
            break;
          case 758:
            *a4 = a1[311];
            result = 1;
            break;
          case 759:
            *a4 = a1[312];
            result = 1;
            break;
          case 760:
            *a4 = a1[313];
            result = 1;
            break;
          case 770:
            *a4 = a1[314];
            result = 1;
            break;
          case 771:
            *a4 = a1[315];
            result = 1;
            break;
          case 772:
            *a4 = a1[316];
            result = 1;
            break;
          case 773:
            *a4 = a1[317];
            result = 1;
            break;
          case 779:
            *a4 = a1[318];
            result = 1;
            break;
          case 781:
            *a4 = a1[319];
            result = 1;
            break;
          case 782:
            *a4 = a1[320];
            result = 1;
            break;
          case 783:
            *a4 = a1[321];
            result = 1;
            break;
          case 784:
            *a4 = a1[322];
            result = 1;
            break;
          case 785:
            *a4 = a1[323];
            result = 1;
            break;
          case 786:
            *a4 = a1[324];
            result = 1;
            break;
          case 787:
            *a4 = a1[325];
            result = 1;
            break;
          case 788:
            *a4 = a1[326];
            result = 1;
            break;
          case 789:
            *a4 = a1[327];
            result = 1;
            break;
          case 790:
            *a4 = a1[328];
            result = 1;
            break;
          case 791:
            *a4 = a1[329];
            result = 1;
            break;
          case 792:
            *a4 = a1[330];
            result = 1;
            break;
          case 793:
            *a4 = a1[331];
            result = 1;
            break;
          case 794:
            *a4 = a1[332];
            result = 1;
            break;
          case 795:
            *a4 = a1[333];
            result = 1;
            break;
          case 796:
            *a4 = a1[334];
            result = 1;
            break;
          case 797:
            *a4 = a1[335];
            result = 1;
            break;
          case 798:
            *a4 = a1[336];
            result = 1;
            break;
          case 799:
            *a4 = a1[337];
            result = 1;
            break;
          case 800:
            *a4 = a1[338];
            result = 1;
            break;
          case 801:
            *a4 = a1[339];
            result = 1;
            break;
          case 803:
            *a4 = a1[340];
            result = 1;
            break;
          case 810:
            *a4 = a1[341];
            result = 1;
            break;
          case 830:
            *a4 = a1[342];
            result = 1;
            break;
          case 838:
            *a4 = a1[343];
            result = 1;
            break;
          case 839:
            *a4 = a1[344];
            result = 1;
            break;
          case 840:
            *a4 = a1[345];
            result = 1;
            break;
          case 841:
            *a4 = a1[346];
            result = 1;
            break;
          case 842:
            *a4 = a1[347];
            result = 1;
            break;
          case 843:
            *a4 = a1[348];
            result = 1;
            break;
          case 844:
            *a4 = a1[349];
            result = 1;
            break;
          case 845:
            *a4 = a1[350];
            result = 1;
            break;
          case 846:
            *a4 = a1[351];
            result = 1;
            break;
          case 847:
            *a4 = a1[352];
            result = 1;
            break;
          case 848:
            *a4 = a1[353];
            result = 1;
            break;
          case 849:
            *a4 = a1[354];
            result = 1;
            break;
          case 850:
            *a4 = a1[355];
            result = 1;
            break;
          case 851:
            *a4 = a1[356];
            result = 1;
            break;
          case 852:
            *a4 = a1[357];
            result = 1;
            break;
          case 853:
            *a4 = a1[358];
            result = 1;
            break;
          case 855:
            *a4 = a1[359];
            result = 1;
            break;
          case 856:
            *a4 = a1[360];
            result = 1;
            break;
          case 857:
            *a4 = a1[361];
            result = 1;
            break;
          case 858:
            *a4 = a1[362];
            result = 1;
            break;
          case 859:
            *a4 = a1[363];
            result = 1;
            break;
          case 860:
            *a4 = a1[364];
            result = 1;
            break;
          case 861:
            *a4 = a1[365];
            result = 1;
            break;
          case 863:
            *a4 = a1[366];
            result = 1;
            break;
          case 871:
            *a4 = a1[367];
            result = 1;
            break;
          case 873:
            *a4 = a1[368];
            result = 1;
            break;
          case 874:
            *a4 = a1[369];
            result = 1;
            break;
          case 875:
            *a4 = a1[370];
            result = 1;
            break;
          case 876:
            *a4 = a1[371];
            result = 1;
            break;
          case 877:
            *a4 = a1[372];
            result = 1;
            break;
          case 878:
            *a4 = a1[373];
            result = 1;
            break;
          default:
            return v4;
        }
      }
    }
    else if ( a3 == 614 )
    {
      *a4 = a1[296];
      return 1;
    }
    else
    {
      switch ( a3 )
      {
        case 313:
          *a4 = a1[257];
          result = 1;
          break;
        case 314:
          *a4 = a1[258];
          result = 1;
          break;
        case 315:
          *a4 = a1[259];
          result = 1;
          break;
        case 316:
          *a4 = a1[260];
          result = 1;
          break;
        case 317:
          *a4 = a1[261];
          result = 1;
          break;
        case 318:
          *a4 = a1[262];
          result = 1;
          break;
        case 373:
          *a4 = a1[263];
          result = 1;
          break;
        case 375:
          *a4 = a1[264];
          result = 1;
          break;
        case 433:
          *a4 = a1[265];
          result = 1;
          break;
        case 434:
          *a4 = a1[266];
          result = 1;
          break;
        case 435:
          *a4 = a1[267];
          result = 1;
          break;
        case 436:
          *a4 = a1[268];
          result = 1;
          break;
        case 437:
          *a4 = a1[269];
          result = 1;
          break;
        case 438:
          *a4 = a1[270];
          result = 1;
          break;
        case 439:
          *a4 = a1[271];
          result = 1;
          break;
        case 440:
          *a4 = a1[272];
          result = 1;
          break;
        case 450:
          *a4 = a1[273];
          result = 1;
          break;
        case 451:
          *a4 = a1[274];
          result = 1;
          break;
        case 452:
          *a4 = a1[275];
          result = 1;
          break;
        case 453:
          *a4 = a1[276];
          result = 1;
          break;
        case 454:
          *a4 = a1[277];
          result = 1;
          break;
        case 455:
          *a4 = a1[278];
          result = 1;
          break;
        case 456:
          *a4 = a1[279];
          result = 1;
          break;
        case 457:
          *a4 = a1[280];
          result = 1;
          break;
        case 467:
          *a4 = a1[281];
          result = 1;
          break;
        case 468:
          *a4 = a1[282];
          result = 1;
          break;
        case 469:
          *a4 = a1[283];
          result = 1;
          break;
        case 470:
          *a4 = a1[284];
          result = 1;
          break;
        case 471:
          *a4 = a1[285];
          result = 1;
          break;
        case 472:
          *a4 = a1[286];
          result = 1;
          break;
        case 473:
          *a4 = a1[287];
          result = 1;
          break;
        case 474:
          *a4 = a1[288];
          result = 1;
          break;
        case 484:
          *a4 = a1[289];
          result = 1;
          break;
        case 493:
          *a4 = a1[290];
          result = 1;
          break;
        case 495:
          *a4 = a1[291];
          result = 1;
          break;
        case 498:
          *a4 = a1[292];
          result = 1;
          break;
        case 553:
          *a4 = a1[293];
          result = 1;
          break;
        case 554:
          *a4 = a1[294];
          result = 1;
          break;
        case 555:
          *a4 = a1[295];
          result = 1;
          break;
        default:
          return v4;
      }
    }
  }
  else if ( a3 == 312 )
  {
    *a4 = a1[256];
    return 1;
  }
  else
  {
    switch ( a3 )
    {
      case 20:
        *a4 = a1[237];
        result = 1;
        break;
      case 128:
        *a4 = a1[238];
        result = 1;
        break;
      case 129:
        *a4 = a1[239];
        result = 1;
        break;
      case 130:
        *a4 = a1[240];
        result = 1;
        break;
      case 131:
        *a4 = a1[241];
        result = 1;
        break;
      case 132:
        *a4 = a1[242];
        result = 1;
        break;
      case 133:
        *a4 = a1[243];
        result = 1;
        break;
      case 134:
        *a4 = a1[244];
        result = 1;
        break;
      case 135:
        *a4 = a1[245];
        result = 1;
        break;
      case 136:
        *a4 = a1[246];
        result = 1;
        break;
      case 137:
        *a4 = a1[247];
        result = 1;
        break;
      case 138:
        *a4 = a1[248];
        result = 1;
        break;
      case 139:
        *a4 = a1[249];
        result = 1;
        break;
      case 140:
        *a4 = a1[250];
        result = 1;
        break;
      case 141:
        *a4 = a1[251];
        result = 1;
        break;
      case 189:
        *a4 = a1[252];
        result = 1;
        break;
      case 196:
        *a4 = a1[254];
        result = 1;
        break;
      case 254:
        *a4 = a1[255];
        result = 1;
        break;
      default:
        return v4;
    }
  }
  return result;
}


// ==== sub_7FF91E017F30 @ rva 0x3B7F30 ====
__int64 __fastcall sub_7FF91E017F30(__int64 a1)
{
  __int64 v2; // rcx

  sub_7FF91E00D0A0(a1);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      v2 = a1 + 6784;
      goto LABEL_8;
    case 1:
      v2 = a1 + 6976;
      goto LABEL_8;
    case 2:
      v2 = a1 + 7184;
      goto LABEL_8;
    case 3:
      v2 = a1 + 7400;
      goto LABEL_8;
    case 4:
      v2 = a1 + 7616;
      goto LABEL_8;
    case 5:
      v2 = a1 + 7824;
LABEL_8:
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 16LL))(v2);
      break;
    default:
      return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 8176) + 8LL))(a1 + 8176);
  }
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 8176) + 8LL))(a1 + 8176);
}


// ==== sub_7FF91E017FD0 @ rva 0x3B7FD0 ====
__int64 __fastcall sub_7FF91E017FD0(__int64 a1)
{
  __int64 result; // rax

  sub_7FF91E00D0A0(a1);
  result = *(int *)(a1 + 1480);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 6784) + 16LL))(a1 + 6784);
      break;
    case 1:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 6976) + 16LL))(a1 + 6976);
      break;
    case 2:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7184) + 16LL))(a1 + 7184);
      break;
    case 3:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7400) + 16LL))(a1 + 7400);
      break;
    case 4:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7616) + 16LL))(a1 + 7616);
      break;
    case 5:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7824) + 16LL))(a1 + 7824);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E0180A0 @ rva 0x3B80A0 ====
__int64 __fastcall sub_7FF91E0180A0(__int64 a1)
{
  __int64 result; // rax
  unsigned int v2; // edi
  __int64 v4; // r8
  unsigned int v5; // ebp
  unsigned int v6; // esi
  void (__fastcall ***v7)(_QWORD, __int64, __int64); // rcx

  result = *(unsigned int *)(a1 + 1612);
  v2 = 0;
  if ( (_DWORD)result || *(int *)(a1 + 1616) < 1 )
  {
    v4 = 0;
    if ( (int)result > 2 )
    {
LABEL_6:
      v5 = 0;
      goto LABEL_7;
    }
  }
  else
  {
    v4 = 1;
  }
  v5 = 1;
  if ( *(int *)(a1 + 1616) < 3 )
    goto LABEL_6;
LABEL_7:
  if ( (int)result > 4 || (v6 = 1, *(int *)(a1 + 1616) < 5) )
    v6 = 0;
  if ( (int)result <= 6 && *(_DWORD *)(a1 + 1616) == 7 )
    v2 = 1;
  v7 = *(void (__fastcall ****)(_QWORD, __int64, __int64))(a1 + 800);
  if ( v7 )
  {
    (**v7)(v7, 1, v4);
    (*(void (__fastcall **)(_QWORD, __int64, _QWORD))(**(_QWORD **)(a1 + 800) + 8LL))(*(_QWORD *)(a1 + 800), 1, v5);
    (*(void (__fastcall **)(_QWORD, __int64, _QWORD))(**(_QWORD **)(a1 + 800) + 16LL))(*(_QWORD *)(a1 + 800), 1, v6);
    return (*(__int64 (__fastcall **)(_QWORD, __int64, _QWORD))(**(_QWORD **)(a1 + 800) + 24LL))(
             *(_QWORD *)(a1 + 800),
             1,
             v2);
  }
  return result;
}


// ==== sub_7FF91E018180 @ rva 0x3B8180 ====
__int64 __fastcall sub_7FF91E018180(__int64 a1, __int64 a2)
{
  __int64 result; // rax
  __int64 v3; // rbx
  __int64 v4; // rbx
  __int64 v5; // rbx
  __int64 v6; // rbx
  __int64 v7; // rbx
  __int64 v8; // rbx

  result = *(int *)(a1 + 1480);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      v3 = a1 + 6784;
      (*(void (__fastcall **)(__int64, __int64, unsigned __int64))(*(_QWORD *)(a1 + 6784) + 16LL))(
        a1 + 6784,
        a2,
        0x7FF91DC60000uLL);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v3 + 56LL))(v3, 1);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v3 + 160LL))(v3, 1, 2);
      result = (*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v3 + 128LL))(v3, 1, 128);
      break;
    case 1:
      v4 = a1 + 6976;
      (*(void (__fastcall **)(__int64, __int64, unsigned __int64))(*(_QWORD *)(a1 + 6976) + 16LL))(
        a1 + 6976,
        a2,
        0x7FF91DC60000uLL);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v4 + 56LL))(v4, 1, 1);
      result = (*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v4 + 160LL))(v4, 1, 2);
      break;
    case 2:
      v5 = a1 + 7184;
      (*(void (__fastcall **)(__int64, __int64, unsigned __int64))(*(_QWORD *)(a1 + 7184) + 16LL))(
        a1 + 7184,
        a2,
        0x7FF91DC60000uLL);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v5 + 64LL))(v5, 1, 1);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v5 + 72LL))(v5, 1, 255);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v5 + 80LL))(v5, 1, 255);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v5 + 120LL))(v5, 1);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v5 + 144LL))(v5, 1, 2);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v5 + 176LL))(v5, 1);
      result = (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v5 + 184LL))(v5, 1);
      break;
    case 3:
      v6 = a1 + 7400;
      (*(void (__fastcall **)(__int64, __int64, unsigned __int64))(*(_QWORD *)(a1 + 7400) + 16LL))(
        a1 + 7400,
        a2,
        0x7FF91DC60000uLL);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 64LL))(v6, 1, 2);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 72LL))(v6, 1, 255);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 80LL))(v6, 1, 255);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v6 + 120LL))(v6, 1);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v6 + 144LL))(v6, 1, 2);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v6 + 176LL))(v6, 1);
      result = (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v6 + 184LL))(v6, 1);
      break;
    case 4:
      v7 = a1 + 7616;
      (*(void (__fastcall **)(__int64, __int64, unsigned __int64))(*(_QWORD *)(a1 + 7616) + 16LL))(
        a1 + 7616,
        a2,
        0x7FF91DC60000uLL);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v7 + 64LL))(v7, 1);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 72LL))(v7, 1, 255);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 80LL))(v7, 1, 255);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 88LL))(v7, 1, 13);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v7 + 96LL))(v7, 1);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 144LL))(v7, 1, 2);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v7 + 128LL))(v7, 1);
      result = (*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v7 + 176LL))(v7, 1, 1);
      break;
    case 5:
      v8 = a1 + 7824;
      (*(void (__fastcall **)(__int64, __int64, unsigned __int64))(*(_QWORD *)(a1 + 7824) + 16LL))(
        a1 + 7824,
        a2,
        0x7FF91DC60000uLL);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v8 + 56LL))(v8, 1);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v8 + 160LL))(v8, 1, 2);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v8 + 128LL))(v8, 1, 128);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v8 + 184LL))(v8, 1, 1);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v8 + 192LL))(v8, 1, 255);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v8 + 200LL))(v8, 1, 255);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v8 + 240LL))(v8, 1);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v8 + 264LL))(v8, 1, 2);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v8 + 272LL))(v8, 1, 50);
      (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v8 + 288LL))(v8, 1, 128);
      (*(void (__fastcall **)(__int64, __int64))(*(_QWORD *)v8 + 296LL))(v8, 1);
      result = (*(__int64 (__fastcall **)(__int64, __int64))(*(_QWORD *)v8 + 304LL))(v8, 1);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E018560 @ rva 0x3B8560 ====
__int64 __fastcall sub_7FF91E018560(__int64 a1)
{
  __int64 v2; // rcx

  sub_7FF91E00D7E0(a1);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      v2 = a1 + 6784;
      goto LABEL_8;
    case 1:
      v2 = a1 + 6976;
      goto LABEL_8;
    case 2:
      v2 = a1 + 7184;
      goto LABEL_8;
    case 3:
      v2 = a1 + 7400;
      goto LABEL_8;
    case 4:
      v2 = a1 + 7616;
      goto LABEL_8;
    case 5:
      v2 = a1 + 7824;
LABEL_8:
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 40LL))(v2);
      break;
    default:
      return sub_7FF91E021670(a1 + 8176);
  }
  return sub_7FF91E021670(a1 + 8176);
}


// ==== sub_7FF91E0185F0 @ rva 0x3B85F0 ====
__int64 __fastcall sub_7FF91E0185F0(__int64 a1)
{
  __int64 result; // rax

  sub_7FF91E00D7E0(a1);
  result = *(int *)(a1 + 1480);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 6784) + 40LL))(a1 + 6784);
      break;
    case 1:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 6976) + 40LL))(a1 + 6976);
      break;
    case 2:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7184) + 40LL))(a1 + 7184);
      break;
    case 3:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7400) + 40LL))(a1 + 7400);
      break;
    case 4:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7616) + 40LL))(a1 + 7616);
      break;
    case 5:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7824) + 40LL))(a1 + 7824);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E0186C0 @ rva 0x3B86C0 ====
__int64 __fastcall sub_7FF91E0186C0(__int64 a1)
{
  __int64 v2; // rcx

  sub_7FF91E00D950(a1);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      v2 = a1 + 6784;
      goto LABEL_8;
    case 1:
      v2 = a1 + 6976;
      goto LABEL_8;
    case 2:
      v2 = a1 + 7184;
      goto LABEL_8;
    case 3:
      v2 = a1 + 7400;
      goto LABEL_8;
    case 4:
      v2 = a1 + 7616;
      goto LABEL_8;
    case 5:
      v2 = a1 + 7824;
LABEL_8:
      (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v2 + 24LL))(v2, 0);
      break;
    default:
      return sub_7FF91E021680(a1 + 8176);
  }
  return sub_7FF91E021680(a1 + 8176);
}


// ==== sub_7FF91E018760 @ rva 0x3B8760 ====
__int64 __fastcall sub_7FF91E018760(__int64 a1)
{
  __int64 result; // rax

  sub_7FF91E00D950(a1);
  result = *(int *)(a1 + 1480);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 6784) + 24LL))(a1 + 6784, 0);
      break;
    case 1:
      result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 6976) + 24LL))(a1 + 6976, 0);
      break;
    case 2:
      result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 7184) + 24LL))(a1 + 7184, 0);
      break;
    case 3:
      result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 7400) + 24LL))(a1 + 7400, 0);
      break;
    case 4:
      result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 7616) + 24LL))(a1 + 7616, 0);
      break;
    case 5:
      result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 7824) + 24LL))(a1 + 7824, 0);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E018830 @ rva 0x3B8830 ====
__int64 __fastcall sub_7FF91E018830(__int64 a1)
{
  __int64 v2; // rcx

  sub_7FF91E00DA80(a1);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      v2 = a1 + 6784;
      goto LABEL_8;
    case 1:
      v2 = a1 + 6976;
      goto LABEL_8;
    case 2:
      v2 = a1 + 7184;
      goto LABEL_8;
    case 3:
      v2 = a1 + 7400;
      goto LABEL_8;
    case 4:
      v2 = a1 + 7616;
      goto LABEL_8;
    case 5:
      v2 = a1 + 7824;
LABEL_8:
      (*(void (__fastcall **)(__int64))(*(_QWORD *)v2 + 32LL))(v2);
      break;
    default:
      return sub_7FF91E0216B0(a1 + 8176);
  }
  return sub_7FF91E0216B0(a1 + 8176);
}


// ==== sub_7FF91E0188C0 @ rva 0x3B88C0 ====
__int64 __fastcall sub_7FF91E0188C0(__int64 a1)
{
  __int64 result; // rax

  sub_7FF91E00DA80(a1);
  result = *(int *)(a1 + 1480);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 6784) + 32LL))(a1 + 6784);
      break;
    case 1:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 6976) + 32LL))(a1 + 6976);
      break;
    case 2:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7184) + 32LL))(a1 + 7184);
      break;
    case 3:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7400) + 32LL))(a1 + 7400);
      break;
    case 4:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7616) + 32LL))(a1 + 7616);
      break;
    case 5:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7824) + 32LL))(a1 + 7824);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E018990 @ rva 0x3B8990 ====
void __fastcall sub_7FF91E018990(__int64 a1, unsigned int a2, int a3)
{
  __int64 v6; // rsi
  void (__fastcall *v7)(__int64, _QWORD, _QWORD); // r9
  __int64 v8; // rsi
  __int64 v9; // rdx
  __int64 v10; // rcx
  void (__fastcall *v11)(__int64, __int64, _QWORD); // r9
  __int64 v12; // r8

  nullsub_11();
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 2:
      v8 = a1 + 7184;
      v9 = a2;
      v10 = v8;
      v11 = *(void (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)v8 + 104LL);
      if ( a3 > 0 )
        goto LABEL_8;
      goto LABEL_10;
    case 3:
      v8 = a1 + 7400;
      v9 = a2;
      v10 = v8;
      v11 = *(void (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)v8 + 104LL);
      if ( a3 > 0 )
      {
LABEL_8:
        v11(v10, v9, (unsigned int)(a3 - 1));
        v12 = 1;
LABEL_11:
        (*(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v8 + 112LL))(v8, a2, v12);
        return;
      }
LABEL_10:
      v11(v10, v9, 0);
      v12 = 0;
      goto LABEL_11;
    case 5:
      v6 = a1 + 7824;
      v7 = *(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v6 + 224LL);
      if ( a3 <= 0 )
      {
        v7(v6, a2, 0);
        (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v6 + 232LL))(v6, a2, 0);
      }
      else
      {
        v7(v6, a2, (unsigned int)(a3 - 1));
        (*(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v6 + 232LL))(v6, a2, 1);
      }
      break;
  }
}


// ==== j_nullsub_983 @ rva 0x3B8AB0 ====
// attributes: thunk
void j_nullsub_983()
{
  nullsub_983();
}


// ==== j_nullsub_984 @ rva 0x3B8AC0 ====
// attributes: thunk
void j_nullsub_984()
{
  nullsub_984();
}


// ==== j_nullsub_985 @ rva 0x3B8AD0 ====
// attributes: thunk
void j_nullsub_985()
{
  nullsub_985();
}


// ==== sub_7FF91E018AE0 @ rva 0x3B8AE0 ====
void __fastcall sub_7FF91E018AE0(__int64 a1, unsigned int a2, int a3)
{
  __int64 v6; // rsi
  void (__fastcall *v7)(__int64, _QWORD, __int64); // r9
  __int64 v8; // rsi
  void (__fastcall *v9)(__int64, _QWORD, __int64); // r9
  __int64 v10; // r8

  nullsub_12();
  if ( *(_DWORD *)(a1 + 1480) == 2 )
  {
    v8 = a1 + 7184;
  }
  else
  {
    if ( *(_DWORD *)(a1 + 1480) != 3 )
    {
      if ( *(_DWORD *)(a1 + 1480) == 5 )
      {
        v6 = a1 + 7824;
        v7 = *(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v6 + 208LL);
        if ( a3 >= 14 )
        {
          v7(v6, a2, 13);
          (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v6 + 216LL))(v6, a2, 0);
        }
        else
        {
          v7(v6, a2, (unsigned int)a3);
          (*(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v6 + 216LL))(v6, a2, 1);
        }
      }
      return;
    }
    v8 = a1 + 7400;
  }
  v9 = *(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v8 + 88LL);
  if ( a3 >= 14 )
  {
    v9(v8, a2, 13);
    v10 = 0;
  }
  else
  {
    v9(v8, a2, (unsigned int)a3);
    v10 = 1;
  }
  (*(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v8 + 96LL))(v8, a2, v10);
}


// ==== sub_7FF91E018BF0 @ rva 0x3B8BF0 ====
void __fastcall sub_7FF91E018BF0(__int64 a1, unsigned int a2, int a3)
{
  __int64 v3; // rdi
  __int64 v6; // rcx

  v3 = a3;
  nullsub_13();
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 2:
      v6 = a1 + 7184;
      goto LABEL_7;
    case 3:
      v6 = a1 + 7400;
LABEL_7:
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v6 + 128LL))(v6, a2, dword_7FF91E624270[v3]);
      return;
    case 5:
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7824) + 248LL))(
        a1 + 7824,
        a2,
        dword_7FF91E624270[v3]);
      break;
  }
}


// ==== sub_7FF91E018C90 @ rva 0x3B8C90 ====
void __fastcall sub_7FF91E018C90(__int64 a1, unsigned int a2, unsigned int a3)
{
  int v6; // r9d
  int v7; // r9d
  __int64 v8; // rcx

  nullsub_14();
  v6 = *(_DWORD *)(a1 + 1480);
  if ( v6 )
  {
    v7 = v6 - 1;
    if ( v7 )
    {
      if ( v7 != 4 )
        return;
      v8 = a1 + 7824;
    }
    else
    {
      v8 = a1 + 6976;
    }
  }
  else
  {
    v8 = a1 + 6784;
  }
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v8 + 64LL))(v8, a2, a3);
}


// ==== sub_7FF91E018D00 @ rva 0x3B8D00 ====
void __fastcall sub_7FF91E018D00(__int64 a1, unsigned int a2, unsigned int a3)
{
  int v6; // r9d
  int v7; // r9d
  __int64 v8; // rcx

  nullsub_15();
  v6 = *(_DWORD *)(a1 + 1480);
  if ( v6 )
  {
    v7 = v6 - 1;
    if ( v7 )
    {
      if ( v7 != 4 )
        return;
      v8 = a1 + 7824;
    }
    else
    {
      v8 = a1 + 6976;
    }
  }
  else
  {
    v8 = a1 + 6784;
  }
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v8 + 136LL))(v8, a2, a3);
}


// ==== sub_7FF91E018D70 @ rva 0x3B8D70 ====
void __fastcall sub_7FF91E018D70(__int64 a1, unsigned int a2, unsigned int a3)
{
  int v6; // r9d
  int v7; // r9d
  __int64 v8; // rcx

  nullsub_16();
  v6 = *(_DWORD *)(a1 + 1480);
  if ( v6 )
  {
    v7 = v6 - 1;
    if ( v7 )
    {
      if ( v7 != 4 )
        return;
      v8 = a1 + 7824;
    }
    else
    {
      v8 = a1 + 6976;
    }
  }
  else
  {
    v8 = a1 + 6784;
  }
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v8 + 112LL))(v8, a2, a3);
}


// ==== sub_7FF91E018DE0 @ rva 0x3B8DE0 ====
void __fastcall sub_7FF91E018DE0(__int64 a1, unsigned int a2, unsigned int a3)
{
  int v6; // r9d
  int v7; // r9d
  __int64 v8; // rcx

  nullsub_17();
  v6 = *(_DWORD *)(a1 + 1480);
  if ( v6 )
  {
    v7 = v6 - 1;
    if ( v7 )
    {
      if ( v7 != 4 )
        return;
      v8 = a1 + 7824;
    }
    else
    {
      v8 = a1 + 6976;
    }
  }
  else
  {
    v8 = a1 + 6784;
  }
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v8 + 120LL))(v8, a2, a3);
}


// ==== sub_7FF91E018E50 @ rva 0x3B8E50 ====
__int64 __fastcall sub_7FF91E018E50(__int64 a1, unsigned int a2, unsigned int a3)
{
  unsigned int v6; // esi
  BOOL v7; // eax
  bool v8; // sf
  bool v9; // of
  __int64 result; // rax
  __int64 v11; // r14
  __int64 v12; // r8
  __int64 v13; // r8
  __int64 v14; // r8
  __int64 v15; // r14
  __int64 v16; // r14
  __int64 v17; // r8
  int v18; // ebp

  nullsub_18();
  v6 = 0;
  v7 = *(_DWORD *)(a1 + 6776) == 0;
  v9 = __OFSUB__(v7, a3);
  v8 = (int)(v7 - a3) < 0;
  result = *(int *)(a1 + 1480);
  *(_DWORD *)(a1 + 6776) = v8 ^ v9;
  switch ( result )
  {
    case 0LL:
      v11 = a1 + 6784;
      goto LABEL_4;
    case 1LL:
      v11 = a1 + 6976;
LABEL_4:
      (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v11 + 48LL))(v11, a2);
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v11 + 72LL))(v11, a2, a3);
      if ( *(_DWORD *)(a1 + 6776) )
        v6 = *(_DWORD *)(a1 + 1512);
      result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v11 + 136LL))(v11, a2, v6);
      break;
    case 2LL:
      v12 = 255;
      if ( (int)(32 * a3) <= 255 )
        v12 = 32 * a3;
      (*(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)(a1 + 7184) + 56LL))(a1 + 7184, a2, v12);
      result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7184) + 168LL))(a1 + 7184, a2, a3);
      break;
    case 3LL:
      v13 = 255;
      if ( (int)(32 * a3) <= 255 )
        v13 = 32 * a3;
      (*(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)(a1 + 7400) + 56LL))(a1 + 7400, a2, v13);
      result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7400) + 168LL))(a1 + 7400, a2, a3);
      break;
    case 4LL:
      v14 = 255;
      v15 = a1 + 7616;
      if ( (int)(32 * a3) <= 255 )
        v14 = 32 * a3;
      (*(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v15 + 56LL))(a1 + 7616, a2, v14);
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v15 + 168LL))(a1 + 7616, a2, a3);
      if ( *(_DWORD *)(a1 + 6776) )
        v6 = *(_DWORD *)(a1 + 1568);
      result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v15 + 120LL))(a1 + 7616, a2, v6);
      break;
    case 5LL:
      v16 = a1 + 7824;
      (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 7824) + 48LL))(a1 + 7824, a2);
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7824) + 72LL))(a1 + 7824, a2, a3);
      if ( *(_DWORD *)(a1 + 6776) )
        v6 = *(_DWORD *)(a1 + 1512);
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v16 + 136LL))(a1 + 7824, a2, v6);
      v17 = 255;
      v18 = 32 * a3;
      if ( v18 <= 255 )
        v17 = (unsigned int)v18;
      result = (*(__int64 (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v16 + 176LL))(a1 + 7824, a2, v17);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E019070 @ rva 0x3B9070 ====
void __fastcall sub_7FF91E019070(__int64 a1, unsigned int a2, unsigned int a3)
{
  int v6; // r9d
  int v7; // r9d
  __int64 v8; // rcx

  nullsub_19();
  v6 = *(_DWORD *)(a1 + 1480);
  if ( v6 )
  {
    v7 = v6 - 1;
    if ( v7 )
    {
      if ( v7 != 4 )
        return;
      v8 = a1 + 7824;
    }
    else
    {
      v8 = a1 + 6976;
    }
  }
  else
  {
    v8 = a1 + 6784;
  }
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v8 + 96LL))(v8, a2, a3);
}


// ==== sub_7FF91E0190E0 @ rva 0x3B90E0 ====
void __fastcall sub_7FF91E0190E0(__int64 a1, unsigned int a2, unsigned int a3)
{
  int v6; // r9d
  int v7; // r9d
  __int64 v8; // rcx

  nullsub_20();
  v6 = *(_DWORD *)(a1 + 1480);
  if ( v6 )
  {
    v7 = v6 - 1;
    if ( v7 )
    {
      if ( v7 != 4 )
        return;
      v8 = a1 + 7824;
    }
    else
    {
      v8 = a1 + 6976;
    }
  }
  else
  {
    v8 = a1 + 6784;
  }
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v8 + 104LL))(v8, a2, a3);
}


// ==== sub_7FF91E019150 @ rva 0x3B9150 ====
void __fastcall sub_7FF91E019150(__int64 a1, unsigned int a2, int a3)
{
  int v6; // edx
  int v7; // edx
  __int64 v8; // rsi
  void (__fastcall *v9)(__int64, _QWORD, __int64); // r9
  __int64 v10; // r8

  nullsub_21();
  v6 = *(_DWORD *)(a1 + 1480);
  if ( v6 )
  {
    v7 = v6 - 1;
    if ( v7 )
    {
      if ( v7 != 4 )
        return;
      v8 = a1 + 7824;
    }
    else
    {
      v8 = a1 + 6976;
    }
  }
  else
  {
    v8 = a1 + 6784;
  }
  v9 = *(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v8 + 80LL);
  if ( a3 >= 14 )
  {
    v9(v8, a2, 13);
    v10 = 0;
  }
  else
  {
    v9(v8, a2, (unsigned int)a3);
    v10 = 1;
  }
  (*(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v8 + 88LL))(v8, a2, v10);
}


// ==== sub_7FF91E0191E0 @ rva 0x3B91E0 ====
void __fastcall sub_7FF91E0191E0(__int64 a1, unsigned int a2, int a3)
{
  nullsub_22();
  if ( *(_DWORD *)(a1 + 1480) == 1 )
    (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 6976) + 128LL))(
      a1 + 6976,
      a2,
      (unsigned int)(255 * a3 / 100));
}


// ==== sub_7FF91E019250 @ rva 0x3B9250 ====
__int64 __fastcall sub_7FF91E019250(__int64 a1, unsigned int a2, int a3)
{
  __int64 v3; // rdi
  __int64 result; // rax
  __int64 v7; // rcx
  __int64 v8; // r8

  v3 = a3;
  nullsub_23();
  result = *(int *)(a1 + 1480);
  if ( (unsigned int)result <= 5 )
  {
    if ( *(_DWORD *)(a1 + 1360) )
    {
      switch ( *(_DWORD *)(a1 + 1480) )
      {
        case 0:
          v7 = a1 + 6784;
          goto LABEL_14;
        case 1:
          v7 = a1 + 6976;
          goto LABEL_14;
        case 2:
LABEL_6:
          v7 = a1 + 7184;
          v8 = (unsigned int)v3;
          goto LABEL_15;
        case 3:
LABEL_7:
          v7 = a1 + 7400;
          v8 = (unsigned int)v3;
          goto LABEL_15;
        case 4:
          return (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7616) + 160LL))(
                   a1 + 7616,
                   a2,
                   (unsigned int)v3);
        case 5:
          v7 = a1 + 7824;
LABEL_14:
          v8 = (unsigned int)(255 - v3);
LABEL_15:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v7 + 152LL))(v7, a2, v8);
          break;
        default:
          return result;
      }
    }
    else
    {
      switch ( *(_DWORD *)(a1 + 1480) )
      {
        case 0:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 6784) + 144LL))(
                     a1 + 6784,
                     a2,
                     (unsigned int)dword_7FF91E623E70[v3]);
          break;
        case 1:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 6976) + 144LL))(
                     a1 + 6976,
                     a2,
                     (unsigned int)dword_7FF91E623E70[v3]);
          break;
        case 2:
          goto LABEL_6;
        case 3:
          goto LABEL_7;
        case 4:
          return (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7616) + 160LL))(
                   a1 + 7616,
                   a2,
                   (unsigned int)v3);
        case 5:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7824) + 144LL))(
                     a1 + 7824,
                     a2,
                     (unsigned int)dword_7FF91E623E70[v3]);
          break;
        default:
          return result;
      }
    }
  }
  return result;
}


// ==== sub_7FF91E0193E0 @ rva 0x3B93E0 ====
__int64 __fastcall sub_7FF91E0193E0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v6; // rdx

  nullsub_24();
  (*(void (__fastcall **)(__int64))(*(_QWORD *)a1 + 24LL))(a1);
  sub_7FF91E021010(*(_QWORD *)(a1 + 8), 5, a3);
  *(_DWORD *)(a1 + 1480) = a3;
  sub_7FF91E018180(a1, v6);
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 1712LL))(a1, a2, *(unsigned int *)(a1 + 1056));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2280LL))(a1, a2, *(unsigned int *)(a1 + 1340));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2272LL))(a1, a2, *(unsigned int *)(a1 + 1336));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2616LL))(a1, a2, *(unsigned int *)(a1 + 1508));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2624LL))(a1, a2, *(unsigned int *)(a1 + 1512));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2632LL))(a1, a2, *(unsigned int *)(a1 + 1516));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2648LL))(a1, a2, *(unsigned int *)(a1 + 1524));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2656LL))(a1, a2, *(unsigned int *)(a1 + 1528));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2664LL))(a1, a2, *(unsigned int *)(a1 + 1532));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2672LL))(a1, a2, *(unsigned int *)(a1 + 1536));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2640LL))(a1, a2, *(unsigned int *)(a1 + 1520));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2680LL))(a1, a2, *(unsigned int *)(a1 + 1540));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2688LL))(a1, a2, *(unsigned int *)(a1 + 1544));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2696LL))(a1, a2, *(unsigned int *)(a1 + 1548));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2728LL))(a1, a2, *(unsigned int *)(a1 + 1564));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2736LL))(a1, a2, *(unsigned int *)(a1 + 1568));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2744LL))(a1, a2, *(unsigned int *)(a1 + 1572));
  (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)a1 + 2752LL))(a1, a2, *(unsigned int *)(a1 + 1576));
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)a1 + 40LL))(a1);
}


// ==== sub_7FF91E0195C0 @ rva 0x3B95C0 ====
void __fastcall sub_7FF91E0195C0(__int64 a1, unsigned int a2, int a3)
{
  __int64 v6; // rbx
  void (__fastcall *v7)(__int64, _QWORD, _QWORD); // r9
  __int64 v8; // r8

  nullsub_25();
  if ( *(_DWORD *)(a1 + 1480) == 4 )
  {
    v6 = a1 + 7616;
    v7 = *(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)v6 + 104LL);
    if ( a3 <= 0 )
    {
      v7(v6, a2, 0);
      v8 = 0;
    }
    else
    {
      v7(v6, a2, (unsigned int)(a3 - 1));
      v8 = 1;
    }
    (*(void (__fastcall **)(__int64, _QWORD, __int64))(*(_QWORD *)v6 + 112LL))(v6, a2, v8);
  }
}


// ==== j_nullsub_987 @ rva 0x3B9630 ====
// attributes: thunk
void j_nullsub_987()
{
  nullsub_987();
}


// ==== j_nullsub_988 @ rva 0x3B9640 ====
// attributes: thunk
void j_nullsub_988()
{
  nullsub_988();
}


// ==== j_nullsub_989 @ rva 0x3B9650 ====
// attributes: thunk
void j_nullsub_989()
{
  nullsub_989();
}


// ==== sub_7FF91E019660 @ rva 0x3B9660 ====
void __fastcall sub_7FF91E019660(__int64 a1, unsigned int a2, unsigned int a3)
{
  nullsub_26();
  if ( *(_DWORD *)(a1 + 1480) == 4 )
    (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7616) + 184LL))(a1 + 7616, a2, a3);
}


// ==== sub_7FF91E0196B0 @ rva 0x3B96B0 ====
void __fastcall sub_7FF91E0196B0(__int64 a1, unsigned int a2, unsigned int a3)
{
  nullsub_27();
  if ( *(_DWORD *)(a1 + 1480) == 4 )
    (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7616) + 120LL))(a1 + 7616, a2, a3);
}


// ==== j_nullsub_990 @ rva 0x3B9700 ====
// attributes: thunk
void j_nullsub_990()
{
  nullsub_990();
}


// ==== sub_7FF91E019710 @ rva 0x3B9710 ====
__int64 __fastcall sub_7FF91E019710(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v6; // rax
  __int64 v7; // r8

  sub_7FF91E00F3D0(a1, a2, a3);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 6784) + 168LL))(a1 + 6784, a2, a3);
      break;
    case 1:
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 6976) + 168LL))(a1 + 6976, a2, a3);
      break;
    case 2:
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7184) + 192LL))(a1 + 7184, a2, a3);
      break;
    case 3:
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7400) + 192LL))(a1 + 7400, a2, a3);
      break;
    case 4:
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7616) + 192LL))(a1 + 7616, a2, a3);
      break;
    case 5:
      (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 7824) + 312LL))(a1 + 7824, a2, a3);
      break;
    default:
      break;
  }
  v6 = *(_QWORD *)a1;
  v7 = *(unsigned int *)(a1 + 1340);
  *(_DWORD *)(a1 + 1056) = a3;
  return (*(__int64 (__fastcall **)(__int64, _QWORD, __int64))(v6 + 2280))(a1, a2, v7);
}


// ==== nullsub_1038 @ rva 0x3B9820 ====
void nullsub_1038()
{
  ;
}


// ==== sub_7FF91E019830 @ rva 0x3B9830 ====
__int64 __fastcall sub_7FF91E019830(__int64 a1)
{
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 8176) + 88LL))(a1 + 8176);
}


// ==== sub_7FF91E019840 @ rva 0x3B9840 ====
__int64 __fastcall sub_7FF91E019840(__int64 a1, unsigned int a2, int a3)
{
  return (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 8176) + 104LL))(
           a1 + 8176,
           a2,
           (unsigned int)(100 * a3 / 255));
}


// ==== sub_7FF91E019870 @ rva 0x3B9870 ====
__int64 __fastcall sub_7FF91E019870(__int64 a1)
{
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 8176) + 56LL))(a1 + 8176);
}


// ==== sub_7FF91E019880 @ rva 0x3B9880 ====
__int64 __fastcall sub_7FF91E019880(__int64 a1, unsigned int a2, int a3)
{
  return (*(__int64 (__fastcall **)(__int64, _QWORD, _QWORD))(*(_QWORD *)(a1 + 8176) + 96LL))(
           a1 + 8176,
           a2,
           (unsigned int)(100 * a3 / 255));
}


// ==== sub_7FF91E0198B0 @ rva 0x3B98B0 ====
__int64 __fastcall sub_7FF91E0198B0(__int64 a1)
{
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 8176) + 72LL))(a1 + 8176);
}


// ==== sub_7FF91E0198C0 @ rva 0x3B98C0 ====
__int64 __fastcall sub_7FF91E0198C0(__int64 a1)
{
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 8176) + 48LL))(a1 + 8176);
}


// ==== sub_7FF91E0198D0 @ rva 0x3B98D0 ====
__int64 __fastcall sub_7FF91E0198D0(__int64 a1)
{
  return (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 8176) + 40LL))(a1 + 8176);
}


// ==== sub_7FF91E0198E0 @ rva 0x3B98E0 ====
__int64 __fastcall sub_7FF91E0198E0(__int64 a1, __int64 a2, int a3, __int64 a4)
{
  __int64 result; // rax

  switch ( a3 )
  {
    case 0:
      result = (*(__int64 (__fastcall **)(__int64, __int64, _QWORD))(*(_QWORD *)(a1 + 8176) + 32LL))(a1 + 8176, a2, 0);
      break;
    case 1:
      result = (*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)(a1 + 8176) + 32LL))(a1 + 8176, a2, 1);
      break;
    case 2:
      result = (*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)(a1 + 8176) + 32LL))(a1 + 8176, a2, 2);
      break;
    case 3:
      result = (*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)(a1 + 8176) + 32LL))(a1 + 8176, a2, 3);
      break;
    case 5:
      result = (*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)(a1 + 8176) + 32LL))(a1 + 8176, a2, 6);
      break;
    default:
      result = (*(__int64 (__fastcall **)(__int64, __int64, __int64, __int64))(*(_QWORD *)(a1 + 8176) + 32LL))(
                 a1 + 8176,
                 a2,
                 4,
                 a4);
      break;
  }
  return result;
}


// ==== sub_7FF91E019990 @ rva 0x3B9990 ====
void __fastcall sub_7FF91E019990(__int64 a1, int a2, int a3)
{
  __int64 v4; // rbx
  unsigned int v5; // eax

  if ( !a2 )
  {
    v4 = *(_QWORD *)a1;
    v5 = sub_7FF91E011800(a1, *(_DWORD *)(a1 + 1272), a3);
    (*(void (__fastcall **)(__int64, _QWORD, _QWORD))(v4 + 2144))(a1, 0, v5);
  }
}


// ==== sub_7FF91E0199D0 @ rva 0x3B99D0 ====
__int64 __fastcall sub_7FF91E0199D0(__int64 a1, unsigned int a2, unsigned int a3)
{
  __int64 v6; // rax
  __int64 v7; // r8

  sub_7FF91E011220(a1, a2, a3);
  v6 = *(_QWORD *)a1;
  v7 = *(unsigned int *)(a1 + 1340);
  *(_DWORD *)(a1 + 1360) = a3;
  return (*(__int64 (__fastcall **)(__int64, _QWORD, __int64))(v6 + 2280))(a1, a2, v7);
}


// ==== nullsub_1039 @ rva 0x3B9A20 ====
void nullsub_1039()
{
  ;
}


// ==== sub_7FF91E019A30 @ rva 0x3B9A30 ====
__int64 __fastcall sub_7FF91E019A30(_DWORD *a1, int a2, unsigned int a3, unsigned int a4)
{
  __int64 result; // rax
  int v7; // edx
  int v8; // edx
  int v9; // edx

  if ( a2 > 312 )
  {
    if ( a2 > 614 )
    {
      if ( a2 > 1028 )
      {
        if ( a2 > 1323 )
        {
          v7 = a2 - 1324;
          if ( v7 )
          {
            v8 = v7 - 1;
            if ( v8 )
            {
              v9 = v8 - 1;
              if ( v9 )
              {
                if ( v9 == 1 )
                {
                  result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2816LL))(a1, a3, a4);
                  a1[402] = a4;
                }
              }
              else
              {
                result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2808LL))(a1, a3, a4);
                a1[401] = a4;
              }
            }
            else
            {
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2800LL))(a1, a3, a4);
              a1[400] = a4;
            }
          }
          else
          {
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2792LL))(a1, a3, a4);
            a1[399] = a4;
          }
        }
        else if ( a2 == 1323 )
        {
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2784LL))(a1, a3, a4);
          a1[398] = a4;
        }
        else
        {
          switch ( a2 )
          {
            case 1029:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2600LL))(a1, a3, a4);
              a1[375] = a4;
              break;
            case 1058:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2608LL))(a1, a3, a4);
              a1[376] = a4;
              break;
            case 1178:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2616LL))(a1, a3, a4);
              a1[377] = a4;
              break;
            case 1179:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2624LL))(a1, a3, a4);
              a1[378] = a4;
              break;
            case 1180:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2632LL))(a1, a3, a4);
              a1[379] = a4;
              break;
            case 1181:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2640LL))(a1, a3, a4);
              a1[380] = a4;
              break;
            case 1182:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2648LL))(a1, a3, a4);
              a1[381] = a4;
              break;
            case 1183:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2656LL))(a1, a3, a4);
              a1[382] = a4;
              break;
            case 1184:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2664LL))(a1, a3, a4);
              a1[383] = a4;
              break;
            case 1185:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2672LL))(a1, a3, a4);
              a1[384] = a4;
              break;
            case 1210:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2680LL))(a1, a3, a4);
              a1[385] = a4;
              break;
            case 1211:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2688LL))(a1, a3, a4);
              a1[386] = a4;
              break;
            case 1212:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2696LL))(a1, a3, a4);
              a1[387] = a4;
              break;
            case 1213:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2704LL))(a1, a3, a4);
              a1[388] = a4;
              break;
            case 1214:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2712LL))(a1, a3, a4);
              a1[389] = a4;
              break;
            case 1215:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2720LL))(a1, a3, a4);
              a1[390] = a4;
              break;
            case 1242:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2728LL))(a1, a3, a4);
              a1[391] = a4;
              break;
            case 1243:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2736LL))(a1, a3, a4);
              a1[392] = a4;
              break;
            case 1244:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2744LL))(a1, a3, a4);
              a1[393] = a4;
              break;
            case 1245:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2752LL))(a1, a3, a4);
              a1[394] = a4;
              break;
            case 1246:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2760LL))(a1, a3, a4);
              a1[395] = a4;
              break;
            case 1247:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2768LL))(a1, a3, a4);
              a1[396] = a4;
              break;
            case 1248:
              result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2776LL))(a1, a3, a4);
              a1[397] = a4;
              break;
            default:
              return result;
          }
        }
      }
      else if ( a2 == 1028 )
      {
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2592LL))(a1, a3, a4);
        a1[374] = a4;
      }
      else
      {
        switch ( a2 )
        {
          case 657:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1976LL))(a1, a3, a4);
            a1[297] = a4;
            break;
          case 665:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1984LL))(a1, a3, a4);
            a1[298] = a4;
            break;
          case 668:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1992LL))(a1, a3, a4);
            a1[299] = a4;
            break;
          case 669:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2000LL))(a1, a3, a4);
            a1[300] = a4;
            break;
          case 699:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2008LL))(a1, a3, a4);
            a1[301] = a4;
            break;
          case 707:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2016LL))(a1, a3, a4);
            a1[302] = a4;
            break;
          case 710:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2024LL))(a1, a3, a4);
            a1[303] = a4;
            break;
          case 711:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2032LL))(a1, a3, a4);
            a1[304] = a4;
            break;
          case 751:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2040LL))(a1, a3, a4);
            a1[305] = a4;
            break;
          case 752:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2048LL))(a1, a3, a4);
            a1[306] = a4;
            break;
          case 753:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2056LL))(a1, a3, a4);
            a1[307] = a4;
            break;
          case 754:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2064LL))(a1, a3, a4);
            a1[308] = a4;
            break;
          case 756:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2072LL))(a1, a3, a4);
            a1[309] = a4;
            break;
          case 757:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2080LL))(a1, a3, a4);
            a1[310] = a4;
            break;
          case 758:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2088LL))(a1, a3, a4);
            a1[311] = a4;
            break;
          case 759:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2096LL))(a1, a3, a4);
            a1[312] = a4;
            break;
          case 760:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2104LL))(a1, a3, a4);
            a1[313] = a4;
            break;
          case 770:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2112LL))(a1, a3, a4);
            a1[314] = a4;
            break;
          case 771:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2120LL))(a1, a3, a4);
            a1[315] = a4;
            break;
          case 772:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2128LL))(a1, a3, a4);
            a1[316] = a4;
            break;
          case 773:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2136LL))(a1, a3, a4);
            a1[317] = a4;
            break;
          case 779:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2144LL))(a1, a3, a4);
            a1[318] = a4;
            break;
          case 781:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2152LL))(a1, a3, a4);
            a1[319] = a4;
            break;
          case 782:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2160LL))(a1, a3, a4);
            a1[320] = a4;
            break;
          case 783:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2168LL))(a1, a3, a4);
            a1[321] = a4;
            break;
          case 784:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2176LL))(a1, a3, a4);
            a1[322] = a4;
            break;
          case 785:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2184LL))(a1, a3, a4);
            a1[323] = a4;
            break;
          case 786:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2192LL))(a1, a3, a4);
            a1[324] = a4;
            break;
          case 787:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2200LL))(a1, a3, a4);
            a1[325] = a4;
            break;
          case 788:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2208LL))(a1, a3, a4);
            a1[326] = a4;
            break;
          case 789:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2216LL))(a1, a3, a4);
            a1[327] = a4;
            break;
          case 790:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2224LL))(a1, a3, a4);
            a1[328] = a4;
            break;
          case 791:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2232LL))(a1, a3, a4);
            a1[329] = a4;
            break;
          case 792:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2240LL))(a1, a3, a4);
            a1[330] = a4;
            break;
          case 793:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2248LL))(a1, a3, a4);
            a1[331] = a4;
            break;
          case 794:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2256LL))(a1, a3, a4);
            a1[332] = a4;
            break;
          case 795:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2264LL))(a1, a3, a4);
            a1[333] = a4;
            break;
          case 796:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2272LL))(a1, a3, a4);
            a1[334] = a4;
            break;
          case 797:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2280LL))(a1, a3, a4);
            a1[335] = a4;
            break;
          case 798:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2288LL))(a1, a3, a4);
            a1[336] = a4;
            break;
          case 799:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2296LL))(a1, a3, a4);
            a1[337] = a4;
            break;
          case 800:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2304LL))(a1, a3, a4);
            a1[338] = a4;
            break;
          case 801:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2312LL))(a1, a3, a4);
            a1[339] = a4;
            break;
          case 803:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2320LL))(a1, a3, a4);
            a1[340] = a4;
            break;
          case 810:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2328LL))(a1, a3, a4);
            a1[341] = a4;
            break;
          case 830:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2336LL))(a1, a3, a4);
            a1[342] = a4;
            break;
          case 838:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2344LL))(a1, a3, a4);
            a1[343] = a4;
            break;
          case 839:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2352LL))(a1, a3, a4);
            a1[344] = a4;
            break;
          case 840:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2360LL))(a1, a3, a4);
            a1[345] = a4;
            break;
          case 841:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2368LL))(a1, a3, a4);
            a1[346] = a4;
            break;
          case 842:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2376LL))(a1, a3, a4);
            a1[347] = a4;
            break;
          case 843:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2384LL))(a1, a3, a4);
            a1[348] = a4;
            break;
          case 844:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2392LL))(a1, a3, a4);
            a1[349] = a4;
            break;
          case 845:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2400LL))(a1, a3, a4);
            a1[350] = a4;
            break;
          case 846:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2408LL))(a1, a3, a4);
            a1[351] = a4;
            break;
          case 847:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2416LL))(a1, a3, a4);
            a1[352] = a4;
            break;
          case 848:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2424LL))(a1, a3, a4);
            a1[353] = a4;
            break;
          case 849:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2432LL))(a1, a3, a4);
            a1[354] = a4;
            break;
          case 850:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2440LL))(a1, a3, a4);
            a1[355] = a4;
            break;
          case 851:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2448LL))(a1, a3, a4);
            a1[356] = a4;
            break;
          case 852:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2456LL))(a1, a3, a4);
            a1[357] = a4;
            break;
          case 853:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2464LL))(a1, a3, a4);
            a1[358] = a4;
            break;
          case 855:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2472LL))(a1, a3, a4);
            a1[359] = a4;
            break;
          case 856:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2480LL))(a1, a3, a4);
            a1[360] = a4;
            break;
          case 857:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2488LL))(a1, a3, a4);
            a1[361] = a4;
            break;
          case 858:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2496LL))(a1, a3, a4);
            a1[362] = a4;
            break;
          case 859:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2504LL))(a1, a3, a4);
            a1[363] = a4;
            break;
          case 860:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2512LL))(a1, a3, a4);
            a1[364] = a4;
            break;
          case 861:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2520LL))(a1, a3, a4);
            a1[365] = a4;
            break;
          case 863:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2528LL))(a1, a3, a4);
            a1[366] = a4;
            break;
          case 871:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2536LL))(a1, a3, a4);
            a1[367] = a4;
            break;
          case 873:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2544LL))(a1, a3, a4);
            a1[368] = a4;
            break;
          case 874:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2552LL))(a1, a3, a4);
            a1[369] = a4;
            break;
          case 875:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2560LL))(a1, a3, a4);
            a1[370] = a4;
            break;
          case 876:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2568LL))(a1, a3, a4);
            a1[371] = a4;
            break;
          case 877:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2576LL))(a1, a3, a4);
            a1[372] = a4;
            break;
          case 878:
            result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 2584LL))(a1, a3, a4);
            a1[373] = a4;
            break;
          default:
            return result;
        }
      }
    }
    else if ( a2 == 614 )
    {
      result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1968LL))(a1, a3, a4);
      a1[296] = a4;
    }
    else
    {
      switch ( a2 )
      {
        case 313:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1656LL))(a1, a3, a4);
          a1[257] = a4;
          break;
        case 314:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1664LL))(a1, a3, a4);
          a1[258] = a4;
          break;
        case 315:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1672LL))(a1, a3, a4);
          a1[259] = a4;
          break;
        case 316:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1680LL))(a1, a3, a4);
          a1[260] = a4;
          break;
        case 317:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1688LL))(a1, a3, a4);
          a1[261] = a4;
          break;
        case 318:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1696LL))(a1, a3, a4);
          a1[262] = a4;
          break;
        case 373:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1704LL))(a1, a3, a4);
          a1[263] = a4;
          break;
        case 375:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1712LL))(a1, a3, a4);
          a1[264] = a4;
          break;
        case 433:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1720LL))(a1, a3, a4);
          a1[265] = a4;
          break;
        case 434:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1728LL))(a1, a3, a4);
          a1[266] = a4;
          break;
        case 435:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1736LL))(a1, a3, a4);
          a1[267] = a4;
          break;
        case 436:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1744LL))(a1, a3, a4);
          a1[268] = a4;
          break;
        case 437:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1752LL))(a1, a3, a4);
          a1[269] = a4;
          break;
        case 438:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1760LL))(a1, a3, a4);
          a1[270] = a4;
          break;
        case 439:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1768LL))(a1, a3, a4);
          a1[271] = a4;
          break;
        case 440:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1776LL))(a1, a3, a4);
          a1[272] = a4;
          break;
        case 450:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1784LL))(a1, a3, a4);
          a1[273] = a4;
          break;
        case 451:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1792LL))(a1, a3, a4);
          a1[274] = a4;
          break;
        case 452:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1800LL))(a1, a3, a4);
          a1[275] = a4;
          break;
        case 453:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1808LL))(a1, a3, a4);
          a1[276] = a4;
          break;
        case 454:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1816LL))(a1, a3, a4);
          a1[277] = a4;
          break;
        case 455:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1824LL))(a1, a3, a4);
          a1[278] = a4;
          break;
        case 456:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1832LL))(a1, a3, a4);
          a1[279] = a4;
          break;
        case 457:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1840LL))(a1, a3, a4);
          a1[280] = a4;
          break;
        case 467:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1848LL))(a1, a3, a4);
          a1[281] = a4;
          break;
        case 468:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1856LL))(a1, a3, a4);
          a1[282] = a4;
          break;
        case 469:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1864LL))(a1, a3, a4);
          a1[283] = a4;
          break;
        case 470:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1872LL))(a1, a3, a4);
          a1[284] = a4;
          break;
        case 471:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1880LL))(a1, a3, a4);
          a1[285] = a4;
          break;
        case 472:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1888LL))(a1, a3, a4);
          a1[286] = a4;
          break;
        case 473:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1896LL))(a1, a3, a4);
          a1[287] = a4;
          break;
        case 474:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1904LL))(a1, a3, a4);
          a1[288] = a4;
          break;
        case 484:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1912LL))(a1, a3, a4);
          a1[289] = a4;
          break;
        case 493:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1920LL))(a1, a3, a4);
          a1[290] = a4;
          break;
        case 495:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1928LL))(a1, a3, a4);
          a1[291] = a4;
          break;
        case 498:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1936LL))(a1, a3, a4);
          a1[292] = a4;
          break;
        case 553:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1944LL))(a1, a3, a4);
          a1[293] = a4;
          break;
        case 554:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1952LL))(a1, a3, a4);
          a1[294] = a4;
          break;
        case 555:
          result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1960LL))(a1, a3, a4);
          a1[295] = a4;
          break;
        default:
          return result;
      }
    }
  }
  else if ( a2 == 312 )
  {
    result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1648LL))(a1, a3, a4);
    a1[256] = a4;
  }
  else
  {
    switch ( a2 )
    {
      case 20:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1496LL))(a1, a3, a4);
        a1[237] = a4;
        break;
      case 128:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1504LL))(a1, a3, a4);
        a1[238] = a4;
        break;
      case 129:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1512LL))(a1, a3, a4);
        a1[239] = a4;
        break;
      case 130:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1520LL))(a1, a3, a4);
        a1[240] = a4;
        break;
      case 131:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1528LL))(a1, a3, a4);
        a1[241] = a4;
        break;
      case 132:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1536LL))(a1, a3, a4);
        a1[242] = a4;
        break;
      case 133:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1544LL))(a1, a3, a4);
        a1[243] = a4;
        break;
      case 134:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1552LL))(a1, a3, a4);
        a1[244] = a4;
        break;
      case 135:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1560LL))(a1, a3, a4);
        a1[245] = a4;
        break;
      case 136:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1568LL))(a1, a3, a4);
        a1[246] = a4;
        break;
      case 137:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1576LL))(a1, a3, a4);
        a1[247] = a4;
        break;
      case 138:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1584LL))(a1, a3, a4);
        a1[248] = a4;
        break;
      case 139:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1592LL))(a1, a3, a4);
        a1[249] = a4;
        break;
      case 140:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1600LL))(a1, a3, a4);
        a1[250] = a4;
        break;
      case 141:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1608LL))(a1, a3, a4);
        a1[251] = a4;
        break;
      case 189:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1616LL))(a1, a3, a4);
        a1[252] = a4;
        break;
      case 196:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1632LL))(a1, a3, a4);
        a1[254] = a4;
        break;
      case 254:
        result = (*(__int64 (__fastcall **)(_DWORD *, _QWORD, _QWORD))(*(_QWORD *)a1 + 1640LL))(a1, a3, a4);
        a1[255] = a4;
        break;
      default:
        return result;
    }
  }
  return result;
}


// ==== sub_7FF91E01B800 @ rva 0x3BB800 ====
__int64 __fastcall sub_7FF91E01B800(__int64 a1, int a2, unsigned int a3)
{
  __int64 result; // rax
  int v4; // edx
  int v5; // edx
  int v6; // edx

  if ( a2 > 312 )
  {
    if ( a2 > 614 )
    {
      if ( a2 > 1028 )
      {
        if ( a2 > 1323 )
        {
          v4 = a2 - 1324;
          if ( v4 )
          {
            v5 = v4 - 1;
            if ( v5 )
            {
              v6 = v5 - 1;
              if ( v6 )
              {
                if ( v6 == 1 )
                  return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1480LL))(a1, a3);
              }
              else
              {
                return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1472LL))(a1, a3);
              }
            }
            else
            {
              return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1464LL))(a1, a3);
            }
          }
          else
          {
            return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1456LL))(a1, a3);
          }
        }
        else if ( a2 == 1323 )
        {
          return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1448LL))(a1, a3);
        }
        else
        {
          switch ( a2 )
          {
            case 1029:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1264LL))(a1, a3);
              break;
            case 1058:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1272LL))(a1, a3);
              break;
            case 1178:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1280LL))(a1, a3);
              break;
            case 1179:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1288LL))(a1, a3);
              break;
            case 1180:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1296LL))(a1, a3);
              break;
            case 1181:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1304LL))(a1, a3);
              break;
            case 1182:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1312LL))(a1, a3);
              break;
            case 1183:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1320LL))(a1, a3);
              break;
            case 1184:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1328LL))(a1, a3);
              break;
            case 1185:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1336LL))(a1, a3);
              break;
            case 1210:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1344LL))(a1, a3);
              break;
            case 1211:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1352LL))(a1, a3);
              break;
            case 1212:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1360LL))(a1, a3);
              break;
            case 1213:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1368LL))(a1, a3);
              break;
            case 1214:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1376LL))(a1, a3);
              break;
            case 1215:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1384LL))(a1, a3);
              break;
            case 1242:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1392LL))(a1, a3);
              break;
            case 1243:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1400LL))(a1, a3);
              break;
            case 1244:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1408LL))(a1, a3);
              break;
            case 1245:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1416LL))(a1, a3);
              break;
            case 1246:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1424LL))(a1, a3);
              break;
            case 1247:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1432LL))(a1, a3);
              break;
            case 1248:
              result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1440LL))(a1, a3);
              break;
            default:
              return result;
          }
        }
      }
      else if ( a2 == 1028 )
      {
        return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1256LL))(a1, a3);
      }
      else
      {
        switch ( a2 )
        {
          case 657:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 640LL))(a1, a3);
            break;
          case 665:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 648LL))(a1, a3);
            break;
          case 668:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 656LL))(a1, a3);
            break;
          case 669:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 664LL))(a1, a3);
            break;
          case 699:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 672LL))(a1, a3);
            break;
          case 707:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 680LL))(a1, a3);
            break;
          case 710:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 688LL))(a1, a3);
            break;
          case 711:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 696LL))(a1, a3);
            break;
          case 751:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 704LL))(a1, a3);
            break;
          case 752:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 712LL))(a1, a3);
            break;
          case 753:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 720LL))(a1, a3);
            break;
          case 754:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 728LL))(a1, a3);
            break;
          case 756:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 736LL))(a1, a3);
            break;
          case 757:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 744LL))(a1, a3);
            break;
          case 758:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 752LL))(a1, a3);
            break;
          case 759:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 760LL))(a1, a3);
            break;
          case 760:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 768LL))(a1, a3);
            break;
          case 770:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 776LL))(a1, a3);
            break;
          case 771:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 784LL))(a1, a3);
            break;
          case 772:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 792LL))(a1, a3);
            break;
          case 773:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 800LL))(a1, a3);
            break;
          case 779:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 808LL))(a1, a3);
            break;
          case 781:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 816LL))(a1, a3);
            break;
          case 782:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 824LL))(a1, a3);
            break;
          case 783:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 832LL))(a1, a3);
            break;
          case 784:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 840LL))(a1, a3);
            break;
          case 785:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 848LL))(a1, a3);
            break;
          case 786:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 856LL))(a1, a3);
            break;
          case 787:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 864LL))(a1, a3);
            break;
          case 788:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 872LL))(a1, a3);
            break;
          case 789:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 880LL))(a1, a3);
            break;
          case 790:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 888LL))(a1, a3);
            break;
          case 791:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 896LL))(a1, a3);
            break;
          case 792:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 904LL))(a1, a3);
            break;
          case 793:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 912LL))(a1, a3);
            break;
          case 794:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 920LL))(a1, a3);
            break;
          case 795:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 928LL))(a1, a3);
            break;
          case 796:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 936LL))(a1, a3);
            break;
          case 797:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 944LL))(a1, a3);
            break;
          case 798:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 952LL))(a1, a3);
            break;
          case 799:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 960LL))(a1, a3);
            break;
          case 800:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 968LL))(a1, a3);
            break;
          case 801:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 976LL))(a1, a3);
            break;
          case 803:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 984LL))(a1, a3);
            break;
          case 810:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 992LL))(a1, a3);
            break;
          case 830:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1000LL))(a1, a3);
            break;
          case 838:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1008LL))(a1, a3);
            break;
          case 839:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1016LL))(a1, a3);
            break;
          case 840:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1024LL))(a1, a3);
            break;
          case 841:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1032LL))(a1, a3);
            break;
          case 842:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1040LL))(a1, a3);
            break;
          case 843:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1048LL))(a1, a3);
            break;
          case 844:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1056LL))(a1, a3);
            break;
          case 845:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1064LL))(a1, a3);
            break;
          case 846:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1072LL))(a1, a3);
            break;
          case 847:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1080LL))(a1, a3);
            break;
          case 848:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1088LL))(a1, a3);
            break;
          case 849:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1096LL))(a1, a3);
            break;
          case 850:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1104LL))(a1, a3);
            break;
          case 851:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1112LL))(a1, a3);
            break;
          case 852:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1120LL))(a1, a3);
            break;
          case 853:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1128LL))(a1, a3);
            break;
          case 855:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1136LL))(a1, a3);
            break;
          case 856:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1144LL))(a1, a3);
            break;
          case 857:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1152LL))(a1, a3);
            break;
          case 858:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1160LL))(a1, a3);
            break;
          case 859:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1168LL))(a1, a3);
            break;
          case 860:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1176LL))(a1, a3);
            break;
          case 861:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1184LL))(a1, a3);
            break;
          case 863:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1192LL))(a1, a3);
            break;
          case 871:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1200LL))(a1, a3);
            break;
          case 873:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1208LL))(a1, a3);
            break;
          case 874:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1216LL))(a1, a3);
            break;
          case 875:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1224LL))(a1, a3);
            break;
          case 876:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1232LL))(a1, a3);
            break;
          case 877:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1240LL))(a1, a3);
            break;
          case 878:
            result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 1248LL))(a1, a3);
            break;
          default:
            return result;
        }
      }
    }
    else if ( a2 == 614 )
    {
      return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 632LL))(a1, a3);
    }
    else
    {
      switch ( a2 )
      {
        case 313:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 320LL))(a1, a3);
          break;
        case 314:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 328LL))(a1, a3);
          break;
        case 315:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 336LL))(a1, a3);
          break;
        case 316:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 344LL))(a1, a3);
          break;
        case 317:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 352LL))(a1, a3);
          break;
        case 318:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 360LL))(a1, a3);
          break;
        case 373:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 368LL))(a1, a3);
          break;
        case 375:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 376LL))(a1, a3);
          break;
        case 433:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 384LL))(a1, a3);
          break;
        case 434:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 392LL))(a1, a3);
          break;
        case 435:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 400LL))(a1, a3);
          break;
        case 436:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 408LL))(a1, a3);
          break;
        case 437:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 416LL))(a1, a3);
          break;
        case 438:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 424LL))(a1, a3);
          break;
        case 439:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 432LL))(a1, a3);
          break;
        case 440:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 440LL))(a1, a3);
          break;
        case 450:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 448LL))(a1, a3);
          break;
        case 451:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 456LL))(a1, a3);
          break;
        case 452:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 464LL))(a1, a3);
          break;
        case 453:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 472LL))(a1, a3);
          break;
        case 454:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 480LL))(a1, a3);
          break;
        case 455:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 488LL))(a1, a3);
          break;
        case 456:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 496LL))(a1, a3);
          break;
        case 457:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 504LL))(a1, a3);
          break;
        case 467:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 512LL))(a1, a3);
          break;
        case 468:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 520LL))(a1, a3);
          break;
        case 469:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 528LL))(a1, a3);
          break;
        case 470:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 536LL))(a1, a3);
          break;
        case 471:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 544LL))(a1, a3);
          break;
        case 472:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 552LL))(a1, a3);
          break;
        case 473:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 560LL))(a1, a3);
          break;
        case 474:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 568LL))(a1, a3);
          break;
        case 484:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 576LL))(a1, a3);
          break;
        case 493:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 584LL))(a1, a3);
          break;
        case 495:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 592LL))(a1, a3);
          break;
        case 498:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 600LL))(a1, a3);
          break;
        case 553:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 608LL))(a1, a3);
          break;
        case 554:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 616LL))(a1, a3);
          break;
        case 555:
          result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 624LL))(a1, a3);
          break;
        default:
          return result;
      }
    }
  }
  else if ( a2 == 312 )
  {
    return (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 312LL))(a1, a3);
  }
  else
  {
    switch ( a2 )
    {
      case 20:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 160LL))(a1, a3);
        break;
      case 128:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 168LL))(a1, a3);
        break;
      case 129:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 176LL))(a1, a3);
        break;
      case 130:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 184LL))(a1, a3);
        break;
      case 131:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 192LL))(a1, a3);
        break;
      case 132:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 200LL))(a1, a3);
        break;
      case 133:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 208LL))(a1, a3);
        break;
      case 134:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 216LL))(a1, a3);
        break;
      case 135:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 224LL))(a1, a3);
        break;
      case 136:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 232LL))(a1, a3);
        break;
      case 137:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 240LL))(a1, a3);
        break;
      case 138:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 248LL))(a1, a3);
        break;
      case 139:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 256LL))(a1, a3);
        break;
      case 140:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 264LL))(a1, a3);
        break;
      case 141:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 272LL))(a1, a3);
        break;
      case 189:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 280LL))(a1, a3);
        break;
      case 196:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 296LL))(a1, a3);
        break;
      case 254:
        result = (*(__int64 (__fastcall **)(__int64, _QWORD))(*(_QWORD *)a1 + 304LL))(a1, a3);
        break;
      default:
        return result;
    }
  }
  return result;
}


// ==== sub_7FF91E01C980 @ rva 0x3BC980 ====
__int64 __fastcall sub_7FF91E01C980(__int64 a1, unsigned int a2)
{
  __int64 v2; // rsi
  _QWORD *v5; // rbx
  __int64 v6; // rcx
  __int64 v7; // rcx
  __int64 v8; // rcx
  __int64 v9; // rcx
  __int64 v10; // rcx
  __int64 result; // rax

  v2 = *(int *)(a1 + 1612);
  if ( (int)v2 <= *(_DWORD *)(a1 + 1616) )
  {
    v5 = (_QWORD *)(a1 + 16 * (v2 + 1));
    do
    {
      v6 = v5[32];
      if ( v6 )
        (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v6 + 120LL))(v6, a2);
      if ( *v5 )
        (*(void (__fastcall **)(_QWORD, _QWORD))(*(_QWORD *)*v5 + 160LL))(*v5, a2);
      v7 = v5[16];
      if ( v7 )
        (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v7 + 96LL))(v7, a2);
      v8 = v5[80];
      if ( v8 )
        (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v8 + 104LL))(v8, a2);
      LODWORD(v2) = v2 + 1;
      v5 += 2;
    }
    while ( (int)v2 <= *(_DWORD *)(a1 + 1616) );
  }
  v9 = *(_QWORD *)(a1 + 912);
  if ( v9 )
    (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v9 + 64LL))(v9, a2);
  v10 = *(_QWORD *)(a1 + 928);
  if ( v10 )
    (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)v10 + 56LL))(v10, a2);
  (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 6784) + 176LL))(a1 + 6784, a2);
  (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 6976) + 176LL))(a1 + 6976, a2);
  (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 7184) + 200LL))(a1 + 7184, a2);
  (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 7400) + 200LL))(a1 + 7400, a2);
  (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 7616) + 200LL))(a1 + 7616, a2);
  (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 7824) + 320LL))(a1 + 7824, a2);
  (*(void (__fastcall **)(__int64, _QWORD))(*(_QWORD *)(a1 + 8176) + 16LL))(a1 + 8176, a2);
  result = *(int *)(a1 + 1480);
  switch ( *(_DWORD *)(a1 + 1480) )
  {
    case 0:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 6784) + 184LL))(a1 + 6784);
      break;
    case 1:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 6976) + 184LL))(a1 + 6976);
      break;
    case 2:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7184) + 208LL))(a1 + 7184);
      break;
    case 3:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7400) + 208LL))(a1 + 7400);
      break;
    case 4:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7616) + 208LL))(a1 + 7616);
      break;
    case 5:
      result = (*(__int64 (__fastcall **)(__int64))(*(_QWORD *)(a1 + 7824) + 328LL))(a1 + 7824);
      break;
    default:
      return result;
  }
  return result;
}


// ==== sub_7FF91E01CBC0 @ rva 0x3BCBC0 ====
__int64 __fastcall sub_7FF91E01CBC0(__int64 a1, unsigned int a2, unsigned int a3)
{
  sub_7FF91E00D710(a1, 1u);
  sub_7FF91E021010(*(_QWORD *)(a1 + 8), 4, a3);
  sub_7FF91E0117B0((unsigned int *)a1, a2);
  return sub_7FF91E00D660(a1);
}


// ==== sub_7FF91E01CC20 @ rva 0x3BCC20 ====
__int64 __fastcall sub_7FF91E01CC20(__int64 a1, __int64 a2, int a3, int a4)
{
  sub_7FF91E00DC00(a1, 0);
  sub_7FF91E021010(*(_QWORD *)(a1 + 8), 1, (unsigned int)(a4 + 6 * a3));
  return sub_7FF91E00DBA0(a1);
}


// ==== sub_7FF91E01CC70 @ rva 0x3BCC70 ====
__int64 __fastcall sub_7FF91E01CC70(__int64 a1, __int64 a2, int a3, int a4)
{
  sub_7FF91E00DD50(a1, 0);
  sub_7FF91E021010(*(_QWORD *)(a1 + 8), 2, (unsigned int)(a4 + 6 * a3));
  return sub_7FF91E00DCF0(a1);
}


// ==== sub_7FF91E01CCC0 @ rva 0x3BCCC0 ====
__int64 __fastcall sub_7FF91E01CCC0(int *a1)
{
  __int64 v1; // rbx
  __int64 v2; // rdx

  v1 = (__int64)a1;
  sub_7FF91E012120(a1);
  sub_7FF91E018180(v1, v2);
  v1 += 8176;
  (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v1 + 24LL))(v1, 1, 1);
  (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v1 + 48LL))(v1, 1, 20);
  (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v1 + 56LL))(v1, 1, 2);
  (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v1 + 72LL))(v1, 1, 11);
  (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v1 + 88LL))(v1, 1, 10);
  (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v1 + 104LL))(v1, 1, 100);
  return (*(__int64 (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v1 + 120LL))(v1, 1, 127);
}


// ==== ?_DeleteExceptionPtr@@YAXQEAV__ExceptionPtr@@@Z_0 @ rva 0x3BCD60 ====
void __fastcall _DeleteExceptionPtr(struct __ExceptionPtr *const a1)
{
  __int64 v2; // rdx

  sub_7FF91E012120((int *)a1);
  sub_7FF91E018180((__int64)a1, v2);
}


// ==== sub_7FF91E01CD80 @ rva 0x3BCD80 ====
__int64 __fastcall sub_7FF91E01CD80(__int64 a1)
{
  __int64 v2; // rcx
  int v3; // eax
  unsigned int v4; // edi
  __int64 v5; // r8
  unsigned int v6; // ebp
  unsigned int v7; // esi
  void (__fastcall ***v8)(_QWORD, __int64, __int64); // rcx

  v2 = *(_QWORD *)(a1 + 832);
  if ( v2 )
    (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)v2 + 8LL))(v2, 1, 128);
  sub_7FF91E00D590(a1);
  v3 = *(_DWORD *)(a1 + 1612);
  v4 = 0;
  if ( v3 || *(int *)(a1 + 1616) < 1 )
  {
    v5 = 0;
    if ( v3 > 2 )
    {
LABEL_8:
      v6 = 0;
      goto LABEL_9;
    }
  }
  else
  {
    v5 = 1;
  }
  v6 = 1;
  if ( *(int *)(a1 + 1616) < 3 )
    goto LABEL_8;
LABEL_9:
  if ( v3 > 4 || (v7 = 1, *(int *)(a1 + 1616) < 5) )
    v7 = 0;
  if ( v3 <= 6 && *(_DWORD *)(a1 + 1616) == 7 )
    v4 = 1;
  v8 = *(void (__fastcall ****)(_QWORD, __int64, __int64))(a1 + 800);
  if ( v8 )
  {
    (**v8)(v8, 1, v5);
    (*(void (__fastcall **)(_QWORD, __int64, _QWORD))(**(_QWORD **)(a1 + 800) + 8LL))(*(_QWORD *)(a1 + 800), 1, v6);
    (*(void (__fastcall **)(_QWORD, __int64, _QWORD))(**(_QWORD **)(a1 + 800) + 16LL))(*(_QWORD *)(a1 + 800), 1, v7);
    (*(void (__fastcall **)(_QWORD, __int64, _QWORD))(**(_QWORD **)(a1 + 800) + 24LL))(*(_QWORD *)(a1 + 800), 1, v4);
  }
  sub_7FF91E00CF60(a1);
  sub_7FF91E00CEF0(a1);
  sub_7FF91E00CED0(a1);
  sub_7FF91E00CD20(a1);
  return sub_7FF91E011D60(a1);
}


// ==== sub_7FF91E01CEB0 @ rva 0x3BCEB0 ====
void __fastcall sub_7FF91E01CEB0(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CEC0 @ rva 0x3BCEC0 ====
void __fastcall sub_7FF91E01CEC0(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CED0 @ rva 0x3BCED0 ====
void __fastcall sub_7FF91E01CED0(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CEE0 @ rva 0x3BCEE0 ====
void __fastcall sub_7FF91E01CEE0(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CEF0 @ rva 0x3BCEF0 ====
void __fastcall sub_7FF91E01CEF0(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CF00 @ rva 0x3BCF00 ====
void __fastcall sub_7FF91E01CF00(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CF10 @ rva 0x3BCF10 ====
void __fastcall sub_7FF91E01CF10(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CF20 @ rva 0x3BCF20 ====
void __fastcall sub_7FF91E01CF20(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CF30 @ rva 0x3BCF30 ====
void __fastcall sub_7FF91E01CF30(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CF40 @ rva 0x3BCF40 ====
void __fastcall sub_7FF91E01CF40(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CF50 @ rva 0x3BCF50 ====
void __fastcall sub_7FF91E01CF50(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CF60 @ rva 0x3BCF60 ====
void __fastcall sub_7FF91E01CF60(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CF70 @ rva 0x3BCF70 ====
void __fastcall sub_7FF91E01CF70(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CF80 @ rva 0x3BCF80 ====
void __fastcall sub_7FF91E01CF80(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CF90 @ rva 0x3BCF90 ====
void __fastcall sub_7FF91E01CF90(__int64 a1)
{
  j_j_free(*(void **)(a1 + 16));
}


// ==== sub_7FF91E01CFA0 @ rva 0x3BCFA0 ====
__int64 sub_7FF91E01CFA0()
{
  return 0;
}


// ==== sub_7FF91E01CFB0 @ rva 0x3BCFB0 ====
__int64 sub_7FF91E01CFB0()
{
  return 0;
}


// ==== sub_7FF91E01CFC0 @ rva 0x3BCFC0 ====
__int64 sub_7FF91E01CFC0()
{
  return 0;
}


// ==== sub_7FF91E01CFD0 @ rva 0x3BCFD0 ====
__int64 sub_7FF91E01CFD0()
{
  return 0;
}


// ==== sub_7FF91E01CFE0 @ rva 0x3BCFE0 ====
__int64 sub_7FF91E01CFE0()
{
  return 0;
}


// ==== sub_7FF91E01CFF0 @ rva 0x3BCFF0 ====
__int64 sub_7FF91E01CFF0()
{
  return 0;
}


// ==== sub_7FF91E01D000 @ rva 0x3BD000 ====
__int64 sub_7FF91E01D000()
{
  return 0;
}


// ==== sub_7FF91E01D010 @ rva 0x3BD010 ====
__int64 sub_7FF91E01D010()
{
  return 0;
}


// ==== sub_7FF91E01D020 @ rva 0x3BD020 ====
__int64 sub_7FF91E01D020()
{
  return 0;
}


// ==== sub_7FF91E01D030 @ rva 0x3BD030 ====
__int64 sub_7FF91E01D030()
{
  return 0;
}


// ==== sub_7FF91E01D040 @ rva 0x3BD040 ====
__int64 sub_7FF91E01D040()
{
  return 0;
}


// ==== sub_7FF91E01D050 @ rva 0x3BD050 ====
__int64 sub_7FF91E01D050()
{
  return 0;
}


// ==== sub_7FF91E01D060 @ rva 0x3BD060 ====
__int64 sub_7FF91E01D060()
{
  return 0;
}


// ==== sub_7FF91E01D070 @ rva 0x3BD070 ====
__int64 sub_7FF91E01D070()
{
  return 0;
}


// ==== sub_7FF91E01D080 @ rva 0x3BD080 ====
__int64 sub_7FF91E01D080()
{
  return 0;
}


// ==== sub_7FF91E01D090 @ rva 0x3BD090 ====
__int64 sub_7FF91E01D090()
{
  return 0;
}


// ==== sub_7FF91E01D0A0 @ rva 0x3BD0A0 ====
__int64 sub_7FF91E01D0A0()
{
  return 0;
}


// ==== sub_7FF91E01D0B0 @ rva 0x3BD0B0 ====
__int64 sub_7FF91E01D0B0()
{
  return 0;
}


// ==== sub_7FF91E01D0C0 @ rva 0x3BD0C0 ====
__int64 sub_7FF91E01D0C0()
{
  return 0;
}


// ==== sub_7FF91E01D0D0 @ rva 0x3BD0D0 ====
__int64 sub_7FF91E01D0D0()
{
  return 0;
}


// ==== sub_7FF91E01D0E0 @ rva 0x3BD0E0 ====
__int64 sub_7FF91E01D0E0()
{
  return 0;
}


// ==== sub_7FF91E01D0F0 @ rva 0x3BD0F0 ====
__int64 sub_7FF91E01D0F0()
{
  return 0;
}


// ==== sub_7FF91E01D100 @ rva 0x3BD100 ====
__int64 sub_7FF91E01D100()
{
  return 0;
}


// ==== sub_7FF91E01D110 @ rva 0x3BD110 ====
__int64 sub_7FF91E01D110()
{
  return 0;
}


// ==== sub_7FF91E01D120 @ rva 0x3BD120 ====
__int64 sub_7FF91E01D120()
{
  return 0;
}


// ==== sub_7FF91E01D130 @ rva 0x3BD130 ====
__int64 sub_7FF91E01D130()
{
  return 0;
}


// ==== sub_7FF91E01D140 @ rva 0x3BD140 ====
__int64 sub_7FF91E01D140()
{
  return 0;
}


// ==== sub_7FF91E01D150 @ rva 0x3BD150 ====
__int64 sub_7FF91E01D150()
{
  return 0;
}


// ==== sub_7FF91E01D160 @ rva 0x3BD160 ====
__int64 sub_7FF91E01D160()
{
  return 0;
}


// ==== sub_7FF91E01D170 @ rva 0x3BD170 ====
__int64 sub_7FF91E01D170()
{
  return 0;
}


// ==== sub_7FF91E01D180 @ rva 0x3BD180 ====
__int64 sub_7FF91E01D180()
{
  return 0;
}


// ==== sub_7FF91E01D190 @ rva 0x3BD190 ====
__int64 sub_7FF91E01D190()
{
  return 0;
}


// ==== sub_7FF91E01D1A0 @ rva 0x3BD1A0 ====
__int64 sub_7FF91E01D1A0()
{
  return 0;
}


// ==== sub_7FF91E01D1B0 @ rva 0x3BD1B0 ====
__int64 sub_7FF91E01D1B0()
{
  return 0;
}


// ==== sub_7FF91E01D1C0 @ rva 0x3BD1C0 ====
__int64 sub_7FF91E01D1C0()
{
  return 0;
}


// ==== sub_7FF91E01D1D0 @ rva 0x3BD1D0 ====
__int64 sub_7FF91E01D1D0()
{
  return 0;
}


// ==== sub_7FF91E01D1E0 @ rva 0x3BD1E0 ====
__int64 sub_7FF91E01D1E0()
{
  return 0;
}


// ==== sub_7FF91E01D1F0 @ rva 0x3BD1F0 ====
__int64 sub_7FF91E01D1F0()
{
  return 0;
}


// ==== sub_7FF91E01D200 @ rva 0x3BD200 ====
__int64 sub_7FF91E01D200()
{
  return 0;
}


// ==== sub_7FF91E01D210 @ rva 0x3BD210 ====
__int64 sub_7FF91E01D210()
{
  return 0;
}


// ==== sub_7FF91E01D220 @ rva 0x3BD220 ====
__int64 sub_7FF91E01D220()
{
  return 0;
}


// ==== sub_7FF91E01D230 @ rva 0x3BD230 ====
__int64 sub_7FF91E01D230()
{
  return 0;
}


// ==== sub_7FF91E01D240 @ rva 0x3BD240 ====
__int64 sub_7FF91E01D240()
{
  return 0;
}


// ==== sub_7FF91E01D250 @ rva 0x3BD250 ====
__int64 sub_7FF91E01D250()
{
  return 0;
}


// ==== sub_7FF91E01D260 @ rva 0x3BD260 ====
__int64 sub_7FF91E01D260()
{
  return 0;
}


// ==== sub_7FF91E01D270 @ rva 0x3BD270 ====
__int64 __fastcall sub_7FF91E01D270(__int64 a1)
{
  *(_QWORD *)a1 = &CArpeggio::`vftable';
  sub_7FF91E020E40(a1 + 8, 31415);
  *(_BYTE *)(a1 + 10) = 0;
  *(_QWORD *)(a1 + 20) = 0;
  *(_QWORD *)(a1 + 32) = 0;
  *(_BYTE *)(a1 + 40) = 0;
  *(_DWORD *)(a1 + 44) = 0;
  *(_DWORD *)(a1 + 3464) = 0;
  *(_BYTE *)(a1 + 3468) = 0;
  *(_QWORD *)(a1 + 3472) = 0;
  *(_WORD *)(a1 + 3488) = 0;
  *(_DWORD *)(a1 + 3456) = -1;
  *(_WORD *)(a1 + 3460) = 256;
  *(_BYTE *)(a1 + 3053) = 16;
  return a1;
}


// ==== sub_7FF91E01D3A0 @ rva 0x3BD3A0 ====
__int64 __fastcall sub_7FF91E01D3A0(unsigned __int8 *a1)
{
  unsigned __int8 *v2; // rbx
  __int64 v3; // rdi
  __int64 v4; // rdx
  __int64 result; // rax

  v2 = a1 + 806;
  v3 = 16;
  do
  {
    v4 = *v2;
    if ( (unsigned int)v4 < 0x80 )
    {
      (*(void (__fastcall **)(unsigned __int8 *, __int64, __int64))(*(_QWORD *)a1 + 8LL))(a1, v4, 64);
      result = (char)v2[1];
      a1[result + 3324] = 0x80;
      *v2 = 0x80;
    }
    v2 += 12;
    --v3;
  }
  while ( v3 );
  return result;
}


// ==== sub_7FF91E01D410 @ rva 0x3BD410 ====
__int64 __fastcall sub_7FF91E01D410(unsigned __int8 *a1)
{
  unsigned __int8 *v2; // rbx
  __int64 v3; // rdi
  __int64 v4; // rdx
  __int64 result; // rax

  v2 = a1 + 806;
  v3 = 16;
  do
  {
    v4 = *v2;
    if ( (unsigned int)v4 < 0x80 )
    {
      (*(void (__fastcall **)(unsigned __int8 *, __int64, __int64))(*(_QWORD *)a1 + 8LL))(a1, v4, 64);
      result = (char)v2[1];
      a1[result + 3324] = 0x80;
      *v2 = 0x80;
    }
    v2 += 12;
    --v3;
  }
  while ( v3 );
  return result;
}


// ==== sub_7FF91E01D480 @ rva 0x3BD480 ====
__int64 __fastcall sub_7FF91E01D480(char *a1, int a2)
{
  int v2; // edi
  unsigned __int8 *v5; // rbx
  __int64 v6; // rdx
  __int64 result; // rax

  v2 = 0;
  if ( a1[3054] > 0 )
  {
    v5 = (unsigned __int8 *)(a1 + 806);
    do
    {
      if ( *(_DWORD *)(v5 + 6) == a2 )
      {
        v6 = *v5;
        if ( (unsigned int)v6 < 0x80 )
        {
          (*(void (__fastcall **)(char *, __int64, __int64))(*(_QWORD *)a1 + 8LL))(a1, v6, 64);
          a1[(char)v5[1] + 3324] = 0x80;
          *v5 = 0x80;
        }
      }
      result = (unsigned int)a1[3054];
      ++v2;
      v5 += 12;
    }
    while ( v2 < (int)result );
  }
  return result;
}


// ==== sub_7FF91E01D540 @ rva 0x3BD540 ====
__int64 __fastcall sub_7FF91E01D540(__int64 a1, _BYTE *a2)
{
  _BYTE *v3; // rax
  __int64 v4; // r10
  _BYTE *v5; // r9
  __int64 v6; // r8
  __int64 v7; // rdx
  _BYTE *v8; // rcx
  __int64 v9; // r8
  __int64 v10; // rdx
  _BYTE *v11; // rcx
  __int64 v12; // r8
  __int64 v13; // rdx
  _BYTE *v14; // rcx
  __int64 v15; // r8
  __int64 v16; // rdx
  _BYTE *v17; // rcx
  __int64 v18; // r8
  __int64 v19; // rdx
  _BYTE *v20; // rcx
  __int64 v21; // r8
  __int64 v22; // rdx
  _BYTE *v23; // rcx
  __int64 v24; // r8
  __int64 v25; // rdx
  _BYTE *v26; // rcx
  __int64 v27; // r8
  __int64 v28; // rdx
  _BYTE *v29; // rcx
  int v30; // ebp
  __int64 v31; // r14
  int v32; // r15d
  int v33; // esi
  __int64 i; // r9
  unsigned __int8 v35; // r8
  unsigned __int8 v36; // al
  int v37; // r11d
  __int64 v38; // r10
  char *v39; // rax
  char v40; // r8
  char *v41; // rdx
  __int64 result; // rax

  if ( !a2 )
    sub_7FF91E01D540(a1, a1 + 804);
  v3 = a2 + 24;
  v4 = 2;
  v5 = a2 + 196;
  do
  {
    if ( *(v3 - 24) < 0x80u )
    {
      v6 = (char)a2[2251];
      v7 = 0;
      if ( v6 <= 0 )
      {
LABEL_9:
        *(v3 - 24) = 0x80;
      }
      else
      {
        v8 = v5 - 4;
        while ( (*v8 & 0x7F) == 0 )
        {
          ++v7;
          v8 += 64;
          if ( v7 >= v6 )
            goto LABEL_9;
        }
      }
    }
    if ( *(v3 - 12) < 0x80u )
    {
      v9 = (char)a2[2251];
      v10 = 0;
      if ( v9 <= 0 )
      {
LABEL_15:
        *(v3 - 12) = 0x80;
      }
      else
      {
        v11 = v5;
        while ( (*v11 & 0x7F) == 0 )
        {
          ++v10;
          v11 += 64;
          if ( v10 >= v9 )
            goto LABEL_15;
        }
      }
    }
    if ( *v3 < 0x80u )
    {
      v12 = (char)a2[2251];
      v13 = 0;
      if ( v12 <= 0 )
      {
LABEL_21:
        *v3 = 0x80;
      }
      else
      {
        v14 = v5 + 4;
        while ( (*v14 & 0x7F) == 0 )
        {
          ++v13;
          v14 += 64;
          if ( v13 >= v12 )
            goto LABEL_21;
        }
      }
    }
    if ( v3[12] < 0x80u )
    {
      v15 = (char)a2[2251];
      v16 = 0;
      if ( v15 <= 0 )
      {
LABEL_27:
        v3[12] = 0x80;
      }
      else
      {
        v17 = v5 + 8;
        while ( (*v17 & 0x7F) == 0 )
        {
          ++v16;
          v17 += 64;
          if ( v16 >= v15 )
            goto LABEL_27;
        }
      }
    }
    if ( v3[24] < 0x80u )
    {
      v18 = (char)a2[2251];
      v19 = 0;
      if ( v18 <= 0 )
      {
LABEL_33:
        v3[24] = 0x80;
      }
      else
      {
        v20 = v5 + 12;
        while ( (*v20 & 0x7F) == 0 )
        {
          ++v19;
          v20 += 64;
          if ( v19 >= v18 )
            goto LABEL_33;
        }
      }
    }
    if ( v3[36] < 0x80u )
    {
      v21 = (char)a2[2251];
      v22 = 0;
      if ( v21 <= 0 )
      {
LABEL_39:
        v3[36] = 0x80;
      }
      else
      {
        v23 = v5 + 16;
        while ( (*v23 & 0x7F) == 0 )
        {
          ++v22;
          v23 += 64;
          if ( v22 >= v21 )
            goto LABEL_39;
        }
      }
    }
    if ( v3[48] < 0x80u )
    {
      v24 = (char)a2[2251];
      v25 = 0;
      if ( v24 <= 0 )
      {
LABEL_45:
        v3[48] = 0x80;
      }
      else
      {
        v26 = v5 + 20;
        while ( (*v26 & 0x7F) == 0 )
        {
          ++v25;
          v26 += 64;
          if ( v25 >= v24 )
            goto LABEL_45;
        }
      }
    }
    if ( v3[60] < 0x80u )
    {
      v27 = (char)a2[2251];
      v28 = 0;
      if ( v27 <= 0 )
      {
LABEL_51:
        v3[60] = 0x80;
      }
      else
      {
        v29 = v5 + 24;
        while ( (*v29 & 0x7F) == 0 )
        {
          ++v28;
          v29 += 64;
          if ( v28 >= v27 )
            goto LABEL_51;
        }
      }
    }
    v5 += 32;
    v3 += 96;
    --v4;
  }
  while ( v4 );
  v30 = 8;
  do
  {
    v31 = v30;
    if ( v30 < 16LL )
    {
      v32 = 0;
      do
      {
        v33 = v32;
        for ( i = v31 - v30; v33 >= 0; v33 -= v30 )
        {
          v35 = a2[12 * i];
          v36 = a2[12 * v30 + 12 * i];
          if ( v35 <= v36 )
            break;
          a2[12 * i] = v36;
          v37 = 0;
          a2[12 * v30 + 12 * i] = v35;
          if ( (char)a2[2251] > 0 )
          {
            v38 = 48;
            v39 = &a2[4 * i + 192];
            do
            {
              v40 = *v39;
              v39 += 64;
              v41 = &a2[4 * i + 4 * v30 + 4 * v38];
              ++v37;
              v38 += 16;
              *(v39 - 64) = *v41;
              *v41 = v40;
            }
            while ( v37 < (char)a2[2251] );
          }
          i -= v30;
        }
        ++v32;
        ++v31;
      }
      while ( v31 < 16 );
    }
    result = (unsigned int)(v30 / 2);
    v30 = result;
  }
  while ( (int)result > 0 );
  return result;
}


// ==== sub_7FF91E01D810 @ rva 0x3BD810 ====
__int64 __fastcall sub_7FF91E01D810(__int64 a1)
{
  int v1; // edx
  int v3; // ecx
  int v4; // ecx
  int v5; // ecx
  bool v6; // zf
  __int64 result; // rax
  int v8; // eax

  v1 = *(_DWORD *)(a1 + 48);
  if ( v1 )
    *(_DWORD *)(a1 + 48) = --v1;
  v3 = *(_DWORD *)(a1 + 44);
  if ( !v3 )
  {
    if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
      return result;
    goto LABEL_27;
  }
  v4 = v3 - 1;
  if ( !v4 )
  {
    if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
    {
LABEL_21:
      *(_DWORD *)(a1 + 44) = 0;
      return sub_7FF91E01D3A0((unsigned __int8 *)a1);
    }
    if ( v1 )
      return result;
LABEL_27:
    v8 = *(_DWORD *)(a1 + 24) + 1;
    *(_QWORD *)(a1 + 60) = -1;
    *(_DWORD *)(a1 + 3048) = v8;
    result = 0;
    *(_QWORD *)(a1 + 52) = 0;
    *(_DWORD *)(a1 + 3056) = -1;
LABEL_28:
    *(_DWORD *)(a1 + 44) = 2;
    return result;
  }
  v5 = v4 - 1;
  if ( v5 )
  {
    if ( v5 != 1 )
      return result;
    if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
    {
      if ( !*(_DWORD *)(a1 + 604) )
      {
        *(_DWORD *)(a1 + 604) = -1;
        return result;
      }
      goto LABEL_21;
    }
    goto LABEL_28;
  }
  if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
  {
    v6 = *(_BYTE *)(a1 + 608) == 0;
    result = *(unsigned int *)(a1 + 600);
    *(_DWORD *)(a1 + 604) = result;
    if ( v6 )
      result = sub_7FF91E01D3A0((unsigned __int8 *)a1);
    *(_DWORD *)(a1 + 44) = 3;
  }
  return result;
}


// ==== sub_7FF91E01D960 @ rva 0x3BD960 ====
__int64 __fastcall sub_7FF91E01D960(__int64 a1)
{
  int v2; // ecx
  int v3; // ecx
  int v4; // ecx
  bool v5; // zf
  __int64 result; // rax
  int v7; // eax

  v2 = *(_DWORD *)(a1 + 44);
  if ( !v2 )
  {
    if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
      return result;
    goto LABEL_25;
  }
  v3 = v2 - 1;
  if ( !v3 )
  {
    if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
    {
LABEL_19:
      *(_DWORD *)(a1 + 44) = 0;
      return sub_7FF91E01D3A0((unsigned __int8 *)a1);
    }
    if ( *(_DWORD *)(a1 + 48) )
      return result;
LABEL_25:
    v7 = *(_DWORD *)(a1 + 24) + 1;
    *(_QWORD *)(a1 + 60) = -1;
    *(_DWORD *)(a1 + 3048) = v7;
    result = 0;
    *(_QWORD *)(a1 + 52) = 0;
    *(_DWORD *)(a1 + 3056) = -1;
LABEL_26:
    *(_DWORD *)(a1 + 44) = 2;
    return result;
  }
  v4 = v3 - 1;
  if ( v4 )
  {
    if ( v4 != 1 )
      return result;
    if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
    {
      if ( !*(_DWORD *)(a1 + 604) )
      {
        *(_DWORD *)(a1 + 604) = -1;
        return result;
      }
      goto LABEL_19;
    }
    goto LABEL_26;
  }
  if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
  {
    v5 = *(_BYTE *)(a1 + 608) == 0;
    result = *(unsigned int *)(a1 + 600);
    *(_DWORD *)(a1 + 604) = result;
    if ( v5 )
      result = sub_7FF91E01D3A0((unsigned __int8 *)a1);
    *(_DWORD *)(a1 + 44) = 3;
  }
  return result;
}


// ==== sub_7FF91E01DAA0 @ rva 0x3BDAA0 ====
_BYTE *__fastcall sub_7FF91E01DAA0(__int64 a1)
{
  _BYTE *result; // rax
  __int64 v3; // rdx
  _WORD *v4; // rcx

  if ( (unsigned int)(*(_DWORD *)(a1 + 44) - 1) <= 2 )
  {
    *(_DWORD *)(a1 + 44) = 0;
    sub_7FF91E01D3A0((unsigned __int8 *)a1);
  }
  result = (_BYTE *)(a1 + 3192);
  v3 = 4;
  v4 = (_WORD *)(a1 + 210);
  do
  {
    *(v4 - 1) = 0;
    *(result - 128) = -1;
    *result = 0;
    memset(result + 132, 128, 21);
    *v4 = 0;
    *(result - 127) = -1;
    result[1] = 0;
    v4[1] = 0;
    *(result - 126) = -1;
    result[2] = 0;
    v4[2] = 0;
    *(result - 125) = -1;
    result[3] = 0;
    v4[3] = 0;
    *(result - 124) = -1;
    result[4] = 0;
    v4[4] = 0;
    *(result - 123) = -1;
    result[5] = 0;
    v4[5] = 0;
    *(result - 122) = -1;
    result[6] = 0;
    v4[6] = 0;
    *(result - 121) = -1;
    result[7] = 0;
    v4[7] = 0;
    *(result - 120) = -1;
    result[8] = 0;
    v4[8] = 0;
    *(result - 119) = -1;
    result[9] = 0;
    v4[9] = 0;
    *(result - 118) = -1;
    result[10] = 0;
    v4[10] = 0;
    *(result - 117) = -1;
    result[11] = 0;
    v4[11] = 0;
    *(result - 116) = -1;
    result[12] = 0;
    v4[12] = 0;
    *(result - 115) = -1;
    result[13] = 0;
    v4[13] = 0;
    *(result - 114) = -1;
    result[14] = 0;
    v4[14] = 0;
    *(result - 113) = -1;
    result[15] = 0;
    v4[15] = 0;
    *(result - 112) = -1;
    result[16] = 0;
    v4[16] = 0;
    *(result - 111) = -1;
    result[17] = 0;
    v4[17] = 0;
    *(result - 110) = -1;
    result[18] = 0;
    v4[18] = 0;
    *(result - 109) = -1;
    result[19] = 0;
    v4[19] = 0;
    *(result - 108) = -1;
    v4 += 32;
    result[20] = 0;
    result += 32;
    *(v4 - 12) = 0;
    *(result - 139) = -1;
    *(result - 11) = 0;
    result[121] = 0x80;
    *(v4 - 11) = 0;
    *(result - 138) = -1;
    *(result - 10) = 0;
    result[122] = 0x80;
    *(v4 - 10) = 0;
    *(result - 137) = -1;
    *(result - 9) = 0;
    result[123] = 0x80;
    *(v4 - 9) = 0;
    *(result - 136) = -1;
    *(result - 8) = 0;
    result[124] = 0x80;
    *(v4 - 8) = 0;
    *(result - 135) = -1;
    *(result - 7) = 0;
    result[125] = 0x80;
    *(v4 - 7) = 0;
    *(result - 134) = -1;
    *(result - 6) = 0;
    result[126] = 0x80;
    *(v4 - 6) = 0;
    *(result - 133) = -1;
    *(result - 5) = 0;
    result[127] = 0x80;
    *(v4 - 5) = 0;
    *(result - 132) = -1;
    *(result - 4) = 0;
    result[128] = 0x80;
    *(v4 - 4) = 0;
    *(result - 131) = -1;
    *(result - 3) = 0;
    result[129] = 0x80;
    *(v4 - 3) = 0;
    *(result - 130) = -1;
    *(result - 2) = 0;
    result[130] = 0x80;
    *(v4 - 2) = 0;
    *(result - 129) = -1;
    *(result - 1) = 0;
    result[131] = 0x80;
    --v3;
  }
  while ( v3 );
  *(_QWORD *)(a1 + 200) = 0;
  *(_DWORD *)(a1 + 592) = 0;
  *(_DWORD *)(a1 + 3320) = 0;
  *(_BYTE *)(a1 + 3452) = -1;
  return result;
}


// ==== sub_7FF91E01DD80 @ rva 0x3BDD80 ====
_BYTE *__fastcall sub_7FF91E01DD80(__int64 a1, _BYTE *a2)
{
  _BYTE *result; // rax
  __int64 v3; // rcx

  *a2 = 0x80;
  result = a2 + 192;
  a2[2] = 0x80;
  v3 = 32;
  a2[12] = 0x80;
  a2[14] = 0x80;
  a2[24] = 0x80;
  a2[26] = 0x80;
  a2[36] = 0x80;
  a2[38] = 0x80;
  a2[48] = 0x80;
  a2[50] = 0x80;
  a2[60] = 0x80;
  a2[62] = 0x80;
  a2[72] = 0x80;
  a2[74] = 0x80;
  a2[84] = 0x80;
  a2[86] = 0x80;
  a2[96] = 0x80;
  a2[98] = 0x80;
  a2[108] = 0x80;
  a2[110] = 0x80;
  a2[120] = 0x80;
  a2[122] = 0x80;
  a2[132] = 0x80;
  a2[134] = 0x80;
  a2[144] = 0x80;
  a2[146] = 0x80;
  a2[156] = 0x80;
  a2[158] = 0x80;
  a2[168] = 0x80;
  a2[170] = 0x80;
  a2[180] = 0x80;
  a2[182] = 0x80;
  do
  {
    *result = 0;
    result[4] = 0;
    result[8] = 0;
    result[12] = 0;
    result[16] = 0;
    result[20] = 0;
    result[24] = 0;
    result[28] = 0;
    result[32] = 0;
    result[36] = 0;
    result[40] = 0;
    result[44] = 0;
    result[48] = 0;
    result[52] = 0;
    result[56] = 0;
    result[60] = 0;
    result += 64;
    --v3;
  }
  while ( v3 );
  a2[2256] = 60;
  return result;
}


// ==== nullsub_1040 @ rva 0x3BDE90 ====
void nullsub_1040()
{
  ;
}


// ==== sub_7FF91E01DEA0 @ rva 0x3BDEA0 ====
void __fastcall sub_7FF91E01DEA0(__int64 a1)
{
  int v1; // edx
  int v3; // ecx
  int v4; // ecx
  int v5; // ecx
  int v6; // eax
  int v7; // ecx
  bool v8; // cc
  int v9; // eax
  int v10; // ebp
  int v11; // esi
  unsigned __int8 *v12; // rdi
  __int64 v13; // rdx
  int v14; // ebp
  unsigned __int8 *v15; // rdi
  __int64 v16; // rsi
  __int64 v17; // rdx
  __int64 v18; // rdx

  v1 = *(_DWORD *)(a1 + 48);
  if ( v1 )
    *(_DWORD *)(a1 + 48) = --v1;
  v3 = *(_DWORD *)(a1 + 44);
  if ( !v3 )
  {
    if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
      goto LABEL_29;
    goto LABEL_27;
  }
  v4 = v3 - 1;
  if ( !v4 )
  {
    if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
    {
LABEL_21:
      *(_DWORD *)(a1 + 44) = 0;
      sub_7FF91E01D3A0((unsigned __int8 *)a1);
      goto LABEL_29;
    }
    if ( v1 )
      goto LABEL_29;
LABEL_27:
    v6 = *(_DWORD *)(a1 + 24) + 1;
    *(_QWORD *)(a1 + 60) = -1;
    *(_DWORD *)(a1 + 3048) = v6;
    *(_QWORD *)(a1 + 52) = 0;
    *(_DWORD *)(a1 + 3056) = -1;
LABEL_28:
    *(_DWORD *)(a1 + 44) = 2;
    goto LABEL_29;
  }
  v5 = v4 - 1;
  if ( v5 )
  {
    if ( v5 != 1 )
      goto LABEL_29;
    if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
    {
      if ( !*(_DWORD *)(a1 + 604) )
      {
        *(_DWORD *)(a1 + 604) = -1;
        goto LABEL_29;
      }
      goto LABEL_21;
    }
    goto LABEL_28;
  }
  if ( !*(_DWORD *)(a1 + 3320) && !*(_WORD *)(a1 + 592) && !*(_DWORD *)(a1 + 204) )
  {
    *(_DWORD *)(a1 + 604) = *(_DWORD *)(a1 + 600);
    if ( !*(_BYTE *)(a1 + 608) )
      sub_7FF91E01D3A0((unsigned __int8 *)a1);
    *(_DWORD *)(a1 + 44) = 3;
  }
LABEL_29:
  if ( *(_BYTE *)(a1 + 197) )
  {
    v7 = *(_DWORD *)(a1 + 20) + 1;
    v8 = *(_DWORD *)(a1 + 44) < 2;
    *(_DWORD *)(a1 + 20) = v7;
    if ( v8 )
    {
      *(_DWORD *)(a1 + 24) = v7;
    }
    else
    {
      v9 = *(_DWORD *)(a1 + 24);
      if ( v7 != v9 )
      {
        do
        {
          v10 = v9 + 1;
          v11 = 0;
          *(_DWORD *)(a1 + 24) = v9 + 1;
          if ( *(char *)(a1 + 3054) > 0 )
          {
            v12 = (unsigned __int8 *)(a1 + 806);
            do
            {
              if ( *(_DWORD *)(v12 + 6) == v10 )
              {
                v13 = *v12;
                if ( (unsigned int)v13 < 0x80 )
                {
                  (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)a1 + 8LL))(a1, v13, 64);
                  *(_BYTE *)((char)v12[1] + a1 + 3324) = 0x80;
                  *v12 = 0x80;
                }
              }
              ++v11;
              v12 += 12;
            }
            while ( v11 < *(char *)(a1 + 3054) );
          }
          if ( *(_DWORD *)(a1 + 24) == *(_DWORD *)(a1 + 3048) )
          {
            if ( *(_BYTE *)(a1 + 40) )
            {
              v14 = *(_DWORD *)(a1 + 44);
              if ( (unsigned int)(v14 - 1) <= 2 )
              {
                *(_DWORD *)(a1 + 44) = 0;
                v15 = (unsigned __int8 *)(a1 + 806);
                v16 = 16;
                do
                {
                  v17 = *v15;
                  if ( (unsigned int)v17 < 0x80 )
                  {
                    (*(void (__fastcall **)(__int64, __int64, __int64))(*(_QWORD *)a1 + 8LL))(a1, v17, 64);
                    *(_BYTE *)((char)v15[1] + a1 + 3324) = 0x80;
                    *v15 = 0x80;
                  }
                  v15 += 12;
                  --v16;
                }
                while ( v16 );
              }
              v18 = *(_QWORD *)(a1 + 32);
              *(_DWORD *)(a1 + 44) = v14;
              sub_7FF91E01F9F0(a1, v18, a1 + 804);
              sub_7FF91E01FED0(a1, 0);
              *(_BYTE *)(a1 + 40) = 0;
            }
            if ( *(_BYTE *)(a1 + 3489) )
              sub_7FF91E0204E0(a1);
            else
              sub_7FF91E020260(a1);
          }
          v9 = *(_DWORD *)(a1 + 24);
        }
        while ( *(_DWORD *)(a1 + 20) != v9 );
      }
    }
  }
}


// ==== nullsub_1041 @ rva 0x3BE160 ====
void nullsub_1041()
{
  ;
}


// ==== sub_7FF91E01E190 @ rva 0x3BE190 ====
__int64 __fastcall sub_7FF91E01E190(_DWORD *a1)
{
  __int64 result; // rax
  unsigned __int8 *v3; // rbx
  __int64 v4; // rdi
  __int64 v5; // rdx

  result = (unsigned int)(a1[11] - 1);
  if ( (unsigned int)result <= 2 )
  {
    v3 = (unsigned __int8 *)a1 + 806;
    v4 = 16;
    a1[11] = 0;
    do
    {
      v5 = *v3;
      if ( (unsigned int)v5 < 0x80 )
      {
        (*(void (__fastcall **)(_DWORD *, __int64, __int64))(*(_QWORD *)a1 + 8LL))(a1, v5, 64);
        result = (char)v3[1];
        *((_BYTE *)a1 + result + 3324) = 0x80;
        *v3 = 0x80;
      }
      v3 += 12;
      --v4;
    }
    while ( v4 );
  }
  return result;
}


// ==== sub_7FF91E01E250 @ rva 0x3BE250 ====
void __fastcall sub_7FF91E01E250(__int64 a1)
{
  int v1; // ebx
  __int16 *v3; // rdi
  bool v4; // zf
  __int16 v5; // ax

  v1 = 0;
  *(_WORD *)(a1 + 592) = 0;
  if ( *(_WORD *)(a1 + 594) )
  {
    v3 = (__int16 *)(a1 + 208);
    *(_WORD *)(a1 + 594) = 0;
    *(_DWORD *)(a1 + 204) = 0;
    do
    {
      v4 = *v3 == 0;
      if ( *v3 < 0 )
      {
        v5 = *v3 & 0x7FFF;
        *v3 = v5;
        if ( !v5 )
        {
          sub_7FF91E01F2A0(a1, (unsigned int)v1);
          v5 = *v3;
        }
        v4 = v5 == 0;
      }
      if ( !v4 )
        ++*(_DWORD *)(a1 + 204);
      ++v1;
      ++v3;
    }
    while ( v1 < 128 );
  }
}


// ==== sub_7FF91E01E2E0 @ rva 0x3BE2E0 ====
__int64 __fastcall sub_7FF91E01E2E0(__int64 a1)
{
  *(_WORD *)(a1 + 592) = 0x8000;
  return 0x8000;
}


// ==== sub_7FF91E01E2F0 @ rva 0x3BE2F0 ====
__int64 __fastcall sub_7FF91E01E2F0(__int64 a1)
{
  __int64 result; // rax

  *(_BYTE *)(a1 + 10) = 0;
  sub_7FF91E01DAA0(a1);
  *(_BYTE *)(a1 + 3488) = 1;
  *(_QWORD *)(a1 + 32) = 0;
  *(_BYTE *)(a1 + 40) = 0;
  *(_QWORD *)(a1 + 20) = 0;
  *(_DWORD *)(a1 + 44) = 0;
  *(_BYTE *)(a1 + 608) = 0;
  *(_BYTE *)(a1 + 3053) = 16;
  *(_DWORD *)(a1 + 3456) = -1;
  *(_DWORD *)(a1 + 600) = 1;
  *(_WORD *)(a1 + 196) = 256;
  sub_7FF91E01F8B0(a1, 0, 0);
  sub_7FF91E01F3D0(a1, 5, 2);
  *(_QWORD *)(a1 + 3472) = 0;
  *(_QWORD *)(a1 + 3480) = sub_7FF91E01EFC0;
  sub_7FF91E01DD80(a1, (_BYTE *)(a1 + 804));
  result = sub_7FF91E01FED0(a1, 0);
  *(_BYTE *)(a1 + 3488) = 0;
  return result;
}


// ==== sub_7FF91E01E3B0 @ rva 0x3BE3B0 ====
_BYTE *__fastcall sub_7FF91E01E3B0(__int64 a1, char a2)
{
  _BYTE *result; // rax

  if ( a2 != *(_BYTE *)(a1 + 10) )
  {
    if ( !a2 )
    {
      if ( (unsigned int)(*(_DWORD *)(a1 + 44) - 1) <= 2 )
      {
        *(_DWORD *)(a1 + 44) = 0;
        sub_7FF91E01D3A0((unsigned __int8 *)a1);
      }
      result = sub_7FF91E01DAA0(a1);
    }
    *(_BYTE *)(a1 + 10) = a2;
  }
  return result;
}


// ==== sub_7FF91E01E400 @ rva 0x3BE400 ====
__int64 __fastcall sub_7FF91E01E400(__int64 a1)
{
  __int64 v1; // r9
  int v3; // eax
  int v4; // ecx
  char v5; // r10
  __int64 v6; // rax
  int v7; // edx
  char v8; // dl
  __int64 result; // rax

  v1 = *(int *)(a1 + 3320);
  v3 = 0;
  if ( *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054) >= 0 )
    v3 = *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054);
  if ( *(_DWORD *)(a1 + 56) > 2 * v3 - 1 )
    *(_DWORD *)(a1 + 56) = 0;
  v4 = *(_DWORD *)(a1 + 3464);
  if ( v4 > 2 * (int)v1 - 2 )
  {
    *(_BYTE *)(a1 + 3468) = 1;
    v4 = (int)v1 > 1;
    *(_DWORD *)(a1 + 3464) = v4;
  }
  if ( v4 < 0 )
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v4 = 0;
  }
  v5 = *(_BYTE *)(a1 + 3460);
  if ( v4 > (int)v1 - 1 )
  {
    if ( v5 )
    {
      v7 = 2 * v1 - v4 - 2;
    }
    else
    {
      *(_DWORD *)(a1 + 3464) = 0;
      v7 = 0;
      v4 = 0;
    }
    v6 = v7;
  }
  else
  {
    if ( !v5 )
    {
      *(_DWORD *)(a1 + 3464) = 0;
      v4 = 0;
    }
    v6 = v4;
  }
  v8 = *(_BYTE *)(v6 + a1 + 3064);
  result = (unsigned int)v8;
  if ( v8 < 0 )
    result = (unsigned int)*(char *)(v1 + a1 + 3063);
  if ( !v5 )
    *(_BYTE *)(a1 + 3460) = 1;
  *(_DWORD *)(a1 + 3464) = v4 + 1;
  return result;
}


// ==== sub_7FF91E01E4E0 @ rva 0x3BE4E0 ====
__int64 __fastcall sub_7FF91E01E4E0(__int64 a1, int a2)
{
  __int64 v2; // r9
  int v3; // r11d
  int v4; // ebx
  int v5; // r8d
  __int64 result; // rax

  v2 = *(int *)(a1 + 3320);
  v3 = 0;
  v4 = *(char *)(a1 + 3054);
  v5 = *(_DWORD *)(a1 + 56);
  if ( *(_DWORD *)(a1 + 3320) - v4 >= 0 )
    v3 = *(_DWORD *)(a1 + 3320) - v4;
  if ( v5 > 2 * v3 - 1 )
  {
    *(_DWORD *)(a1 + 56) = 0;
    v5 = 0;
  }
  if ( a2 == v4 - 1 )
  {
    a2 = v2 - 1;
  }
  else if ( a2 )
  {
    if ( v5 > v3 )
      v5 = 2 * v3 - v5;
    a2 += v5;
  }
  result = (unsigned int)*(char *)(a2 + a1 + 3064);
  if ( (int)result < 0 )
    return (unsigned int)*(char *)(v2 + a1 + 3063);
  return result;
}


// ==== sub_7FF91E01E560 @ rva 0x3BE560 ====
__int64 __fastcall sub_7FF91E01E560(__int64 a1, int a2)
{
  int v2; // r9d
  __int64 v3; // r10
  int v5; // edx
  __int64 result; // rax

  v2 = 0;
  v3 = *(int *)(a1 + 3320);
  v5 = *(_DWORD *)(a1 + 56);
  if ( *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054) >= 0 )
    v2 = *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054);
  if ( v5 > 2 * v2 - 1 )
  {
    *(_DWORD *)(a1 + 56) = 0;
    v5 = 0;
  }
  if ( v5 > v2 )
    v5 = 2 * v2 - v5;
  result = (unsigned int)*(char *)(a2 + v5 + a1 + 3064);
  if ( (int)result < 0 )
    return (unsigned int)*(char *)(v3 + a1 + 3063);
  return result;
}


// ==== sub_7FF91E01E5C0 @ rva 0x3BE5C0 ====
__int64 __fastcall sub_7FF91E01E5C0(__int64 a1)
{
  __int64 v1; // rbx
  int v2; // eax
  int v3; // r10d
  bool v4; // sf
  int v5; // edx
  int v6; // eax
  char v7; // r11
  int v8; // r9d
  int v9; // eax
  int v10; // edx
  bool v11; // zf
  __int64 result; // rax

  v1 = *(int *)(a1 + 3320);
  v2 = *(char *)(a1 + 3054);
  v3 = v1 * (*(_DWORD *)(a1 + 3476) + 1) - 1;
  v4 = (int)v1 - v2 < 0;
  v5 = v1 - v2;
  v6 = 0;
  if ( !v4 )
    v6 = v5;
  if ( *(_DWORD *)(a1 + 56) > v6 )
    *(_DWORD *)(a1 + 56) = 0;
  v7 = *(_BYTE *)(a1 + 3460);
  if ( v7 )
  {
    v8 = *(_DWORD *)(a1 + 3464);
    v9 = v8;
  }
  else
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v8 = 0;
    *(_BYTE *)(a1 + 3461) = 1;
    v9 = 0;
  }
  if ( v8 > v3 )
  {
    do
    {
      v8 = v9 - 1;
      v9 = v8;
    }
    while ( v8 > v3 );
    *(_DWORD *)(a1 + 3464) = v8;
  }
  if ( v8 < 0 )
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v8 = 0;
  }
  v10 = *(char *)(v8 % (int)v1 + a1 + 3064);
  *(_DWORD *)(a1 + 3472) = v8 / (int)v1;
  if ( v10 < 0 )
    v10 = *(char *)(v1 + a1 + 3063);
  if ( !v7 )
    *(_BYTE *)(a1 + 3460) = 1;
  v11 = *(_BYTE *)(a1 + 3461) == 0;
  *(_BYTE *)(a1 + 3468) = 0;
  if ( v11 )
  {
    *(_DWORD *)(a1 + 3464) = v8 - 1;
    result = (unsigned int)v10;
    if ( v8 - 1 <= 0 )
      *(_BYTE *)(a1 + 3461) = 1;
  }
  else
  {
    result = (unsigned int)v10;
    *(_DWORD *)(a1 + 3464) = v8 + 1;
    if ( v8 + 1 >= v3 )
      *(_BYTE *)(a1 + 3461) = 0;
  }
  return result;
}


// ==== sub_7FF91E01E6E0 @ rva 0x3BE6E0 ====
__int64 __fastcall sub_7FF91E01E6E0(__int64 a1)
{
  int v1; // eax
  __int64 v3; // r9
  int v4; // ecx
  bool v5; // sf
  int v6; // edx
  int v7; // eax
  int v8; // edx
  char v9; // r10
  __int64 result; // rax

  v1 = *(char *)(a1 + 3054);
  v3 = *(int *)(a1 + 3320);
  v4 = 0;
  v5 = (int)v3 - v1 < 0;
  v6 = v3 - v1;
  v7 = 0;
  if ( !v5 )
    v7 = v6;
  if ( *(_DWORD *)(a1 + 56) > v7 )
    *(_DWORD *)(a1 + 56) = 0;
  v8 = *(_DWORD *)(a1 + 3464);
  if ( v8 > (int)v3 - 1 )
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v8 = 0;
    *(_BYTE *)(a1 + 3468) = 1;
  }
  if ( v8 < 0 )
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v8 = 0;
  }
  v9 = *(_BYTE *)(a1 + 3460);
  if ( v9 )
  {
    v4 = v3 - v8 - 1;
  }
  else
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v8 = 0;
  }
  result = (unsigned int)*(char *)(v4 + a1 + 3064);
  if ( (int)result < 0 )
    result = (unsigned int)*(char *)(v3 + a1 + 3063);
  if ( !v9 )
    *(_BYTE *)(a1 + 3460) = 1;
  *(_DWORD *)(a1 + 3464) = v8 + 1;
  return result;
}


// ==== sub_7FF91E01E790 @ rva 0x3BE790 ====
__int64 __fastcall sub_7FF91E01E790(__int64 a1, int a2)
{
  __int64 v2; // r9
  int v3; // r8d
  int v4; // r11d
  int v5; // r10d
  __int64 result; // rax

  v2 = *(int *)(a1 + 3320);
  v3 = 0;
  v4 = *(char *)(a1 + 3054);
  v5 = *(_DWORD *)(a1 + 56);
  if ( *(_DWORD *)(a1 + 3320) - v4 >= 0 )
    v3 = *(_DWORD *)(a1 + 3320) - v4;
  if ( v5 > v3 )
  {
    *(_DWORD *)(a1 + 56) = 0;
    v5 = 0;
  }
  if ( a2 == v4 - 1 )
  {
    a2 = v2 - 1;
  }
  else if ( a2 )
  {
    a2 += v3 - v5;
  }
  result = (unsigned int)*(char *)(a2 + a1 + 3064);
  if ( (int)result < 0 )
    return (unsigned int)*(char *)(v2 + a1 + 3063);
  return result;
}


// ==== sub_7FF91E01E800 @ rva 0x3BE800 ====
__int64 __fastcall sub_7FF91E01E800(__int64 a1, int a2)
{
  __int64 v2; // r9
  int v3; // eax
  int v4; // r8d
  __int64 result; // rax

  v2 = *(int *)(a1 + 3320);
  v3 = 0;
  if ( *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054) >= 0 )
    v3 = *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054);
  v4 = *(_DWORD *)(a1 + 56);
  if ( v4 > v3 )
  {
    *(_DWORD *)(a1 + 56) = 0;
    v4 = 0;
  }
  result = (unsigned int)*(char *)(a2 + v3 - v4 + a1 + 3064);
  if ( (int)result < 0 )
    return (unsigned int)*(char *)(v2 + a1 + 3063);
  return result;
}


// ==== sub_7FF91E01E850 @ rva 0x3BE850 ====
__int64 __fastcall sub_7FF91E01E850(__int64 a1)
{
  __int64 v1; // rbx
  int v3; // eax
  int v4; // r10d
  bool v5; // sf
  int v6; // edx
  int v7; // eax
  char v8; // r11
  int v9; // r8d
  int v10; // eax
  int v11; // edx
  int v12; // ecx
  __int64 result; // rax

  v1 = *(int *)(a1 + 3320);
  v3 = *(char *)(a1 + 3054);
  v4 = v1 * (*(_DWORD *)(a1 + 3476) + 1) - 1;
  v5 = (int)v1 - v3 < 0;
  v6 = v1 - v3;
  v7 = 0;
  if ( !v5 )
    v7 = v6;
  if ( *(_DWORD *)(a1 + 56) > v7 )
    *(_DWORD *)(a1 + 56) = 0;
  v8 = *(_BYTE *)(a1 + 3460);
  if ( v8 )
  {
    v9 = *(_DWORD *)(a1 + 3464);
    v10 = v9;
  }
  else
  {
    *(_DWORD *)(a1 + 3464) = v4;
    v9 = v4;
    v10 = v4;
  }
  if ( v9 > v4 )
  {
    do
    {
      v9 = v10 - 1;
      v10 = v9;
    }
    while ( v9 > v4 );
    *(_DWORD *)(a1 + 3464) = v9;
  }
  if ( v9 < 0 )
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v9 = 0;
  }
  v11 = *(char *)(v9 % (int)v1 + a1 + 3064);
  *(_DWORD *)(a1 + 3472) = v9 / (int)v1;
  if ( v11 < 0 )
    v11 = *(char *)(v1 + a1 + 3063);
  if ( !v8 )
    *(_BYTE *)(a1 + 3460) = 1;
  v12 = v9 - 1;
  *(_BYTE *)(a1 + 3468) = 0;
  result = (unsigned int)v11;
  if ( v9 - 1 < 0 )
    v12 = v4;
  *(_DWORD *)(a1 + 3464) = v12;
  return result;
}


// ==== sub_7FF91E01E940 @ rva 0x3BE940 ====
__int64 __fastcall sub_7FF91E01E940(__int64 a1, int a2)
{
  int v2; // r8d

  if ( !a2 )
    return (unsigned int)*(char *)(a1 + 3064);
  v2 = a2 + *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054);
  if ( v2 < 0 )
    v2 = 0;
  return (unsigned int)*(char *)(v2 + a1 + 3064);
}


// ==== sub_7FF91E01E990 @ rva 0x3BE990 ====
__int64 __fastcall sub_7FF91E01E990(__int64 a1)
{
  int v1; // r8d
  __int64 v2; // r10
  int v3; // eax
  int v4; // eax
  int v5; // ebx
  __int64 v6; // r9
  int v7; // r11d
  int v8; // edx
  __int64 result; // rax

  v1 = 0;
  v2 = *(int *)(a1 + 3320);
  v3 = 0;
  if ( *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054) >= 0 )
    v3 = *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054);
  if ( *(_DWORD *)(a1 + 56) > 2 * v3 - 1 )
    *(_DWORD *)(a1 + 56) = 0;
  v4 = *(_DWORD *)(a1 + 3464);
  if ( *(_BYTE *)(a1 + 3461) )
  {
    if ( v4 >= (int)v2 )
    {
      if ( *(_DWORD *)(a1 + 3472) == *(_DWORD *)(a1 + 3476) )
      {
        if ( (int)v2 <= 1 )
        {
          v4 = 0;
          *(_BYTE *)(a1 + 3468) = 1;
          *(_DWORD *)(a1 + 3464) = 0;
          *(_BYTE *)(a1 + 3461) = 0;
        }
        else
        {
          v4 = v2 - 2;
          *(_BYTE *)(a1 + 3461) = 0;
          *(_DWORD *)(a1 + 3464) = v2 - 2;
        }
        goto LABEL_19;
      }
      *(_DWORD *)(a1 + 3464) = 0;
      v4 = 0;
      goto LABEL_18;
    }
  }
  else if ( v4 < 0 )
  {
    if ( !*(_DWORD *)(a1 + 3472) )
    {
      if ( (int)v2 <= 1 )
      {
        v4 = 0;
        *(_BYTE *)(a1 + 3468) = 1;
        *(_DWORD *)(a1 + 3464) = 0;
        *(_BYTE *)(a1 + 3461) = 1;
      }
      else
      {
        v4 = 1;
        *(_BYTE *)(a1 + 3461) = 1;
        *(_DWORD *)(a1 + 3464) = 1;
      }
      goto LABEL_19;
    }
    v4 = v2 - 1;
    *(_DWORD *)(a1 + 3464) = v2 - 1;
LABEL_18:
    *(_BYTE *)(a1 + 3468) = 1;
  }
LABEL_19:
  v5 = -1;
  v6 = 0;
  v7 = -1;
  do
  {
    v8 = v4;
    if ( v1 >= (int)v2 )
      break;
    v7 = *(char *)(v6 + a1 + 3064);
    v4 = *(_DWORD *)(a1 + 3464);
    if ( v7 > -1 )
    {
      v8 = *(_DWORD *)(a1 + 3464);
      if ( v4 == v1 )
        break;
      ++v1;
    }
    ++v6;
    v8 = *(_DWORD *)(a1 + 3464);
  }
  while ( v6 < 128 );
  if ( v7 < 0 )
    v7 = *(char *)(v2 + a1 + 3063);
  if ( !*(_BYTE *)(a1 + 3460) )
    *(_BYTE *)(a1 + 3460) = 1;
  result = (unsigned int)v7;
  if ( *(_BYTE *)(a1 + 3461) )
    v5 = 1;
  *(_DWORD *)(a1 + 3464) = v8 + v5;
  return result;
}


// ==== sub_7FF91E01EB10 @ rva 0x3BEB10 ====
__int64 __fastcall sub_7FF91E01EB10(__int64 a1)
{
  int v1; // eax
  __int64 v3; // r11
  int v4; // ecx
  bool v5; // sf
  int v6; // edx
  int v7; // eax
  int v8; // eax
  int v9; // edx
  int v10; // r10d
  __int64 i; // r9
  int v12; // edx

  v1 = *(char *)(a1 + 3054);
  v3 = *(int *)(a1 + 3320);
  v4 = 0;
  v5 = (int)v3 - v1 < 0;
  v6 = v3 - v1;
  v7 = 0;
  if ( !v5 )
    v7 = v6;
  if ( *(_DWORD *)(a1 + 56) > v7 )
    *(_DWORD *)(a1 + 56) = 0;
  v8 = *(_DWORD *)(a1 + 3464);
  v9 = v3 - 1;
  if ( v8 > (int)v3 - 1 )
  {
    do
      --v8;
    while ( v8 > v9 );
    *(_DWORD *)(a1 + 3464) = v8;
  }
  if ( v8 < 0 )
  {
    *(_DWORD *)(a1 + 3464) = v9;
    v8 = v3 - 1;
    *(_BYTE *)(a1 + 3468) = 1;
  }
  v10 = -1;
  for ( i = 0; i < 128; ++i )
  {
    v12 = v8;
    if ( v4 >= (int)v3 )
      break;
    v10 = *(char *)(i + a1 + 3064);
    v8 = *(_DWORD *)(a1 + 3464);
    if ( v10 > -1 )
    {
      v12 = *(_DWORD *)(a1 + 3464);
      if ( v8 == v4 )
        break;
      ++v4;
    }
    v12 = *(_DWORD *)(a1 + 3464);
  }
  if ( v10 < 0 )
    v10 = *(char *)(v3 + a1 + 3063);
  if ( !*(_BYTE *)(a1 + 3460) )
    *(_BYTE *)(a1 + 3460) = 1;
  *(_DWORD *)(a1 + 3464) = v12 - 1;
  return (unsigned int)v10;
}


// ==== sub_7FF91E01EBF0 @ rva 0x3BEBF0 ====
__int64 __fastcall sub_7FF91E01EBF0(__int64 a1)
{
  unsigned __int16 v2; // ax
  __int64 v3; // rdx
  unsigned __int16 v4; // ax
  int v5; // r9d
  int v6; // r8d
  int v7; // eax
  __int64 v8; // rcx
  int v9; // edx

  v2 = sub_7FF91E020E50(a1 + 8, (unsigned __int16)(*(_WORD *)(a1 + 3476) + 1));
  v3 = *(unsigned __int16 *)(a1 + 3320);
  *(_DWORD *)(a1 + 3472) = v2;
  v4 = sub_7FF91E020E50(a1 + 8, v3);
  v5 = *(_DWORD *)(a1 + 3320);
  v6 = v4;
  v7 = 0;
  *(_DWORD *)(a1 + 3464) = v6;
  v8 = 0;
  v9 = -1;
  do
  {
    if ( v7 >= v5 )
      break;
    v9 = *(char *)(v8 + a1 + 3064);
    if ( v9 > -1 )
    {
      if ( v6 == v7 )
        return (unsigned int)v9;
      ++v7;
    }
    ++v8;
  }
  while ( v8 < 128 );
  return (unsigned int)v9;
}


// ==== sub_7FF91E01EC80 @ rva 0x3BEC80 ====
__int64 __fastcall sub_7FF91E01EC80(__int64 a1)
{
  __int64 v1; // r11
  int v3; // edx
  int v4; // ecx
  int v5; // eax
  int v6; // r10d
  __int64 i; // r9
  int v8; // edx

  v1 = *(int *)(a1 + 3320);
  v3 = *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054);
  v4 = 0;
  if ( *(_DWORD *)(a1 + 56) > v3 )
    *(_DWORD *)(a1 + 56) = 0;
  v5 = *(_DWORD *)(a1 + 3464);
  if ( v5 >= (int)v1 )
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v5 = 0;
    *(_BYTE *)(a1 + 3468) = 1;
  }
  v6 = -1;
  for ( i = 0; i < 128; ++i )
  {
    v8 = v5;
    if ( v4 >= (int)v1 )
      break;
    v6 = *(char *)(i + a1 + 3064);
    v5 = *(_DWORD *)(a1 + 3464);
    if ( v6 > -1 )
    {
      v8 = *(_DWORD *)(a1 + 3464);
      if ( v5 == v4 )
        break;
      ++v4;
    }
    v8 = *(_DWORD *)(a1 + 3464);
  }
  if ( v6 < 0 )
    v6 = *(char *)(v1 + a1 + 3063);
  if ( !*(_BYTE *)(a1 + 3460) )
    *(_BYTE *)(a1 + 3460) = 1;
  *(_DWORD *)(a1 + 3464) = v8 + 1;
  return (unsigned int)v6;
}


// ==== sub_7FF91E01ED30 @ rva 0x3BED30 ====
__int64 __fastcall sub_7FF91E01ED30(__int64 a1, int a2)
{
  __int64 result; // rax

  result = (unsigned int)*(char *)(a2 + a1 + 3064);
  if ( (int)result < 0 )
    return (unsigned int)*(char *)(*(int *)(a1 + 3320) + a1 + 3063);
  return result;
}


// ==== sub_7FF91E01ED50 @ rva 0x3BED50 ====
__int64 __fastcall sub_7FF91E01ED50(__int64 a1, int a2)
{
  char v2; // r10
  int v4; // r9d

  v2 = *(_BYTE *)(a1 + 3452);
  if ( v2 < 0 )
    return 0xFFFFFFFFLL;
  v4 = v2 + *(unsigned __int8 *)(a1 + 12 * (a2 + 67LL)) - *(unsigned __int8 *)(a1 + 3060);
  if ( !*(_BYTE *)(v4 + a1 + 3192) )
    *(_BYTE *)(v4 + a1 + 464) = *(_BYTE *)(v2 + a1 + 464);
  return (unsigned int)v4;
}


// ==== sub_7FF91E01EDB0 @ rva 0x3BEDB0 ====
__int64 __fastcall sub_7FF91E01EDB0(__int64 a1, int a2)
{
  int v3; // ecx
  __int64 v4; // rbp
  int v5; // eax
  int v6; // ecx
  int v7; // ecx
  int v8; // r14d
  int v9; // r12d
  int v10; // esi
  __int64 v11; // r15
  unsigned __int16 v12; // ax
  int v13; // edx
  int v14; // eax
  __int64 result; // rax

  v3 = *(_DWORD *)(a1 + 56);
  v4 = a2;
  if ( *(_DWORD *)(a1 + 60) != v3 || *(_DWORD *)(a1 + 64) != *(_DWORD *)(a1 + 3320) )
  {
    v5 = *(char *)(a1 + 3054);
    *(_DWORD *)(a1 + 60) = v3;
    v6 = *(_DWORD *)(a1 + 3320);
    *(_DWORD *)(a1 + 64) = v6;
    v7 = v6 - v5 + 1;
    v8 = 1;
    v9 = 1;
    *(_BYTE *)(a1 + 68) = 0;
    if ( *(char *)(a1 + 3054) > 1 )
    {
      v10 = 0;
      v11 = a1 + 69;
      if ( v7 >= 0 )
        v10 = v7;
      do
      {
        v12 = sub_7FF91E020E50(a1 + 8, (unsigned __int16)v10);
        v13 = v12 + v8 + 1;
        ++v11;
        v10 -= v12;
        ++v9;
        *(_BYTE *)(v11 - 1) = v12 + v8;
        v14 = *(_DWORD *)(a1 + 3320);
        v8 = v14 - 1;
        if ( v13 < v14 )
          v8 = v13;
      }
      while ( v9 < *(char *)(a1 + 3054) );
    }
  }
  if ( (_DWORD)v4 )
    LODWORD(v4) = *(char *)(v4 + a1 + 68);
  result = (unsigned int)*(char *)((int)v4 + a1 + 3064);
  if ( (int)result < 0 )
    return (unsigned int)*(char *)(*(int *)(a1 + 3320) + a1 + 3063);
  return result;
}


// ==== sub_7FF91E01EEC0 @ rva 0x3BEEC0 ====
__int64 __fastcall sub_7FF91E01EEC0(__int64 a1)
{
  unsigned int v2; // edi
  int v3; // eax
  __int16 v4; // ax
  int v6; // eax
  int v7; // ecx

  v2 = *(char *)((unsigned __int16)sub_7FF91E020E50(a1 + 8, *(unsigned __int16 *)(a1 + 3320)) + a1 + 3064);
  v3 = *(_DWORD *)(a1 + 3476);
  if ( v3 )
  {
    v4 = sub_7FF91E020E50(a1 + 8, (unsigned int)(v3 + 1));
    switch ( v4 )
    {
      case 1:
        v6 = -1;
        v7 = 1;
        break;
      case 2:
        v6 = -2;
        v7 = 2;
        break;
      case 3:
        v6 = -3;
        v7 = 3;
        break;
      case 4:
        v6 = -4;
        v7 = 4;
        break;
      default:
        *(_DWORD *)(a1 + 3472) = 0;
        return v2;
    }
    if ( *(int *)(a1 + 3476) > 0 )
      v6 = v7;
    *(_DWORD *)(a1 + 3472) = v6;
  }
  return v2;
}


// ==== sub_7FF91E01EF80 @ rva 0x3BEF80 ====
__int64 __fastcall sub_7FF91E01EF80(__int64 a1, int a2)
{
  __int64 result; // rax

  if ( a2 == *(char *)(a1 + 3054) - 1 )
    a2 = *(_DWORD *)(a1 + 3320) - 1;
  result = (unsigned int)*(char *)(a2 + a1 + 3064);
  if ( (int)result < 0 )
    return (unsigned int)*(char *)(*(int *)(a1 + 3320) + a1 + 3063);
  return result;
}


// ==== sub_7FF91E01EFC0 @ rva 0x3BEFC0 ====
__int64 __fastcall sub_7FF91E01EFC0(__int64 a1)
{
  __int64 v1; // r9
  int v3; // ecx
  char v4; // dl
  __int64 result; // rax

  v1 = *(int *)(a1 + 3320);
  if ( *(_DWORD *)(a1 + 56) > *(_DWORD *)(a1 + 3320) - *(char *)(a1 + 3054) )
    *(_DWORD *)(a1 + 56) = 0;
  v3 = *(_DWORD *)(a1 + 3464);
  if ( v3 > (int)v1 - 1 )
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v3 = 0;
    *(_BYTE *)(a1 + 3468) = 1;
  }
  if ( v3 < 0 )
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v3 = 0;
  }
  v4 = *(_BYTE *)(a1 + 3460);
  if ( !v4 )
  {
    *(_DWORD *)(a1 + 3464) = 0;
    v3 = 0;
  }
  result = (unsigned int)*(char *)(v3 + a1 + 3064);
  if ( (int)result < 0 )
    result = (unsigned int)*(char *)(v1 + a1 + 3063);
  if ( !v4 )
    *(_BYTE *)(a1 + 3460) = 1;
  *(_DWORD *)(a1 + 3464) = v3 + 1;
  return result;
}


// ==== sub_7FF91E01F060 @ rva 0x3BF060 ====
__int64 __fastcall sub_7FF91E01F060(__int64 a1, int a2)
{
  __int64 v2; // r9
  int v3; // r10d
  int v4; // r8d
  __int64 result; // rax

  v2 = *(int *)(a1 + 3320);
  v3 = *(char *)(a1 + 3054);
  v4 = *(_DWORD *)(a1 + 56);
  if ( v4 > *(_DWORD *)(a1 + 3320) - v3 )
  {
    v4 = 0;
    *(_DWORD *)(a1 + 56) = 0;
  }
  if ( a2 == v3 - 1 )
  {
    a2 = v2 - 1;
  }
  else if ( a2 )
  {
    a2 += v4;
  }
  result = (unsigned int)*(char *)(a2 + a1 + 3064);
  if ( (int)result < 0 )
    return (unsigned int)*(char *)(v2 + a1 + 3063);
  return result;
}


// ==== sub_7FF91E01F0C0 @ rva 0x3BF0C0 ====
__int64 __fastcall sub_7FF91E01F0C0(__int64 a1, int a2)
{
  __int64 v2; // r10
  int v4; // ecx
  __int64 result; // rax

  v2 = *(int *)(a1 + 3320);
  v4 = *(_DWORD *)(a1 + 56);
  if ( v4 > (int)v2 - *(char *)(a1 + 3054) )
  {
    v4 = 0;
    *(_DWORD *)(a1 + 56) = 0;
  }
  result = (unsigned int)*(char *)(v4 + a2 + a1 + 3064);
  if ( (int)result < 0 )
    return (unsigned int)*(char *)(v2 + a1 + 3063);
  return result;
}


// ==== sub_7FF91E01F110 @ rva 0x3BF110 ====
__int16 __fastcall sub_7FF91E01F110(__int64 a1, __int64 a2)
{
  __int64 v3; // rcx
  __int16 result; // ax
  __int16 v5; // ax
  int v6; // eax

  v3 = a1 + 2LL * (int)a2;
  result = *(_WORD *)(v3 + 208) & 0x7FFF;
  if ( result )
  {
    *(_WORD *)(v3 + 208) = *(_WORD *)(a1 + 592) | (result - 1);
    v5 = *(_WORD *)(a1 + 592);
    --*(_DWORD *)(a1 + 200);
    *(_WORD *)(a1 + 594) = v5;
    if ( !*(_WORD *)(v3 + 208) )
    {
      v6 = *(_DWORD *)(a1 + 204);
      if ( v6 )
        *(_DWORD *)(a1 + 204) = v6 - 1;
      sub_7FF91E01F2A0(a1, a2);
    }
    return *(unsigned __int8 *)(a1 + 596);
  }
  return result;
}


// ==== sub_7FF91E01F290 @ rva 0x3BF290 ====
// attributes: thunk
__int16 __fastcall sub_7FF91E01F290(__int64 a1, __int64 a2)
{
  return sub_7FF91E01F110(a1, a2);
}


// ==== sub_7FF91E01F2A0 @ rva 0x3BF2A0 ====
void __fastcall sub_7FF91E01F2A0(unsigned __int8 *a1, int a2)
{
  __int64 v2; // r9
  __int64 v3; // r8
  char v4; // r10
  unsigned __int8 *v5; // rdx
  int v6; // eax
  int v7; // r8d
  __int64 v8; // rdx
  __int64 v9; // rdx
  unsigned __int8 v10; // r8

  v2 = a2;
  if ( a1[a2 + 3192] )
  {
    if ( a1[3489] )
    {
      v7 = 0;
      v8 = 0;
      while ( (char)a1[v8 + 3064] != (_DWORD)v2 )
      {
        ++v7;
        if ( ++v8 >= 128 )
          goto LABEL_13;
      }
      a1[v7 + 3064] = -1;
      --*((_DWORD *)a1 + 830);
    }
    else
    {
      v3 = *((int *)a1 + 830);
      v4 = -1;
      *((_DWORD *)a1 + 830) = v3 - 1;
      if ( v3 - 1 >= 0 )
      {
        v5 = &a1[v3 + 3063];
        do
        {
          v6 = (char)*v5;
          *v5 = v4;
          v4 = v6;
          if ( v6 == (_DWORD)v2 )
            break;
          --v5;
        }
        while ( (__int64)&v5[-3064LL - (_QWORD)a1] >= 0 );
      }
    }
LABEL_13:
    a1[v2 + 3192] = 0;
    v9 = *((int *)a1 + 830);
    if ( (int)v9 <= 0 )
      v10 = -1;
    else
      v10 = a1[v9 + 3063];
    a1[3452] = v10;
    if ( (int)v9 <= 0 )
    {
      *((_DWORD *)a1 + 866) = 0;
      *((_DWORD *)a1 + 868) = 0;
      a1[3468] = 0;
      if ( !(_DWORD)v9
        && !*((_WORD *)a1 + 296)
        && !*((_DWORD *)a1 + 51)
        && (unsigned int)(*((_DWORD *)a1 + 11) - 1) <= 2 )
      {
        *((_DWORD *)a1 + 11) = 0;
        sub_7FF91E01D3A0(a1);
      }
    }
  }
}


// ==== sub_7FF91E01F3C0 @ rva 0x3BF3C0 ====
__int64 __fastcall sub_7FF91E01F3C0(__int64 a1, __int64 a2)
{
  return sub_7FF91E01F3D0(a1, a2, *(unsigned int *)(a1 + 16));
}


// ==== sub_7FF91E01F3D0 @ rva 0x3BF3D0 ====
__int64 __fastcall sub_7FF91E01F3D0(__int64 a1, int a2, int a3)
{
  int v3; // r10d
  __int64 v4; // r11
  int v5; // r9d
  int v6; // ebx
  __int16 v7; // si
  __int16 v8; // bp
  int v9; // edi
  int v10; // r14d
  unsigned __int16 v11; // ax
  unsigned __int16 v12; // r10
  int v13; // r9d
  int v14; // r8d
  char v15; // al
  __int16 v16; // ax
  char v17; // al
  bool v18; // zf
  int v19; // r8d
  char v20; // al
  __int16 v21; // ax
  int v22; // r8d
  char v23; // al
  int v24; // r8d
  char v25; // al
  __int16 v26; // ax
  int v27; // r8d
  char v28; // al
  int v29; // r8d
  char v30; // al
  __int16 v31; // ax
  char v32; // al
  int v33; // r8d
  char v34; // al
  __int16 v35; // ax
  int v36; // r8d
  char v37; // al
  int v38; // r8d
  char v39; // al
  __int16 v40; // ax
  int v41; // r8d
  char v42; // al
  int v43; // r8d
  char v44; // al
  __int16 v45; // ax
  int v46; // r8d
  char v47; // al
  int v48; // r8d
  char v49; // al
  __int16 v50; // ax
  char v51; // al

  v3 = 0;
  v4 = a1 + 610;
  v5 = 0;
  v6 = 1;
  if ( a2 >= 0 )
    v5 = a2;
  if ( v5 >= 10 )
    v5 = 9;
  *(_DWORD *)(a1 + 12) = v5;
  if ( a3 >= 0 )
    v3 = a3;
  if ( v3 >= 10 )
    v3 = 9;
  *(_DWORD *)(a1 + 16) = v3;
  *(_BYTE *)(a1 + 596) = v3 < 10;
  *(_BYTE *)(a1 + 597) = v3 >= 10;
  v7 = word_7FF91E6243B8[3 * v5];
  v8 = word_7FF91E6243BA[3 * v5];
  v9 = word_7FF91E6243BC[3 * v5];
  v10 = word_7FF91E6243F8[v3];
  do
  {
    v11 = v7;
    if ( (((_BYTE)v6 - 1) & 1) != 0 )
      v11 = v8;
    v12 = v11;
    *(_WORD *)v4 = v11;
    v13 = v10 * v11 / 100;
    *(_WORD *)(v4 + 2) = v13;
    *(_BYTE *)(v4 + 4) = (v6 - 1) % v9 != 0;
    v14 = v6 + 1;
    v15 = 127;
    if ( v6 != 1 )
      v15 = 100;
    *(_BYTE *)(v4 + 5) = v15;
    v16 = v7;
    if ( (v6 & 1) != 0 )
      v16 = v8;
    *(_WORD *)(v4 + 6) = v16;
    *(_WORD *)(v4 + 8) = (__int16)(v10 * v16) / 100;
    *(_BYTE *)(v4 + 10) = v6 % v9 != 0;
    v17 = 127;
    if ( v6 )
      v17 = 100;
    *(_BYTE *)(v4 + 11) = v17;
    *(_WORD *)(v4 + 12) = v12;
    *(_WORD *)(v4 + 14) = v13;
    v18 = v14 == 0;
    *(_BYTE *)(v4 + 16) = v14 % v9 != 0;
    v19 = v6 + 2;
    v20 = 127;
    if ( !v18 )
      v20 = 100;
    *(_BYTE *)(v4 + 17) = v20;
    v21 = v7;
    if ( (v19 & 1) != 0 )
      v21 = v8;
    *(_WORD *)(v4 + 18) = v21;
    *(_WORD *)(v4 + 20) = (__int16)(v10 * v21) / 100;
    *(_BYTE *)(v4 + 22) = v19 % v9 != 0;
    v18 = v19 == 0;
    v22 = v6 + 3;
    v23 = 127;
    if ( !v18 )
      v23 = 100;
    *(_BYTE *)(v4 + 23) = v23;
    *(_WORD *)(v4 + 24) = v12;
    *(_WORD *)(v4 + 26) = v13;
    v18 = v22 == 0;
    *(_BYTE *)(v4 + 28) = v22 % v9 != 0;
    v24 = v6 + 4;
    v25 = 127;
    if ( !v18 )
      v25 = 100;
    *(_BYTE *)(v4 + 29) = v25;
    v26 = v7;
    if ( (v24 & 1) != 0 )
      v26 = v8;
    *(_WORD *)(v4 + 30) = v26;
    *(_WORD *)(v4 + 32) = (__int16)(v10 * v26) / 100;
    v18 = v24 == 0;
    *(_BYTE *)(v4 + 34) = v24 % v9 != 0;
    v27 = v6 + 5;
    v28 = 127;
    if ( !v18 )
      v28 = 100;
    *(_BYTE *)(v4 + 35) = v28;
    *(_WORD *)(v4 + 36) = v12;
    *(_WORD *)(v4 + 38) = v13;
    v18 = v27 == 0;
    *(_BYTE *)(v4 + 40) = v27 % v9 != 0;
    v29 = v6 + 6;
    v30 = 127;
    if ( !v18 )
      v30 = 100;
    *(_BYTE *)(v4 + 41) = v30;
    v31 = v7;
    if ( (v29 & 1) != 0 )
      v31 = v8;
    *(_WORD *)(v4 + 42) = v31;
    *(_WORD *)(v4 + 44) = (__int16)(v10 * v31) / 100;
    *(_BYTE *)(v4 + 46) = v29 % v9 != 0;
    v32 = 127;
    if ( v6 != -6 )
      v32 = 100;
    *(_BYTE *)(v4 + 47) = v32;
    *(_WORD *)(v4 + 48) = v12;
    *(_WORD *)(v4 + 50) = v13;
    *(_BYTE *)(v4 + 52) = (v6 + 7) % v9 != 0;
    v33 = v6 + 8;
    v34 = 127;
    if ( v6 != -7 )
      v34 = 100;
    *(_BYTE *)(v4 + 53) = v34;
    v35 = v7;
    if ( (v33 & 1) != 0 )
      v35 = v8;
    *(_WORD *)(v4 + 54) = v35;
    *(_WORD *)(v4 + 56) = (__int16)(v10 * v35) / 100;
    v18 = v33 == 0;
    *(_BYTE *)(v4 + 58) = v33 % v9 != 0;
    v36 = v6 + 9;
    v37 = 127;
    if ( !v18 )
      v37 = 100;
    *(_BYTE *)(v4 + 59) = v37;
    *(_WORD *)(v4 + 60) = v12;
    *(_WORD *)(v4 + 62) = v13;
    v18 = v36 == 0;
    *(_BYTE *)(v4 + 64) = v36 % v9 != 0;
    v38 = v6 + 10;
    v39 = 127;
    if ( !v18 )
      v39 = 100;
    *(_BYTE *)(v4 + 65) = v39;
    v40 = v7;
    if ( (v38 & 1) != 0 )
      v40 = v8;
    *(_WORD *)(v4 + 66) = v40;
    *(_WORD *)(v4 + 68) = (__int16)(v10 * v40) / 100;
    v18 = v38 == 0;
    *(_BYTE *)(v4 + 70) = v38 % v9 != 0;
    v41 = v6 + 11;
    v42 = 127;
    if ( !v18 )
      v42 = 100;
    *(_BYTE *)(v4 + 71) = v42;
    *(_WORD *)(v4 + 72) = v12;
    *(_WORD *)(v4 + 74) = v13;
    *(_BYTE *)(v4 + 76) = v41 % v9 != 0;
    v18 = v41 == 0;
    v4 += 96;
    v43 = v6 + 12;
    v44 = 127;
    if ( !v18 )
      v44 = 100;
    *(_BYTE *)(v4 - 19) = v44;
    v45 = v7;
    if ( (v43 & 1) != 0 )
      v45 = v8;
    *(_WORD *)(v4 - 18) = v45;
    *(_WORD *)(v4 - 16) = (__int16)(v10 * v45) / 100;
    v18 = v43 == 0;
    *(_BYTE *)(v4 - 14) = v43 % v9 != 0;
    v46 = v6 + 13;
    v47 = 127;
    if ( !v18 )
      v47 = 100;
    *(_BYTE *)(v4 - 13) = v47;
    *(_WORD *)(v4 - 12) = v12;
    *(_WORD *)(v4 - 10) = v13;
    v18 = v46 == 0;
    *(_BYTE *)(v4 - 8) = v46 % v9 != 0;
    v48 = v6 + 14;
    v49 = 127;
    if ( !v18 )
      v49 = 100;
    *(_BYTE *)(v4 - 7) = v49;
    v50 = v7;
    if ( (v48 & 1) != 0 )
      v50 = v8;
    *(_WORD *)(v4 - 6) = v50;
    *(_WORD *)(v4 - 4) = (__int16)(v10 * v50) / 100;
    *(_BYTE *)(v4 - 2) = v48 % v9 != 0;
    v51 = 127;
    if ( v6 != -14 )
      v51 = 100;
    v6 += 16;
    *(_BYTE *)(v4 - 1) = v51;
  }
  while ( v6 <= 32 );
  return sub_7FF91E01FED0(a1, 0);
}


// ==== sub_7FF91E01F8B0 @ rva 0x3BF8B0 ====
__int64 __fastcall sub_7FF91E01F8B0(__int64 a1, __int64 a2)
{
  int v2; // esi
  int v5; // ecx
  int v6; // eax

  v2 = *(_DWORD *)(a1 + 44);
  if ( (unsigned int)(v2 - 1) <= 2 )
  {
    *(_DWORD *)(a1 + 44) = 0;
    sub_7FF91E01D3A0((unsigned __int8 *)a1);
  }
  *(_DWORD *)(a1 + 44) = v2;
  *(_QWORD *)(a1 + 32) = a2;
  sub_7FF91E01F9F0(a1, a2, a1 + 804);
  v5 = *(char *)(a1 + 3055);
  v6 = *(_DWORD *)(a1 + 3056);
  if ( v6 >= v5 )
    *(_DWORD *)(a1 + 3056) = v6 % v5;
  return sub_7FF91E01FED0(a1, 0);
}


// ==== sub_7FF91E01F930 @ rva 0x3BF930 ====
__int64 __fastcall sub_7FF91E01F930(__int64 a1, __int64 a2, __int64 a3, int a4, int a5, int a6)
{
  if ( (unsigned int)(*(_DWORD *)(a1 + 44) - 1) <= 2 )
  {
    *(_DWORD *)(a1 + 44) = 0;
    sub_7FF91E01D3A0((unsigned __int8 *)a1);
  }
  *(_BYTE *)(a1 + 3488) = 1;
  sub_7FF91E01F3D0(a1, a4, a5);
  *(_DWORD *)(a1 + 3476) = a6;
  *(_DWORD *)(a1 + 3472) = 0;
  *(_BYTE *)(a1 + 3488) = 0;
  return sub_7FF91E01F8B0(a1, a2);
}


// ==== sub_7FF91E01F9C0 @ rva 0x3BF9C0 ====
__int64 __fastcall sub_7FF91E01F9C0(__int64 a1, __int64 a2)
{
  int v2; // r8d
  __int64 result; // rax
  int v4; // edx

  v2 = *(char *)(a1 + 3055);
  result = *(unsigned int *)(a1 + 3056);
  *(_QWORD *)(a1 + 32) = a2;
  *(_BYTE *)(a1 + 40) = 1;
  if ( (int)result >= v2 )
  {
    v4 = (int)result % v2;
    *(_DWORD *)(a1 + 3056) = v4;
    return (unsigned int)((int)result / v2);
  }
  return result;
}


// ==== sub_7FF91E01F9F0 @ rva 0x3BF9F0 ====
void __fastcall sub_7FF91E01F9F0(__int64 a1, char *a2, _BYTE *a3)
{
  _BYTE *v3; // rbx
  char *v4; // rdi
  _BYTE *v6; // rcx
  char v7; // cl
  unsigned __int8 *v8; // rcx
  int v9; // edi
  int v10; // r9d
  unsigned __int8 *v11; // r8
  _BYTE *v12; // rdx
  unsigned __int8 v13; // al
  unsigned __int8 v14; // al
  char *v15; // r10
  int v16; // eax
  int v17; // ecx
  unsigned __int8 *v18; // r8
  __int64 v19; // r9
  char *v20; // rdx
  char v21; // cl

  v3 = a3;
  v4 = a2;
  if ( a2 )
  {
    sub_7FF91E01DD80(a1, a3);
    v7 = 32;
    if ( (unsigned __int8)*v4 < 0x20u )
      v7 = *v4;
    v3[2251] = v7;
    v8 = (unsigned __int8 *)(v4 + 6);
    v9 = 0;
    v10 = 0;
    if ( (char)v3[2249] > 0 )
    {
      v11 = v3;
      v12 = v3 + 256;
      do
      {
        v13 = *v8;
        *v11 = *v8;
        if ( v13 >= 0x80u )
          break;
        ++v10;
        *(v12 - 64) = v8[1];
        v11 += 12;
        *v12 = v8[2];
        v12[64] = v8[3];
        v12[128] = v8[4];
        v12[192] = v8[5];
        v12[256] = v8[6];
        v12[320] = v8[7];
        v12[384] = v8[8];
        v12[448] = v8[9];
        v12[512] = v8[10];
        v12[576] = v8[11];
        v12[640] = v8[12];
        v12[704] = v8[13];
        v12[768] = v8[14];
        v12[832] = v8[15];
        v12[896] = v8[16];
        v12[960] = v8[17];
        v12[1024] = v8[18];
        v12[1088] = v8[19];
        v12[1152] = v8[20];
        v12[1216] = v8[21];
        v12[1280] = v8[22];
        v12[1344] = v8[23];
        v12[1408] = v8[24];
        v12[1472] = v8[25];
        v12[1536] = v8[26];
        v12[1600] = v8[27];
        v12[1664] = v8[28];
        v12[1728] = v8[29];
        v12[1792] = v8[30];
        v12[1856] = v8[31];
        v14 = v8[32];
        v8 += 34;
        v12[1920] = v14;
        v12 += 4;
      }
      while ( v10 < (char)v3[2249] );
    }
    sub_7FF91E01D540(a1, v3);
    v15 = v3 + 192;
    v16 = 128;
    do
    {
      if ( v9 >= (char)v3[2251] )
        break;
      v17 = (char)v3[2249];
      if ( v17 > 0 )
      {
        v18 = v3;
        v19 = (unsigned int)v17;
        v20 = v15;
        do
        {
          if ( *v20 > 0 && *v18 < v16 )
            v16 = *v18;
          v20 += 4;
          v18 += 12;
          --v19;
        }
        while ( v19 );
      }
      ++v9;
      v15 += 64;
    }
    while ( v16 == 128 );
    v21 = v16;
    if ( v16 == 128 )
      v21 = 60;
    v3[2256] = v21;
  }
  else
  {
    a3[2251] = 1;
    if ( (char)a3[2249] > 0 )
    {
      v6 = a3 + 192;
      do
      {
        *v3 = 0x80;
        LODWORD(v4) = (_DWORD)v4 + 1;
        *v6 = 0;
        v6 += 4;
        v3 += 12;
      }
      while ( (int)v4 < (char)a3[2249] );
    }
  }
}


// ==== sub_7FF91E01FCA0 @ rva 0x3BFCA0 ====
__int64 __fastcall sub_7FF91E01FCA0(__int64 a1, int a2)
{
  return sub_7FF91E01F3D0(a1, *(_DWORD *)(a1 + 12), a2);
}


// ==== sub_7FF91E01FCB0 @ rva 0x3BFCB0 ====
void *__fastcall sub_7FF91E01FCB0(__int64 a1, int a2)
{
  void *result; // rax

  switch ( a2 )
  {
    case 0:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01EFC0;
      result = sub_7FF91E01EFC0;
      break;
    case 1:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01F060;
      result = sub_7FF91E01F060;
      break;
    case 2:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01F0C0;
      result = sub_7FF91E01F0C0;
      break;
    case 3:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01E6E0;
      result = sub_7FF91E01E6E0;
      break;
    case 4:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01E790;
      result = sub_7FF91E01E790;
      break;
    case 5:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01E800;
      result = sub_7FF91E01E800;
      break;
    case 6:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01E400;
      result = sub_7FF91E01E400;
      break;
    case 7:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01E4E0;
      result = sub_7FF91E01E4E0;
      break;
    case 8:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01E560;
      result = sub_7FF91E01E560;
      break;
    case 9:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01EDB0;
      result = sub_7FF91E01EDB0;
      break;
    case 10:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01EEC0;
      result = sub_7FF91E01EEC0;
      break;
    case 11:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01ED50;
      result = sub_7FF91E01ED50;
      break;
    case 13:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01E940;
      result = sub_7FF91E01E940;
      break;
    case 14:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01EF80;
      result = sub_7FF91E01EF80;
      break;
    case 15:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01EC80;
      result = sub_7FF91E01EC80;
      break;
    case 16:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01EB10;
      result = sub_7FF91E01EB10;
      break;
    case 17:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01E990;
      result = sub_7FF91E01E990;
      break;
    case 18:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01EBF0;
      result = sub_7FF91E01EBF0;
      break;
    case 19:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01E850;
      result = sub_7FF91E01E850;
      break;
    case 20:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01E5C0;
      result = sub_7FF91E01E5C0;
      break;
    default:
      *(_QWORD *)(a1 + 3480) = sub_7FF91E01ED30;
      result = sub_7FF91E01ED30;
      break;
  }
  return result;
}


// ==== sub_7FF91E01FE60 @ rva 0x3BFE60 ====
void __fastcall sub_7FF91E01FE60(__int64 a1, int a2)
{
  *(_DWORD *)(a1 + 3472) = 0;
  *(_DWORD *)(a1 + 3476) = a2;
}


// ==== sub_7FF91E01FE80 @ rva 0x3BFE80 ====
void __fastcall sub_7FF91E01FE80(__int64 a1, int a2, char a3)
{
  *(_DWORD *)(a1 + 600) = a2;
  *(_BYTE *)(a1 + 608) = a3;
}


// ==== sub_7FF91E01FE90 @ rva 0x3BFE90 ====
__int64 __fastcall sub_7FF91E01FE90(__int64 a1, char a2)
{
  __int64 result; // rax

  if ( (unsigned int)(*(_DWORD *)(a1 + 44) - 1) <= 2 )
  {
    *(_DWORD *)(a1 + 44) = 0;
    sub_7FF91E01D3A0((unsigned __int8 *)a1);
  }
  result = *(unsigned int *)(a1 + 20);
  *(_DWORD *)(a1 + 24) = result;
  *(_BYTE *)(a1 + 197) = a2;
  return result;
}


// ==== sub_7FF91E01FED0 @ rva 0x3BFED0 ====
void __fastcall sub_7FF91E01FED0(__int64 a1, char *a2)
{
  char *v2; // r15
  __int64 v3; // r10
  __int64 v4; // r12
  char *v5; // r13
  int v6; // r8d
  char v7; // dl
  __int64 v8; // rbx
  char *v9; // rax
  __int64 v10; // rbp
  char v11; // r9
  __int16 v12; // ax
  __int64 v13; // rsi
  __int64 v14; // rcx
  bool v15; // sf
  int v16; // ecx
  __int64 v17; // r11
  char *v18; // rcx
  char v19; // di
  __int16 v20; // r9
  char *v21; // r14
  __int16 v22; // dx
  __int16 v23; // cx
  __int16 v24; // cx
  int v26; // [rsp+70h] [rbp+18h]
  char *v27; // [rsp+78h] [rbp+20h]

  v2 = a2;
  v3 = a1;
  if ( !*(_BYTE *)(a1 + 3488) )
  {
    if ( !a2 )
    {
      v2 = (char *)(a1 + 804);
      sub_7FF91E01FED0(a1, a1 + 804);
      v3 = a1;
    }
    v2[2250] = 0;
    v26 = 0;
    if ( v2[2249] > 0 )
    {
      v4 = 2;
      v5 = v2;
      v27 = v2;
      do
      {
        if ( (unsigned __int8)*v5 >= 0x80u )
          break;
        ++v2[2250];
        v6 = 0;
        v7 = v2[2251];
        v8 = 0;
        if ( v7 > 0 )
        {
          v9 = &v2[v4 + 190];
          while ( 1 )
          {
            v10 = v7;
            if ( (*v9 & 0x7F) != 0 )
              break;
            ++v6;
            ++v8;
            v9 += 64;
            if ( v6 >= v7 )
              goto LABEL_31;
          }
          v11 = *v9;
          v12 = 0;
          v13 = v6;
          do
          {
            v14 = v10;
            v15 = v13 - 1 < 0;
            if ( v13 - 1 >= 0 )
              v14 = v13;
            v13 = v14 - 1;
            v16 = v10;
            if ( !v15 )
              v16 = v6;
            v6 = v16 - 1;
            v17 = v3 + 6 * v13;
            v18 = &v2[64 * v13 + 192];
            v19 = v18[v4 - 2];
            if ( v11 >= 0 )
              v20 = *(_WORD *)(v17 + 612);
            else
              v20 = *(_WORD *)(v17 + 610);
            v21 = &v18[v4];
            if ( (v19 & 0x7F) != 0 )
              v22 = v12 + v20;
            else
              v22 = 0;
            v23 = 0;
            *(_WORD *)v21 = v22;
            if ( (v19 & 0x7F) == 0 )
              v23 = v12;
            if ( v20 )
            {
              v24 = v20 + v23;
              v12 = 0;
              if ( v19 < 0 )
                v12 = v24;
            }
            else
            {
              v12 = v23 + *(_WORD *)(v17 + 610);
            }
            v3 = a1;
            v11 = v19;
          }
          while ( v13 != v8 );
          v5 = v27;
        }
LABEL_31:
        v5 += 12;
        v3 = a1;
        v4 += 4;
        ++v26;
        v27 = v5;
      }
      while ( v26 < v2[2249] );
    }
  }
}

