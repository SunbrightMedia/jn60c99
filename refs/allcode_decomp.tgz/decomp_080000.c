// ==== sub_7FF91DCF0490 @ rva 0x90490 ====
// None

// ==== sub_7FF91DD0BD60 @ rva 0xABD60 ====
int sub_7FF91DD0BD60()
{
  unsigned __int8 v1; // [rsp+20h] [rbp-E0h]
  _OWORD v2[381]; // [rsp+30h] [rbp-D0h] BYREF
  __int64 v3; // [rsp+1800h] [rbp+1700h] BYREF

  v2[0] = xmmword_7FF91E5C37F0;
  v2[1] = xmmword_7FF91E5C37E0;
  v2[2] = xmmword_7FF91E5C37D0;
  v2[3] = xmmword_7FF91E5C37C0;
  v2[4] = xmmword_7FF91E5C37B0;
  v2[5] = xmmword_7FF91E5C37A0;
  v2[6] = xmmword_7FF91E5C3780;
  v2[7] = xmmword_7FF91E5C3770;
  v2[8] = xmmword_7FF91E5C3760;
  v2[9] = xmmword_7FF91E5C3750;
  v2[10] = xmmword_7FF91E5C3740;
  v2[11] = xmmword_7FF91E5C3730;
  v2[12] = xmmword_7FF91E5C3720;
  v2[13] = xmmword_7FF91E5C3710;
  v2[14] = xmmword_7FF91E5C3700;
  v2[15] = xmmword_7FF91E5C36F0;
  v2[16] = xmmword_7FF91E5C36E0;
  v2[17] = xmmword_7FF91E5C36C0;
  v2[18] = xmmword_7FF91E5C36B0;
  v2[19] = xmmword_7FF91E5C36A0;
  v2[20] = xmmword_7FF91E5C3690;
  v2[21] = xmmword_7FF91E5C3680;
  v2[22] = xmmword_7FF91E5C3670;
  v2[23] = xmmword_7FF91E5C3660;
  v2[24] = xmmword_7FF91E5C3650;
  v2[25] = xmmword_7FF91E5C3630;
  v2[26] = xmmword_7FF91E5C3610;
  v2[27] = xmmword_7FF91E5C35E0;
  v2[28] = xmmword_7FF91E5C3550;
  v2[29] = xmmword_7FF91E5C33D0;
  v2[30] = xmmword_7FF91E5C3300;
  v2[31] = xmmword_7FF91E5C3230;
  v2[32] = xmmword_7FF91E5C3190;
  v2[33] = xmmword_7FF91E5C30F0;
  v2[34] = xmmword_7FF91E5C3050;
  v2[35] = xmmword_7FF91E5C2F60;
  v2[36] = xmmword_7FF91E5C2DD0;
  v2[37] = xmmword_7FF91E5C2CC0;
  v2[38] = xmmword_7FF91E5C2620;
  v2[39] = xmmword_7FF91E5C3F40;
  v2[40] = xmmword_7FF91E5C5D00;
  v2[42] = xmmword_7FF91E5C6450;
  v2[41] = xmmword_7FF91E5C5FC0;
  v2[44] = xmmword_7FF91E5C6570;
  v2[43] = xmmword_7FF91E5C6540;
  v2[46] = xmmword_7FF91E5C65E0;
  v2[45] = xmmword_7FF91E5C65B0;
  v2[48] = xmmword_7FF91E5C6650;
  v2[47] = xmmword_7FF91E5C6610;
  v2[50] = xmmword_7FF91E5C66B0;
  v2[49] = xmmword_7FF91E5C6680;
  v2[52] = xmmword_7FF91E5C66F0;
  v2[51] = xmmword_7FF91E5C66D0;
  v2[54] = xmmword_7FF91E5C6730;
  v2[53] = xmmword_7FF91E5C6710;
  v2[56] = xmmword_7FF91E5C6760;
  v2[55] = xmmword_7FF91E5C6750;
  v2[58] = xmmword_7FF91E5C6720;
  v2[57] = xmmword_7FF91E5C6740;
  v2[60] = xmmword_7FF91E5C66E0;
  v2[59] = xmmword_7FF91E5C6700;
  v2[62] = xmmword_7FF91E5C66A0;
  v2[61] = xmmword_7FF91E5C66C0;
  v2[64] = xmmword_7FF91E5C6660;
  v2[63] = xmmword_7FF91E5C6690;
  v2[66] = xmmword_7FF91E5C6600;
  v2[65] = xmmword_7FF91E5C6630;
  v2[68] = xmmword_7FF91E5C65C0;
  v2[67] = xmmword_7FF91E5C65F0;
  v2[70] = xmmword_7FF91E5C6560;
  v2[69] = xmmword_7FF91E5C65A0;
  v2[72] = xmmword_7FF91E5C6530;
  v2[71] = xmmword_7FF91E5C6550;
  v2[74] = xmmword_7FF91E5C6100;
  v2[73] = xmmword_7FF91E5C6470;
  v2[76] = xmmword_7FF91E5C5DD0;
  v2[75] = xmmword_7FF91E5C5F40;
  v2[78] = xmmword_7FF91E5C5350;
  v2[77] = xmmword_7FF91E5C5990;
  v2[80] = xmmword_7FF91E5C2380;
  v2[79] = xmmword_7FF91E5C1570;
  v2[81] = xmmword_7FF91E5C2640;
  v2[82] = xmmword_7FF91E5C29E0;
  v2[83] = xmmword_7FF91E5C2C60;
  v2[84] = xmmword_7FF91E5C2CD0;
  v2[85] = xmmword_7FF91E5C2D30;
  v2[86] = xmmword_7FF91E5C2D80;
  v2[87] = xmmword_7FF91E5C2DC0;
  v2[88] = xmmword_7FF91E5C2E10;
  v2[89] = xmmword_7FF91E5C2E40;
  v2[90] = xmmword_7FF91E5C2E80;
  v2[91] = xmmword_7FF91E5C2EB0;
  v2[92] = xmmword_7FF91E5C2EF0;
  v2[93] = xmmword_7FF91E5C2F20;
  v2[94] = xmmword_7FF91E5C2F50;
  v2[95] = xmmword_7FF91E5C2F80;
  v2[96] = xmmword_7FF91E5C2FA0;
  v2[97] = xmmword_7FF91E5C2F90;
  v2[98] = xmmword_7FF91E5C2F70;
  v2[99] = xmmword_7FF91E5C2F40;
  v2[100] = xmmword_7FF91E5C2F10;
  v2[101] = xmmword_7FF91E5C2EE0;
  v2[102] = xmmword_7FF91E5C2EC0;
  v2[103] = xmmword_7FF91E5C2E90;
  v2[104] = xmmword_7FF91E5C2E60;
  v2[105] = xmmword_7FF91E5C2E20;
  v2[106] = xmmword_7FF91E5C2DF0;
  v2[107] = xmmword_7FF91E5C2DA0;
  v2[108] = xmmword_7FF91E5C2D70;
  v2[109] = xmmword_7FF91E5C2D40;
  v2[110] = xmmword_7FF91E5C2CF0;
  v2[111] = xmmword_7FF91E5C2CA0;
  v2[112] = xmmword_7FF91E5C2C40;
  v2[113] = xmmword_7FF91E5C2B70;
  v2[114] = xmmword_7FF91E5C27B0;
  v2[115] = xmmword_7FF91E5C25A0;
  v2[116] = xmmword_7FF91E5C2400;
  v2[117] = xmmword_7FF91E5C1DB0;
  v2[118] = xmmword_7FF91E5C1470;
  v2[119] = xmmword_7FF91E5C4AD0;
  v2[120] = xmmword_7FF91E5C5450;
  v2[121] = xmmword_7FF91E5C5730;
  v2[123] = xmmword_7FF91E5C5D50;
  v2[122] = xmmword_7FF91E5C5C20;
  v2[125] = xmmword_7FF91E5C5E80;
  v2[124] = xmmword_7FF91E5C5DF0;
  v2[127] = xmmword_7FF91E5C5F90;
  v2[126] = xmmword_7FF91E5C5F10;
  v2[129] = xmmword_7FF91E5C60A0;
  v2[128] = xmmword_7FF91E5C6030;
  v2[131] = xmmword_7FF91E5C61B0;
  v2[130] = xmmword_7FF91E5C6130;
  v2[133] = xmmword_7FF91E5C6270;
  v2[132] = xmmword_7FF91E5C6210;
  v2[135] = xmmword_7FF91E5C6310;
  v2[134] = xmmword_7FF91E5C62D0;
  v2[137] = xmmword_7FF91E5C6330;
  v2[136] = xmmword_7FF91E5C6340;
  v2[139] = xmmword_7FF91E5C62B0;
  v2[138] = xmmword_7FF91E5C62F0;
  v2[141] = xmmword_7FF91E5C6200;
  v2[140] = xmmword_7FF91E5C6260;
  v2[143] = xmmword_7FF91E5C6140;
  v2[142] = xmmword_7FF91E5C6190;
  v2[145] = xmmword_7FF91E5C6040;
  v2[144] = xmmword_7FF91E5C60C0;
  v2[147] = xmmword_7FF91E5C5F60;
  v2[146] = xmmword_7FF91E5C5FE0;
  v2[149] = xmmword_7FF91E5C5E70;
  v2[148] = xmmword_7FF91E5C5EE0;
  v2[151] = xmmword_7FF91E5C5D90;
  v2[150] = xmmword_7FF91E5C5E10;
  v2[153] = xmmword_7FF91E5C5B10;
  v2[152] = xmmword_7FF91E5C5D20;
  v2[155] = xmmword_7FF91E5C55D0;
  v2[154] = xmmword_7FF91E5C57E0;
  v2[157] = xmmword_7FF91E5C4C80;
  v2[156] = xmmword_7FF91E5C53C0;
  v2[159] = xmmword_7FF91E5C1560;
  v2[158] = xmmword_7FF91E5C4000;
  v2[161] = xmmword_7FF91E5C1F00;
  v2[160] = xmmword_7FF91E5C1BA0;
  v2[162] = xmmword_7FF91E5C2390;
  v2[163] = xmmword_7FF91E5C2460;
  v2[164] = xmmword_7FF91E5C2510;
  v2[165] = xmmword_7FF91E5C25D0;
  v2[166] = xmmword_7FF91E5C2690;
  v2[167] = xmmword_7FF91E5C2760;
  v2[168] = xmmword_7FF91E5C2820;
  v2[169] = xmmword_7FF91E5C28F0;
  v2[170] = xmmword_7FF91E5C29C0;
  v2[171] = xmmword_7FF91E5C2B40;
  v2[172] = xmmword_7FF91E5C2B90;
  v2[173] = xmmword_7FF91E5C2BB0;
  v2[174] = xmmword_7FF91E5C2BD0;
  v2[175] = xmmword_7FF91E5C2BF0;
  v2[176] = xmmword_7FF91E5C2C10;
  v2[177] = xmmword_7FF91E5C2C00;
  v2[178] = xmmword_7FF91E5C2BE0;
  v2[179] = xmmword_7FF91E5C2BC0;
  v2[180] = xmmword_7FF91E5C2BA0;
  v2[181] = xmmword_7FF91E5C2B50;
  v2[182] = xmmword_7FF91E5C2A30;
  v2[183] = xmmword_7FF91E5C2940;
  v2[184] = xmmword_7FF91E5C2890;
  v2[185] = xmmword_7FF91E5C27D0;
  v2[186] = xmmword_7FF91E5C2730;
  v2[187] = xmmword_7FF91E5C26A0;
  v2[188] = xmmword_7FF91E5C25F0;
  v2[189] = xmmword_7FF91E5C2560;
  v2[190] = xmmword_7FF91E5C24D0;
  v2[191] = xmmword_7FF91E5C2440;
  v2[192] = xmmword_7FF91E5C23B0;
  v2[193] = xmmword_7FF91E5C20C0;
  v2[194] = xmmword_7FF91E5C1DF0;
  v2[195] = xmmword_7FF91E5C1BC0;
  v2[196] = xmmword_7FF91E5C19F0;
  v2[197] = xmmword_7FF91E5C1220;
  v2[198] = xmmword_7FF91E5C3BB0;
  v2[199] = xmmword_7FF91E5C4970;
  v2[200] = xmmword_7FF91E5C4CB0;
  v2[201] = xmmword_7FF91E5C50E0;
  v2[202] = xmmword_7FF91E5C53F0;
  v2[204] = xmmword_7FF91E5C55E0;
  v2[203] = xmmword_7FF91E5C54F0;
  v2[206] = xmmword_7FF91E5C5760;
  v2[205] = xmmword_7FF91E5C56A0;
  v2[208] = xmmword_7FF91E5C5900;
  v2[207] = xmmword_7FF91E5C5840;
  v2[210] = xmmword_7FF91E5C5AD0;
  v2[209] = xmmword_7FF91E5C59F0;
  v2[212] = xmmword_7FF91E5C5C60;
  v2[211] = xmmword_7FF91E5C5C30;
  v2[214] = xmmword_7FF91E5C5CA0;
  v2[213] = xmmword_7FF91E5C5C80;
  v2[216] = xmmword_7FF91E5C5CE0;
  v2[215] = xmmword_7FF91E5C5CD0;
  v2[218] = xmmword_7FF91E5C5C90;
  v2[217] = xmmword_7FF91E5C5CC0;
  v2[220] = xmmword_7FF91E5C5C50;
  v2[219] = xmmword_7FF91E5C5C70;
  v2[222] = xmmword_7FF91E5C5A60;
  v2[221] = xmmword_7FF91E5C5B60;
  v2[224] = xmmword_7FF91E5C58D0;
  v2[223] = xmmword_7FF91E5C59A0;
  v2[226] = xmmword_7FF91E5C5770;
  v2[225] = xmmword_7FF91E5C5830;
  v2[228] = xmmword_7FF91E5C5640;
  v2[227] = xmmword_7FF91E5C56D0;
  v2[230] = xmmword_7FF91E5C54E0;
  v2[229] = xmmword_7FF91E5C5590;
  v2[232] = xmmword_7FF91E5C5360;
  v2[231] = xmmword_7FF91E5C5430;
  v2[234] = xmmword_7FF91E5C4D40;
  v2[233] = xmmword_7FF91E5C5030;
  v2[236] = xmmword_7FF91E5C4920;
  v2[235] = xmmword_7FF91E5C4B00;
  v2[238] = xmmword_7FF91E5C0940;
  v2[237] = xmmword_7FF91E5C41C0;
  v2[240] = xmmword_7FF91E5C1530;
  v2[239] = xmmword_7FF91E5C1130;
  v2[242] = xmmword_7FF91E5C1A80;
  v2[241] = xmmword_7FF91E5C1980;
  v2[243] = xmmword_7FF91E5C1B50;
  v2[244] = xmmword_7FF91E5C1C20;
  v2[245] = xmmword_7FF91E5C1CD0;
  v2[246] = xmmword_7FF91E5C1D90;
  v2[247] = xmmword_7FF91E5C1E90;
  v2[248] = xmmword_7FF91E5C1F30;
  v2[249] = xmmword_7FF91E5C1FE0;
  v2[250] = xmmword_7FF91E5C2070;
  v2[251] = xmmword_7FF91E5C2110;
  v2[252] = xmmword_7FF91E5C21B0;
  v2[253] = xmmword_7FF91E5C2240;
  v2[254] = xmmword_7FF91E5C22C0;
  v2[255] = xmmword_7FF91E5C2340;
  v2[256] = xmmword_7FF91E5C22D0;
  v2[257] = xmmword_7FF91E5C2250;
  v2[258] = xmmword_7FF91E5C21D0;
  v2[259] = xmmword_7FF91E5C2130;
  v2[260] = xmmword_7FF91E5C20B0;
  v2[261] = xmmword_7FF91E5C2010;
  v2[262] = xmmword_7FF91E5C1F90;
  v2[263] = xmmword_7FF91E5C1EF0;
  v2[264] = xmmword_7FF91E5C1E60;
  v2[265] = xmmword_7FF91E5C1DA0;
  v2[266] = xmmword_7FF91E5C1D00;
  v2[267] = xmmword_7FF91E5C1C90;
  v2[268] = xmmword_7FF91E5C1BF0;
  v2[269] = xmmword_7FF91E5C1B40;
  v2[270] = xmmword_7FF91E5C1AC0;
  v2[271] = xmmword_7FF91E5C1A20;
  v2[272] = xmmword_7FF91E5C1830;
  v2[273] = xmmword_7FF91E5C15E0;
  v2[274] = xmmword_7FF91E5C1350;
  v2[275] = xmmword_7FF91E5C1120;
  v2[276] = xmmword_7FF91E5C0F20;
  v2[277] = xmmword_7FF91E5C0740;
  v2[278] = xmmword_7FF91E5C3F10;
  v2[279] = xmmword_7FF91E5C42F0;
  v2[280] = xmmword_7FF91E5C45C0;
  v2[281] = xmmword_7FF91E5C4960;
  v2[282] = xmmword_7FF91E5C4A10;
  v2[283] = xmmword_7FF91E5C4AE0;
  v2[285] = xmmword_7FF91E5C4C60;
  v2[284] = xmmword_7FF91E5C4B90;
  v2[287] = xmmword_7FF91E5C4DA0;
  v2[286] = xmmword_7FF91E5C4D10;
  v2[289] = xmmword_7FF91E5C4EB0;
  v2[288] = xmmword_7FF91E5C4E20;
  v2[291] = xmmword_7FF91E5C4F80;
  v2[290] = xmmword_7FF91E5C4F10;
  v2[293] = xmmword_7FF91E5C5000;
  v2[292] = xmmword_7FF91E5C4FC0;
  v2[295] = xmmword_7FF91E5C5010;
  v2[294] = xmmword_7FF91E5C5020;
  v2[297] = xmmword_7FF91E5C4FB0;
  v2[296] = xmmword_7FF91E5C4FE0;
  v2[299] = xmmword_7FF91E5C4EF0;
  v2[298] = xmmword_7FF91E5C4F60;
  v2[301] = xmmword_7FF91E5C4E30;
  v2[300] = xmmword_7FF91E5C4EA0;
  v2[303] = xmmword_7FF91E5C4D50;
  v2[302] = xmmword_7FF91E5C4DD0;
  v2[305] = xmmword_7FF91E5C4C30;
  v2[304] = xmmword_7FF91E5C4CC0;
  v2[307] = xmmword_7FF91E5C4B40;
  v2[306] = xmmword_7FF91E5C4BB0;
  v2[309] = xmmword_7FF91E5C4A00;
  v2[308] = xmmword_7FF91E5C4A90;
  v2[311] = xmmword_7FF91E5C4910;
  v2[310] = xmmword_7FF91E5C4990;
  v2[313] = xmmword_7FF91E5C4440;
  v2[312] = xmmword_7FF91E5C4600;
  v2[315] = xmmword_7FF91E5C40A0;
  v2[314] = xmmword_7FF91E5C42C0;
  v2[317] = xmmword_7FF91E5C3910;
  v2[316] = xmmword_7FF91E5C3EB0;
  v2[319] = xmmword_7FF91E5C0A50;
  v2[318] = xmmword_7FF91E5C07A0;
  v2[321] = xmmword_7FF91E5C0F90;
  v2[320] = xmmword_7FF91E5C0DE0;
  v2[323] = xmmword_7FF91E5C10D0;
  v2[322] = xmmword_7FF91E5C1040;
  v2[324] = xmmword_7FF91E5C1170;
  v2[325] = xmmword_7FF91E5C11E0;
  v2[326] = xmmword_7FF91E5C1270;
  v2[327] = xmmword_7FF91E5C12C0;
  v2[328] = xmmword_7FF91E5C1340;
  v2[329] = xmmword_7FF91E5C1390;
  v2[330] = xmmword_7FF91E5C13D0;
  v2[331] = xmmword_7FF91E5C1430;
  v2[332] = xmmword_7FF91E5C1450;
  v2[333] = xmmword_7FF91E5C1480;
  v2[334] = xmmword_7FF91E5C1460;
  v2[335] = xmmword_7FF91E5C1440;
  v2[336] = xmmword_7FF91E5C1400;
  v2[337] = xmmword_7FF91E5C13C0;
  v2[338] = xmmword_7FF91E5C1380;
  v2[339] = xmmword_7FF91E5C1320;
  v2[340] = xmmword_7FF91E5C12D0;
  v2[341] = xmmword_7FF91E5C1290;
  v2[342] = xmmword_7FF91E5C1230;
  v2[343] = xmmword_7FF91E5C11D0;
  v2[344] = xmmword_7FF91E5C1160;
  v2[345] = xmmword_7FF91E5C1100;
  v2[346] = xmmword_7FF91E5C1080;
  v2[347] = xmmword_7FF91E5C1030;
  v2[348] = xmmword_7FF91E5C0FD0;
  v2[349] = xmmword_7FF91E5C0F60;
  v2[350] = xmmword_7FF91E5C0F00;
  v2[351] = xmmword_7FF91E5C0C50;
  v2[352] = xmmword_7FF91E5C0AD0;
  v2[353] = xmmword_7FF91E5C0960;
  v2[354] = xmmword_7FF91E5C0820;
  v2[355] = xmmword_7FF91E5C0700;
  v2[356] = xmmword_7FF91E5C0610;
  v2[357] = xmmword_7FF91E5C38E0;
  v2[358] = xmmword_7FF91E5C3A10;
  v2[359] = xmmword_7FF91E5C3C10;
  v2[360] = xmmword_7FF91E5C3E90;
  v2[361] = xmmword_7FF91E5C3F00;
  v2[362] = xmmword_7FF91E5C3F80;
  v2[363] = xmmword_7FF91E5C3FC0;
  v2[364] = xmmword_7FF91E5C4010;
  v2[366] = xmmword_7FF91E5C40C0;
  v2[365] = xmmword_7FF91E5C4060;
  v2[368] = xmmword_7FF91E5C4150;
  v2[367] = xmmword_7FF91E5C4110;
  v2[370] = xmmword_7FF91E5C41D0;
  v2[369] = xmmword_7FF91E5C4190;
  v2[372] = xmmword_7FF91E5C41E0;
  v2[371] = xmmword_7FF91E5C41F0;
  v2[374] = xmmword_7FF91E5C4170;
  v2[373] = xmmword_7FF91E5C41A0;
  v2[376] = xmmword_7FF91E5C4100;
  v2[375] = xmmword_7FF91E5C4130;
  v2[378] = xmmword_7FF91E5C4080;
  v2[377] = xmmword_7FF91E5C40B0;
  v2[380] = xmmword_7FF91E5C3FF0;
  v2[379] = xmmword_7FF91E5C4040;
  sub_7FF91DFA3780(&xmmword_7FF91E9105F0, v2, &v3, v1);
  return atexit(sub_7FF91E58F110);
}


// ==== sub_7FF91DD0D270 @ rva 0xAD270 ====
int sub_7FF91DD0D270()
{
  return atexit((void (__cdecl *)())sub_7FF91E58F180);
}


// ==== sub_7FF91DD0D280 @ rva 0xAD280 ====
int sub_7FF91DD0D280()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58F330);
}


// ==== sub_7FF91DD0D2A0 @ rva 0xAD2A0 ====
int sub_7FF91DD0D2A0()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58F390);
}


// ==== sub_7FF91DD0D2C0 @ rva 0xAD2C0 ====
int sub_7FF91DD0D2C0()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58F4B0);
}


// ==== sub_7FF91DD0D2E0 @ rva 0xAD2E0 ====
int sub_7FF91DD0D2E0()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58F510);
}


// ==== sub_7FF91DD0D300 @ rva 0xAD300 ====
int sub_7FF91DD0D300()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58F630);
}


// ==== sub_7FF91DD0D320 @ rva 0xAD320 ====
int sub_7FF91DD0D320()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58F690);
}


// ==== sub_7FF91DD0D340 @ rva 0xAD340 ====
int sub_7FF91DD0D340()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58F7B0);
}


// ==== sub_7FF91DD0D360 @ rva 0xAD360 ====
int sub_7FF91DD0D360()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58F810);
}


// ==== sub_7FF91DD0D380 @ rva 0xAD380 ====
int sub_7FF91DD0D380()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58F930);
}


// ==== sub_7FF91DD0D3A0 @ rva 0xAD3A0 ====
int sub_7FF91DD0D3A0()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58F990);
}


// ==== sub_7FF91DD0D3C0 @ rva 0xAD3C0 ====
int sub_7FF91DD0D3C0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E58FAB0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E58FAB0);
  }
}


// ==== sub_7FF91DD0D480 @ rva 0xAD480 ====
int sub_7FF91DD0D480()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E58FB40);
}


// ==== sub_7FF91DD0D520 @ rva 0xAD520 ====
int sub_7FF91DD0D520()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E58FCC0);
}


// ==== sub_7FF91DD0D540 @ rva 0xAD540 ====
int sub_7FF91DD0D540()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E58FD20);
}


// ==== sub_7FF91DD0D560 @ rva 0xAD560 ====
int sub_7FF91DD0D560()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E590160);
}


// ==== sub_7FF91DD0D580 @ rva 0xAD580 ====
int sub_7FF91DD0D580()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E5901C0);
}


// ==== sub_7FF91DD0D5A0 @ rva 0xAD5A0 ====
int sub_7FF91DD0D5A0()
{
  sub_7FF91E025820((int)&qword_7FF91E910E18);
  return atexit(sub_7FF91E590220);
}


// ==== sub_7FF91DD14980 @ rva 0xB4980 ====
int sub_7FF91DD14980()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E5902F0);
}


// ==== sub_7FF91DD149A0 @ rva 0xB49A0 ====
int sub_7FF91DD149A0()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E590350);
}


// ==== sub_7FF91DD149C0 @ rva 0xB49C0 ====
int sub_7FF91DD149C0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E5903B0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E5903B0);
  }
}


// ==== sub_7FF91DD14A80 @ rva 0xB4A80 ====
int sub_7FF91DD14A80()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E590440);
}


// ==== sub_7FF91DD14B20 @ rva 0xB4B20 ====
int sub_7FF91DD14B20()
{
  return atexit((void (__cdecl *)())sub_7FF91E5905E0);
}


// ==== sub_7FF91DD14B30 @ rva 0xB4B30 ====
int sub_7FF91DD14B30()
{
  return atexit((void (__cdecl *)())sub_7FF91E5905F0);
}


// ==== sub_7FF91DD14B40 @ rva 0xB4B40 ====
int sub_7FF91DD14B40()
{
  return atexit((void (__cdecl *)())sub_7FF91E590600);
}


// ==== sub_7FF91DD14B50 @ rva 0xB4B50 ====
int sub_7FF91DD14B50()
{
  return atexit((void (__cdecl *)())sub_7FF91E590610);
}


// ==== sub_7FF91DD14B60 @ rva 0xB4B60 ====
int sub_7FF91DD14B60()
{
  return atexit((void (__cdecl *)())sub_7FF91E590620);
}


// ==== sub_7FF91DD14B70 @ rva 0xB4B70 ====
int sub_7FF91DD14B70()
{
  return atexit((void (__cdecl *)())sub_7FF91E590630);
}


// ==== sub_7FF91DD14B80 @ rva 0xB4B80 ====
int sub_7FF91DD14B80()
{
  return atexit((void (__cdecl *)())sub_7FF91E590640);
}


// ==== sub_7FF91DD14B90 @ rva 0xB4B90 ====
int sub_7FF91DD14B90()
{
  return atexit((void (__cdecl *)())sub_7FF91E590650);
}


// ==== sub_7FF91DD14BA0 @ rva 0xB4BA0 ====
int sub_7FF91DD14BA0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590660);
}


// ==== sub_7FF91DD14BB0 @ rva 0xB4BB0 ====
int sub_7FF91DD14BB0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590670);
}


// ==== sub_7FF91DD14BC0 @ rva 0xB4BC0 ====
int sub_7FF91DD14BC0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590680);
}


// ==== sub_7FF91DD14BD0 @ rva 0xB4BD0 ====
int sub_7FF91DD14BD0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590690);
}


// ==== sub_7FF91DD14BE0 @ rva 0xB4BE0 ====
int sub_7FF91DD14BE0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5906A0);
}


// ==== sub_7FF91DD14BF0 @ rva 0xB4BF0 ====
int sub_7FF91DD14BF0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5906B0);
}


// ==== sub_7FF91DD14C00 @ rva 0xB4C00 ====
int sub_7FF91DD14C00()
{
  return atexit((void (__cdecl *)())sub_7FF91E5906C0);
}


// ==== sub_7FF91DD14C10 @ rva 0xB4C10 ====
int sub_7FF91DD14C10()
{
  return atexit((void (__cdecl *)())sub_7FF91E5906D0);
}


// ==== sub_7FF91DD14C20 @ rva 0xB4C20 ====
int sub_7FF91DD14C20()
{
  return atexit((void (__cdecl *)())sub_7FF91E5906E0);
}


// ==== sub_7FF91DD14C30 @ rva 0xB4C30 ====
int sub_7FF91DD14C30()
{
  return atexit((void (__cdecl *)())sub_7FF91E5906F0);
}


// ==== sub_7FF91DD14C40 @ rva 0xB4C40 ====
int sub_7FF91DD14C40()
{
  return atexit((void (__cdecl *)())sub_7FF91E590700);
}


// ==== sub_7FF91DD14C50 @ rva 0xB4C50 ====
int sub_7FF91DD14C50()
{
  return atexit((void (__cdecl *)())sub_7FF91E590710);
}


// ==== sub_7FF91DD14C60 @ rva 0xB4C60 ====
int sub_7FF91DD14C60()
{
  return atexit((void (__cdecl *)())sub_7FF91E590720);
}


// ==== sub_7FF91DD14C70 @ rva 0xB4C70 ====
int sub_7FF91DD14C70()
{
  return atexit((void (__cdecl *)())sub_7FF91E590730);
}


// ==== sub_7FF91DD14C80 @ rva 0xB4C80 ====
int sub_7FF91DD14C80()
{
  return atexit((void (__cdecl *)())sub_7FF91E590740);
}


// ==== sub_7FF91DD14C90 @ rva 0xB4C90 ====
int sub_7FF91DD14C90()
{
  return atexit((void (__cdecl *)())sub_7FF91E590750);
}


// ==== sub_7FF91DD14CA0 @ rva 0xB4CA0 ====
int sub_7FF91DD14CA0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590760);
}


// ==== sub_7FF91DD14CB0 @ rva 0xB4CB0 ====
int sub_7FF91DD14CB0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590770);
}


// ==== sub_7FF91DD14CC0 @ rva 0xB4CC0 ====
int sub_7FF91DD14CC0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590780);
}


// ==== sub_7FF91DD14CD0 @ rva 0xB4CD0 ====
int sub_7FF91DD14CD0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590790);
}


// ==== sub_7FF91DD14CE0 @ rva 0xB4CE0 ====
int sub_7FF91DD14CE0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5907A0);
}


// ==== sub_7FF91DD14CF0 @ rva 0xB4CF0 ====
int sub_7FF91DD14CF0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5907B0);
}


// ==== sub_7FF91DD14D00 @ rva 0xB4D00 ====
int sub_7FF91DD14D00()
{
  return atexit((void (__cdecl *)())sub_7FF91E5907C0);
}


// ==== sub_7FF91DD14D10 @ rva 0xB4D10 ====
int sub_7FF91DD14D10()
{
  return atexit((void (__cdecl *)())sub_7FF91E5907D0);
}


// ==== sub_7FF91DD14D20 @ rva 0xB4D20 ====
int sub_7FF91DD14D20()
{
  return atexit((void (__cdecl *)())sub_7FF91E5907E0);
}


// ==== sub_7FF91DD14D30 @ rva 0xB4D30 ====
int sub_7FF91DD14D30()
{
  return atexit((void (__cdecl *)())sub_7FF91E5907F0);
}


// ==== sub_7FF91DD14D40 @ rva 0xB4D40 ====
int sub_7FF91DD14D40()
{
  return atexit((void (__cdecl *)())sub_7FF91E590800);
}


// ==== sub_7FF91DD14D50 @ rva 0xB4D50 ====
int sub_7FF91DD14D50()
{
  return atexit((void (__cdecl *)())sub_7FF91E590810);
}


// ==== sub_7FF91DD14D60 @ rva 0xB4D60 ====
int sub_7FF91DD14D60()
{
  return atexit((void (__cdecl *)())sub_7FF91E590820);
}


// ==== sub_7FF91DD14D70 @ rva 0xB4D70 ====
int sub_7FF91DD14D70()
{
  return atexit((void (__cdecl *)())sub_7FF91E590830);
}


// ==== sub_7FF91DD14D80 @ rva 0xB4D80 ====
int sub_7FF91DD14D80()
{
  return atexit((void (__cdecl *)())sub_7FF91E590840);
}


// ==== sub_7FF91DD14D90 @ rva 0xB4D90 ====
int sub_7FF91DD14D90()
{
  return atexit((void (__cdecl *)())sub_7FF91E590850);
}


// ==== sub_7FF91DD14DA0 @ rva 0xB4DA0 ====
int sub_7FF91DD14DA0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590860);
}


// ==== sub_7FF91DD14DB0 @ rva 0xB4DB0 ====
int sub_7FF91DD14DB0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590870);
}


// ==== sub_7FF91DD14DC0 @ rva 0xB4DC0 ====
int sub_7FF91DD14DC0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590880);
}


// ==== sub_7FF91DD14DD0 @ rva 0xB4DD0 ====
int sub_7FF91DD14DD0()
{
  return atexit((void (__cdecl *)())sub_7FF91E590890);
}


// ==== sub_7FF91DD14DE0 @ rva 0xB4DE0 ====
int sub_7FF91DD14DE0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5908A0);
}


// ==== sub_7FF91DD14DF0 @ rva 0xB4DF0 ====
int sub_7FF91DD14DF0()
{
  return atexit((void (__cdecl *)())sub_7FF91E5908B0);
}


// ==== sub_7FF91DD14E00 @ rva 0xB4E00 ====
int sub_7FF91DD14E00()
{
  return atexit((void (__cdecl *)())sub_7FF91E5908C0);
}


// ==== sub_7FF91DD14E10 @ rva 0xB4E10 ====
int sub_7FF91DD14E10()
{
  return atexit((void (__cdecl *)())sub_7FF91E5908D0);
}


// ==== sub_7FF91DD14E20 @ rva 0xB4E20 ====
int sub_7FF91DD14E20()
{
  return atexit((void (__cdecl *)())sub_7FF91E5908E0);
}


// ==== sub_7FF91DD14E30 @ rva 0xB4E30 ====
int sub_7FF91DD14E30()
{
  return atexit((void (__cdecl *)())sub_7FF91E5908F0);
}


// ==== sub_7FF91DD14E40 @ rva 0xB4E40 ====
int sub_7FF91DD14E40()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E590B30);
}


// ==== sub_7FF91DD14E60 @ rva 0xB4E60 ====
int sub_7FF91DD14E60()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E590B90);
}


// ==== sub_7FF91DD14E80 @ rva 0xB4E80 ====
int sub_7FF91DD14E80()
{
  sub_7FF91E296FE0((unsigned int)&qword_7FF91E911EF0, -226474809, 1716931645, -1661145906, 1654210557);
  return atexit(sub_7FF91E590CB0);
}


// ==== sub_7FF91DD14EC0 @ rva 0xB4EC0 ====
int sub_7FF91DD14EC0()
{
  sub_7FF91E296FE0((unsigned int)&qword_7FF91E911F08, -855291928, 204623754, -1084791749, -87630269);
  return atexit(sub_7FF91E590CC0);
}


// ==== sub_7FF91DD14F00 @ rva 0xB4F00 ====
int sub_7FF91DD14F00()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E590E50);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E590E50);
  }
}


// ==== sub_7FF91DD14FC0 @ rva 0xB4FC0 ====
int sub_7FF91DD14FC0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E590EE0);
}


// ==== sub_7FF91DD15060 @ rva 0xB5060 ====
int sub_7FF91DD15060()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E591120);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E591120);
  }
}


// ==== sub_7FF91DD15120 @ rva 0xB5120 ====
int sub_7FF91DD15120()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E5911B0);
}


// ==== sub_7FF91DD151C0 @ rva 0xB51C0 ====
int sub_7FF91DD151C0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E5912A0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E5912A0);
  }
}


// ==== sub_7FF91DD15280 @ rva 0xB5280 ====
int sub_7FF91DD15280()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E591330);
}


// ==== sub_7FF91DD15320 @ rva 0xB5320 ====
int sub_7FF91DD15320()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E591420);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E591420);
  }
}


// ==== sub_7FF91DD153E0 @ rva 0xB53E0 ====
int sub_7FF91DD153E0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E5914B0);
}


// ==== sub_7FF91DD15480 @ rva 0xB5480 ====
int sub_7FF91DD15480()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E5915A0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E5915A0);
  }
}


// ==== sub_7FF91DD15540 @ rva 0xB5540 ====
int sub_7FF91DD15540()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E591630);
}


// ==== sub_7FF91DD155E0 @ rva 0xB55E0 ====
// attributes: thunk
__int64 sub_7FF91DD155E0()
{
  return sub_7FF91E05B9C0();
}


// ==== sub_7FF91DD155F0 @ rva 0xB55F0 ====
int sub_7FF91DD155F0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E591780);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E591780);
  }
}


// ==== sub_7FF91DD156B0 @ rva 0xB56B0 ====
int sub_7FF91DD156B0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E591810);
}


// ==== sub_7FF91DD15750 @ rva 0xB5750 ====
int sub_7FF91DD15750()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E5919E0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E5919E0);
  }
}


// ==== sub_7FF91DD15810 @ rva 0xB5810 ====
int sub_7FF91DD15810()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E591A70);
}


// ==== sub_7FF91DD158B0 @ rva 0xB58B0 ====
int sub_7FF91DD158B0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E591B60);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E591B60);
  }
}


// ==== sub_7FF91DD15970 @ rva 0xB5970 ====
int sub_7FF91DD15970()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E591BF0);
}


// ==== sub_7FF91DD15A10 @ rva 0xB5A10 ====
int sub_7FF91DD15A10()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E591CE0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E591CE0);
  }
}


// ==== sub_7FF91DD15AD0 @ rva 0xB5AD0 ====
int sub_7FF91DD15AD0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E591D70);
}


// ==== sub_7FF91DD15B70 @ rva 0xB5B70 ====
int sub_7FF91DD15B70()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E591F60);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E591F60);
  }
}


// ==== sub_7FF91DD15C30 @ rva 0xB5C30 ====
int sub_7FF91DD15C30()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E591FF0);
}


// ==== sub_7FF91DD15CD0 @ rva 0xB5CD0 ====
int sub_7FF91DD15CD0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E5920D0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E5920D0);
  }
}


// ==== sub_7FF91DD15D90 @ rva 0xB5D90 ====
int sub_7FF91DD15D90()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E592160);
}


// ==== sub_7FF91DD15E30 @ rva 0xB5E30 ====
int sub_7FF91DD15E30()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E592240);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E592240);
  }
}


// ==== sub_7FF91DD15EF0 @ rva 0xB5EF0 ====
int sub_7FF91DD15EF0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E5922D0);
}


// ==== sub_7FF91DD15F90 @ rva 0xB5F90 ====
int sub_7FF91DD15F90()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E5923B0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E5923B0);
  }
}


// ==== sub_7FF91DD16050 @ rva 0xB6050 ====
int sub_7FF91DD16050()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E592440);
}


// ==== sub_7FF91DD160F0 @ rva 0xB60F0 ====
int sub_7FF91DD160F0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E592530);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E592530);
  }
}


// ==== sub_7FF91DD161B0 @ rva 0xB61B0 ====
int sub_7FF91DD161B0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E5925C0);
}


// ==== sub_7FF91DD16250 @ rva 0xB6250 ====
int sub_7FF91DD16250()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E5926A0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E5926A0);
  }
}


// ==== sub_7FF91DD16310 @ rva 0xB6310 ====
int sub_7FF91DD16310()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E592730);
}


// ==== sub_7FF91DD163B0 @ rva 0xB63B0 ====
int sub_7FF91DD163B0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E592820);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E592820);
  }
}


// ==== sub_7FF91DD16470 @ rva 0xB6470 ====
int sub_7FF91DD16470()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E5928B0);
}


// ==== sub_7FF91DD16510 @ rva 0xB6510 ====
// attributes: thunk
__int64 sub_7FF91DD16510()
{
  return sub_7FF91E05B9C0();
}


// ==== sub_7FF91DD16520 @ rva 0xB6520 ====
int sub_7FF91DD16520()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E592990);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E592990);
  }
}


// ==== sub_7FF91DD165E0 @ rva 0xB65E0 ====
int sub_7FF91DD165E0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E592A20);
}


// ==== sub_7FF91DD16680 @ rva 0xB6680 ====
int sub_7FF91DD16680()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E592B00);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E592B00);
  }
}


// ==== sub_7FF91DD16740 @ rva 0xB6740 ====
int sub_7FF91DD16740()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E592B90);
}


// ==== sub_7FF91DD167E0 @ rva 0xB67E0 ====
int sub_7FF91DD167E0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E592C80);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E592C80);
  }
}


// ==== sub_7FF91DD168A0 @ rva 0xB68A0 ====
int sub_7FF91DD168A0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E592D10);
}


// ==== sub_7FF91DD16940 @ rva 0xB6940 ====
int sub_7FF91DD16940()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E592DF0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E592DF0);
  }
}


// ==== sub_7FF91DD16A00 @ rva 0xB6A00 ====
int sub_7FF91DD16A00()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E592E80);
}


// ==== sub_7FF91DD16AA0 @ rva 0xB6AA0 ====
// attributes: thunk
__int64 sub_7FF91DD16AA0()
{
  return sub_7FF91E05B9C0();
}


// ==== __acrt_uninitialize_tmpfile @ rva 0xB6AB0 ====
// Microsoft VisualC v14 64bit runtime
__int64 _acrt_uninitialize_tmpfile()
{
  sub_7FF91E06E6E0();
  return sub_7FF91E06E600();
}


// ==== sub_7FF91DD16AD0 @ rva 0xB6AD0 ====
int sub_7FF91DD16AD0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E592F60);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E592F60);
  }
}


// ==== sub_7FF91DD16B90 @ rva 0xB6B90 ====
int sub_7FF91DD16B90()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E592FF0);
}


// ==== sub_7FF91DD16C30 @ rva 0xB6C30 ====
int sub_7FF91DD16C30()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E593150);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E593150);
  }
}


// ==== sub_7FF91DD16CF0 @ rva 0xB6CF0 ====
int sub_7FF91DD16CF0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E5931E0);
}


// ==== sub_7FF91DD16D90 @ rva 0xB6D90 ====
int sub_7FF91DD16D90()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E5932D0);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E5932D0);
  }
}


// ==== sub_7FF91DD16E50 @ rva 0xB6E50 ====
int sub_7FF91DD16E50()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E593360);
}


// ==== sub_7FF91DD16EF0 @ rva 0xB6EF0 ====
int sub_7FF91DD16EF0()
{
  signed int LastError; // eax
  bool v1; // sf

  stru_7FF91E90FC40.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC40.LockCount = 0;
  stru_7FF91E90FC40.OwningThread = nullptr;
  stru_7FF91E90FC40.LockSemaphore = nullptr;
  stru_7FF91E90FC40.SpinCount = 0;
  dword_7FF91E90FC20 = 0;
  qword_7FF91E90FC28 = 0x7FF91DC60000uLL;
  qword_7FF91E90FC30 = (__int64)&unk_7FF91E89DA30;
  qword_7FF91E90FC38 = (__int64)&unk_7FF91E89DA30;
  if ( InitializeCriticalSectionEx(&stru_7FF91E90FC40, 0, 0) )
    goto LABEL_6;
  LastError = GetLastError();
  v1 = LastError < 0;
  if ( LastError > 0 )
    v1 = 1;
  if ( !v1 )
  {
LABEL_6:
    dword_7FF91E90FC20 = 72;
    return atexit(sub_7FF91E593530);
  }
  else
  {
    byte_7FF91E90FC10 = 1;
    return atexit(sub_7FF91E593530);
  }
}


// ==== sub_7FF91DD16FB0 @ rva 0xB6FB0 ====
int sub_7FF91DD16FB0()
{
  signed int LastError; // eax
  bool v1; // sf

  dword_7FF91E90FC70 = 72;
  stru_7FF91E90FC78.DebugInfo = nullptr;
  *(_QWORD *)&stru_7FF91E90FC78.LockCount = 0;
  stru_7FF91E90FC78.OwningThread = nullptr;
  stru_7FF91E90FC78.LockSemaphore = nullptr;
  stru_7FF91E90FC78.SpinCount = 0;
  qword_7FF91E90FCA8 = nullptr;
  qword_7FF91E90FCB0 = 0;
  qword_7FF91E90FCA0 = 0;
  if ( !InitializeCriticalSectionEx(&stru_7FF91E90FC78, 0, 0) )
  {
    LastError = GetLastError();
    v1 = LastError < 0;
    if ( LastError > 0 )
      v1 = 1;
    if ( v1 )
    {
      byte_7FF91E90FC10 = 1;
      dword_7FF91E90FC70 = 0;
    }
  }
  return atexit(sub_7FF91E5935C0);
}


// ==== sub_7FF91DD17050 @ rva 0xB7050 ====
__int64 sub_7FF91DD17050()
{
  return sub_7FF91E07C5A0(sub_7FF91E091AA0);
}


// ==== sub_7FF91DD17060 @ rva 0xB7060 ====
// Hidden C++ exception states: #wind=1
int sub_7FF91DD17060()
{
  __int64 v0; // rax
  char *v1; // rbx
  char *v2; // rax
  unsigned __int64 v3; // rbx
  _QWORD v5[3]; // [rsp+20h] [rbp-48h] BYREF
  void *Block[3]; // [rsp+38h] [rbp-30h] BYREF
  unsigned __int64 v7; // [rsp+50h] [rbp-18h]

  v5[2] = -2;
  v5[0] = byte_7FF91E722CD8;
  v5[1] = 0;
  sub_7FF91DD18850(&byte_7FF91E8AEB60);
  qword_7FF91E8AEB78 = 15;
  qword_7FF91E8AEB70 = 0;
  byte_7FF91E8AEB60 = 0;
  v0 = sub_7FF91E07C730(v5, Block);
  sub_7FF91DD71280(&byte_7FF91E8AEB60, v0);
  if ( v7 >= 0x10 )
  {
    v1 = (char *)Block[0];
    nullsub_2(Block, Block);
    if ( v7 + 1 >= 0x1000 )
    {
      if ( ((unsigned __int8)v1 & 0x1F) != 0 )
        invalid_parameter_noinfo_noreturn();
      v2 = *((char **)v1 - 1);
      if ( v2 >= v1 )
        invalid_parameter_noinfo_noreturn();
      v3 = v1 - v2;
      if ( v3 < 8 )
        invalid_parameter_noinfo_noreturn();
      if ( v3 > 0x27 )
        invalid_parameter_noinfo_noreturn();
      v1 = v2;
    }
    j_free(v1);
  }
  v7 = 15;
  Block[2] = nullptr;
  LOBYTE(Block[0]) = 0;
  nullsub_1(Block);
  return atexit(sub_7FF91E5936D0);
}


// ==== sub_7FF91DD171A0 @ rva 0xB71A0 ====
int sub_7FF91DD171A0()
{
  sub_7FF91DD18850(&byte_7FF91E9125C0);
  qword_7FF91E9125D8 = 15;
  qword_7FF91E9125D0 = 0;
  byte_7FF91E9125C0 = 0;
  return atexit(sub_7FF91E5936E0);
}


// ==== sub_7FF91DD171E0 @ rva 0xB71E0 ====
// Hidden C++ exception states: #wind=1
int sub_7FF91DD171E0()
{
  __int64 v0; // rax
  char *v1; // rbx
  char *v2; // rax
  unsigned __int64 v3; // rbx
  _QWORD v5[3]; // [rsp+20h] [rbp-48h] BYREF
  void *Block[3]; // [rsp+38h] [rbp-30h] BYREF
  unsigned __int64 v7; // [rsp+50h] [rbp-18h]

  v5[2] = -2;
  v5[0] = byte_7FF91E722CD8;
  v5[1] = 0;
  sub_7FF91DD18850(&byte_7FF91E8AEB88);
  qword_7FF91E8AEBA0 = 15;
  qword_7FF91E8AEB98 = 0;
  byte_7FF91E8AEB88 = 0;
  v0 = sub_7FF91E07C730(v5, Block);
  sub_7FF91DD71280(&byte_7FF91E8AEB88, v0);
  if ( v7 >= 0x10 )
  {
    v1 = (char *)Block[0];
    nullsub_2(Block, Block);
    if ( v7 + 1 >= 0x1000 )
    {
      if ( ((unsigned __int8)v1 & 0x1F) != 0 )
        invalid_parameter_noinfo_noreturn();
      v2 = *((char **)v1 - 1);
      if ( v2 >= v1 )
        invalid_parameter_noinfo_noreturn();
      v3 = v1 - v2;
      if ( v3 < 8 )
        invalid_parameter_noinfo_noreturn();
      if ( v3 > 0x27 )
        invalid_parameter_noinfo_noreturn();
      v1 = v2;
    }
    j_free(v1);
  }
  v7 = 15;
  Block[2] = nullptr;
  LOBYTE(Block[0]) = 0;
  nullsub_1(Block);
  return atexit(sub_7FF91E5936F0);
}


// ==== sub_7FF91DD17320 @ rva 0xB7320 ====
void sub_7FF91DD17320()
{
  byte_7FF91E912614 = 1;
}


// ==== sub_7FF91DD17330 @ rva 0xB7330 ====
__int64 sub_7FF91DD17330()
{
  return sub_7FF91DD79C00((struct std::once_flag *)&unk_7FF91E9130E8);
}


// ==== sub_7FF91DD17350 @ rva 0xB7350 ====
int sub_7FF91DD17350()
{
  return atexit((void (__cdecl *)())sub_7FF91E593800);
}


// ==== sub_7FF91DD17360 @ rva 0xB7360 ====
int sub_7FF91DD17360()
{
  return atexit((void (__cdecl *)())sub_7FF91E593810);
}


// ==== sub_7FF91DD17370 @ rva 0xB7370 ====
int sub_7FF91DD17370()
{
  return atexit((void (__cdecl *)())sub_7FF91E593820);
}


// ==== sub_7FF91DD17380 @ rva 0xB7380 ====
int sub_7FF91DD17380()
{
  return atexit((void (__cdecl *)())sub_7FF91E593830);
}


// ==== sub_7FF91DD17390 @ rva 0xB7390 ====
int sub_7FF91DD17390()
{
  return atexit((void (__cdecl *)())sub_7FF91E593840);
}


// ==== sub_7FF91DD173A0 @ rva 0xB73A0 ====
int sub_7FF91DD173A0()
{
  return atexit((void (__cdecl *)())sub_7FF91E593850);
}


// ==== sub_7FF91DD173B0 @ rva 0xB73B0 ====
int sub_7FF91DD173B0()
{
  return atexit((void (__cdecl *)())sub_7FF91E593860);
}


// ==== sub_7FF91DD173C0 @ rva 0xB73C0 ====
int sub_7FF91DD173C0()
{
  return atexit((void (__cdecl *)())sub_7FF91E593870);
}


// ==== sub_7FF91DD173D0 @ rva 0xB73D0 ====
int sub_7FF91DD173D0()
{
  return atexit((void (__cdecl *)())sub_7FF91E593880);
}


// ==== sub_7FF91DD173E0 @ rva 0xB73E0 ====
int sub_7FF91DD173E0()
{
  return atexit((void (__cdecl *)())sub_7FF91E593890);
}


// ==== sub_7FF91DD173F0 @ rva 0xB73F0 ====
int sub_7FF91DD173F0()
{
  std::exception::exception((std::exception *)&qword_7FF91E915658);
  return atexit(sub_7FF91E5938A0);
}


// ==== sub_7FF91DD17410 @ rva 0xB7410 ====
int sub_7FF91DD17410()
{
  return atexit(sub_7FF91E5938B0);
}


// ==== sub_7FF91DD17420 @ rva 0xB7420 ====
__int64 sub_7FF91DD17420()
{
  return sub_7FF91E297460(&qword_7FF91E915658);
}


// ==== sub_7FF91DD17430 @ rva 0xB7430 ====
int sub_7FF91DD17430()
{
  return atexit((void (__cdecl *)())sub_7FF91E5939D0);
}


// ==== sub_7FF91DD17440 @ rva 0xB7440 ====
int sub_7FF91DD17440()
{
  return atexit((void (__cdecl *)())sub_7FF91E5939E0);
}


// ==== sub_7FF91DD17450 @ rva 0xB7450 ====
int sub_7FF91DD17450()
{
  return atexit((void (__cdecl *)())sub_7FF91E5939F0);
}


// ==== sub_7FF91DD17460 @ rva 0xB7460 ====
int sub_7FF91DD17460()
{
  return atexit((void (__cdecl *)())sub_7FF91E593A00);
}


// ==== sub_7FF91DD17470 @ rva 0xB7470 ====
int sub_7FF91DD17470()
{
  return atexit((void (__cdecl *)())sub_7FF91E593A10);
}


// ==== sub_7FF91DD17480 @ rva 0xB7480 ====
int sub_7FF91DD17480()
{
  return atexit((void (__cdecl *)())sub_7FF91E593A20);
}


// ==== sub_7FF91DD1748C @ rva 0xB748C ====
int sub_7FF91DD1748C()
{
  std::_Init_locks::_Init_locks((std::_Init_locks *)&unk_7FF91E915680);
  return atexit(sub_7FF91E593A30);
}


// ==== sub_7FF91DD174AC @ rva 0xB74AC ====
int sub_7FF91DD174AC()
{
  return atexit(sub_7FF91E593A3C);
}


// ==== sub_7FF91DD174B8 @ rva 0xB74B8 ====
int sub_7FF91DD174B8()
{
  return atexit((void (__cdecl *)())std::`dynamic atexit destructor for 'classic_locale'');
}


// ==== sub_7FF91DD174C4 @ rva 0xB74C4 ====
int sub_7FF91DD174C4()
{
  sub_7FF91DD4F660(&qword_7FF91E915C20, &qword_7FF91E915C90, 0, 1);
  return atexit(sub_7FF91E593A90);
}


// ==== ??__Efout@std@@YAXXZ @ rva 0xB74F4 ====
int std::`dynamic initializer for 'fout''()
{
  FILE *v0; // rbx

  v0 = _acrt_iob_func(1u);
  sub_7FF91DD4FA50(&qword_7FF91E915C90);
  qword_7FF91E915C90 = (__int64)&std::filebuf::`vftable';
  sub_7FF91DEE8040(&qword_7FF91E915C90, v0, 0);
  return atexit(sub_7FF91E593AF0);
}


// ==== sub_7FF91DD17544 @ rva 0xB7544 ====
void *sub_7FF91DD17544()
{
  __int64 *v0; // r8

  v0 = &qword_7FF91E915C20;
  qword_7FF91E915ED8 = (__int64)&qword_7FF91E915C20;
  if ( qword_7FF91E915ED0 )
  {
    *(_QWORD *)(*(int *)(*(_QWORD *)qword_7FF91E915ED0 + 4LL) + qword_7FF91E915ED0 + 80) = &qword_7FF91E915C20;
    v0 = (__int64 *)qword_7FF91E915ED8;
  }
  if ( qword_7FF91E915EE0 )
  {
    *(_QWORD *)(*(int *)(*(_QWORD *)qword_7FF91E915EE0 + 4LL) + qword_7FF91E915EE0 + 80) = v0;
    v0 = (__int64 *)qword_7FF91E915ED8;
  }
  if ( qword_7FF91E915EE8 )
    *(_QWORD *)(*(int *)(*(_QWORD *)qword_7FF91E915EE8 + 4LL) + qword_7FF91E915EE8 + 80) = v0;
  return &unk_7FF91E915C11;
}


// ==== sub_7FF91DD17550 @ rva 0xB7550 ====
int sub_7FF91DD17550()
{
  std::_Init_locks::_Init_locks((std::_Init_locks *)&unk_7FF91E915C10);
  return atexit(sub_7FF91E593AFC);
}


// ==== sub_7FF91DD17570 @ rva 0xB7570 ====
int sub_7FF91DD17570()
{
  return atexit(`dynamic atexit destructor for 'init_atexit'');
}


// ==== sub_7FF91DD1757C @ rva 0xB757C ====
int sub_7FF91DD1757C()
{
  std::_Init_locks::_Init_locks((std::_Init_locks *)&unk_7FF91E915F10);
  return atexit(sub_7FF91E593B50);
}


// ==== sub_7FF91DD1759C @ rva 0xB759C ====
int sub_7FF91DD1759C()
{
  sub_7FF91E2D6FE0(&unk_7FF91E9168E0);
  return atexit(sub_7FF91E593B5C);
}


// ==== sub_7FF91DD175C0 @ rva 0xB75C0 ====
int sub_7FF91DD175C0()
{
  sub_7FF91DF542D0(&unk_7FF91E90FD98);
  return atexit(sub_7FF91E593B70);
}


// ==== sub_7FF91DD175E0 @ rva 0xB75E0 ====
int sub_7FF91DD175E0()
{
  sub_7FF91DF54730(aPf);
  return atexit(sub_7FF91E593BD0);
}


// ==== sub_7FF91DD17600 @ rva 0xB7600 ====
int sub_7FF91DD17600()
{
  return atexit(sub_7FF91E593CEC);
}


// ==== sub_7FF91DD1760C @ rva 0xB760C ====
FILE *sub_7FF91DD1760C()
{
  FILE *result; // rax

  result = _acrt_iob_func(2u);
  qword_7FF91E9169D0 = result;
  return result;
}


// ==== ??__E?s_cookie@Security@details@Concurrency@@2_KA@@YAXXZ @ rva 0xB7628 ====
unsigned __int64 `dynamic initializer for 'public: static unsigned __int64 Concurrency::details::Security::s_cookie''()
{
  unsigned __int64 result; // rax

  result = Concurrency::details::Security::InitializeCookie();
  qword_7FF91E916A70 = result;
  return result;
}


// ==== sub_7FF91DD17640 @ rva 0xB7640 ====
void sub_7FF91DD17640()
{
  InitializeSListHead(&stru_7FF91E916A60);
}


// ==== sub_7FF91DD17670 @ rva 0xB7670 ====
__int64 __fastcall sub_7FF91DD17670(__int64 a1, __int64 a2)
{
  return a2;
}


// ==== j_memchr @ rva 0xB7680 ====
// attributes: thunk
void *__cdecl j_memchr(const void *Buf, int Val, size_t MaxCount)
{
  return memchr(Buf, Val, MaxCount);
}


// ==== ?copy@?$char_traits@D@std@@SAPEADPEADPEBD_K@Z @ rva 0xB76B0 ====
__int64 __fastcall std::char_traits<char>::copy(__int64 a1, __int64 a2, __int64 a3)
{
  if ( a3 )
    sub_7FF91E30DC00(a1, a2, a3);
  return a1;
}


// ==== ?assign@?$char_traits@D@std@@SAXAEADAEBD@Z @ rva 0xB76E0 ====
__int64 __fastcall std::char_traits<char>::assign(_BYTE *a1, unsigned __int8 *a2)
{
  __int64 result; // rax

  result = *a2;
  *a1 = result;
  return result;
}


// ==== nullsub_120 @ rva 0xB76F0 ====
void nullsub_120()
{
  ;
}


// ==== sub_7FF91DD17700 @ rva 0xB7700 ====
void *__fastcall sub_7FF91DD17700(unsigned __int64 a1, unsigned __int64 a2, char a3)
{
  size_t v4; // rcx
  void *v5; // rax

  if ( !a1 )
    return nullptr;
  if ( 0xFFFFFFFFFFFFFFFFuLL / a2 < a1 )
    goto LABEL_9;
  v4 = a2 * a1;
  if ( a3 && v4 >= 0x1000 )
  {
    if ( v4 + 39 >= v4 )
    {
      v5 = operator new(v4 + 39);
      *(_QWORD *)((((unsigned __int64)v5 + 39) & 0xFFFFFFFFFFFFFFE0uLL) - 8) = v5;
      return (void *)(((unsigned __int64)v5 + 39) & 0xFFFFFFFFFFFFFFE0uLL);
    }
LABEL_9:
    Concurrency::cancel_current_task();
  }
  return operator new(v4);
}


// ==== sub_7FF91DD17770 @ rva 0xB7770 ====
void __fastcall sub_7FF91DD17770(_QWORD *a1, unsigned __int64 a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rax

  if ( a2 > 0xFFFFFFFFFFFFFFFFuLL / a3 )
    goto LABEL_8;
  if ( a3 * a2 >= 0x1000 )
  {
    if ( ((unsigned __int8)a1 & 0x1F) == 0 )
    {
      v3 = *(a1 - 1);
      if ( v3 < (unsigned __int64)a1 && (unsigned __int64)a1 - v3 - 8 <= 0x1F )
      {
        a1 = (_QWORD *)*(a1 - 1);
        goto LABEL_7;
      }
    }
LABEL_8:
    invalid_parameter_noinfo_noreturn();
  }
LABEL_7:
  j_free(a1);
}


// ==== sub_7FF91DD177D0 @ rva 0xB77D0 ====
__int64 __fastcall sub_7FF91DD177D0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD177E0 @ rva 0xB77E0 ====
__int64 __fastcall sub_7FF91DD177E0(__int64 a1)
{
  return *(unsigned int *)(a1 + 12);
}


// ==== creal @ rva 0xB77F0 ====
double __cdecl creal(_Dcomplex *Z)
{
  return Z->_Val[0];
}


// ==== sub_7FF91DD17800 @ rva 0xB7800 ====
__int64 __fastcall sub_7FF91DD17800(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD17810 @ rva 0xB7810 ====
__int64 __fastcall sub_7FF91DD17810(__int64 a1, __int64 a2)
{
  LARGE_INTEGER PerformanceCount; // [rsp+30h] [rbp+8h] BYREF

  *(_QWORD *)a1 = 0;
  *(_BYTE *)(a1 + 16) = 0;
  if ( a2 < 1 )
    a2 = 1;
  *(_QWORD *)(a1 + 8) = a2;
  QueryPerformanceCounter(&PerformanceCount);
  *(_QWORD *)a1 = qword_7FF91E9194C0 + PerformanceCount.QuadPart;
  return a1;
}


// ==== sub_7FF91DD17880 @ rva 0xB7880 ====
__int64 __fastcall sub_7FF91DD17880(__int64 a1, double a2)
{
  double v3; // xmm0_8
  double v4; // xmm1_8
  __int64 v5; // rax
  LARGE_INTEGER PerformanceCount; // [rsp+30h] [rbp+8h] BYREF

  *(_QWORD *)a1 = 0;
  v3 = (double)(int)qword_7FF91E9194B8;
  *(_BYTE *)(a1 + 16) = 0;
  v4 = a2 * 1000.0 / 1000.0 * v3;
  v5 = (unsigned int)(int)v4;
  if ( !(int)v4 )
    v5 = 1;
  *(_QWORD *)(a1 + 8) = v5;
  QueryPerformanceCounter(&PerformanceCount);
  *(_QWORD *)a1 = qword_7FF91E9194C0 + PerformanceCount.QuadPart;
  return a1;
}


// ==== sub_7FF91DD178F0 @ rva 0xB78F0 ====
void __fastcall sub_7FF91DD178F0(__int64 a1)
{
  *(_BYTE *)(a1 + 320) = 1;
}


// ==== sub_7FF91DD17900 @ rva 0xB7900 ====
void __fastcall sub_7FF91DD17900(std::locale::_Locimp *this)
{
  _DWORD *v2; // rcx
  _DWORD *v3; // rcx

  v2 = (_DWORD *)(*((_QWORD *)this + 40) - 16LL);
  if ( (*v2 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v2, 0xFFFFFFFF) )
    j_j_free_0(v2);
  v3 = (_DWORD *)(*((_QWORD *)this + 39) - 16LL);
  if ( (*v3 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v3, 0xFFFFFFFF) )
    j_j_free_0(v3);
  std::locale::_Locimp::~_Locimp(this);
}


// ==== sub_7FF91DD17970 @ rva 0xB7970 ====
__int64 __fastcall sub_7FF91DD17970(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z @ rva 0xB79A0 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== unknown_libname_6912 @ rva 0xB79B0 ====
// Microsoft VisualC v14 64bit runtime
// Microsoft VisualC 64bit universal runtime
_QWORD *__fastcall unknown_libname_6912(_QWORD *a1, __int64 a2, __int64 a3)
{
  *a1 = a2;
  a1[1] = a3;
  return a1;
}


// ==== sub_7FF91DD179C0 @ rva 0xB79C0 ====
__int64 __fastcall sub_7FF91DD179C0(__int64 a1)
{
  return *(unsigned int *)(a1 + 12);
}


// ==== __except_get_jumpbuf_sp @ rva 0xB79D0 ====
__int64 __fastcall _except_get_jumpbuf_sp(__int64 a1)
{
  return *(_QWORD *)(a1 + 16);
}


// ==== sub_7FF91DD17A30 @ rva 0xB7A30 ====
_QWORD *__fastcall sub_7FF91DD17A30(_QWORD *a1, _QWORD *a2, __int64 a3, __int64 a4)
{
  _QWORD *v5; // rbx
  _QWORD *v6; // rax
  __int64 v7; // rsi

  v5 = a1;
  if ( a1[3] < 0x10u )
    v6 = a1;
  else
    v6 = (_QWORD *)*a1;
  v7 = a3 - (_QWORD)v6;
  sub_7FF91DD17DC0(a1, a3 - (_QWORD)v6, a4 - a3);
  if ( v5[3] >= 0x10u )
    v5 = (_QWORD *)*v5;
  *a2 = (char *)v5 + v7;
  return a2;
}


// ==== sub_7FF91DD17A90 @ rva 0xB7A90 ====
void __fastcall sub_7FF91DD17A90(_QWORD *a1)
{
  unsigned __int64 v1; // rax
  _QWORD *v2; // rbx
  _QWORD *v3; // rcx
  unsigned __int64 v4; // rax
  bool v5; // cf

  v1 = a1[3];
  v2 = a1;
  if ( v1 >= 0x10 )
  {
    v3 = (_QWORD *)*a1;
    if ( v1 + 1 >= 0x1000 )
    {
      if ( ((unsigned __int8)v3 & 0x1F) != 0
        || (v4 = *(v3 - 1), v4 >= (unsigned __int64)v3)
        || (unsigned __int64)v3 - v4 - 8 > 0x1F )
      {
        invalid_parameter_noinfo_noreturn();
      }
      v3 = (_QWORD *)*(v3 - 1);
    }
    j_free(v3);
  }
  v2[3] = 15;
  v5 = v2[3] < 0x10u;
  v2[2] = 0;
  if ( !v5 )
    v2 = (_QWORD *)*v2;
  *(_BYTE *)v2 = 0;
}


// ==== sub_7FF91DD17B00 @ rva 0xB7B00 ====
__int64 __fastcall sub_7FF91DD17B00(__int64 a1, _BYTE *a2)
{
  __int64 v2; // r8

  v2 = 0;
  *(_QWORD *)(a1 + 24) = 15;
  *(_QWORD *)(a1 + 16) = 0;
  *(_BYTE *)a1 = 0;
  if ( *a2 )
  {
    v2 = -1;
    do
      ++v2;
    while ( a2[v2] );
  }
  sub_7FF91DD17EC0(a1, a2, v2);
  return a1;
}


// ==== sub_7FF91DD17B50 @ rva 0xB7B50 ====
__int64 __fastcall sub_7FF91DD17B50(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 24) = 15;
  *(_QWORD *)(a1 + 16) = 0;
  *(_BYTE *)a1 = 0;
  sub_7FF91DD17FF0(a1, a2, 0, -1);
  return a1;
}


// ==== nullsub_1 @ rva 0xB7B90 ====
void nullsub_1()
{
  ;
}


// ==== nullsub_121 @ rva 0xB7BA0 ====
void nullsub_121()
{
  ;
}


// ==== nullsub_122 @ rva 0xB7BB0 ====
void nullsub_122()
{
  ;
}


// ==== sub_7FF91DD17BC0 @ rva 0xB7BC0 ====
__int64 __fastcall sub_7FF91DD17BC0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD17BD0 @ rva 0xB7BD0 ====
__int64 __fastcall sub_7FF91DD17BD0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD17BE0 @ rva 0xB7BE0 ====
__int64 __fastcall sub_7FF91DD17BE0(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD17BF0 @ rva 0xB7BF0 ====
__int64 __fastcall sub_7FF91DD17BF0(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD17C20 @ rva 0xB7C20 ====
__int64 __fastcall sub_7FF91DD17C20(__int64 a1)
{
  return *(unsigned int *)(a1 + 12);
}


// ==== sub_7FF91DD17C30 @ rva 0xB7C30 ====
__int64 __fastcall sub_7FF91DD17C30(__int64 a1)
{
  return a1;
}


// ==== nullsub_123 @ rva 0xB7C40 ====
void nullsub_123()
{
  ;
}


// ==== sub_7FF91DD17C50 @ rva 0xB7C50 ====
__int64 __fastcall sub_7FF91DD17C50(_QWORD *a1, _QWORD *a2)
{
  return *a1 - *a2;
}


// ==== ??H?$_String_iterator@V?$_String_val@U?$_Simple_types@D@std@@@std@@@std@@QEBA?AV01@_J@Z @ rva 0xB7C60 ====
_QWORD *__fastcall std::_String_iterator<std::_String_val<std::_Simple_types<char>>>::operator+(
        _QWORD *a1,
        _QWORD *a2,
        __int64 a3)
{
  *a2 = a3 + *a1;
  return a2;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_0 @ rva 0xB7C70 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD17C90 @ rva 0xB7C90 ====
__int64 __fastcall sub_7FF91DD17C90(__int64 a1, __int64 a2)
{
  return a2;
}


// ==== sub_7FF91DD17CA0 @ rva 0xB7CA0 ====
__int64 __fastcall sub_7FF91DD17CA0(__int64 a1, __int64 a2)
{
  return a2;
}


// ==== get_srw_lock @ rva 0xB7CB0 ====
__int64 __fastcall get_srw_lock(__int64 a1)
{
  return a1 + 16;
}


// ==== sub_7FF91DD17CC0 @ rva 0xB7CC0 ====
__int64 __fastcall sub_7FF91DD17CC0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD17CD0 @ rva 0xB7CD0 ====
__int64 __fastcall sub_7FF91DD17CD0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD17CE0 @ rva 0xB7CE0 ====
__int64 __fastcall sub_7FF91DD17CE0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD17CF0 @ rva 0xB7CF0 ====
__int64 __fastcall sub_7FF91DD17CF0(__int64 a1)
{
  *(_QWORD *)(a1 + 16) = 0;
  *(_QWORD *)(a1 + 24) = 0;
  return a1;
}


// ==== sub_7FF91DD17D00 @ rva 0xB7D00 ====
_QWORD *__fastcall sub_7FF91DD17D00(_QWORD *a1)
{
  if ( a1[3] < 0x10u )
    return a1;
  else
    return (_QWORD *)*a1;
}


// ==== sub_7FF91DD17D20 @ rva 0xB7D20 ====
void __fastcall sub_7FF91DD17D20(_QWORD *a1, char a2, __int64 a3)
{
  _QWORD *v4; // rdi
  unsigned __int64 v5; // rax
  _QWORD *v6; // rbx
  unsigned __int64 v7; // rax
  bool v8; // cf

  v4 = a1;
  if ( a2 )
  {
    v5 = a1[3];
    if ( v5 >= 0x10 )
    {
      v6 = (_QWORD *)*a1;
      if ( a3 )
      {
        sub_7FF91E30DC00(a1, *a1, a3);
        v5 = v4[3];
      }
      if ( v5 + 1 >= 0x1000 )
      {
        if ( ((unsigned __int8)v6 & 0x1F) != 0
          || (v7 = *(v6 - 1), v7 >= (unsigned __int64)v6)
          || (unsigned __int64)v6 - v7 - 8 > 0x1F )
        {
          invalid_parameter_noinfo_noreturn();
        }
        v6 = (_QWORD *)*(v6 - 1);
      }
      j_free(v6);
    }
  }
  v4[3] = 15;
  v8 = v4[3] < 0x10u;
  v4[2] = a3;
  if ( !v8 )
    v4 = (_QWORD *)*v4;
  *((_BYTE *)v4 + a3) = 0;
}


// ==== sub_7FF91DD17DC0 @ rva 0xB7DC0 ====
_QWORD *__fastcall sub_7FF91DD17DC0(_QWORD *a1, unsigned __int64 a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rdi
  _QWORD *v6; // rax
  unsigned __int64 v7; // rdi
  bool v8; // cf

  v3 = a1[2];
  if ( v3 < a2 )
    std::vector<void *>::_Xlen();
  if ( v3 - a2 > a3 )
  {
    if ( a3 )
    {
      if ( a1[3] < 0x10u )
        v6 = a1;
      else
        v6 = (_QWORD *)*a1;
      v7 = v3 - a3;
      if ( v7 != a2 )
        sub_7FF91E30DC00((char *)v6 + a2, (char *)v6 + a2 + a3, v7 - a2);
      v8 = a1[3] < 0x10u;
      a1[2] = v7;
      if ( !v8 )
      {
        *(_BYTE *)(*a1 + v7) = 0;
        return a1;
      }
      *((_BYTE *)a1 + v7) = 0;
    }
    return a1;
  }
  else
  {
    a1[2] = a2;
    if ( a1[3] < 0x10u )
    {
      *((_BYTE *)a1 + a2) = 0;
      return a1;
    }
    else
    {
      *(_BYTE *)(*a1 + a2) = 0;
      return a1;
    }
  }
}


// ==== sub_7FF91DD17EC0 @ rva 0xB7EC0 ====
__int64 __fastcall sub_7FF91DD17EC0(_QWORD *a1, unsigned __int64 a2, unsigned __int64 a3)
{
  _QWORD *v5; // rbx
  unsigned __int64 v6; // rdx
  _QWORD *v7; // rax
  _BYTE *v8; // rax
  _QWORD *v10; // rcx
  bool v11; // cf
  _QWORD *v12; // rax

  v5 = a1;
  if ( a2 )
  {
    v6 = a1[3];
    v7 = v6 < 0x10 ? a1 : (_QWORD *)*a1;
    if ( a2 >= (unsigned __int64)v7 )
    {
      if ( v6 >= 0x10 )
        a1 = (_QWORD *)*a1;
      if ( (unsigned __int64)a1 + v5[2] > a2 )
      {
        if ( v6 < 0x10 )
          v8 = v5;
        else
          v8 = (_BYTE *)*v5;
        return sub_7FF91DD17FF0(v5, v5, a2 - (_QWORD)v8, a3);
      }
    }
  }
  if ( a3 == -1 )
    std::vector<void *>::_Xlen(v5);
  if ( v5[3] < a3 )
  {
    sub_7FF91DD18400(v5, a3, v5[2]);
    if ( !a3 )
      return (__int64)v5;
LABEL_16:
    if ( v5[3] < 0x10u )
      v10 = v5;
    else
      v10 = (_QWORD *)*v5;
    if ( a3 )
      sub_7FF91E30DC00(v10, a2, a3);
    v11 = v5[3] < 0x10u;
    v5[2] = a3;
    if ( v11 )
      v12 = v5;
    else
      v12 = (_QWORD *)*v5;
    *((_BYTE *)v12 + a3) = 0;
    return (__int64)v5;
  }
  if ( a3 )
    goto LABEL_16;
  v11 = v5[3] < 0x10u;
  v5[2] = 0;
  if ( v11 )
    *(_BYTE *)v5 = 0;
  else
    *(_BYTE *)*v5 = 0;
  return (__int64)v5;
}


// ==== sub_7FF91DD17FF0 @ rva 0xB7FF0 ====
_QWORD *__fastcall sub_7FF91DD17FF0(_QWORD *a1, _QWORD *a2, unsigned __int64 a3, unsigned __int64 a4)
{
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // rdi
  _QWORD *v7; // rsi
  _QWORD *v8; // rbx
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rax
  _QWORD *v11; // rcx
  bool v12; // cf
  _QWORD *v13; // rax

  v4 = a2[2];
  v5 = a4;
  v7 = a2;
  v8 = a1;
  if ( v4 < a3 )
    std::vector<void *>::_Xlen(a2);
  v9 = v4 - a3;
  if ( a4 > v9 )
    v5 = v9;
  if ( a1 == a2 )
  {
    v10 = a3 + v5;
    if ( a1[2] < a3 + v5 )
      std::vector<void *>::_Xlen(a1);
    a1[2] = v10;
    if ( a1[3] >= 0x10u )
      a1 = (_QWORD *)*a1;
    *((_BYTE *)a1 + v10) = 0;
    sub_7FF91DD17DC0(v8, 0, a3);
  }
  else
  {
    if ( v5 == -1 )
      std::vector<void *>::_Xlen(a1);
    if ( a1[3] >= v5 )
    {
      if ( !v5 )
      {
        v12 = a1[3] < 0x10u;
        a1[2] = 0;
        if ( v12 )
          *(_BYTE *)a1 = 0;
        else
          *(_BYTE *)*a1 = 0;
        return v8;
      }
    }
    else
    {
      sub_7FF91DD18400(a1, v5, a1[2]);
      if ( !v5 )
        return v8;
    }
    if ( v7[3] >= 0x10u )
      v7 = (_QWORD *)*v7;
    if ( v8[3] < 0x10u )
      v11 = v8;
    else
      v11 = (_QWORD *)*v8;
    sub_7FF91E30DC00(v11, (char *)v7 + a3, v5);
    v12 = v8[3] < 0x10u;
    v8[2] = v5;
    if ( v12 )
      v13 = v8;
    else
      v13 = (_QWORD *)*v8;
    *((_BYTE *)v13 + v5) = 0;
  }
  return v8;
}


// ==== sub_7FF91DD18110 @ rva 0xB8110 ====
__int64 __fastcall sub_7FF91DD18110(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18120 @ rva 0xB8120 ====
__int64 __fastcall sub_7FF91DD18120(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18130 @ rva 0xB8130 ====
__int64 __fastcall sub_7FF91DD18130(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18140 @ rva 0xB8140 ====
__int64 __fastcall sub_7FF91DD18140(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18150 @ rva 0xB8150 ====
__int64 __fastcall sub_7FF91DD18150(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18160 @ rva 0xB8160 ====
__int64 __fastcall sub_7FF91DD18160(__int64 a1)
{
  return a1;
}


// ==== nullsub_124 @ rva 0xB8170 ====
void nullsub_124()
{
  ;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_1 @ rva 0xB8180 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD18190 @ rva 0xB8190 ====
_QWORD *__fastcall sub_7FF91DD18190(_QWORD *a1, __int64 a2)
{
  *a1 += a2;
  return a1;
}


// ==== sub_7FF91DD181B0 @ rva 0xB81B0 ====
__int64 __fastcall sub_7FF91DD181B0(__int64 a1)
{
  return a1;
}


// ==== ?deallocate@?$allocator@D@std@@QEAAXQEAD_K@Z @ rva 0xB81C0 ====
void __fastcall std::allocator<char>::deallocate(__int64 a1, _QWORD *a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rax

  if ( a3 >= 0x1000 )
  {
    if ( ((unsigned __int8)a2 & 0x1F) != 0
      || (v3 = *(a2 - 1), v3 >= (unsigned __int64)a2)
      || (unsigned __int64)a2 - v3 - 8 > 0x1F )
    {
      invalid_parameter_noinfo_noreturn();
    }
    a2 = (_QWORD *)*(a2 - 1);
  }
  j_free(a2);
}


// ==== sub_7FF91DD18200 @ rva 0xB8200 ====
__int64 __fastcall sub_7FF91DD18200(__int64 a1)
{
  return a1 + 24;
}


// ==== get_srw_lock_0 @ rva 0xB8210 ====
__int64 __fastcall get_srw_lock_0(__int64 a1)
{
  return a1 + 16;
}


// ==== sub_7FF91DD18220 @ rva 0xB8220 ====
__int64 __fastcall sub_7FF91DD18220(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18230 @ rva 0xB8230 ====
__int64 __fastcall sub_7FF91DD18230(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18240 @ rva 0xB8240 ====
void __fastcall sub_7FF91DD18240(__int64 a1, unsigned __int64 a2)
{
  if ( *(_QWORD *)(a1 + 16) < a2 )
    std::vector<void *>::_Xlen(a1);
}


// ==== ?_Xlen@?$vector@PEAXV?$allocator@PEAX@std@@@std@@IEBAXXZ @ rva 0xB8260 ====
void __noreturn std::vector<void *>::_Xlen()
{
  sub_7FF91E2A81A4("string too long");
}


// ==== sub_7FF91DD182C0 @ rva 0xB82C0 ====
bool __fastcall sub_7FF91DD182C0(_QWORD *a1, unsigned __int64 a2, char a3)
{
  unsigned __int64 v5; // r8
  bool v6; // zf
  bool v7; // cf

  if ( a2 == -1 )
    std::vector<void *>::_Xlen();
  if ( a1[3] >= a2 )
  {
    if ( a3 && a2 < 0x10 )
    {
      v5 = a1[2];
      if ( a2 < v5 )
        v5 = a2;
      sub_7FF91DD17D20(a1, 1, v5);
      return a2 != 0;
    }
    else
    {
      v6 = a2 == 0;
      if ( !a2 )
      {
        v7 = a1[3] < 0x10u;
        a1[2] = 0;
        if ( !v7 )
          a1 = (_QWORD *)*a1;
        *(_BYTE *)a1 = 0;
        v6 = 1;
      }
      return !v6;
    }
  }
  else
  {
    sub_7FF91DD18400(a1, a2, a1[2]);
    return a2 != 0;
  }
}


// ==== unknown_libname_4219 @ rva 0xB8360 ====
// Microsoft VisualC v14 64bit runtime
unsigned __int64 __fastcall unknown_libname_4219(__int64 a1, __int64 a2, unsigned __int64 a3)
{
  unsigned __int64 result; // rax

  result = *(_QWORD *)(a1 + 16) - a2;
  if ( a3 <= result )
    return a3;
  return result;
}


// ==== sub_7FF91DD18370 @ rva 0xB8370 ====
_QWORD *__fastcall sub_7FF91DD18370(_QWORD *a1, unsigned __int64 a2)
{
  if ( a1[2] < a2 )
    std::vector<void *>::_Xlen(a1);
  a1[2] = a2;
  if ( a1[3] < 0x10u )
  {
    *((_BYTE *)a1 + a2) = 0;
    return a1;
  }
  else
  {
    *(_BYTE *)(*a1 + a2) = 0;
    return a1;
  }
}


// ==== sub_7FF91DD183B0 @ rva 0xB83B0 ====
__int64 __fastcall sub_7FF91DD183B0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD183C0 @ rva 0xB83C0 ====
__int64 __fastcall sub_7FF91DD183C0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD183D0 @ rva 0xB83D0 ====
_QWORD *__fastcall sub_7FF91DD183D0(_QWORD *a1, __int64 a2)
{
  *a1 += a2;
  return a1;
}


// ==== ?_Xlen@?$vector@PEAXV?$allocator@PEAX@std@@@std@@IEBAXXZ_0 @ rva 0xB83E0 ====
void __noreturn std::vector<void *>::_Xlen()
{
  sub_7FF91E2A81C8("invalid string position");
}


// ==== sub_7FF91DD18400 @ rva 0xB8400 ====
_BYTE *__fastcall sub_7FF91DD18400(_QWORD *a1, unsigned __int64 a2, __int64 a3)
{
  __int64 v3; // r14
  _QWORD *v4; // rbx
  unsigned __int64 v5; // rdi
  unsigned __int64 v6; // r8
  unsigned __int64 v7; // rcx
  size_t v8; // rcx
  _QWORD *v9; // rsi
  void *v10; // rax
  _QWORD *v11; // rdx
  unsigned __int64 v12; // rax
  char *v13; // rcx
  char *v14; // rax
  unsigned __int64 v15; // rcx
  _BYTE *result; // rax
  size_t v17; // rcx
  _QWORD *v18; // rax
  void *v19; // rcx

  v3 = a3;
  v4 = a1;
  v5 = a2 | 0xF;
  if ( (a2 | 0xF) == 0xFFFFFFFFFFFFFFFFuLL )
  {
    v5 = a2;
  }
  else
  {
    v6 = a1[3];
    v7 = v6 >> 1;
    if ( v6 >> 1 > v5 / 3 )
    {
      v5 = -2;
      if ( v6 <= -2LL - v7 )
        v5 = v7 + v6;
    }
  }
  v8 = v5 + 1;
  if ( v5 == -1 )
  {
    v9 = nullptr;
  }
  else
  {
    try
    {
      if ( v8 < 0x1000 )
      {
        v9 = operator new(v8);
      }
      else
      {
        if ( v5 + 40 < v5 + 1 )
          Concurrency::cancel_current_task();
        v10 = operator new(v5 + 40);
        v9 = (_QWORD *)(((unsigned __int64)v10 + 39) & 0xFFFFFFFFFFFFFFE0uLL);
        *(v9 - 1) = v10;
      }
    }
    catch ( ... )
    {
      v17 = a2 + 1;
      if ( a2 == -1 )
      {
        v18 = nullptr;
      }
      else if ( v17 < 0x1000 )
      {
        v18 = operator new(v17);
      }
      else
      {
        if ( a2 + 40 < a2 + 1 )
          Concurrency::cancel_current_task();
        v19 = operator new(a2 + 40);
        v18 = (_QWORD *)(((unsigned __int64)v19 + 39) & 0xFFFFFFFFFFFFFFE0uLL);
        *(v18 - 1) = v19;
      }
      v4 = a1;
      v3 = a3;
      v5 = a2;
      v9 = v18;
    }
  }
  if ( v3 )
  {
    if ( v4[3] < 0x10u )
      v11 = v4;
    else
      v11 = (_QWORD *)*v4;
    sub_7FF91E30DC00(v9, v11, v3);
  }
  v12 = v4[3];
  if ( v12 >= 0x10 )
  {
    v13 = (char *)*v4;
    if ( v12 + 1 >= 0x1000 )
    {
      if ( ((unsigned __int8)v13 & 0x1F) != 0 )
        invalid_parameter_noinfo_noreturn();
      v14 = *((char **)v13 - 1);
      if ( v14 >= v13 )
        invalid_parameter_noinfo_noreturn();
      v15 = v13 - v14;
      if ( v15 < 8 )
        invalid_parameter_noinfo_noreturn();
      if ( v15 > 0x27 )
        invalid_parameter_noinfo_noreturn();
      v13 = v14;
    }
    j_free(v13);
  }
  v4[3] = 15;
  v4[2] = 0;
  if ( v4[3] < 0x10u )
    result = v4;
  else
    result = (_BYTE *)*v4;
  *result = 0;
  *v4 = v9;
  v4[3] = v5;
  v4[2] = v3;
  if ( v4[3] >= 0x10u )
    v4 = v9;
  *((_BYTE *)v4 + v3) = 0;
  return result;
}


// ==== ?max_size@?$basic_string@DU?$char_traits@D@std@@V?$allocator@D@2@@std@@QEBA_KXZ @ rva 0xB8590 ====
__int64 std::string::max_size()
{
  return -2;
}


// ==== ?deallocate@?$allocator@D@std@@QEAAXQEAD_K@Z_0 @ rva 0xB85A0 ====
void __fastcall std::allocator<char>::deallocate(__int64 a1, _QWORD *a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rax

  if ( a3 >= 0x1000 )
  {
    if ( ((unsigned __int8)a2 & 0x1F) != 0
      || (v3 = *(a2 - 1), v3 >= (unsigned __int64)a2)
      || (unsigned __int64)a2 - v3 - 8 > 0x1F )
    {
      invalid_parameter_noinfo_noreturn();
    }
    a2 = (_QWORD *)*(a2 - 1);
  }
  j_free(a2);
}


// ==== sub_7FF91DD185E0 @ rva 0xB85E0 ====
__int64 __fastcall sub_7FF91DD185E0(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_6913 @ rva 0xB85F0 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
// Microsoft VisualC 64bit universal runtime
__int64 unknown_libname_6913()
{
  return -1;
}


// ==== sub_7FF91DD18600 @ rva 0xB8600 ====
void *__fastcall sub_7FF91DD18600(__int64 a1, size_t a2)
{
  void *v3; // rax

  if ( !a2 )
    return nullptr;
  if ( a2 < 0x1000 )
    return operator new(a2);
  if ( a2 + 39 < a2 )
    Concurrency::cancel_current_task();
  v3 = operator new(a2 + 39);
  *(_QWORD *)((((unsigned __int64)v3 + 39) & 0xFFFFFFFFFFFFFFE0uLL) - 8) = v3;
  return (void *)(((unsigned __int64)v3 + 39) & 0xFFFFFFFFFFFFFFE0uLL);
}


// ==== unknown_libname_6914 @ rva 0xB8660 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
// Microsoft VisualC 64bit universal runtime
__int64 unknown_libname_6914()
{
  return -1;
}


// ==== sub_7FF91DD18670 @ rva 0xB8670 ====
void *__fastcall sub_7FF91DD18670(__int64 a1, size_t a2)
{
  void *v3; // rax

  if ( !a2 )
    return nullptr;
  if ( a2 < 0x1000 )
    return operator new(a2);
  if ( a2 + 39 < a2 )
    Concurrency::cancel_current_task();
  v3 = operator new(a2 + 39);
  *(_QWORD *)((((unsigned __int64)v3 + 39) & 0xFFFFFFFFFFFFFFE0uLL) - 8) = v3;
  return (void *)(((unsigned __int64)v3 + 39) & 0xFFFFFFFFFFFFFFE0uLL);
}


// ==== unknown_libname_6915 @ rva 0xB86D0 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
// Microsoft VisualC 64bit universal runtime
__int64 unknown_libname_6915()
{
  return -1;
}


// ==== ?_HasCapturedContext@_ContextCallback@details@Concurrency@@QEBA_NXZ @ rva 0xB86F0 ====
bool __fastcall Concurrency::details::_ContextCallback::_HasCapturedContext(
        Concurrency::details::_ContextCallback *this)
{
  return *(_QWORD *)this != 0;
}


// ==== sub_7FF91DD18700 @ rva 0xB8700 ====
_QWORD *__fastcall sub_7FF91DD18700(_QWORD *a1, const void *a2, unsigned __int64 a3, _BYTE *a4)
{
  _BYTE *v7; // rax
  _BYTE *v8; // rdx
  __int64 v9; // rcx
  _BYTE *v10; // rax
  unsigned __int64 v11; // r9

  v7 = memchr(a2, (unsigned __int8)*a4, a3 - (_QWORD)a2);
  v8 = (_BYTE *)a3;
  if ( v7 )
    v8 = v7;
  if ( v8 != (_BYTE *)a3 )
  {
    v9 = 0;
    v10 = v8 + 1;
    v11 = a3 - (_QWORD)(v8 + 1);
    if ( (unsigned __int64)(v8 + 1) > a3 )
      v11 = 0;
    if ( v11 )
    {
      do
      {
        if ( *v10 != *a4 )
          *v8++ = *v10;
        ++v10;
        ++v9;
      }
      while ( v9 != v11 );
    }
  }
  *a1 = v8;
  return a1;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_2 @ rva 0xB8790 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD187A0 @ rva 0xB87A0 ====
__int64 __fastcall sub_7FF91DD187A0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD187B0 @ rva 0xB87B0 ====
__int64 __fastcall sub_7FF91DD187B0(__int64 a1)
{
  *(_QWORD *)(a1 + 16) = 0;
  *(_QWORD *)(a1 + 24) = 0;
  return a1;
}


// ==== sub_7FF91DD187C0 @ rva 0xB87C0 ====
__int64 __fastcall sub_7FF91DD187C0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD187D0 @ rva 0xB87D0 ====
__int64 __fastcall sub_7FF91DD187D0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD187E0 @ rva 0xB87E0 ====
__int64 __fastcall sub_7FF91DD187E0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD187F0 @ rva 0xB87F0 ====
__int64 __fastcall sub_7FF91DD187F0(__int64 a1)
{
  *(_QWORD *)(a1 + 16) = 0;
  *(_QWORD *)(a1 + 24) = 0;
  return a1;
}


// ==== sub_7FF91DD18800 @ rva 0xB8800 ====
__int64 __fastcall sub_7FF91DD18800(__int64 a1)
{
  return a1;
}


// ==== nullsub_2 @ rva 0xB8810 ====
void nullsub_2()
{
  ;
}


// ==== unknown_libname_4223 @ rva 0xB8820 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4223(__int64 a1, __int64 *a2, __int64 *a3)
{
  __int64 result; // rax

  if ( a2 )
  {
    result = *a3;
    *a2 = *a3;
  }
  return result;
}


// ==== sub_7FF91DD18830 @ rva 0xB8830 ====
__int64 __fastcall sub_7FF91DD18830(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18840 @ rva 0xB8840 ====
__int64 __fastcall sub_7FF91DD18840(__int64 a1)
{
  *(_QWORD *)(a1 + 16) = 0;
  *(_QWORD *)(a1 + 24) = 0;
  return a1;
}


// ==== sub_7FF91DD18850 @ rva 0xB8850 ====
__int64 __fastcall sub_7FF91DD18850(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18860 @ rva 0xB8860 ====
__int64 __fastcall sub_7FF91DD18860(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18870 @ rva 0xB8870 ====
__int64 __fastcall sub_7FF91DD18870(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_4224 @ rva 0xB8880 ====
// Microsoft VisualC v14 64bit runtime
bool __fastcall unknown_libname_4224(_QWORD *a1)
{
  return *a1 == 0;
}


// ==== sub_7FF91DD18890 @ rva 0xB8890 ====
__int64 __fastcall sub_7FF91DD18890(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD188A0 @ rva 0xB88A0 ====
_BYTE *__fastcall sub_7FF91DD188A0(const void *a1, unsigned __int64 a2, _BYTE *a3)
{
  _BYTE *v5; // rcx
  _BYTE *result; // rax
  __int64 v7; // rdx
  _BYTE *v8; // rcx
  unsigned __int64 v9; // r9

  v5 = memchr(a1, (unsigned __int8)*a3, a2 - (_QWORD)a1);
  result = (_BYTE *)a2;
  if ( v5 )
    result = v5;
  if ( result != (_BYTE *)a2 )
  {
    v7 = 0;
    v8 = result + 1;
    v9 = a2 - (_QWORD)(result + 1);
    if ( (unsigned __int64)(result + 1) > a2 )
      v9 = 0;
    if ( v9 )
    {
      do
      {
        if ( *v8 != *a3 )
          *result++ = *v8;
        ++v8;
        ++v7;
      }
      while ( v7 != v9 );
    }
  }
  return result;
}


// ==== sub_7FF91DD18920 @ rva 0xB8920 ====
_QWORD *__fastcall sub_7FF91DD18920(_QWORD *a1, _QWORD *a2, __int64 a3)
{
  *a2 = a3;
  *a1 = a3;
  return a1;
}


// ==== unknown_libname_4225 @ rva 0xB8930 ====
// Microsoft VisualC v14 64bit runtime
_QWORD *__fastcall unknown_libname_4225(_QWORD *a1, __int64 a2, _QWORD *a3)
{
  *a1 = *a3;
  return a1;
}


// ==== sub_7FF91DD18940 @ rva 0xB8940 ====
__int64 __fastcall sub_7FF91DD18940(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18950 @ rva 0xB8950 ====
__int64 __fastcall sub_7FF91DD18950(__int64 a1)
{
  *(_QWORD *)(a1 + 16) = 0;
  *(_QWORD *)(a1 + 24) = 0;
  return a1;
}


// ==== sub_7FF91DD18960 @ rva 0xB8960 ====
__int64 __fastcall sub_7FF91DD18960(__int64 a1)
{
  return a1;
}


// ==== nullsub_125 @ rva 0xB8970 ====
void nullsub_125()
{
  ;
}


// ==== sub_7FF91DD18980 @ rva 0xB8980 ====
__int64 __fastcall sub_7FF91DD18980(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_4226 @ rva 0xB8990 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4226(__int64 a1, __int64 *a2, __int64 *a3)
{
  __int64 result; // rax

  if ( a2 )
  {
    result = *a3;
    *a2 = *a3;
  }
  return result;
}


// ==== ?_HasCapturedContext@_ContextCallback@details@Concurrency@@QEBA_NXZ_0 @ rva 0xB89A0 ====
bool __fastcall Concurrency::details::_ContextCallback::_HasCapturedContext(
        Concurrency::details::_ContextCallback *this)
{
  return *(_QWORD *)this != 0;
}


// ==== sub_7FF91DD189B0 @ rva 0xB89B0 ====
__int64 __fastcall sub_7FF91DD189B0(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD189C0 @ rva 0xB89C0 ====
__int64 __fastcall sub_7FF91DD189C0(__int64 a1)
{
  return a1;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_3 @ rva 0xB89D0 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD189E0 @ rva 0xB89E0 ====
__int64 __fastcall sub_7FF91DD189E0(__int64 a1)
{
  return a1;
}


// ==== ??$_Find_unchecked@PEBDD@std@@YAPEBDPEBDQEBDAEBD@Z @ rva 0xB89F0 ====
void *__fastcall std::_Find_unchecked<char const *,char>(const void *a1, __int64 a2, unsigned __int8 *a3)
{
  __int64 v3; // rbx
  void *v4; // rax

  v3 = a2;
  v4 = memchr(a1, *a3, a2 - (_QWORD)a1);
  if ( v4 )
    return v4;
  return (void *)v3;
}


// ==== sub_7FF91DD18A20 @ rva 0xB8A20 ====
__int64 __fastcall sub_7FF91DD18A20(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18A30 @ rva 0xB8A30 ====
__int64 __fastcall sub_7FF91DD18A30(__int64 a1)
{
  return a1;
}


// ==== nullsub_126 @ rva 0xB8A40 ====
void nullsub_126()
{
  ;
}


// ==== unknown_libname_4227 @ rva 0xB8A50 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4227(__int64 a1, __int64 *a2, __int64 *a3)
{
  __int64 result; // rax

  if ( a2 )
  {
    result = *a3;
    *a2 = *a3;
  }
  return result;
}


// ==== ??$_Find_unchecked@PEBDD@std@@YAPEBDPEBDQEBDAEBD@Z_0 @ rva 0xB8A60 ====
void *__fastcall std::_Find_unchecked<char const *,char>(const void *a1, __int64 a2, unsigned __int8 *a3)
{
  __int64 v3; // rbx
  void *v4; // rax

  v3 = a2;
  v4 = memchr(a1, *a3, a2 - (_QWORD)a1);
  if ( v4 )
    return v4;
  return (void *)v3;
}


// ==== sub_7FF91DD18A90 @ rva 0xB8A90 ====
char sub_7FF91DD18A90()
{
  return 1;
}


// ==== sub_7FF91DD18AA0 @ rva 0xB8AA0 ====
char sub_7FF91DD18AA0()
{
  return 1;
}


// ==== sub_7FF91DD18AB0 @ rva 0xB8AB0 ====
__int64 __fastcall sub_7FF91DD18AB0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD18AC0 @ rva 0xB8AC0 ====
// Hidden C++ exception states: #wind=4
__int64 __fastcall sub_7FF91DD18AC0(__int64 a1)
{
  _BYTE *v2; // rax

  *(_QWORD *)(a1 + 24) = 15;
  *(_QWORD *)(a1 + 16) = 0;
  if ( *(_QWORD *)(a1 + 24) < 0x10u )
    v2 = (_BYTE *)a1;
  else
    v2 = *(_BYTE **)a1;
  *v2 = 0;
  sub_7FF91DD17EC0((_QWORD *)a1, (unsigned __int64)byte_7FF91E722CD8, 0);
  *(_QWORD *)(a1 + 56) = 15;
  *(_QWORD *)(a1 + 48) = 0;
  *(_BYTE *)(a1 + 32) = 0;
  sub_7FF91DD17EC0((_QWORD *)(a1 + 32), (unsigned __int64)byte_7FF91E722CD8, 0);
  *(_QWORD *)(a1 + 88) = 15;
  *(_QWORD *)(a1 + 80) = 0;
  *(_BYTE *)(a1 + 64) = 0;
  sub_7FF91DD17EC0((_QWORD *)(a1 + 64), (unsigned __int64)byte_7FF91E722CD8, 0);
  *(_QWORD *)(a1 + 120) = 15;
  *(_QWORD *)(a1 + 112) = 0;
  *(_BYTE *)(a1 + 96) = 0;
  sub_7FF91DD17EC0((_QWORD *)(a1 + 96), (unsigned __int64)byte_7FF91E722CD8, 0);
  *(_QWORD *)(a1 + 152) = 15;
  *(_QWORD *)(a1 + 144) = 0;
  *(_BYTE *)(a1 + 128) = 0;
  sub_7FF91DD17EC0((_QWORD *)(a1 + 128), (unsigned __int64)byte_7FF91E722CD8, 0);
  *(_DWORD *)(a1 + 160) = 9;
  return a1;
}


// ==== sub_7FF91DD18BC0 @ rva 0xB8BC0 ====
// Hidden C++ exception states: #wind=4
__int64 __fastcall sub_7FF91DD18BC0(__int64 a1, __int64 a2)
{
  __int64 v3; // rdi
  _BYTE *v4; // rax

  v3 = a1 + 144;
  *(_QWORD *)(a2 + 24) = 15;
  *(_QWORD *)(a2 + 16) = 0;
  if ( *(_QWORD *)(a2 + 24) < 0x10u )
    v4 = (_BYTE *)a2;
  else
    v4 = *(_BYTE **)a2;
  *v4 = 0;
  sub_7FF91DD17FF0((_QWORD *)a2, (_QWORD *)(a1 + 144), 0, 0xFFFFFFFFFFFFFFFFuLL);
  *(_QWORD *)(a2 + 56) = 15;
  *(_QWORD *)(a2 + 48) = 0;
  *(_BYTE *)(a2 + 32) = 0;
  sub_7FF91DD17FF0((_QWORD *)(a2 + 32), (_QWORD *)(v3 + 32), 0, 0xFFFFFFFFFFFFFFFFuLL);
  *(_QWORD *)(a2 + 88) = 15;
  *(_QWORD *)(a2 + 80) = 0;
  *(_BYTE *)(a2 + 64) = 0;
  sub_7FF91DD17FF0((_QWORD *)(a2 + 64), (_QWORD *)(v3 + 64), 0, 0xFFFFFFFFFFFFFFFFuLL);
  *(_QWORD *)(a2 + 120) = 15;
  *(_QWORD *)(a2 + 112) = 0;
  *(_BYTE *)(a2 + 96) = 0;
  sub_7FF91DD17FF0((_QWORD *)(a2 + 96), (_QWORD *)(v3 + 96), 0, 0xFFFFFFFFFFFFFFFFuLL);
  *(_QWORD *)(a2 + 152) = 15;
  *(_QWORD *)(a2 + 144) = 0;
  *(_BYTE *)(a2 + 128) = 0;
  sub_7FF91DD17FF0((_QWORD *)(a2 + 128), (_QWORD *)(v3 + 128), 0, 0xFFFFFFFFFFFFFFFFuLL);
  *(_DWORD *)(a2 + 160) = *(_DWORD *)(v3 + 160);
  return a2;
}


// ==== sub_7FF91DD18CE0 @ rva 0xB8CE0 ====
// Hidden C++ exception states: #wind=4
__int64 __fastcall sub_7FF91DD18CE0(__int64 a1, __int64 a2)
{
  _BYTE *v4; // rax

  *(_QWORD *)(a1 + 24) = 15;
  *(_QWORD *)(a1 + 16) = 0;
  if ( *(_QWORD *)(a1 + 24) < 0x10u )
    v4 = (_BYTE *)a1;
  else
    v4 = *(_BYTE **)a1;
  *v4 = 0;
  sub_7FF91DD17FF0((_QWORD *)a1, (_QWORD *)a2, 0, 0xFFFFFFFFFFFFFFFFuLL);
  *(_QWORD *)(a1 + 56) = 15;
  *(_QWORD *)(a1 + 48) = 0;
  *(_BYTE *)(a1 + 32) = 0;
  sub_7FF91DD17FF0((_QWORD *)(a1 + 32), (_QWORD *)(a2 + 32), 0, 0xFFFFFFFFFFFFFFFFuLL);
  *(_QWORD *)(a1 + 88) = 15;
  *(_QWORD *)(a1 + 80) = 0;
  *(_BYTE *)(a1 + 64) = 0;
  sub_7FF91DD17FF0((_QWORD *)(a1 + 64), (_QWORD *)(a2 + 64), 0, 0xFFFFFFFFFFFFFFFFuLL);
  *(_QWORD *)(a1 + 120) = 15;
  *(_QWORD *)(a1 + 112) = 0;
  *(_BYTE *)(a1 + 96) = 0;
  sub_7FF91DD17FF0((_QWORD *)(a1 + 96), (_QWORD *)(a2 + 96), 0, 0xFFFFFFFFFFFFFFFFuLL);
  *(_QWORD *)(a1 + 152) = 15;
  *(_QWORD *)(a1 + 144) = 0;
  *(_BYTE *)(a1 + 128) = 0;
  sub_7FF91DD17FF0((_QWORD *)(a1 + 128), (_QWORD *)(a2 + 128), 0, 0xFFFFFFFFFFFFFFFFuLL);
  *(_DWORD *)(a1 + 160) = *(_DWORD *)(a2 + 160);
  return a1;
}


// ==== sub_7FF91DD18E00 @ rva 0xB8E00 ====
void __fastcall sub_7FF91DD18E00(_QWORD *a1)
{
  sub_7FF91DD17A90(a1 + 16);
  sub_7FF91DD17A90(a1 + 12);
  sub_7FF91DD17A90(a1 + 8);
  sub_7FF91DD17A90(a1 + 4);
  sub_7FF91DD17A90(a1);
}


// ==== sub_7FF91DD18E40 @ rva 0xB8E40 ====
__int64 __fastcall sub_7FF91DD18E40(__int64 a1)
{
  return a1 + 328;
}


// ==== sub_7FF91DD18E50 @ rva 0xB8E50 ====
__int64 __fastcall sub_7FF91DD18E50(__int64 a1)
{
  return a1 + 336;
}


// ==== sub_7FF91DD18E60 @ rva 0xB8E60 ====
__int64 __fastcall sub_7FF91DD18E60(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 24) = 15;
  *(_QWORD *)(a1 + 16) = 0;
  *(_BYTE *)a1 = 0;
  ((void (*)(void))sub_7FF91DD18F90)();
  *(_QWORD *)(a1 + 56) = 15;
  *(_QWORD *)(a1 + 48) = 0;
  *(_BYTE *)(a1 + 32) = 0;
  sub_7FF91DD18F90(a1 + 32, a2 + 32);
  *(_QWORD *)(a1 + 88) = 15;
  *(_QWORD *)(a1 + 80) = 0;
  *(_BYTE *)(a1 + 64) = 0;
  sub_7FF91DD18F90(a1 + 64, a2 + 64);
  *(_QWORD *)(a1 + 120) = 15;
  *(_QWORD *)(a1 + 112) = 0;
  *(_BYTE *)(a1 + 96) = 0;
  sub_7FF91DD18F90(a1 + 96, a2 + 96);
  *(_QWORD *)(a1 + 152) = 15;
  *(_QWORD *)(a1 + 144) = 0;
  *(_BYTE *)(a1 + 128) = 0;
  sub_7FF91DD18F90(a1 + 128, a2 + 128);
  *(_DWORD *)(a1 + 160) = *(_DWORD *)(a2 + 160);
  return a1;
}


// ==== sub_7FF91DD18F30 @ rva 0xB8F30 ====
void __fastcall sub_7FF91DD18F30(LPCRITICAL_SECTION *a1)
{
  LeaveCriticalSection(*a1);
}


// ==== sub_7FF91DD18F40 @ rva 0xB8F40 ====
struct _RTL_CRITICAL_SECTION **__fastcall sub_7FF91DD18F40(
        struct _RTL_CRITICAL_SECTION **a1,
        struct _RTL_CRITICAL_SECTION *a2)
{
  *a1 = a2;
  EnterCriticalSection(a2);
  return a1;
}


// ==== sub_7FF91DD18F60 @ rva 0xB8F60 ====
__int64 __fastcall sub_7FF91DD18F60(__int64 a1, __int64 a2)
{
  *(_QWORD *)(a1 + 24) = 15;
  *(_QWORD *)(a1 + 16) = 0;
  *(_BYTE *)a1 = 0;
  sub_7FF91DD18F90(a1, a2);
  return a1;
}


// ==== sub_7FF91DD18F90 @ rva 0xB8F90 ====
__int64 __fastcall sub_7FF91DD18F90(_QWORD *a1, _QWORD *a2)
{
  __int64 result; // rax
  bool v5; // cf

  if ( a2[3] >= 0x10u )
  {
    if ( a1 )
      *a1 = *a2;
    *a2 = 0;
  }
  else if ( a2[2] != -1 )
  {
    sub_7FF91E30DC00(a1, a2, a2[2] + 1LL);
  }
  a1[2] = a2[2];
  result = a2[3];
  a1[3] = result;
  a2[3] = 15;
  v5 = a2[3] < 0x10u;
  a2[2] = 0;
  if ( v5 )
  {
    *(_BYTE *)a2 = 0;
  }
  else
  {
    result = *a2;
    *(_BYTE *)*a2 = 0;
  }
  return result;
}


// ==== sub_7FF91DD19010 @ rva 0xB9010 ====
__int64 __fastcall sub_7FF91DD19010(__int64 a1)
{
  return a1;
}


// ==== nullsub_3 @ rva 0xB9020 ====
void nullsub_3()
{
  ;
}


// ==== nullsub_127 @ rva 0xB9040 ====
void nullsub_127()
{
  ;
}


// ==== sub_7FF91DD19050 @ rva 0xB9050 ====
__int64 __fastcall sub_7FF91DD19050(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD19060 @ rva 0xB9060 ====
__int64 __fastcall sub_7FF91DD19060(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD19070 @ rva 0xB9070 ====
void __fastcall sub_7FF91DD19070(_DWORD *a1, int a2)
{
  *a1 = a2;
}


// ==== sub_7FF91DD19080 @ rva 0xB9080 ====
void __fastcall sub_7FF91DD19080(_DWORD *a1, int a2)
{
  *a1 = a2;
}


// ==== sub_7FF91DD19090 @ rva 0xB9090 ====
void __fastcall sub_7FF91DD19090(volatile __int32 *a1, __int32 a2)
{
  _InterlockedExchange(a1, a2);
}


// ==== sub_7FF91DD190C0 @ rva 0xB90C0 ====
__int64 __fastcall sub_7FF91DD190C0(unsigned int *a1)
{
  return *a1;
}


// ==== sub_7FF91DD190D0 @ rva 0xB90D0 ====
__int64 __fastcall sub_7FF91DD190D0(unsigned int *a1)
{
  return *a1;
}


// ==== sub_7FF91DD190E0 @ rva 0xB90E0 ====
__int64 __fastcall sub_7FF91DD190E0(unsigned int *a1)
{
  return *a1;
}


// ==== sub_7FF91DD19110 @ rva 0xB9110 ====
void __fastcall sub_7FF91DD19110(_QWORD *a1, __int64 a2)
{
  *a1 = a2;
}


// ==== sub_7FF91DD19120 @ rva 0xB9120 ====
void __fastcall sub_7FF91DD19120(_QWORD *a1, __int64 a2)
{
  *a1 = a2;
}


// ==== sub_7FF91DD19130 @ rva 0xB9130 ====
void __fastcall sub_7FF91DD19130(volatile __int64 *a1, __int64 a2)
{
  _InterlockedExchange64(a1, a2);
}


// ==== sub_7FF91DD19160 @ rva 0xB9160 ====
__int64 __fastcall sub_7FF91DD19160(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD19170 @ rva 0xB9170 ====
__int64 __fastcall sub_7FF91DD19170(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD19180 @ rva 0xB9180 ====
__int64 __fastcall sub_7FF91DD19180(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD191B0 @ rva 0xB91B0 ====
__int64 __fastcall sub_7FF91DD191B0(volatile __int32 *a1, unsigned __int32 a2)
{
  _InterlockedExchange(a1, a2);
  return a2;
}


// ==== sub_7FF91DD191E0 @ rva 0xB91E0 ====
void __fastcall sub_7FF91DD191E0(volatile __int32 *a1, __int32 a2)
{
  _InterlockedExchange(a1, a2);
}


// ==== sub_7FF91DD19210 @ rva 0xB9210 ====
__int64 __fastcall sub_7FF91DD19210(unsigned int *a1)
{
  return *a1;
}


// ==== sub_7FF91DD19220 @ rva 0xB9220 ====
__int64 __fastcall sub_7FF91DD19220(volatile __int32 *a1, unsigned __int32 a2)
{
  _InterlockedExchange(a1, a2);
  return a2;
}


// ==== sub_7FF91DD19230 @ rva 0xB9230 ====
__int64 __fastcall sub_7FF91DD19230(unsigned int *a1)
{
  return *a1;
}


// ==== unknown_libname_7 @ rva 0xB9240 ====
// Microsoft VisualC v7/14 64bit runtime
_QWORD *__fastcall unknown_libname_7(_QWORD *a1)
{
  *a1 = 0;
  return a1;
}


// ==== sub_7FF91DD19250 @ rva 0xB9250 ====
__int64 __fastcall sub_7FF91DD19250(__int64 a1, __int64 a2)
{
  _InterlockedExchange64(&qword_7FF91E91A228, a2);
  return a2;
}


// ==== sub_7FF91DD19260 @ rva 0xB9260 ====
void __fastcall sub_7FF91DD19260(__int64 a1, __int64 a2)
{
  _InterlockedExchange64(&qword_7FF91E91A228, a2);
}


// ==== sub_7FF91DD19270 @ rva 0xB9270 ====
void __fastcall sub_7FF91DD19270(__int64 a1, __int64 a2)
{
  _InterlockedExchange64(&qword_7FF91E91A228, a2);
}


// ==== sub_7FF91DD19280 @ rva 0xB9280 ====
__int64 __fastcall sub_7FF91DD19280(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD19290 @ rva 0xB9290 ====
__int64 __fastcall sub_7FF91DD19290(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD192A0 @ rva 0xB92A0 ====
__int64 __fastcall sub_7FF91DD192A0(__int64 a1, __int64 a2)
{
  _InterlockedExchange64(&qword_7FF91E91A228, a2);
  return a2;
}


// ==== sub_7FF91DD192B0 @ rva 0xB92B0 ====
__int64 __fastcall sub_7FF91DD192B0(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD192C0 @ rva 0xB92C0 ====
__int64 __fastcall sub_7FF91DD192C0(__int64 a1)
{
  sub_7FF91DD1CDC0();
  return a1;
}


// ==== sub_7FF91DD192E0 @ rva 0xB92E0 ====
__int64 __fastcall sub_7FF91DD192E0(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD192F0 @ rva 0xB92F0 ====
__int64 __fastcall sub_7FF91DD192F0(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== ?file_name@__crt_win32_buffer_debug_info@@QEBAPEBDXZ @ rva 0xB9300 ====
const char *__fastcall __crt_win32_buffer_debug_info::file_name(__crt_win32_buffer_debug_info *this)
{
  return *((const char **)this + 1);
}


// ==== sub_7FF91DD19310 @ rva 0xB9310 ====
void __fastcall sub_7FF91DD19310(_QWORD *a1)
{
  _DWORD *v1; // rcx

  v1 = (_DWORD *)(*a1 - 16LL);
  if ( (*v1 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v1, 0xFFFFFFFF) )
    j_j_free_0(v1);
}


// ==== ?_Check_C_return@std@@YAHH@Z @ rva 0xB9340 ====
__int64 __fastcall std::_Check_C_return(unsigned int a1)
{
  if ( a1 )
    std::_Throw_C_error(a1);
  return a1;
}


// ==== sub_7FF91DD19360 @ rva 0xB9360 ====
__int64 __fastcall sub_7FF91DD19360(_Thrd_imp_t *a1, __int64 a2, void *a3)
{
  int v3; // eax
  unsigned int v4; // ebx

  v3 = Thrd_start(a1, sub_7FF91DD196B0, a3);
  v4 = 1;
  if ( v3 != 4 )
    v4 = v3;
  if ( v4 )
    std::_Throw_C_error(v4);
  return v4;
}


// ==== sub_7FF91DD19390 @ rva 0xB9390 ====
int __fastcall sub_7FF91DD19390(_Thrd_t *a1)
{
  int result; // eax
  int v2; // ebx
  _Thrd_t v3; // [rsp+20h] [rbp-18h] BYREF

  v3 = *a1;
  result = Thrd_detach(&v3);
  v2 = result;
  if ( result )
  {
    std::_Throw_C_error(result);
    return v2;
  }
  return result;
}


// ==== sub_7FF91DD193C0 @ rva 0xB93C0 ====
int __fastcall sub_7FF91DD193C0(_Mtx_t *a1)
{
  int result; // eax
  int v2; // ebx

  result = Mtx_init(a1, 1);
  v2 = result;
  if ( result )
  {
    std::_Throw_C_error(result);
    return v2;
  }
  return result;
}


// ==== sub_7FF91DD193F0 @ rva 0xB93F0 ====
int __fastcall sub_7FF91DD193F0(struct _Mtx_internal_imp_t *a1)
{
  int result; // eax
  int v2; // ebx

  result = Mtx_lock(a1);
  v2 = result;
  if ( result )
  {
    std::_Throw_C_error(result);
    return v2;
  }
  return result;
}


// ==== sub_7FF91DD19410 @ rva 0xB9410 ====
int __fastcall sub_7FF91DD19410(struct _Mtx_internal_imp_t *a1)
{
  int result; // eax
  int v2; // ebx

  result = Mtx_unlock(a1);
  v2 = result;
  if ( result )
  {
    std::_Throw_C_error(result);
    return v2;
  }
  return result;
}


// ==== sub_7FF91DD19430 @ rva 0xB9430 ====
int __fastcall sub_7FF91DD19430(_Cnd_t *a1)
{
  int result; // eax
  int v2; // ebx

  result = Cnd_init(a1);
  v2 = result;
  if ( result )
  {
    std::_Throw_C_error(result);
    return v2;
  }
  return result;
}


// ==== sub_7FF91DD19450 @ rva 0xB9450 ====
__int64 sub_7FF91DD19450()
{
  __int64 result; // rax
  unsigned int v1; // ebx

  result = sub_7FF91E2AB4AC();
  v1 = result;
  if ( (_DWORD)result )
  {
    std::_Throw_C_error(result);
    return v1;
  }
  return result;
}


// ==== sub_7FF91DD19470 @ rva 0xB9470 ====
int __fastcall sub_7FF91DD19470(struct _Cnd_internal_imp_t *a1)
{
  int result; // eax
  int v2; // ebx

  result = Cnd_signal(a1);
  v2 = result;
  if ( result )
  {
    std::_Throw_C_error(result);
    return v2;
  }
  return result;
}


// ==== sub_7FF91DD19490 @ rva 0xB9490 ====
__int64 __fastcall sub_7FF91DD19490(__int64 a1, __int64 a2)
{
  *(_BYTE *)a1 = 1;
  *(_QWORD *)(a1 + 8) = a2;
  return a1;
}


// ==== sub_7FF91DD194A0 @ rva 0xB94A0 ====
void __fastcall sub_7FF91DD194A0(__int64 a1)
{
  if ( *(_BYTE *)a1 )
    Cnd_destroy(*(_Cnd_t *)(a1 + 8));
}


// ==== sub_7FF91DD194B0 @ rva 0xB94B0 ====
void __fastcall sub_7FF91DD194B0(_BYTE *a1)
{
  *a1 = 0;
}


// ==== sub_7FF91DD194C0 @ rva 0xB94C0 ====
__int64 __fastcall sub_7FF91DD194C0(__int64 a1, __int64 a2)
{
  *(_BYTE *)a1 = 1;
  *(_QWORD *)(a1 + 8) = a2;
  return a1;
}


// ==== sub_7FF91DD194D0 @ rva 0xB94D0 ====
void __fastcall sub_7FF91DD194D0(__int64 a1)
{
  if ( *(_BYTE *)a1 )
    Mtx_destroy(*(_Mtx_t *)(a1 + 8));
}


// ==== sub_7FF91DD194E0 @ rva 0xB94E0 ====
void __fastcall sub_7FF91DD194E0(_BYTE *a1)
{
  *a1 = 0;
}


// ==== sub_7FF91DD194F0 @ rva 0xB94F0 ====
// Hidden C++ exception states: #wind=2
__int64 __fastcall sub_7FF91DD194F0(__int64 a1)
{
  int v2; // eax
  int v3; // eax
  int v4; // eax
  struct _Mtx_internal_imp_t *v6; // [rsp+40h] [rbp-18h]

  *(_QWORD *)a1 = &std::_Pad::`vftable';
  v2 = Cnd_init((_Cnd_t *)(a1 + 8));
  if ( v2 )
    std::_Throw_C_error(v2);
  v3 = Mtx_init((_Mtx_t *)(a1 + 16), 1);
  if ( v3 )
    std::_Throw_C_error(v3);
  v6 = *(struct _Mtx_internal_imp_t **)(a1 + 16);
  *(_BYTE *)(a1 + 24) = 0;
  v4 = Mtx_lock(v6);
  if ( v4 )
    std::_Throw_C_error(v4);
  return a1;
}


// ==== sub_7FF91DD19580 @ rva 0xB9580 ====
void __fastcall sub_7FF91DD19580(_QWORD *a1)
{
  struct _Cnd_internal_imp_t *v1; // rdi
  struct _Mtx_internal_imp_t *v2; // rbx
  int v3; // eax

  *a1 = &std::_Pad::`vftable';
  v1 = (struct _Cnd_internal_imp_t *)a1[1];
  v2 = (struct _Mtx_internal_imp_t *)a1[2];
  v3 = Mtx_unlock(v2);
  if ( v3 )
    std::_Throw_C_error(v3);
  Mtx_destroy(v2);
  Cnd_destroy(v1);
}


// ==== sub_7FF91DD195E0 @ rva 0xB95E0 ====
void __fastcall sub_7FF91DD195E0(void *a1, _Thrd_imp_t *a2)
{
  int v3; // eax
  int v4; // ecx
  int v5; // eax

  v3 = Thrd_start(a2, sub_7FF91DD196B0, a1);
  v4 = 1;
  if ( v3 != 4 )
    v4 = v3;
  if ( v4 )
    std::_Throw_C_error(v4);
  while ( !*((_BYTE *)a1 + 24) )
  {
    v5 = sub_7FF91E2AB4AC(*((_QWORD *)a1 + 1), *((_QWORD *)a1 + 2));
    if ( v5 )
      std::_Throw_C_error(v5);
  }
}


// ==== sub_7FF91DD19650 @ rva 0xB9650 ====
void __fastcall sub_7FF91DD19650(__int64 a1)
{
  int v2; // eax
  struct _Cnd_internal_imp_t *v3; // rcx
  int v4; // eax
  int v5; // eax

  v2 = Mtx_lock(*(_Mtx_t *)(a1 + 16));
  if ( v2 )
    std::_Throw_C_error(v2);
  v3 = *(struct _Cnd_internal_imp_t **)(a1 + 8);
  *(_BYTE *)(a1 + 24) = 1;
  v4 = Cnd_signal(v3);
  if ( v4 )
    std::_Throw_C_error(v4);
  v5 = Mtx_unlock(*(_Mtx_t *)(a1 + 16));
  if ( v5 )
    std::_Throw_C_error(v5);
}


// ==== sub_7FF91DD196B0 @ rva 0xB96B0 ====
// Hidden C++ exception states: #wind=1
__int64 __fastcall sub_7FF91DD196B0(void *a1)
{
  char *v2; // rbx
  int v3; // eax
  int v4; // eax
  int v5; // eax

  v2 = *((char **)a1 + 4);
  *((_QWORD *)a1 + 4) = 0;
  v3 = Mtx_lock(*((_Mtx_t *)a1 + 2));
  if ( v3 )
    std::_Throw_C_error(v3);
  *((_BYTE *)a1 + 24) = 1;
  v4 = Cnd_signal(*((_Cnd_t *)a1 + 1));
  if ( v4 )
    std::_Throw_C_error(v4);
  v5 = Mtx_unlock(*((_Mtx_t *)a1 + 2));
  if ( v5 )
    std::_Throw_C_error(v5);
  sub_7FF91E3EDC00(v2, v2 + 8);
  if ( v2 )
  {
    sub_7FF91DD19A90(v2);
    j_j_free(v2);
  }
  Cnd_do_broadcast_at_thread_exit();
  return 0;
}


// ==== sub_7FF91DD19750 @ rva 0xB9750 ====
void __fastcall sub_7FF91DD19750(__int64 a1)
{
  if ( *(_DWORD *)(a1 + 8) )
    terminate();
}


// ==== sub_7FF91DD19780 @ rva 0xB9780 ====
__int64 __fastcall sub_7FF91DD19780(_Thrd_t *a1)
{
  int v2; // eax
  _Thrd_t v4; // [rsp+20h] [rbp-18h] BYREF

  if ( !a1->_Id )
    std::_Throw_Cpp_error(1);
  v4 = *a1;
  v2 = Thrd_detach(&v4);
  if ( v2 )
    std::_Throw_C_error(v2);
  a1->_Id = 0;
  a1->_Hnd = nullptr;
  return 0;
}


// ==== sub_7FF91DD197D0 @ rva 0xB97D0 ====
// Hidden C++ exception states: #wind=3
void __fastcall sub_7FF91DD197D0(__int64 *a1, __int64 *a2, __int64 *a3, unsigned int a4)
{
  int v8; // eax
  DWORD Time; // eax
  __int64 v10; // rcx
  __int64 v11; // rdx
  _DWORD *v12; // rcx
  __int64 v13; // rcx
  __int64 v14; // rcx
  __int64 v15; // rcx
  _Thrd_t *v16; // rax
  _Thrd_t *v17; // rdi
  int v18; // eax
  __int64 v19; // rdx
  __int64 v20; // rcx
  void *v21; // rcx
  void *v22; // rcx
  void *v23; // rcx
  _Thrd_t v24; // [rsp+30h] [rbp-48h] BYREF
  _Thrd_imp_t v25; // [rsp+40h] [rbp-38h] BYREF
  __int64 v26; // [rsp+50h] [rbp-28h]
  __int64 v27; // [rsp+58h] [rbp-20h]
  __int64 v28; // [rsp+60h] [rbp-18h]

  EnterCriticalSection(&stru_7FF91E919988);
  v8 = dword_7FF91E918124 + 1;
  dword_7FF91E918124 = v8;
  if ( v8 <= 1 )
  {
    if ( off_7FF91E8F63C0 != (_UNKNOWN *)*a2 && (unsigned int)sub_7FF91DD652D0(off_7FF91E8F63C0, *a2) )
      goto LABEL_11;
    Time = timeGetTime();
    v10 = (unsigned int)dword_7FF91E9194A4;
    if ( Time >= dword_7FF91E9194A4 )
    {
      _InterlockedExchange(&dword_7FF91E9194A4, Time);
    }
    else
    {
      v10 = (unsigned int)(dword_7FF91E9194A4 - 1000);
      if ( Time < (unsigned int)v10 )
        v10 = (unsigned int)_InterlockedExchange(&dword_7FF91E9194A4, Time);
    }
    v11 = Time - dword_7FF91E918120;
    if ( (unsigned int)v11 >= a4 )
    {
LABEL_11:
      if ( (*(_DWORD *)(*a2 - 16) & 0x30000000) == 0 )
        _InterlockedExchangeAdd((volatile signed __int32 *)(*a2 - 16), 1u);
      v12 = (_DWORD *)(_InterlockedExchange64((volatile __int64 *)&off_7FF91E8F63C0, *a2) - 16);
      if ( (*v12 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v12, 0xFFFFFFFF) )
        j_j_free_0(v12);
      v13 = *a1;
      v26 = v13;
      if ( (*(_DWORD *)(v13 - 16) & 0x30000000) == 0 )
        _InterlockedExchangeAdd((volatile signed __int32 *)(v13 - 16), 1u);
      v14 = *a2;
      v27 = v14;
      if ( (*(_DWORD *)(v14 - 16) & 0x30000000) == 0 )
        _InterlockedExchangeAdd((volatile signed __int32 *)(v14 - 16), 1u);
      v15 = *a3;
      v28 = v15;
      if ( (*(_DWORD *)(v15 - 16) & 0x30000000) == 0 )
        _InterlockedExchangeAdd((volatile signed __int32 *)(v15 - 16), 1u);
      v16 = (_Thrd_t *)sub_7FF91DD1CEB0(&v25);
      v17 = v16;
      if ( !v16->_Id )
        std::_Throw_Cpp_error(1);
      v24 = *v16;
      v18 = Thrd_detach(&v24);
      if ( v18 )
        std::_Throw_C_error(v18);
      v17->_Hnd = nullptr;
      v17->_Id = 0;
      if ( v25._Id )
        terminate(v20, v19);
      v21 = (void *)(v28 - 16);
      if ( (*(_DWORD *)(v28 - 16) & 0x30000000) == 0
        && !_InterlockedExchangeAdd((volatile signed __int32 *)v21, 0xFFFFFFFF) )
      {
        j_j_free_0(v21);
      }
      v22 = (void *)(v27 - 16);
      if ( (*(_DWORD *)(v27 - 16) & 0x30000000) == 0
        && !_InterlockedExchangeAdd((volatile signed __int32 *)v22, 0xFFFFFFFF) )
      {
        j_j_free_0(v22);
      }
      v23 = (void *)(v26 - 16);
      if ( (*(_DWORD *)(v26 - 16) & 0x30000000) == 0
        && !_InterlockedExchangeAdd((volatile signed __int32 *)v23, 0xFFFFFFFF) )
      {
        j_j_free_0(v23);
      }
    }
    else
    {
      --dword_7FF91E918124;
      _InterlockedExchange(&dword_7FF91E918120, sub_7FF91E3E6280(v10, v11));
    }
  }
  else
  {
    dword_7FF91E918124 = v8 - 1;
  }
  LeaveCriticalSection(&stru_7FF91E919988);
}


// ==== sub_7FF91DD19A20 @ rva 0xB9A20 ====
__int64 __fastcall sub_7FF91DD19A20(__int64 a1)
{
  return sub_7FF91E3EDC00(a1, a1 + 8);
}


// ==== sub_7FF91DD19A90 @ rva 0xB9A90 ====
void __fastcall sub_7FF91DD19A90(_QWORD *a1)
{
  _DWORD *v2; // rcx
  _DWORD *v3; // rcx
  _DWORD *v4; // rcx

  v2 = (_DWORD *)(a1[2] - 16LL);
  if ( (*v2 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v2, 0xFFFFFFFF) )
    j_j_free_0(v2);
  v3 = (_DWORD *)(a1[1] - 16LL);
  if ( (*v3 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v3, 0xFFFFFFFF) )
    j_j_free_0(v3);
  v4 = (_DWORD *)(*a1 - 16LL);
  if ( (*v4 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v4, 0xFFFFFFFF) )
    j_j_free_0(v4);
}


// ==== sub_7FF91DD19B10 @ rva 0xB9B10 ====
_DWORD *__fastcall sub_7FF91DD19B10(_DWORD *a1, int a2, int a3, int a4)
{
  *a1 = a2;
  a1[1] = a3;
  a1[2] = a4;
  return a1;
}


// ==== sub_7FF91DD19B20 @ rva 0xB9B20 ====
// Hidden C++ exception states: #wind=6
__int64 __fastcall sub_7FF91DD19B20(__int64 a1, __int64 a2)
{
  __int64 v3; // rsi
  __int64 v4; // rdi
  __int64 v5; // rax
  __int64 v6; // rax
  __int64 v7; // rax
  __int64 v8; // rax
  void *v9; // rdx
  void *v10; // rdx
  void *v11; // rdx
  void *v12; // rdx
  void *v13; // rdx
  _BYTE *v14; // rdx
  void *Block[3]; // [rsp+28h] [rbp-79h] BYREF
  unsigned __int64 v17; // [rsp+40h] [rbp-61h]
  void *v18[3]; // [rsp+48h] [rbp-59h] BYREF
  unsigned __int64 v19; // [rsp+60h] [rbp-41h]
  void *v20[3]; // [rsp+68h] [rbp-39h] BYREF
  unsigned __int64 v21; // [rsp+80h] [rbp-21h]
  void *v22[3]; // [rsp+88h] [rbp-19h] BYREF
  unsigned __int64 v23; // [rsp+A0h] [rbp-1h]
  void *v24[3]; // [rsp+A8h] [rbp+7h] BYREF
  unsigned __int64 v25; // [rsp+C0h] [rbp+1Fh]
  __int64 v26; // [rsp+C8h] [rbp+27h]
  void *v27; // [rsp+D0h] [rbp+2Fh] BYREF
  unsigned __int64 v28; // [rsp+E8h] [rbp+47h]

  v26 = -2;
  v3 = sub_7FF91DD192C0((__int64)&v27);
  v4 = sub_7FF91DD192C0((__int64)v24);
  v5 = sub_7FF91DD192C0((__int64)v22);
  v6 = sub_7FF91DD1D050(v20, v5, &unk_7FF91E722CDC);
  v7 = sub_7FF91DD1D090(v18, v6, v4);
  v8 = sub_7FF91DD1D050(Block, v7, &unk_7FF91E722CDC);
  sub_7FF91DD1D090(a2, v8, v3);
  if ( v17 >= 0x10 )
  {
    v9 = Block[0];
    if ( v17 + 1 >= 0x1000 )
    {
      if ( ((__int64)Block[0] & 0x1F) != 0 )
        invalid_parameter_noinfo_noreturn();
      v9 = *((void **)Block[0] - 1);
      if ( v9 >= Block[0] )
        invalid_parameter_noinfo_noreturn();
      if ( (void *)((char *)Block[0] - (char *)v9) < (void *)8 )
        invalid_parameter_noinfo_noreturn();
      if ( (void *)((char *)Block[0] - (char *)v9) > (void *)0x27 )
        invalid_parameter_noinfo_noreturn();
    }
    j_free(v9);
  }
  v17 = 15;
  Block[2] = nullptr;
  LOBYTE(Block[0]) = 0;
  if ( v19 >= 0x10 )
  {
    v10 = v18[0];
    if ( v19 + 1 >= 0x1000 )
    {
      if ( ((__int64)v18[0] & 0x1F) != 0 )
        invalid_parameter_noinfo_noreturn();
      v10 = *((void **)v18[0] - 1);
      if ( v10 >= v18[0] )
        invalid_parameter_noinfo_noreturn();
      if ( (void *)((char *)v18[0] - (char *)v10) < (void *)8 )
        invalid_parameter_noinfo_noreturn();
      if ( (void *)((char *)v18[0] - (char *)v10) > (void *)0x27 )
        invalid_parameter_noinfo_noreturn();
    }
    j_free(v10);
  }
  v19 = 15;
  v18[2] = nullptr;
  LOBYTE(v18[0]) = 0;
  if ( v21 >= 0x10 )
  {
    v11 = v20[0];
    if ( v21 + 1 >= 0x1000 )
    {
      if ( ((__int64)v20[0] & 0x1F) != 0 )
        invalid_parameter_noinfo_noreturn();
      v11 = *((void **)v20[0] - 1);
      if ( v11 >= v20[0] )
        invalid_parameter_noinfo_noreturn();
      if ( (void *)((char *)v20[0] - (char *)v11) < (void *)8 )
        invalid_parameter_noinfo_noreturn();
      if ( (void *)((char *)v20[0] - (char *)v11) > (void *)0x27 )
        invalid_parameter_noinfo_noreturn();
    }
    j_free(v11);
  }
  v21 = 15;
  v20[2] = nullptr;
  LOBYTE(v20[0]) = 0;
  if ( v23 >= 0x10 )
  {
    v12 = v22[0];
    if ( v23 + 1 >= 0x1000 )
    {
      if ( ((__int64)v22[0] & 0x1F) != 0 )
        invalid_parameter_noinfo_noreturn();
      v12 = *((void **)v22[0] - 1);
      if ( v12 >= v22[0] )
        invalid_parameter_noinfo_noreturn();
      if ( (void *)((char *)v22[0] - (char *)v12) < (void *)8 )
        invalid_parameter_noinfo_noreturn();
      if ( (void *)((char *)v22[0] - (char *)v12) > (void *)0x27 )
        invalid_parameter_noinfo_noreturn();
    }
    j_free(v12);
  }
  v23 = 15;
  v22[2] = nullptr;
  LOBYTE(v22[0]) = 0;
  if ( v25 >= 0x10 )
  {
    v13 = v24[0];
    if ( v25 + 1 >= 0x1000 )
    {
      if ( ((__int64)v24[0] & 0x1F) != 0 )
        invalid_parameter_noinfo_noreturn();
      v13 = *((void **)v24[0] - 1);
      if ( v13 >= v24[0] )
        invalid_parameter_noinfo_noreturn();
      if ( (void *)((char *)v24[0] - (char *)v13) < (void *)8 )
        invalid_parameter_noinfo_noreturn();
      if ( (void *)((char *)v24[0] - (char *)v13) > (void *)0x27 )
        invalid_parameter_noinfo_noreturn();
    }
    j_free(v13);
  }
  v25 = 15;
  v24[2] = nullptr;
  LOBYTE(v24[0]) = 0;
  if ( v28 >= 0x10 )
  {
    v14 = v27;
    if ( v28 + 1 >= 0x1000 )
    {
      if ( ((unsigned __int8)v27 & 0x1F) != 0 )
        invalid_parameter_noinfo_noreturn();
      v14 = *((_BYTE **)v27 - 1);
      if ( v14 >= v27 )
        invalid_parameter_noinfo_noreturn();
      if ( (unsigned __int64)((_BYTE *)v27 - v14) < 8 )
        invalid_parameter_noinfo_noreturn();
      if ( (unsigned __int64)((_BYTE *)v27 - v14) > 0x27 )
        invalid_parameter_noinfo_noreturn();
    }
    j_free(v14);
  }
  return a2;
}


// ==== ??0_Mutex_base@std@@QEAA@H@Z @ rva 0xB9EB0 ====
std::_Mutex_base *__fastcall std::_Mutex_base::_Mutex_base(std::_Mutex_base *this, int a2)
{
  Mtx_init_in_situ(this, a2 | 2);
  return this;
}


// ==== j__Mtx_destroy_in_situ_2 @ rva 0xB9ED0 ====
// attributes: thunk
void __cdecl j__Mtx_destroy_in_situ_2(_Mtx_t a1)
{
  Mtx_destroy_in_situ(a1);
}


// ==== sub_7FF91DD19EE0 @ rva 0xB9EE0 ====
void __fastcall sub_7FF91DD19EE0(struct _Mtx_internal_imp_t *a1)
{
  int v1; // eax

  v1 = Mtx_lock(a1);
  if ( v1 )
    std::_Throw_C_error(v1);
}


// ==== sub_7FF91DD19F00 @ rva 0xB9F00 ====
void __fastcall sub_7FF91DD19F00(struct _Mtx_internal_imp_t *a1)
{
  int v1; // eax

  v1 = Mtx_unlock(a1);
  if ( v1 )
    std::_Throw_C_error(v1);
}


// ==== sub_7FF91DD19F20 @ rva 0xB9F20 ====
__int64 __fastcall sub_7FF91DD19F20(__int64 a1)
{
  return a1;
}


// ==== ??0mutex@std@@QEAA@XZ @ rva 0xB9F30 ====
std::mutex *__fastcall std::mutex::mutex(std::mutex *this)
{
  Mtx_init_in_situ(this, 2);
  return this;
}


// ==== j__Mtx_destroy_in_situ @ rva 0xB9F50 ====
// attributes: thunk
void __cdecl j__Mtx_destroy_in_situ(_Mtx_t a1)
{
  Mtx_destroy_in_situ(a1);
}


// ==== sub_7FF91DD19F60 @ rva 0xB9F60 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91DD19F60(__int64 a1)
{
  sub_7FF91DD1CB70(a1, *((_QWORD *)Block + 1));
  *((_QWORD *)Block + 1) = Block;
  *(_QWORD *)Block = Block;
  *((_QWORD *)Block + 2) = Block;
  *(&Block + 1) = nullptr;
  j_free(Block);
}


// ==== sub_7FF91DD19FC0 @ rva 0xB9FC0 ====
void **__fastcall sub_7FF91DD19FC0(void **Block)
{
  _BYTE *v2; // rcx
  unsigned __int64 v3; // rax
  unsigned __int64 v4; // rax

  v2 = *Block;
  if ( v2 )
  {
    v3 = ((_BYTE *)Block[2] - v2) >> 3;
    if ( v3 <= 0x1FFFFFFFFFFFFFFFLL )
    {
      if ( 8 * v3 < 0x1000 )
      {
LABEL_8:
        j_free(v2);
        *Block = nullptr;
        Block[1] = nullptr;
        Block[2] = nullptr;
        goto LABEL_9;
      }
      if ( ((unsigned __int8)v2 & 0x1F) == 0 )
      {
        v4 = *((_QWORD *)v2 - 1);
        if ( v4 < (unsigned __int64)v2 && (unsigned __int64)&v2[-v4 - 8] <= 0x1F )
        {
          v2 = *((_BYTE **)v2 - 1);
          goto LABEL_8;
        }
      }
    }
    invalid_parameter_noinfo_noreturn();
  }
LABEL_9:
  j_j_free(Block);
  return Block;
}


// ==== sub_7FF91DD1A050 @ rva 0xBA050 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91DD1A050(__int64 a1)
{
  sub_7FF91DD1C8A0(a1, *((_QWORD *)xmmword_7FF91E91A238 + 1));
  *((_QWORD *)xmmword_7FF91E91A238 + 1) = xmmword_7FF91E91A238;
  *(_QWORD *)xmmword_7FF91E91A238 = xmmword_7FF91E91A238;
  *((_QWORD *)xmmword_7FF91E91A238 + 2) = xmmword_7FF91E91A238;
  *(&xmmword_7FF91E91A238 + 1) = nullptr;
  j_free(xmmword_7FF91E91A238);
}


// ==== sub_7FF91DD1A0B0 @ rva 0xBA0B0 ====
void **__fastcall sub_7FF91DD1A0B0(void **Block)
{
  _DWORD *v2; // rcx

  sub_7FF91DD4E5A0(Block + 8);
  sub_7FF91DD556D0(Block + 5);
  free(Block[5]);
  sub_7FF91DD556D0(Block + 3);
  free(Block[3]);
  sub_7FF91DD556D0(Block + 1);
  free(Block[1]);
  v2 = (char *)*Block - 16;
  if ( (*v2 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v2, 0xFFFFFFFF) )
    j_j_free_0(v2);
  j_j_free(Block);
  return Block;
}


// ==== sub_7FF91DD1A150 @ rva 0xBA150 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91DD1A150(__int64 a1, int a2, _QWORD *a3)
{
  __int64 v4; // rcx
  int v5; // [rsp+48h] [rbp+10h] BYREF
  _QWORD *v6; // [rsp+50h] [rbp+18h]

  v6 = a3;
  v5 = a2;
  v4 = *(_QWORD *)(a1 + 56);
  if ( !v4 )
    Concurrency::cancel_current_task();
  (*(void (__fastcall **)(__int64, int *))(*(_QWORD *)v4 + 16LL))(v4, &v5);
  sub_7FF91DD17A90(a3);
}


// ==== unknown_libname_4228 @ rva 0xBA210 ====
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4228(_QWORD *a1)
{
  return *a1 + 32LL;
}


// ==== unknown_libname_8 @ rva 0xBA220 ====
// Microsoft VisualC v7/14 64bit runtime
_QWORD *__fastcall unknown_libname_8(_QWORD *a1)
{
  *a1 = 0;
  return a1;
}


// ==== unknown_libname_4229 @ rva 0xBA230 ====
// Microsoft VisualC v14 64bit runtime
bool __fastcall unknown_libname_4229(_QWORD *a1, _QWORD *a2)
{
  return *a1 != *a2;
}


// ==== ??$?8$$CBU_EXCEPTION_RECORD@@$$CBU0@@std@@YA_NAEBV?$shared_ptr@$$CBU_EXCEPTION_RECORD@@@0@0@Z @ rva 0xBA240 ====
bool __fastcall std::operator==<_EXCEPTION_RECORD const,_EXCEPTION_RECORD const>(_QWORD *a1, _QWORD *a2)
{
  return *a1 == *a2;
}


// ==== sub_7FF91DD1A250 @ rva 0xBA250 ====
_QWORD *__fastcall sub_7FF91DD1A250(__int64 *a1, _QWORD *a2, __int64 a3)
{
  __int64 *v3; // r14
  __int64 *v6; // rdi
  __int64 *v7; // rbx

  v3 = (__int64 *)*a1;
  v6 = (__int64 *)*a1;
  v7 = *(__int64 **)(*a1 + 8);
  while ( !*((_BYTE *)v7 + 25) )
  {
    if ( (int)sub_7FF91DD1AC80(v7 + 4, a3) >= 0 )
    {
      v6 = v7;
      v7 = (__int64 *)*v7;
    }
    else
    {
      v7 = (__int64 *)v7[2];
    }
  }
  if ( v6 == v3 || (int)sub_7FF91DD1AC80(a3, v6 + 4) < 0 )
    *a2 = v3;
  else
    *a2 = v6;
  return a2;
}


// ==== sub_7FF91DD1A2E0 @ rva 0xBA2E0 ====
__int64 **__fastcall sub_7FF91DD1A2E0(_QWORD *a1, __int64 **a2, __int64 *a3)
{
  __int64 *j; // rbx
  __int64 **v7; // rax
  __int64 *v8; // r8
  __int64 i; // rax
  __int64 **v10; // r10
  __int64 *v11; // r9
  _QWORD *v12; // r8
  _QWORD *k; // rdx
  __int64 *v14; // rcx
  __int64 v15; // rdx
  __int64 *v16; // rax
  __int64 **m; // rcx
  void **v18; // rax
  char v19; // cl
  __int64 **v20; // r11
  __int64 v21; // rdx
  __int64 v22; // rcx
  __int64 v23; // rax

  j = a3;
  if ( !*((_BYTE *)a3 + 25) )
  {
    v7 = (__int64 **)a3[2];
    if ( *((_BYTE *)v7 + 25) )
    {
      for ( i = a3[1]; !*(_BYTE *)(i + 25); i = *(_QWORD *)(i + 8) )
      {
        if ( j != *(__int64 **)(i + 16) )
          break;
        j = (__int64 *)i;
      }
      j = (__int64 *)i;
    }
    else
    {
      v8 = *v7;
      for ( j = (__int64 *)v7; !*((_BYTE *)v8 + 25); v8 = (__int64 *)*v8 )
        j = v8;
    }
  }
  v10 = (__int64 **)a3[2];
  if ( *(_BYTE *)(*a3 + 25) )
    goto LABEL_14;
  if ( *((_BYTE *)v10 + 25) )
  {
    v10 = (__int64 **)*a3;
LABEL_14:
    v11 = (__int64 *)a3[1];
    if ( !*((_BYTE *)v10 + 25) )
      v10[1] = v11;
    if ( *(__int64 **)(*a1 + 8LL) == a3 )
    {
      *(_QWORD *)(*a1 + 8LL) = v10;
    }
    else if ( (__int64 *)*v11 == a3 )
    {
      *v11 = (__int64)v10;
    }
    else
    {
      v11[2] = (__int64)v10;
    }
    v12 = (_QWORD *)*a1;
    if ( *(__int64 **)*a1 == a3 )
    {
      if ( *((_BYTE *)v10 + 25) )
      {
        k = v11;
      }
      else
      {
        v14 = *v10;
        for ( k = v10; !*((_BYTE *)v14 + 25); v14 = (__int64 *)*v14 )
          k = v14;
      }
      *v12 = k;
    }
    v15 = *a1;
    if ( *(__int64 **)(*a1 + 16LL) == a3 )
    {
      if ( *((_BYTE *)v10 + 25) )
      {
        *(_QWORD *)(v15 + 16) = v11;
      }
      else
      {
        v16 = v10[2];
        for ( m = v10; !*((_BYTE *)v16 + 25); v16 = (__int64 *)v16[2] )
          m = (__int64 **)v16;
        *(_QWORD *)(v15 + 16) = m;
      }
    }
    goto LABEL_44;
  }
  v10 = (__int64 **)j[2];
  if ( j == a3 )
    goto LABEL_14;
  *(_QWORD *)(*a3 + 8) = j;
  *j = *a3;
  if ( j == (__int64 *)a3[2] )
  {
    v11 = j;
  }
  else
  {
    v11 = (__int64 *)j[1];
    if ( !*((_BYTE *)v10 + 25) )
      v10[1] = v11;
    *v11 = (__int64)v10;
    j[2] = a3[2];
    *(_QWORD *)(a3[2] + 8) = j;
  }
  if ( *(__int64 **)(*a1 + 8LL) == a3 )
  {
    *(_QWORD *)(*a1 + 8LL) = j;
  }
  else
  {
    v18 = (void **)a3[1];
    if ( *v18 == a3 )
      *v18 = j;
    else
      v18[2] = j;
  }
  j[1] = a3[1];
  v19 = *((_BYTE *)j + 24);
  *((_BYTE *)j + 24) = *((_BYTE *)a3 + 24);
  *((_BYTE *)a3 + 24) = v19;
LABEL_44:
  if ( *((_BYTE *)a3 + 24) == 1 )
  {
    if ( v10 != *(__int64 ***)(*a1 + 8LL) )
    {
      do
      {
        v20 = (__int64 **)v11;
        if ( *((_BYTE *)v10 + 24) != 1 )
          break;
        v21 = *v11;
        if ( v10 == (__int64 **)*v11 )
        {
          v21 = v11[2];
          if ( !*(_BYTE *)(v21 + 24) )
          {
            *(_BYTE *)(v21 + 24) = 1;
            *((_BYTE *)v11 + 24) = 0;
            sub_7FF91DD1B270(a1);
            v21 = v11[2];
          }
          if ( *(_BYTE *)(v21 + 25) )
            goto LABEL_62;
          if ( *(_BYTE *)(*(_QWORD *)v21 + 24LL) != 1 || *(_BYTE *)(*(_QWORD *)(v21 + 16) + 24LL) != 1 )
          {
            if ( *(_BYTE *)(*(_QWORD *)(v21 + 16) + 24LL) == 1 )
            {
              *(_BYTE *)(*(_QWORD *)v21 + 24LL) = 1;
              *(_BYTE *)(v21 + 24) = 0;
              sub_7FF91DD1B1F0(a1, v21);
              v21 = v11[2];
            }
            *(_BYTE *)(v21 + 24) = *((_BYTE *)v11 + 24);
            *((_BYTE *)v11 + 24) = 1;
            *(_BYTE *)(*(_QWORD *)(v21 + 16) + 24LL) = 1;
            sub_7FF91DD1B270(a1);
            break;
          }
        }
        else
        {
          if ( !*(_BYTE *)(v21 + 24) )
          {
            *(_BYTE *)(v21 + 24) = 1;
            *((_BYTE *)v11 + 24) = 0;
            sub_7FF91DD1B1F0(a1, v11);
            v21 = *v11;
          }
          if ( *(_BYTE *)(v21 + 25) )
            goto LABEL_62;
          v22 = *(_QWORD *)(v21 + 16);
          if ( *(_BYTE *)(v22 + 24) != 1 || *(_BYTE *)(*(_QWORD *)v21 + 24LL) != 1 )
          {
            if ( *(_BYTE *)(*(_QWORD *)v21 + 24LL) == 1 )
            {
              *(_BYTE *)(v22 + 24) = 1;
              *(_BYTE *)(v21 + 24) = 0;
              sub_7FF91DD1B270(a1);
              v21 = *v11;
            }
            *(_BYTE *)(v21 + 24) = *((_BYTE *)v11 + 24);
            *((_BYTE *)v11 + 24) = 1;
            *(_BYTE *)(*(_QWORD *)v21 + 24LL) = 1;
            sub_7FF91DD1B1F0(a1, v11);
            break;
          }
        }
        *(_BYTE *)(v21 + 24) = 0;
LABEL_62:
        v10 = v20;
        v11 = (__int64 *)v11[1];
      }
      while ( v20 != *(__int64 ***)(*a1 + 8LL) );
    }
    *((_BYTE *)v10 + 24) = 1;
  }
  sub_7FF91DD17A90(a3 + 4);
  j_free(a3);
  v23 = a1[1];
  *a2 = j;
  if ( v23 )
    a1[1] = v23 - 1;
  return a2;
}


// ==== ?begin@?$vector@PEAXV?$allocator@PEAX@std@@@std@@QEBA?AV?$_Vector_const_iterator@V?$_Vector_val@U?$_Simple_types@PEAX@std@@@std@@@2@XZ_0 @ rva 0xBA620 ====
_QWORD *__fastcall std::vector<void *>::begin(_QWORD *a1, _QWORD *a2)
{
  *a2 = *a1;
  return a2;
}


// ==== sub_7FF91DD1A630 @ rva 0xBA630 ====
_QWORD *__fastcall sub_7FF91DD1A630(_QWORD **a1, _QWORD *a2)
{
  *a2 = **a1;
  return a2;
}


// ==== sub_7FF91DD1A640 @ rva 0xBA640 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91DD1A640(__int64 a1)
{
  sub_7FF91DD1C8A0(a1, *((_QWORD *)xmmword_7FF91E91A238 + 1));
  *((_QWORD *)xmmword_7FF91E91A238 + 1) = xmmword_7FF91E91A238;
  *(_QWORD *)xmmword_7FF91E91A238 = xmmword_7FF91E91A238;
  *((_QWORD *)xmmword_7FF91E91A238 + 2) = xmmword_7FF91E91A238;
  *(&xmmword_7FF91E91A238 + 1) = nullptr;
  j_free(xmmword_7FF91E91A238);
}


// ==== unknown_libname_4230 @ rva 0xBA6A0 ====
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4230(_QWORD *a1)
{
  return *a1 + 32LL;
}


// ==== unknown_libname_9 @ rva 0xBA6B0 ====
// Microsoft VisualC v7/14 64bit runtime
_QWORD *__fastcall unknown_libname_9(_QWORD *a1)
{
  *a1 = 0;
  return a1;
}


// ==== unknown_libname_4231 @ rva 0xBA6C0 ====
// Microsoft VisualC v14 64bit runtime
bool __fastcall unknown_libname_4231(_QWORD *a1, _QWORD *a2)
{
  return *a1 != *a2;
}


// ==== sub_7FF91DD1A6D0 @ rva 0xBA6D0 ====
_QWORD *__fastcall sub_7FF91DD1A6D0(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  _QWORD *v3; // rbp
  _QWORD *v6; // rsi
  _QWORD *v7; // rdi
  __int64 v8; // rbx

  v3 = Block;
  v6 = Block;
  v7 = *((_QWORD **)Block + 1);
  if ( !*((_BYTE *)v7 + 25) )
  {
    v8 = *a3;
    do
    {
      if ( (int)sub_7FF91DD652D0(v7[4], v8) >= 0 )
      {
        v6 = v7;
        v7 = (_QWORD *)*v7;
      }
      else
      {
        v7 = (_QWORD *)v7[2];
      }
    }
    while ( !*((_BYTE *)v7 + 25) );
  }
  if ( v6 == v3 || (int)sub_7FF91DD652D0(*a3, v6[4]) < 0 )
  {
    *a2 = v3;
    return a2;
  }
  else
  {
    *a2 = v6;
    return a2;
  }
}


// ==== sub_7FF91DD1A780 @ rva 0xBA780 ====
_QWORD *__fastcall sub_7FF91DD1A780(__int64 a1, _QWORD *a2)
{
  *a2 = Block;
  return a2;
}


// ==== sub_7FF91DD1A790 @ rva 0xBA790 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91DD1A790(__int64 a1)
{
  sub_7FF91DD1CB70(a1, *((_QWORD *)Block + 1));
  *((_QWORD *)Block + 1) = Block;
  *(_QWORD *)Block = Block;
  *((_QWORD *)Block + 2) = Block;
  *(&Block + 1) = nullptr;
  j_free(Block);
}


// ==== sub_7FF91DD1A7F0 @ rva 0xBA7F0 ====
char *__fastcall sub_7FF91DD1A7F0(_QWORD *a1, _QWORD *a2)
{
  _QWORD *v3; // rbp
  _QWORD *v4; // rbx
  _QWORD *v5; // rsi
  __int64 v6; // rdi
  __int64 v8; // rax
  __int64 v9; // rcx
  _QWORD *v10; // [rsp+50h] [rbp+8h] BYREF

  v10 = a1;
  v3 = Block;
  v4 = Block;
  v5 = *((_QWORD **)Block + 1);
  if ( !*((_BYTE *)v5 + 25) )
  {
    v6 = *a2;
    do
    {
      if ( (int)sub_7FF91DD652D0(v5[4], v6) >= 0 )
      {
        v4 = v5;
        v5 = (_QWORD *)*v5;
      }
      else
      {
        v5 = (_QWORD *)v5[2];
      }
    }
    while ( !*((_BYTE *)v5 + 25) );
  }
  if ( v4 != v3 && (int)sub_7FF91DD652D0(*a2, v4[4]) >= 0 )
    return (char *)(v4 + 5);
  v10 = a2;
  v8 = sub_7FF91DD1E780(a1, a2, &v10);
  sub_7FF91DD1E7E0(v9, &v10, v4, v8 + 32, v8);
  return (char *)(v10 + 5);
}


// ==== sub_7FF91DD1A8C0 @ rva 0xBA8C0 ====
void **sub_7FF91DD1A8C0()
{
  *(_OWORD *)&Block = 0u;
  Block = (void *)sub_7FF91DD1C9D0();
  return &Block;
}


// ==== sub_7FF91DD1A900 @ rva 0xBA900 ====
__int64 *__fastcall sub_7FF91DD1A900(__int64 *a1, __int64 a2)
{
  __int64 *v2; // rbp
  __int64 *v5; // rbx
  __int64 *v6; // rdi
  void *v8; // rax
  __int64 v9; // [rsp+50h] [rbp+8h] BYREF

  v2 = (__int64 *)*a1;
  v5 = (__int64 *)*a1;
  v6 = *(__int64 **)(*a1 + 8);
  while ( !*((_BYTE *)v6 + 25) )
  {
    if ( (int)sub_7FF91DD1AC80(v6 + 4, a2) >= 0 )
    {
      v5 = v6;
      v6 = (__int64 *)*v6;
    }
    else
    {
      v6 = (__int64 *)v6[2];
    }
  }
  if ( v5 != v2 && (int)sub_7FF91DD1AC80(a2, v5 + 4) >= 0 )
    return v5 + 8;
  v9 = a2;
  v8 = (void *)sub_7FF91DD1EAE0(a1, a2, &v9);
  sub_7FF91DD1EB60((int)a1, v8);
  return (__int64 *)(v9 + 64);
}


// ==== sub_7FF91DD1A9C0 @ rva 0xBA9C0 ====
void **sub_7FF91DD1A9C0()
{
  *(_OWORD *)&xmmword_7FF91E91A238 = 0u;
  xmmword_7FF91E91A238 = (void *)sub_7FF91DD1C860();
  return &xmmword_7FF91E91A238;
}


// ==== unknown_libname_10 @ rva 0xBAA00 ====
// Microsoft VisualC v7/14 64bit runtime
__int64 __fastcall unknown_libname_10(_QWORD *a1, __int64 a2)
{
  return *a1 + 8 * a2;
}


// ==== sub_7FF91DD1AA10 @ rva 0xBAA10 ====
__int64 __fastcall sub_7FF91DD1AA10(_QWORD *a1, unsigned __int64 a2)
{
  if ( (__int64)(a1[1] - *a1) >> 3 <= a2 )
    std::vector<void *>::_Xlen();
  return *a1 + 8 * a2;
}


// ==== unknown_libname_6916 @ rva 0xBAA40 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC 64bit universal runtime
__int64 __fastcall unknown_libname_6916(_QWORD *a1)
{
  return (__int64)(a1[1] - *a1) >> 3;
}


// ==== sub_7FF91DD1AA50 @ rva 0xBAA50 ====
void __fastcall sub_7FF91DD1AA50(__int64 a1)
{
  void *v2; // rcx
  unsigned __int64 v3; // rax
  unsigned __int64 v4; // rax

  v2 = *(void **)a1;
  if ( v2 )
  {
    v3 = (__int64)(*(_QWORD *)(a1 + 16) - (_QWORD)v2) >> 3;
    if ( v3 <= 0x1FFFFFFFFFFFFFFFLL )
    {
      if ( 8 * v3 < 0x1000 )
      {
LABEL_8:
        j_free(v2);
        *(_QWORD *)a1 = 0;
        *(_QWORD *)(a1 + 8) = 0;
        *(_QWORD *)(a1 + 16) = 0;
        return;
      }
      if ( ((unsigned __int8)v2 & 0x1F) == 0 )
      {
        v4 = *((_QWORD *)v2 - 1);
        if ( v4 < (unsigned __int64)v2 && (unsigned __int64)v2 - v4 - 8 <= 0x1F )
        {
          v2 = *((void **)v2 - 1);
          goto LABEL_8;
        }
      }
    }
    invalid_parameter_noinfo_noreturn();
  }
}


// ==== sub_7FF91DD1AAD0 @ rva 0xBAAD0 ====
_QWORD *__fastcall sub_7FF91DD1AAD0(_QWORD *a1, _QWORD *a2)
{
  _QWORD *v2; // r8
  _QWORD *v5; // rax
  __int64 v6; // rdi
  _QWORD *result; // rax

  v2 = (_QWORD *)a1[1];
  if ( a2 >= v2 || *a1 > (unsigned __int64)a2 )
  {
    v5 = (_QWORD *)a1[1];
    if ( v2 == (_QWORD *)a1[2] )
    {
      sub_7FF91DD1B640();
      v2 = (_QWORD *)a1[1];
      v5 = v2;
    }
    if ( v2 )
    {
      *v2 = *a2;
      goto LABEL_11;
    }
  }
  else
  {
    v5 = (_QWORD *)a1[1];
    v6 = ((__int64)a2 - *a1) >> 3;
    if ( v2 == (_QWORD *)a1[2] )
    {
      sub_7FF91DD1B640();
      v2 = (_QWORD *)a1[1];
      v5 = v2;
    }
    if ( v2 )
    {
      *v2 = *(_QWORD *)(*a1 + 8 * v6);
LABEL_11:
      v5 = (_QWORD *)a1[1];
    }
  }
  result = v5 + 1;
  a1[1] = result;
  return result;
}


// ==== unknown_libname_6917 @ rva 0xBAB60 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC 64bit universal runtime
_QWORD *__fastcall unknown_libname_6917(_QWORD *a1)
{
  *a1 = 0;
  a1[1] = 0;
  a1[2] = 0;
  return a1;
}


// ==== ??1?$lock_guard@Vmutex@std@@@std@@QEAA@XZ @ rva 0xBAB80 ====
void __fastcall std::lock_guard<std::mutex>::~lock_guard<std::mutex>(_Mtx_t *a1)
{
  int v1; // eax

  v1 = Mtx_unlock(*a1);
  if ( v1 )
    std::_Throw_C_error(v1);
}


// ==== ??0?$lock_guard@Vmutex@std@@@std@@QEAA@AEAVmutex@1@@Z @ rva 0xBABB0 ====
struct _Mtx_internal_imp_t **__fastcall std::lock_guard<std::mutex>::lock_guard<std::mutex>(
        struct _Mtx_internal_imp_t **a1,
        struct _Mtx_internal_imp_t *a2)
{
  int v3; // eax

  *a1 = a2;
  v3 = Mtx_lock(a2);
  if ( v3 )
    std::_Throw_C_error(v3);
  return a1;
}


// ==== sub_7FF91DD1ABE0 @ rva 0xBABE0 ====
__int64 __fastcall sub_7FF91DD1ABE0(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD1ABF0 @ rva 0xBABF0 ====
int __fastcall sub_7FF91DD1ABF0(_QWORD *a1, _BYTE *a2)
{
  int v2; // esi
  unsigned __int64 v3; // rbx
  size_t *v4; // rdi
  size_t v5; // rdi
  size_t v6; // r8
  int result; // eax

  v2 = 0;
  if ( *a2 )
  {
    v3 = -1;
    do
      ++v3;
    while ( a2[v3] );
  }
  else
  {
    v3 = 0;
  }
  v4 = a1 + 2;
  if ( a1[3] >= 0x10u )
    a1 = (_QWORD *)*a1;
  v5 = *v4;
  v6 = v3;
  if ( v5 < v3 )
    v6 = v5;
  if ( !v6 || (result = memcmp(a1, a2, v6)) == 0 )
  {
    if ( v5 >= v3 )
    {
      LOBYTE(v2) = v5 > v3;
      return v2;
    }
    else
    {
      return -1;
    }
  }
  return result;
}


// ==== sub_7FF91DD1AC80 @ rva 0xBAC80 ====
int __fastcall sub_7FF91DD1AC80(_QWORD *a1, _QWORD *a2)
{
  size_t *v2; // rbx
  size_t *v3; // rdi
  size_t v4; // rbx
  size_t v5; // rdi
  size_t v6; // r8
  int result; // eax

  v2 = a2 + 2;
  if ( a2[3] >= 0x10u )
    a2 = (_QWORD *)*a2;
  v3 = a1 + 2;
  if ( a1[3] >= 0x10u )
    a1 = (_QWORD *)*a1;
  v4 = *v2;
  v5 = *v3;
  v6 = v4;
  if ( v5 < v4 )
    v6 = v5;
  if ( !v6 || (result = memcmp(a1, a2, v6)) == 0 )
  {
    if ( v5 >= v4 )
      return v5 > v4;
    else
      return -1;
  }
  return result;
}


// ==== sub_7FF91DD1ACF0 @ rva 0xBACF0 ====
__int64 __fastcall sub_7FF91DD1ACF0(_QWORD *a1, _BYTE *a2)
{
  _QWORD *v3; // rbx
  unsigned __int64 v4; // rdi
  unsigned __int64 v5; // rdx
  _QWORD *v6; // rax
  _QWORD *v7; // rax
  __int64 v8; // r8
  unsigned __int64 v9; // rbp
  _QWORD *v10; // rcx
  bool v11; // cf
  _QWORD *v12; // rax

  v3 = a1;
  if ( *a2 )
  {
    v4 = -1;
    do
      ++v4;
    while ( a2[v4] );
  }
  else
  {
    v4 = 0;
  }
  v5 = a1[3];
  if ( v5 < 0x10 )
    v6 = a1;
  else
    v6 = (_QWORD *)*a1;
  if ( a2 < (_BYTE *)v6 )
    goto LABEL_16;
  if ( v5 >= 0x10 )
    a1 = (_QWORD *)*a1;
  if ( (char *)a1 + v3[2] <= a2 )
  {
LABEL_16:
    v8 = v3[2];
    if ( ~v8 <= v4 )
      goto LABEL_33;
    v9 = v8 + v4;
    if ( !v4 )
      return (__int64)v3;
    if ( v9 == -1 )
LABEL_33:
      std::vector<void *>::_Xlen();
    if ( v5 >= v9 )
    {
      if ( !v9 )
      {
        v3[2] = 0;
        if ( v5 < 0x10 )
          *(_BYTE *)v3 = 0;
        else
          *(_BYTE *)*v3 = 0;
        return (__int64)v3;
      }
    }
    else
    {
      sub_7FF91DD18400(v3, v8 + v4, v8);
      if ( !v9 )
        return (__int64)v3;
    }
    if ( v3[3] < 0x10u )
      v10 = v3;
    else
      v10 = (_QWORD *)*v3;
    sub_7FF91E30DC00((char *)v10 + v3[2], a2, v4);
    v11 = v3[3] < 0x10u;
    v3[2] = v9;
    if ( v11 )
      v12 = v3;
    else
      v12 = (_QWORD *)*v3;
    *((_BYTE *)v12 + v9) = 0;
  }
  else
  {
    if ( v5 < 0x10 )
      v7 = v3;
    else
      v7 = (_QWORD *)*v3;
    return sub_7FF91DD1B8A0(v3, v3, a2 - (_BYTE *)v7, v4);
  }
  return (__int64)v3;
}


// ==== unknown_libname_13 @ rva 0xBAE30 ====
// Microsoft VisualC v7/14 64bit runtime
__int64 __fastcall unknown_libname_13(__int64 a1, __int64 a2)
{
  return sub_7FF91DD1B8A0(a1, a2, 0, -1);
}


// ==== sub_7FF91DD1AE70 @ rva 0xBAE70 ====
void __fastcall sub_7FF91DD1AE70(_QWORD *a1)
{
  a1[3] = 15;
  a1[2] = 0;
  *(_BYTE *)a1 = 0;
}


// ==== sub_7FF91DD1AE90 @ rva 0xBAE90 ====
__int64 __fastcall sub_7FF91DD1AE90(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1AEA0 @ rva 0xBAEA0 ====
__int64 __fastcall sub_7FF91DD1AEA0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1AEB0 @ rva 0xBAEB0 ====
__int64 __fastcall sub_7FF91DD1AEB0(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== get_srw_lock_1 @ rva 0xBAEC0 ====
__int64 __fastcall get_srw_lock_1(__int64 a1)
{
  return a1 + 16;
}


// ==== ?GetLocaleT@_LocaleUpdate@@QEAAPEAU__crt_locale_pointers@@XZ @ rva 0xBAED0 ====
struct __crt_locale_pointers *__fastcall _LocaleUpdate::GetLocaleT(_LocaleUpdate *this)
{
  return (struct __crt_locale_pointers *)((char *)this + 8);
}


// ==== ?GetLocaleT@_LocaleUpdate@@QEAAPEAU__crt_locale_pointers@@XZ_0 @ rva 0xBAEE0 ====
struct __crt_locale_pointers *__fastcall _LocaleUpdate::GetLocaleT(_LocaleUpdate *this)
{
  return (struct __crt_locale_pointers *)((char *)this + 8);
}


// ==== sub_7FF91DD1AEF0 @ rva 0xBAEF0 ====
__int64 __fastcall sub_7FF91DD1AEF0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1AF00 @ rva 0xBAF00 ====
__int64 __fastcall sub_7FF91DD1AF00(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1AF10 @ rva 0xBAF10 ====
__int64 __fastcall sub_7FF91DD1AF10(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_6918 @ rva 0xBAF20 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC 64bit universal runtime
_QWORD *__fastcall unknown_libname_6918(_QWORD *a1)
{
  *a1 = 0;
  a1[1] = 0;
  a1[2] = 0;
  return a1;
}


// ==== ?_GetThrowImageBase@__ExceptionPtr@@AEBA_JXZ @ rva 0xBAF40 ====
__int64 __fastcall __ExceptionPtr::_GetThrowImageBase(__ExceptionPtr *this)
{
  return *((_QWORD *)this + 7);
}


// ==== ?_Empty@?$_Func_class@X$$V@std@@IEBA_NXZ @ rva 0xBAF50 ====
bool __fastcall std::_Func_class<void,>::_Empty(__int64 a1)
{
  return *(_QWORD *)(a1 + 56) == 0;
}


// ==== sub_7FF91DD1AF60 @ rva 0xBAF60 ====
__int64 __fastcall sub_7FF91DD1AF60(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== ??$?0U_Exact_args_t@std@@AEBQEAX$$V$0A@@?$tuple@AEBQEAX@std@@QEAA@U_Exact_args_t@1@AEBQEAX@Z @ rva 0xBAF9F ====
_QWORD *__fastcall std::tuple<void * const &>::tuple<void * const &>(_QWORD *a1, __int64 a2, __int64 a3)
{
  *a1 = a3;
  return a1;
}


// ==== unknown_libname_4232 @ rva 0xBAFD0 ====
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4232(_QWORD *a1)
{
  return *a1 + 32LL;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_4 @ rva 0xBAFE0 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== ??$?0U_Exact_args_t@std@@AEBQEAX$$V$0A@@?$tuple@AEBQEAX@std@@QEAA@U_Exact_args_t@1@AEBQEAX@Z_0 @ rva 0xBB01F ====
_QWORD *__fastcall std::tuple<void * const &>::tuple<void * const &>(_QWORD *a1, __int64 a2, __int64 a3)
{
  *a1 = a3;
  return a1;
}


// ==== unknown_libname_15 @ rva 0xBB050 ====
// Microsoft VisualC v7/14 64bit runtime
_QWORD *__fastcall unknown_libname_15(_QWORD *a1)
{
  *a1 = 0;
  return a1;
}


// ==== sub_7FF91DD1B060 @ rva 0xBB060 ====
void __fastcall sub_7FF91DD1B060(__int64 a1, void *a2)
{
  j_free(a2);
}


// ==== ?GetLocaleT@_LocaleUpdate@@QEAAPEAU__crt_locale_pointers@@XZ_1 @ rva 0xBB070 ====
struct __crt_locale_pointers *__fastcall _LocaleUpdate::GetLocaleT(_LocaleUpdate *this)
{
  return (struct __crt_locale_pointers *)((char *)this + 8);
}


// ==== sub_7FF91DD1B080 @ rva 0xBB080 ====
__int64 __fastcall sub_7FF91DD1B080(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1B090 @ rva 0xBB090 ====
__int64 __fastcall sub_7FF91DD1B090(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1B0A0 @ rva 0xBB0A0 ====
__int64 __fastcall sub_7FF91DD1B0A0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1B0B0 @ rva 0xBB0B0 ====
__int64 __fastcall sub_7FF91DD1B0B0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1B0C0 @ rva 0xBB0C0 ====
void sub_7FF91DD1B0C0()
{
  j_free(xmmword_7FF91E91A238);
}


// ==== sub_7FF91DD1B130 @ rva 0xBB130 ====
__int64 __fastcall sub_7FF91DD1B130(__int64 a1)
{
  return a1 + 32;
}


// ==== get_srw_lock_2 @ rva 0xBB140 ====
__int64 __fastcall get_srw_lock_2(__int64 a1)
{
  return a1 + 16;
}


// ==== ?GetLocaleT@_LocaleUpdate@@QEAAPEAU__crt_locale_pointers@@XZ_2 @ rva 0xBB150 ====
struct __crt_locale_pointers *__fastcall _LocaleUpdate::GetLocaleT(_LocaleUpdate *this)
{
  return (struct __crt_locale_pointers *)((char *)this + 8);
}


// ==== sub_7FF91DD1B160 @ rva 0xBB160 ====
__int64 __fastcall sub_7FF91DD1B160(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1B170 @ rva 0xBB170 ====
__int64 __fastcall sub_7FF91DD1B170(__int64 a1)
{
  return a1 + 25;
}


// ==== sub_7FF91DD1B180 @ rva 0xBB180 ====
__int64 __fastcall sub_7FF91DD1B180(__int64 a1)
{
  return a1 + 24;
}


// ==== sub_7FF91DD1B190 @ rva 0xBB190 ====
__int64 __fastcall sub_7FF91DD1B190(__int64 a1, __int64 a2)
{
  return a2 + 32;
}


// ==== sub_7FF91DD1B1A0 @ rva 0xBB1A0 ====
// Hidden C++ exception states: #wind=1
void *__fastcall sub_7FF91DD1B1A0(__int64 a1)
{
  void *result; // rax

  sub_7FF91DD1C8A0(a1, *((_QWORD *)xmmword_7FF91E91A238 + 1));
  *((_QWORD *)xmmword_7FF91E91A238 + 1) = xmmword_7FF91E91A238;
  *(_QWORD *)xmmword_7FF91E91A238 = xmmword_7FF91E91A238;
  result = xmmword_7FF91E91A238;
  *((_QWORD *)xmmword_7FF91E91A238 + 2) = xmmword_7FF91E91A238;
  *(&xmmword_7FF91E91A238 + 1) = nullptr;
  return result;
}


// ==== sub_7FF91DD1B1F0 @ rva 0xBB1F0 ====
_QWORD *__fastcall sub_7FF91DD1B1F0(__int64 a1, _QWORD *a2)
{
  __int64 v2; // r8
  __int64 v3; // rax
  _QWORD *result; // rax

  v2 = *a2;
  *a2 = *(_QWORD *)(*a2 + 16LL);
  v3 = *(_QWORD *)(v2 + 16);
  if ( !*(_BYTE *)(v3 + 25) )
    *(_QWORD *)(v3 + 8) = a2;
  *(_QWORD *)(v2 + 8) = a2[1];
  result = *(_QWORD **)a1;
  if ( a2 == *(_QWORD **)(*(_QWORD *)a1 + 8LL) )
  {
    result[1] = v2;
    *(_QWORD *)(v2 + 16) = a2;
    a2[1] = v2;
  }
  else
  {
    result = (_QWORD *)a2[1];
    if ( a2 == (_QWORD *)result[2] )
      result[2] = v2;
    else
      *result = v2;
    *(_QWORD *)(v2 + 16) = a2;
    a2[1] = v2;
  }
  return result;
}


// ==== _Mtx_getconcrtcs @ rva 0xBB250 ====
void *__cdecl Mtx_getconcrtcs(_Mtx_t a1)
{
  return (void *)(*(_QWORD *)a1 + 8LL);
}


// ==== sub_7FF91DD1B260 @ rva 0xBB260 ====
__int64 __fastcall sub_7FF91DD1B260(_QWORD *a1)
{
  return *a1 + 16LL;
}


// ==== sub_7FF91DD1B270 @ rva 0xBB270 ====
_QWORD *__fastcall sub_7FF91DD1B270(__int64 a1, __int64 a2)
{
  _QWORD *v2; // r8
  _QWORD *result; // rax

  v2 = *(_QWORD **)(a2 + 16);
  *(_QWORD *)(a2 + 16) = *v2;
  if ( !*(_BYTE *)(*v2 + 25LL) )
    *(_QWORD *)(*v2 + 8LL) = a2;
  v2[1] = *(_QWORD *)(a2 + 8);
  result = *(_QWORD **)a1;
  if ( a2 == *(_QWORD *)(*(_QWORD *)a1 + 8LL) )
  {
    result[1] = v2;
    *v2 = a2;
    *(_QWORD *)(a2 + 8) = v2;
  }
  else
  {
    result = *(_QWORD **)(a2 + 8);
    if ( a2 == *result )
      *result = v2;
    else
      result[2] = v2;
    *v2 = a2;
    *(_QWORD *)(a2 + 8) = v2;
  }
  return result;
}


// ==== sub_7FF91DD1B2D0 @ rva 0xBB2D0 ====
__int64 __fastcall sub_7FF91DD1B2D0(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD1B2E0 @ rva 0xBB2E0 ====
_QWORD *__fastcall sub_7FF91DD1B2E0(__int64 *a1, _QWORD *a2, _QWORD *a3)
{
  __int64 *v3; // rdi
  __int64 *v6; // rbx

  v3 = (__int64 *)*a1;
  v6 = *(__int64 **)(*a1 + 8);
  if ( *((_BYTE *)v6 + 25) )
  {
    *a2 = v3;
  }
  else
  {
    do
    {
      if ( sub_7FF91DD1AC80(v6 + 4, a3) >= 0 )
      {
        v3 = v6;
        v6 = (__int64 *)*v6;
      }
      else
      {
        v6 = (__int64 *)v6[2];
      }
    }
    while ( !*((_BYTE *)v6 + 25) );
    *a2 = v3;
  }
  return a2;
}


// ==== sub_7FF91DD1B360 @ rva 0xBB360 ====
void **sub_7FF91DD1B360()
{
  *(_OWORD *)&xmmword_7FF91E91A238 = 0u;
  xmmword_7FF91E91A238 = (void *)sub_7FF91DD1C860();
  return &xmmword_7FF91E91A238;
}


// ==== unknown_libname_4233 @ rva 0xBB3A0 ====
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4233(_QWORD *a1)
{
  return *a1 + 32LL;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_5 @ rva 0xBB3B0 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== ??$?8$$CBU_EXCEPTION_RECORD@@$$CBU0@@std@@YA_NAEBV?$shared_ptr@$$CBU_EXCEPTION_RECORD@@@0@0@Z_0 @ rva 0xBB3C0 ====
bool __fastcall std::operator==<_EXCEPTION_RECORD const,_EXCEPTION_RECORD const>(_QWORD *a1, _QWORD *a2)
{
  return *a1 == *a2;
}


// ==== unknown_libname_16 @ rva 0xBB3D0 ====
// Microsoft VisualC v7/14 64bit runtime
_QWORD *__fastcall unknown_libname_16(_QWORD *a1)
{
  *a1 = 0;
  return a1;
}


// ==== sub_7FF91DD1B3E0 @ rva 0xBB3E0 ====
void **sub_7FF91DD1B3E0()
{
  return &Block;
}


// ==== sub_7FF91DD1B3F0 @ rva 0xBB3F0 ====
void **sub_7FF91DD1B3F0()
{
  return &Block;
}


// ==== sub_7FF91DD1B400 @ rva 0xBB400 ====
void **sub_7FF91DD1B400()
{
  return &Block;
}


// ==== sub_7FF91DD1B410 @ rva 0xBB410 ====
void sub_7FF91DD1B410()
{
  j_free(Block);
}


// ==== sub_7FF91DD1B420 @ rva 0xBB420 ====
__int64 __fastcall sub_7FF91DD1B420(__int64 a1, __int64 a2)
{
  return a2 + 32;
}


// ==== sub_7FF91DD1B430 @ rva 0xBB430 ====
// Hidden C++ exception states: #wind=1
void *__fastcall sub_7FF91DD1B430(__int64 a1)
{
  void *result; // rax

  sub_7FF91DD1CB70(a1, *((_QWORD *)Block + 1));
  *((_QWORD *)Block + 1) = Block;
  *(_QWORD *)Block = Block;
  result = Block;
  *((_QWORD *)Block + 2) = Block;
  *(&Block + 1) = nullptr;
  return result;
}


// ==== sub_7FF91DD1B480 @ rva 0xBB480 ====
_QWORD *__fastcall sub_7FF91DD1B480(__int64 a1, _QWORD *a2, __int64 *a3)
{
  void *v3; // rsi
  _QWORD *v5; // rdi
  __int64 v6; // rbx

  v3 = Block;
  v5 = *((_QWORD **)Block + 1);
  if ( *((_BYTE *)v5 + 25) )
  {
    *a2 = Block;
    return a2;
  }
  else
  {
    v6 = *a3;
    do
    {
      if ( (int)sub_7FF91DD652D0(v5[4], v6) >= 0 )
      {
        v3 = v5;
        v5 = (_QWORD *)*v5;
      }
      else
      {
        v5 = (_QWORD *)v5[2];
      }
    }
    while ( !*((_BYTE *)v5 + 25) );
    *a2 = v3;
    return a2;
  }
}


// ==== sub_7FF91DD1B510 @ rva 0xBB510 ====
void **sub_7FF91DD1B510()
{
  *(_OWORD *)&Block = 0u;
  Block = (void *)sub_7FF91DD1C9D0();
  return &Block;
}


// ==== sub_7FF91DD1B550 @ rva 0xBB550 ====
__int64 __fastcall sub_7FF91DD1B550(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  return (unsigned int)sub_7FF91DD652D0(*a2, *a3) >> 31;
}


// ==== sub_7FF91DD1B570 @ rva 0xBB570 ====
__int64 __fastcall sub_7FF91DD1B570(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  return (unsigned int)sub_7FF91DD1AC80(a2, a3) >> 31;
}


// ==== nullsub_128 @ rva 0xBB590 ====
void nullsub_128()
{
  ;
}


// ==== ?_Xlen@?$vector@PEAXV?$allocator@PEAX@std@@@std@@IEBAXXZ_1 @ rva 0xBB5A0 ====
void __noreturn std::vector<void *>::_Xlen()
{
  sub_7FF91E2A81C8("invalid vector<T> subscript");
}


// ==== sub_7FF91DD1B5C0 @ rva 0xBB5C0 ====
void __fastcall sub_7FF91DD1B5C0(__int64 a1)
{
  void *v2; // rcx
  unsigned __int64 v3; // rax
  unsigned __int64 v4; // rax

  v2 = *(void **)a1;
  if ( v2 )
  {
    v3 = (__int64)(*(_QWORD *)(a1 + 16) - (_QWORD)v2) >> 3;
    if ( v3 <= 0x1FFFFFFFFFFFFFFFLL )
    {
      if ( 8 * v3 < 0x1000 )
      {
LABEL_8:
        j_free(v2);
        *(_QWORD *)a1 = 0;
        *(_QWORD *)(a1 + 8) = 0;
        *(_QWORD *)(a1 + 16) = 0;
        return;
      }
      if ( ((unsigned __int8)v2 & 0x1F) == 0 )
      {
        v4 = *((_QWORD *)v2 - 1);
        if ( v4 < (unsigned __int64)v2 && (unsigned __int64)v2 - v4 - 8 <= 0x1F )
        {
          v2 = *((void **)v2 - 1);
          goto LABEL_8;
        }
      }
    }
    invalid_parameter_noinfo_noreturn();
  }
}


// ==== sub_7FF91DD1B640 @ rva 0xBB640 ====
__int64 __fastcall sub_7FF91DD1B640(__int64 *a1)
{
  __int64 v1; // r9
  __int64 v3; // rdx
  __int64 result; // rax
  __int64 v5; // rcx
  __int64 v6; // rdx
  unsigned __int64 v7; // rdx
  unsigned __int64 v8; // r9
  unsigned __int64 v9; // rcx

  v1 = a1[2];
  v3 = a1[1];
  result = (v1 - v3) >> 3;
  if ( !result )
  {
    v5 = *a1;
    v6 = (v3 - v5) >> 3;
    if ( v6 == 0x1FFFFFFFFFFFFFFFLL )
      std::vector<void *>::_Xlen(v5, 0x1FFFFFFFFFFFFFFFLL, a1);
    v7 = v6 + 1;
    v8 = (v1 - v5) >> 3;
    v9 = 0;
    if ( 0x1FFFFFFFFFFFFFFFLL - (v8 >> 1) >= v8 )
      v9 = v8 + (v8 >> 1);
    if ( v9 >= v7 )
      v7 = v9;
    return sub_7FF91DD1BF80(a1, v7);
  }
  return result;
}


// ==== sub_7FF91DD1B6E0 @ rva 0xBB6E0 ====
int __fastcall sub_7FF91DD1B6E0(const void *a1, size_t a2, const void *a3, size_t a4)
{
  size_t v5; // r8
  int result; // eax

  v5 = a4;
  if ( a2 < a4 )
    v5 = a2;
  if ( !v5 || (result = memcmp(a1, a3, v5)) == 0 )
  {
    if ( a2 >= a4 )
      return a2 > a4;
    else
      return -1;
  }
  return result;
}


// ==== sub_7FF91DD1B740 @ rva 0xBB740 ====
__int64 __fastcall sub_7FF91DD1B740(__int64 a1)
{
  return *(_QWORD *)(a1 + 24);
}


// ==== __except_get_jumpbuf_sp_0 @ rva 0xBB750 ====
__int64 __fastcall _except_get_jumpbuf_sp_0(__int64 a1)
{
  return *(_QWORD *)(a1 + 16);
}


// ==== sub_7FF91DD1B760 @ rva 0xBB760 ====
__int64 __fastcall sub_7FF91DD1B760(_QWORD *a1, unsigned __int64 a2, unsigned __int64 a3)
{
  _QWORD *v5; // rbx
  unsigned __int64 v6; // r9
  _QWORD *v7; // rax
  _QWORD *v8; // rax
  __int64 v10; // r8
  unsigned __int64 v11; // rdi
  _QWORD *v12; // rcx
  bool v13; // cf
  _QWORD *v14; // rax

  v5 = a1;
  if ( !a2 )
    goto LABEL_13;
  v6 = a1[3];
  v7 = v6 < 0x10 ? a1 : (_QWORD *)*a1;
  if ( a2 < (unsigned __int64)v7 )
    goto LABEL_13;
  if ( v6 >= 0x10 )
    a1 = (_QWORD *)*a1;
  if ( (unsigned __int64)a1 + v5[2] <= a2 )
  {
LABEL_13:
    v10 = v5[2];
    if ( ~v10 > a3 )
    {
      v11 = v10 + a3;
      if ( !a3 )
        return (__int64)v5;
      if ( v11 != -1 )
      {
        if ( v5[3] >= v11 )
        {
          if ( v11 )
            goto LABEL_18;
          v5[2] = 0;
          if ( v5[3] < 0x10u )
            *(_BYTE *)v5 = 0;
          else
            *(_BYTE *)*v5 = 0;
        }
        else
        {
          sub_7FF91DD18400(v5, v10 + a3, v10);
          if ( v11 )
          {
LABEL_18:
            if ( v5[3] < 0x10u )
              v12 = v5;
            else
              v12 = (_QWORD *)*v5;
            sub_7FF91E30DC00((char *)v12 + v5[2], a2, a3);
            v13 = v5[3] < 0x10u;
            v5[2] = v11;
            if ( v13 )
              v14 = v5;
            else
              v14 = (_QWORD *)*v5;
            *((_BYTE *)v14 + v11) = 0;
          }
        }
        return (__int64)v5;
      }
    }
    std::vector<void *>::_Xlen();
  }
  if ( v6 < 0x10 )
    v8 = v5;
  else
    v8 = (_QWORD *)*v5;
  return sub_7FF91DD1B8A0(v5, v5, a2 - (_QWORD)v8, a3);
}


// ==== sub_7FF91DD1B8A0 @ rva 0xBB8A0 ====
_QWORD *__fastcall sub_7FF91DD1B8A0(_QWORD *a1, _QWORD *a2, unsigned __int64 a3, unsigned __int64 a4)
{
  unsigned __int64 v4; // rax
  unsigned __int64 v5; // rbp
  _QWORD *v7; // rsi
  unsigned __int64 v9; // rax
  __int64 v10; // r8
  unsigned __int64 v11; // rdi
  _QWORD *v12; // rcx
  bool v13; // cf
  _QWORD *v14; // rax

  v4 = a2[2];
  v5 = a4;
  v7 = a2;
  if ( v4 < a3 )
    std::vector<void *>::_Xlen();
  v9 = v4 - a3;
  v10 = a1[2];
  if ( a4 > v9 )
    v5 = v9;
  if ( ~v10 <= v5 )
    goto LABEL_24;
  v11 = v10 + v5;
  if ( !v5 )
    return a1;
  if ( v11 == -1 )
LABEL_24:
    std::vector<void *>::_Xlen();
  if ( a1[3] >= v11 )
  {
    if ( !v11 )
    {
      a1[2] = 0;
      if ( a1[3] < 0x10u )
        *(_BYTE *)a1 = 0;
      else
        *(_BYTE *)*a1 = 0;
      return a1;
    }
  }
  else
  {
    sub_7FF91DD18400(a1, v10 + v5, v10);
    if ( !v11 )
      return a1;
  }
  if ( v7[3] >= 0x10u )
    v7 = (_QWORD *)*v7;
  if ( a1[3] < 0x10u )
    v12 = a1;
  else
    v12 = (_QWORD *)*a1;
  sub_7FF91E30DC00((char *)v12 + a1[2], (char *)v7 + a3, v5);
  v13 = a1[3] < 0x10u;
  a1[2] = v11;
  if ( v13 )
    v14 = a1;
  else
    v14 = (_QWORD *)*a1;
  *((_BYTE *)v14 + v11) = 0;
  return a1;
}


// ==== unknown_libname_17 @ rva 0xBB9B0 ====
// Microsoft VisualC v7/14 64bit runtime
_QWORD *__fastcall unknown_libname_17(_QWORD *a1)
{
  *a1 = 0;
  return a1;
}


// ==== sub_7FF91DD1B9C0 @ rva 0xBB9C0 ====
__int64 __fastcall sub_7FF91DD1B9C0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1B9D0 @ rva 0xBB9D0 ====
void __fastcall sub_7FF91DD1B9D0(__int64 a1, _QWORD *a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rax

  if ( a3 > 0x1FFFFFFFFFFFFFFFLL )
    goto LABEL_8;
  if ( 8 * a3 >= 0x1000 )
  {
    if ( ((unsigned __int8)a2 & 0x1F) == 0 )
    {
      v3 = *(a2 - 1);
      if ( v3 < (unsigned __int64)a2 && (unsigned __int64)a2 - v3 - 8 <= 0x1F )
      {
        a2 = (_QWORD *)*(a2 - 1);
        goto LABEL_7;
      }
    }
LABEL_8:
    invalid_parameter_noinfo_noreturn();
  }
LABEL_7:
  j_free(a2);
}


// ==== sub_7FF91DD1BA30 @ rva 0xBBA30 ====
__int64 __fastcall sub_7FF91DD1BA30(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1BA40 @ rva 0xBBA40 ====
__int64 __fastcall sub_7FF91DD1BA40(__int64 a1)
{
  return a1;
}


// ==== nullsub_129 @ rva 0xBBA50 ====
void nullsub_129()
{
  ;
}


// ==== ??$?0U_Exact_args_t@std@@AEBQEAX$$V$0A@@?$tuple@AEBQEAX@std@@QEAA@U_Exact_args_t@1@AEBQEAX@Z_1 @ rva 0xBBA8F ====
_QWORD *__fastcall std::tuple<void * const &>::tuple<void * const &>(_QWORD *a1, __int64 a2, __int64 a3)
{
  *a1 = a3;
  return a1;
}


// ==== unknown_libname_18 @ rva 0xBBAC0 ====
// Microsoft VisualC v7/14 64bit runtime
_QWORD *__fastcall unknown_libname_18(_QWORD *a1)
{
  *a1 = 0;
  return a1;
}


// ==== sub_7FF91DD1BAD0 @ rva 0xBBAD0 ====
__int64 __fastcall sub_7FF91DD1BAD0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1BAE0 @ rva 0xBBAE0 ====
__int64 __fastcall sub_7FF91DD1BAE0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1BAF0 @ rva 0xBBAF0 ====
__int64 __fastcall sub_7FF91DD1BAF0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1BB00 @ rva 0xBBB00 ====
__int64 __fastcall sub_7FF91DD1BB00(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_4234 @ rva 0xBBB10 ====
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4234(_QWORD *a1)
{
  return *a1 + 32LL;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_6 @ rva 0xBBB20 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1BB90 @ rva 0xBBB90 ====
__int64 __fastcall sub_7FF91DD1BB90(__int64 a1)
{
  return a1 + 32;
}


// ==== get_srw_lock_3 @ rva 0xBBBA0 ====
__int64 __fastcall get_srw_lock_3(__int64 a1)
{
  return a1 + 16;
}


// ==== ?GetLocaleT@_LocaleUpdate@@QEAAPEAU__crt_locale_pointers@@XZ_3 @ rva 0xBBBB0 ====
struct __crt_locale_pointers *__fastcall _LocaleUpdate::GetLocaleT(_LocaleUpdate *this)
{
  return (struct __crt_locale_pointers *)((char *)this + 8);
}


// ==== sub_7FF91DD1BBC0 @ rva 0xBBBC0 ====
__int64 __fastcall sub_7FF91DD1BBC0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1BBD0 @ rva 0xBBBD0 ====
__int64 __fastcall sub_7FF91DD1BBD0(__int64 a1)
{
  return a1 + 25;
}


// ==== sub_7FF91DD1BBE0 @ rva 0xBBBE0 ====
__int64 __fastcall sub_7FF91DD1BBE0(__int64 a1)
{
  return a1 + 24;
}


// ==== sub_7FF91DD1BBF0 @ rva 0xBBBF0 ====
void __fastcall sub_7FF91DD1BBF0(__int64 a1, void *a2)
{
  j_free(a2);
}


// ==== sub_7FF91DD1BC00 @ rva 0xBBC00 ====
__int64 __fastcall sub_7FF91DD1BC00(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1BC10 @ rva 0xBBC10 ====
void __fastcall sub_7FF91DD1BC10(__int64 a1, void *a2)
{
  j_free(a2);
}


// ==== sub_7FF91DD1BC20 @ rva 0xBBC20 ====
void **sub_7FF91DD1BC20()
{
  *(_OWORD *)&xmmword_7FF91E91A238 = 0;
  xmmword_7FF91E91A238 = (void *)sub_7FF91DD1C860();
  return &xmmword_7FF91E91A238;
}


// ==== sub_7FF91DD1BC50 @ rva 0xBBC50 ====
__int64 __fastcall sub_7FF91DD1BC50(__int64 a1, __int64 a2)
{
  return a2;
}


// ==== sub_7FF91DD1BC60 @ rva 0xBBC60 ====
// Hidden C++ exception states: #wind=1
__int64 **__fastcall sub_7FF91DD1BC60(__int64 *a1, __int64 **a2, __int64 *a3, __int64 *a4)
{
  __int64 *v5; // rbx
  __int64 *v8; // r8
  _BYTE *v9; // rax
  __int64 *v10; // rcx
  __int64 i; // rax
  __int64 *v12; // [rsp+40h] [rbp+8h] BYREF

  v12 = a1;
  v5 = a3;
  if ( a3 == *(__int64 **)xmmword_7FF91E91A238 && a4 == xmmword_7FF91E91A238 )
  {
    sub_7FF91DD1C8A0(a1, *((_QWORD *)xmmword_7FF91E91A238 + 1));
    *((_QWORD *)xmmword_7FF91E91A238 + 1) = xmmword_7FF91E91A238;
    *(_QWORD *)xmmword_7FF91E91A238 = xmmword_7FF91E91A238;
    *((_QWORD *)xmmword_7FF91E91A238 + 2) = xmmword_7FF91E91A238;
    *(&xmmword_7FF91E91A238 + 1) = nullptr;
    *a2 = *(__int64 **)xmmword_7FF91E91A238;
    return a2;
  }
  else
  {
    if ( a3 != a4 )
    {
      do
      {
        v8 = v5;
        if ( !*((_BYTE *)v5 + 25) )
        {
          v9 = (_BYTE *)v5[2];
          if ( v9[25] )
          {
            for ( i = v5[1]; !*(_BYTE *)(i + 25); i = *(_QWORD *)(i + 8) )
            {
              if ( v5 != *(__int64 **)(i + 16) )
                break;
              v5 = (__int64 *)i;
            }
            v5 = (__int64 *)i;
          }
          else
          {
            v5 = (__int64 *)v5[2];
            v10 = *(__int64 **)v9;
            if ( !*(_BYTE *)(*(_QWORD *)v9 + 25LL) )
            {
              do
              {
                v5 = v10;
                v10 = (__int64 *)*v10;
              }
              while ( !*((_BYTE *)v10 + 25) );
            }
          }
        }
        sub_7FF91DD1A2E0(&xmmword_7FF91E91A238, &v12, v8);
      }
      while ( v5 != a4 );
    }
    *a2 = v5;
    return a2;
  }
}


// ==== sub_7FF91DD1BD80 @ rva 0xBBD80 ====
void **sub_7FF91DD1BD80()
{
  return &Block;
}


// ==== sub_7FF91DD1BD90 @ rva 0xBBD90 ====
void **sub_7FF91DD1BD90()
{
  return &Block;
}


// ==== sub_7FF91DD1BDA0 @ rva 0xBBDA0 ====
__int64 __fastcall sub_7FF91DD1BDA0(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_4235 @ rva 0xBBDB0 ====
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4235(_QWORD *a1)
{
  return *a1 + 32LL;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_7 @ rva 0xBBDC0 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1BDD0 @ rva 0xBBDD0 ====
void __fastcall sub_7FF91DD1BDD0(__int64 a1, void *a2)
{
  j_free(a2);
}


// ==== sub_7FF91DD1BDE0 @ rva 0xBBDE0 ====
void **sub_7FF91DD1BDE0()
{
  *(_OWORD *)&Block = 0;
  Block = (void *)sub_7FF91DD1C9D0();
  return &Block;
}


// ==== sub_7FF91DD1BE10 @ rva 0xBBE10 ====
__int64 __fastcall sub_7FF91DD1BE10(__int64 a1)
{
  return a1 + 32;
}


// ==== sub_7FF91DD1BE20 @ rva 0xBBE20 ====
__int64 __fastcall sub_7FF91DD1BE20(__int64 a1, __int64 a2)
{
  return a2;
}


// ==== sub_7FF91DD1BE30 @ rva 0xBBE30 ====
// Hidden C++ exception states: #wind=1
_QWORD *__fastcall sub_7FF91DD1BE30(_QWORD *a1, _QWORD *a2, _QWORD *a3, _QWORD *a4)
{
  _QWORD *v5; // rbx
  _QWORD *v8; // r8
  _BYTE *v9; // rax
  __int64 i; // rax
  _QWORD *v11; // [rsp+40h] [rbp+8h] BYREF

  v11 = a1;
  v5 = a3;
  if ( a3 == *(_QWORD **)Block && a4 == Block )
  {
    sub_7FF91DD1CB70(a1, *((_QWORD *)Block + 1));
    *((_QWORD *)Block + 1) = Block;
    *(_QWORD *)Block = Block;
    *((_QWORD *)Block + 2) = Block;
    *(&Block + 1) = nullptr;
    *a2 = *(_QWORD *)Block;
    return a2;
  }
  else
  {
    if ( a3 != a4 )
    {
      do
      {
        v8 = v5;
        if ( !*((_BYTE *)v5 + 25) )
        {
          v9 = (_BYTE *)v5[2];
          if ( v9[25] )
          {
            for ( i = v5[1]; !*(_BYTE *)(i + 25); i = *(_QWORD *)(i + 8) )
            {
              if ( v5 != *(_QWORD **)(i + 16) )
                break;
              v5 = (_QWORD *)i;
            }
            v5 = (_QWORD *)i;
          }
          else
          {
            v5 = (_QWORD *)v5[2];
            a1 = *(_QWORD **)v9;
            if ( !*(_BYTE *)(*(_QWORD *)v9 + 25LL) )
            {
              do
              {
                v5 = a1;
                a1 = (_QWORD *)*a1;
              }
              while ( !*((_BYTE *)a1 + 25) );
            }
          }
        }
        sub_7FF91DD1C440(a1, &v11, v8);
      }
      while ( v5 != a4 );
    }
    *a2 = v5;
    return a2;
  }
}


// ==== sub_7FF91DD1BF40 @ rva 0xBBF40 ====
_QWORD *__fastcall sub_7FF91DD1BF40(__int64 a1, _QWORD *a2)
{
  *a2 = *(_QWORD *)Block;
  return a2;
}


// ==== ?_Xlen@?$vector@PEAXV?$allocator@PEAX@std@@@std@@IEBAXXZ_2 @ rva 0xBBF60 ====
void __noreturn std::vector<void *>::_Xlen()
{
  sub_7FF91E2A81A4("vector<T> too long");
}


// ==== sub_7FF91DD1BF80 @ rva 0xBBF80 ====
char *__fastcall sub_7FF91DD1BF80(_QWORD *a1, unsigned __int64 a2)
{
  _QWORD *v4; // rbx
  size_t v5; // rcx
  void *v6; // rax
  void *v7; // rcx
  __int64 v8; // rbp
  unsigned __int64 v9; // rax
  unsigned __int64 v10; // rax
  char *result; // rax

  if ( !a2 )
  {
    v4 = nullptr;
    goto LABEL_8;
  }
  if ( a2 > 0x1FFFFFFFFFFFFFFFLL )
    goto LABEL_18;
  v5 = 8 * a2;
  if ( 8 * a2 >= 0x1000 )
  {
    if ( v5 + 39 >= v5 )
    {
      v6 = operator new(v5 + 39);
      v4 = (_QWORD *)(((unsigned __int64)v6 + 39) & 0xFFFFFFFFFFFFFFE0uLL);
      *(v4 - 1) = v6;
      goto LABEL_8;
    }
LABEL_18:
    Concurrency::cancel_current_task();
  }
  v4 = operator new(v5);
LABEL_8:
  sub_7FF91E30DC00(v4, *a1, a1[1] - *a1);
  v7 = (void *)*a1;
  v8 = (__int64)(a1[1] - *a1) >> 3;
  if ( *a1 )
  {
    v9 = (__int64)(a1[2] - (_QWORD)v7) >> 3;
    if ( v9 <= 0x1FFFFFFFFFFFFFFFLL )
    {
      if ( 8 * v9 < 0x1000 )
      {
LABEL_15:
        j_free(v7);
        goto LABEL_16;
      }
      if ( ((unsigned __int8)v7 & 0x1F) == 0 )
      {
        v10 = *((_QWORD *)v7 - 1);
        if ( v10 < (unsigned __int64)v7 && (unsigned __int64)v7 - v10 - 8 <= 0x1F )
        {
          v7 = *((void **)v7 - 1);
          goto LABEL_15;
        }
      }
    }
    invalid_parameter_noinfo_noreturn();
  }
LABEL_16:
  a1[2] = &v4[a2];
  result = (char *)&v4[v8];
  a1[1] = result;
  *a1 = v4;
  return result;
}


// ==== nullsub_130 @ rva 0xBC0E0 ====
void nullsub_130()
{
  ;
}


// ==== unknown_libname_19 @ rva 0xBC0F0 ====
// Microsoft VisualC v7/14 64bit runtime
__int64 unknown_libname_19()
{
  return 0x1FFFFFFFFFFFFFFFLL;
}


// ==== ?size@?$vector@PEAXV?$allocator@PEAX@std@@@std@@QEBA_KXZ @ rva 0xBC100 ====
__int64 __fastcall std::vector<void *>::size(__int64 a1)
{
  return (__int64)(*(_QWORD *)(a1 + 16) - *(_QWORD *)(a1 + 8)) >> 3;
}


// ==== sub_7FF91DD1C110 @ rva 0xBC110 ====
__int64 __fastcall sub_7FF91DD1C110(__int64 a1)
{
  return a1 + 24;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_8 @ rva 0xBC120 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1C130 @ rva 0xBC130 ====
__int64 __fastcall sub_7FF91DD1C130(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1C140 @ rva 0xBC140 ====
__int64 __fastcall sub_7FF91DD1C140(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_20 @ rva 0xBC150 ====
// Microsoft VisualC v7/14 64bit runtime
__int64 unknown_libname_20()
{
  return 0x1FFFFFFFFFFFFFFFLL;
}


// ==== sub_7FF91DD1C160 @ rva 0xBC160 ====
void *__fastcall sub_7FF91DD1C160(__int64 a1, unsigned __int64 a2)
{
  size_t v3; // rcx
  void *v4; // rax

  if ( !a2 )
    return nullptr;
  if ( a2 > 0x1FFFFFFFFFFFFFFFLL )
    goto LABEL_8;
  v3 = 8 * a2;
  if ( 8 * a2 >= 0x1000 )
  {
    if ( v3 + 39 >= v3 )
    {
      v4 = operator new(v3 + 39);
      *(_QWORD *)((((unsigned __int64)v4 + 39) & 0xFFFFFFFFFFFFFFE0uLL) - 8) = v4;
      return (void *)(((unsigned __int64)v4 + 39) & 0xFFFFFFFFFFFFFFE0uLL);
    }
LABEL_8:
    Concurrency::cancel_current_task();
  }
  return operator new(v3);
}


// ==== get_srw_lock_4 @ rva 0xBC1D0 ====
__int64 __fastcall get_srw_lock_4(__int64 a1)
{
  return a1 + 16;
}


// ==== sub_7FF91DD1C1E0 @ rva 0xBC1E0 ====
__int64 __fastcall sub_7FF91DD1C1E0(__int64 a1)
{
  return a1;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_9 @ rva 0xBC1F0 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1C270 @ rva 0xBC270 ====
__int64 __fastcall sub_7FF91DD1C270(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1C280 @ rva 0xBC280 ====
void *sub_7FF91DD1C280()
{
  void *result; // rax

  result = (void *)sub_7FF91DD1C860();
  xmmword_7FF91E91A238 = result;
  return result;
}


// ==== sub_7FF91DD1C2A0 @ rva 0xBC2A0 ====
void *__fastcall sub_7FF91DD1C2A0(__int64 a1)
{
  void *result; // rax

  sub_7FF91DD1C8A0(a1, *((_QWORD *)xmmword_7FF91E91A238 + 1));
  *((_QWORD *)xmmword_7FF91E91A238 + 1) = xmmword_7FF91E91A238;
  *(_QWORD *)xmmword_7FF91E91A238 = xmmword_7FF91E91A238;
  result = xmmword_7FF91E91A238;
  *((_QWORD *)xmmword_7FF91E91A238 + 2) = xmmword_7FF91E91A238;
  *(&xmmword_7FF91E91A238 + 1) = nullptr;
  return result;
}


// ==== sub_7FF91DD1C360 @ rva 0xBC360 ====
__int64 __fastcall sub_7FF91DD1C360(__int64 a1)
{
  return a1 + 32;
}


// ==== sub_7FF91DD1C370 @ rva 0xBC370 ====
void __fastcall sub_7FF91DD1C370(__int64 a1, void *a2)
{
  j_free(a2);
}


// ==== sub_7FF91DD1C380 @ rva 0xBC380 ====
void **sub_7FF91DD1C380()
{
  return &Block;
}


// ==== sub_7FF91DD1C390 @ rva 0xBC390 ====
void *sub_7FF91DD1C390()
{
  void *result; // rax

  result = (void *)sub_7FF91DD1C9D0();
  Block = result;
  return result;
}


// ==== get_srw_lock_5 @ rva 0xBC3B0 ====
__int64 __fastcall get_srw_lock_5(__int64 a1)
{
  return a1 + 16;
}


// ==== ?GetLocaleT@_LocaleUpdate@@QEAAPEAU__crt_locale_pointers@@XZ_4 @ rva 0xBC3C0 ====
struct __crt_locale_pointers *__fastcall _LocaleUpdate::GetLocaleT(_LocaleUpdate *this)
{
  return (struct __crt_locale_pointers *)((char *)this + 8);
}


// ==== sub_7FF91DD1C3D0 @ rva 0xBC3D0 ====
__int64 __fastcall sub_7FF91DD1C3D0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1C3E0 @ rva 0xBC3E0 ====
void *sub_7FF91DD1C3E0()
{
  return Block;
}


// ==== sub_7FF91DD1C3F0 @ rva 0xBC3F0 ====
void *__fastcall sub_7FF91DD1C3F0(__int64 a1)
{
  void *result; // rax

  sub_7FF91DD1CB70(a1, *((_QWORD *)Block + 1));
  *((_QWORD *)Block + 1) = Block;
  *(_QWORD *)Block = Block;
  result = Block;
  *((_QWORD *)Block + 2) = Block;
  *(&Block + 1) = nullptr;
  return result;
}


// ==== sub_7FF91DD1C440 @ rva 0xBC440 ====
__int64 **__fastcall sub_7FF91DD1C440(__int64 *k, __int64 **a2, __int64 *a3)
{
  __int64 *j; // rbx
  __int64 **v6; // rax
  __int64 i; // rax
  __int64 *v8; // r9
  __int64 *v9; // r8
  __int64 *v10; // rdx
  __int64 *v11; // rax
  void **v12; // rax
  __int64 *v13; // r10
  __int64 *v14; // rdx
  _DWORD *v15; // rcx
  __int64 v16; // rax

  j = a3;
  if ( !*((_BYTE *)a3 + 25) )
  {
    v6 = (__int64 **)a3[2];
    if ( *((_BYTE *)v6 + 25) )
    {
      for ( i = a3[1]; !*(_BYTE *)(i + 25); i = *(_QWORD *)(i + 8) )
      {
        if ( j != *(__int64 **)(i + 16) )
          break;
        j = (__int64 *)i;
      }
      j = (__int64 *)i;
    }
    else
    {
      k = *v6;
      for ( j = (__int64 *)a3[2]; !*((_BYTE *)k + 25); k = (__int64 *)*k )
        j = k;
    }
  }
  v8 = (__int64 *)a3[2];
  if ( *(_BYTE *)(*a3 + 25) )
    goto LABEL_14;
  if ( *((_BYTE *)v8 + 25) )
  {
    v8 = (__int64 *)*a3;
LABEL_14:
    v9 = (__int64 *)a3[1];
    if ( !*((_BYTE *)v8 + 25) )
      v8[1] = (__int64)v9;
    if ( *((__int64 **)Block + 1) == a3 )
    {
      *((_QWORD *)Block + 1) = v8;
    }
    else if ( (__int64 *)*v9 == a3 )
    {
      *v9 = (__int64)v8;
    }
    else
    {
      v9[2] = (__int64)v8;
    }
    if ( *(__int64 **)Block == a3 )
    {
      if ( *((_BYTE *)v8 + 25) )
      {
        v10 = v9;
      }
      else
      {
        k = (__int64 *)*v8;
        v10 = v8;
        if ( !*(_BYTE *)(*v8 + 25) )
        {
          do
          {
            v10 = k;
            k = (__int64 *)*k;
          }
          while ( !*((_BYTE *)k + 25) );
        }
      }
      *(_QWORD *)Block = v10;
    }
    if ( *((__int64 **)Block + 2) == a3 )
    {
      if ( *((_BYTE *)v8 + 25) )
      {
        k = v9;
        *((_QWORD *)Block + 2) = v9;
      }
      else
      {
        v11 = (__int64 *)v8[2];
        for ( k = v8; !*((_BYTE *)v11 + 25); v11 = (__int64 *)v11[2] )
          k = v11;
        *((_QWORD *)Block + 2) = k;
      }
    }
    goto LABEL_44;
  }
  v8 = (__int64 *)j[2];
  if ( j == a3 )
    goto LABEL_14;
  *(_QWORD *)(*a3 + 8) = j;
  *j = *a3;
  if ( j == (__int64 *)a3[2] )
  {
    v9 = j;
  }
  else
  {
    v9 = (__int64 *)j[1];
    if ( !*((_BYTE *)v8 + 25) )
      v8[1] = (__int64)v9;
    *v9 = (__int64)v8;
    j[2] = a3[2];
    *(_QWORD *)(a3[2] + 8) = j;
  }
  if ( *((__int64 **)Block + 1) == a3 )
  {
    *((_QWORD *)Block + 1) = j;
  }
  else
  {
    v12 = (void **)a3[1];
    if ( *v12 == a3 )
      *v12 = j;
    else
      v12[2] = j;
  }
  j[1] = a3[1];
  k = (__int64 *)*((unsigned __int8 *)j + 24);
  *((_BYTE *)j + 24) = *((_BYTE *)a3 + 24);
  *((_BYTE *)a3 + 24) = (_BYTE)k;
LABEL_44:
  if ( *((_BYTE *)a3 + 24) == 1 )
  {
    if ( v8 != *((__int64 **)Block + 1) )
    {
      do
      {
        v13 = v9;
        if ( *((_BYTE *)v8 + 24) != 1 )
          break;
        v14 = (__int64 *)*v9;
        if ( v8 == (__int64 *)*v9 )
        {
          v14 = (__int64 *)v9[2];
          if ( !*((_BYTE *)v14 + 24) )
          {
            *((_BYTE *)v14 + 24) = 1;
            *((_BYTE *)v9 + 24) = 0;
            sub_7FF91DD1CB10(k, v9);
            v14 = (__int64 *)v9[2];
          }
          if ( *((_BYTE *)v14 + 25) )
            goto LABEL_62;
          k = (__int64 *)*v14;
          if ( *(_BYTE *)(*v14 + 24) != 1 || *(_BYTE *)(v14[2] + 24) != 1 )
          {
            if ( *(_BYTE *)(v14[2] + 24) == 1 )
            {
              *((_BYTE *)k + 24) = 1;
              *((_BYTE *)v14 + 24) = 0;
              sub_7FF91DD1CA90(k, v14);
              v14 = (__int64 *)v9[2];
            }
            *((_BYTE *)v14 + 24) = *((_BYTE *)v9 + 24);
            *((_BYTE *)v9 + 24) = 1;
            *(_BYTE *)(v14[2] + 24) = 1;
            sub_7FF91DD1CB10(k, v9);
            break;
          }
        }
        else
        {
          if ( !*((_BYTE *)v14 + 24) )
          {
            *((_BYTE *)v14 + 24) = 1;
            *((_BYTE *)v9 + 24) = 0;
            sub_7FF91DD1CA90(k, v9);
            v14 = (__int64 *)*v9;
          }
          if ( *((_BYTE *)v14 + 25) )
            goto LABEL_62;
          k = (__int64 *)v14[2];
          if ( *((_BYTE *)k + 24) != 1 || *(_BYTE *)(*v14 + 24) != 1 )
          {
            if ( *(_BYTE *)(*v14 + 24) == 1 )
            {
              *((_BYTE *)k + 24) = 1;
              *((_BYTE *)v14 + 24) = 0;
              ((void (*)(void))sub_7FF91DD1CB10)();
              v14 = (__int64 *)*v9;
            }
            *((_BYTE *)v14 + 24) = *((_BYTE *)v9 + 24);
            *((_BYTE *)v9 + 24) = 1;
            *(_BYTE *)(*v14 + 24) = 1;
            sub_7FF91DD1CA90(k, v9);
            break;
          }
        }
        *((_BYTE *)v14 + 24) = 0;
LABEL_62:
        v8 = v13;
        v9 = (__int64 *)v9[1];
      }
      while ( v13 != *((__int64 **)Block + 1) );
    }
    *((_BYTE *)v8 + 24) = 1;
  }
  v15 = (_DWORD *)(a3[4] - 16);
  if ( (*v15 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v15, 0xFFFFFFFF) )
    j_j_free_0(v15);
  j_free(a3);
  v16 = (__int64)*(&Block + 1);
  *a2 = j;
  if ( v16 )
    *(&Block + 1) = (void *)(v16 - 1);
  return a2;
}


// ==== ?capacity@?$vector@PEAXV?$allocator@PEAX@std@@@std@@QEBA_KXZ @ rva 0xBC7B0 ====
__int64 __fastcall std::vector<void *>::capacity(_QWORD *a1)
{
  return (__int64)(a1[2] - *a1) >> 3;
}


// ==== sub_7FF91DD1C7C0 @ rva 0xBC7C0 ====
void __fastcall sub_7FF91DD1C7C0(__int64 a1, _QWORD *a2, unsigned __int64 a3)
{
  unsigned __int64 v3; // rax

  if ( a3 > 0x1FFFFFFFFFFFFFFFLL )
    goto LABEL_8;
  if ( 8 * a3 >= 0x1000 )
  {
    if ( ((unsigned __int8)a2 & 0x1F) == 0 )
    {
      v3 = *(a2 - 1);
      if ( v3 < (unsigned __int64)a2 && (unsigned __int64)a2 - v3 - 8 <= 0x1F )
      {
        a2 = (_QWORD *)*(a2 - 1);
        goto LABEL_7;
      }
    }
LABEL_8:
    invalid_parameter_noinfo_noreturn();
  }
LABEL_7:
  j_free(a2);
}


// ==== sub_7FF91DD1C820 @ rva 0xBC820 ====
__int64 __fastcall sub_7FF91DD1C820(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_21 @ rva 0xBC830 ====
// Microsoft VisualC v7/14 64bit runtime
__int64 unknown_libname_21()
{
  return 0x1FFFFFFFFFFFFFFFLL;
}


// ==== sub_7FF91DD1C840 @ rva 0xBC840 ====
__int64 __fastcall sub_7FF91DD1C840(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1C850 @ rva 0xBC850 ====
__int64 __fastcall sub_7FF91DD1C850(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1C860 @ rva 0xBC860 ====
_QWORD *sub_7FF91DD1C860()
{
  _QWORD *result; // rax

  result = operator new(0x48u);
  *result = result;
  if ( result != (_QWORD *)-8LL )
    result[1] = result;
  if ( result != (_QWORD *)-16LL )
    result[2] = result;
  *((_WORD *)result + 12) = 257;
  return result;
}


// ==== sub_7FF91DD1C8A0 @ rva 0xBC8A0 ====
void __fastcall sub_7FF91DD1C8A0(__int64 a1, _QWORD *a2)
{
  _QWORD *v2; // rdi
  _QWORD *i; // rbx

  v2 = a2;
  for ( i = a2; !*((_BYTE *)i + 25); v2 = i )
  {
    sub_7FF91DD1C8A0(&xmmword_7FF91E91A238, i[2]);
    i = (_QWORD *)*i;
    sub_7FF91DD17A90(v2 + 4);
    j_free(v2);
  }
}


// ==== sub_7FF91DD1C900 @ rva 0xBC900 ====
__int64 __fastcall sub_7FF91DD1C900(__int64 a1)
{
  return a1;
}


// ==== ??$?0U_Exact_args_t@std@@AEBQEAX$$V$0A@@?$tuple@AEBQEAX@std@@QEAA@U_Exact_args_t@1@AEBQEAX@Z_2 @ rva 0xBC93F ====
_QWORD *__fastcall std::tuple<void * const &>::tuple<void * const &>(_QWORD *a1, __int64 a2, __int64 a3)
{
  *a1 = a3;
  return a1;
}


// ==== get_srw_lock_6 @ rva 0xBC970 ====
__int64 __fastcall get_srw_lock_6(__int64 a1)
{
  return a1 + 16;
}


// ==== ?GetLocaleT@_LocaleUpdate@@QEAAPEAU__crt_locale_pointers@@XZ_5 @ rva 0xBC980 ====
struct __crt_locale_pointers *__fastcall _LocaleUpdate::GetLocaleT(_LocaleUpdate *this)
{
  return (struct __crt_locale_pointers *)((char *)this + 8);
}


// ==== sub_7FF91DD1C990 @ rva 0xBC990 ====
__int64 __fastcall sub_7FF91DD1C990(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1C9A0 @ rva 0xBC9A0 ====
void __fastcall sub_7FF91DD1C9A0(__int64 a1, void *a2)
{
  j_free(a2);
}


// ==== sub_7FF91DD1C9B0 @ rva 0xBC9B0 ====
void **sub_7FF91DD1C9B0()
{
  return &Block + 1;
}


// ==== sub_7FF91DD1C9C0 @ rva 0xBC9C0 ====
void **sub_7FF91DD1C9C0()
{
  return &Block;
}


// ==== sub_7FF91DD1C9D0 @ rva 0xBC9D0 ====
_QWORD *sub_7FF91DD1C9D0()
{
  _QWORD *result; // rax

  result = operator new(0x30u);
  *result = result;
  if ( result != (_QWORD *)-8LL )
    result[1] = result;
  if ( result != (_QWORD *)-16LL )
    result[2] = result;
  *((_WORD *)result + 12) = 257;
  return result;
}


// ==== sub_7FF91DD1CA70 @ rva 0xBCA70 ====
__int64 __fastcall sub_7FF91DD1CA70(__int64 a1)
{
  return a1 + 25;
}


// ==== sub_7FF91DD1CA80 @ rva 0xBCA80 ====
__int64 __fastcall sub_7FF91DD1CA80(__int64 a1)
{
  return a1 + 24;
}


// ==== sub_7FF91DD1CA90 @ rva 0xBCA90 ====
_QWORD *__fastcall sub_7FF91DD1CA90(__int64 a1, _QWORD *a2)
{
  __int64 v2; // rcx
  __int64 v3; // rax
  _QWORD *result; // rax

  v2 = *a2;
  *a2 = *(_QWORD *)(*a2 + 16LL);
  v3 = *(_QWORD *)(v2 + 16);
  if ( !*(_BYTE *)(v3 + 25) )
    *(_QWORD *)(v3 + 8) = a2;
  *(_QWORD *)(v2 + 8) = a2[1];
  result = Block;
  if ( a2 == *((_QWORD **)Block + 1) )
  {
    *((_QWORD *)Block + 1) = v2;
    *(_QWORD *)(v2 + 16) = a2;
    a2[1] = v2;
  }
  else
  {
    result = (_QWORD *)a2[1];
    if ( a2 == (_QWORD *)result[2] )
      result[2] = v2;
    else
      *result = v2;
    *(_QWORD *)(v2 + 16) = a2;
    a2[1] = v2;
  }
  return result;
}


// ==== sub_7FF91DD1CAF0 @ rva 0xBCAF0 ====
char *sub_7FF91DD1CAF0()
{
  return (char *)Block + 8;
}


// ==== sub_7FF91DD1CB00 @ rva 0xBCB00 ====
char *sub_7FF91DD1CB00()
{
  return (char *)Block + 16;
}


// ==== sub_7FF91DD1CB10 @ rva 0xBCB10 ====
_QWORD *__fastcall sub_7FF91DD1CB10(__int64 a1, __int64 a2)
{
  _QWORD *v2; // rcx
  _QWORD *result; // rax

  v2 = *(_QWORD **)(a2 + 16);
  *(_QWORD *)(a2 + 16) = *v2;
  if ( !*(_BYTE *)(*v2 + 25LL) )
    *(_QWORD *)(*v2 + 8LL) = a2;
  v2[1] = *(_QWORD *)(a2 + 8);
  result = Block;
  if ( a2 == *((_QWORD *)Block + 1) )
  {
    *((_QWORD *)Block + 1) = v2;
    *v2 = a2;
    *(_QWORD *)(a2 + 8) = v2;
  }
  else
  {
    result = *(_QWORD **)(a2 + 8);
    if ( a2 == *result )
      *result = v2;
    else
      result[2] = v2;
    *v2 = a2;
    *(_QWORD *)(a2 + 8) = v2;
  }
  return result;
}


// ==== sub_7FF91DD1CB70 @ rva 0xBCB70 ====
void __fastcall sub_7FF91DD1CB70(__int64 a1, _QWORD *a2)
{
  _QWORD *v2; // rdi
  _QWORD *i; // rbx
  _DWORD *v4; // rcx

  v2 = a2;
  for ( i = a2; !*((_BYTE *)i + 25); v2 = i )
  {
    sub_7FF91DD1CB70(&Block, i[2]);
    i = (_QWORD *)*i;
    v4 = (_DWORD *)(v2[4] - 16LL);
    if ( (*v4 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v4, 0xFFFFFFFF) )
      j_j_free_0(v4);
    j_free(v2);
  }
}


// ==== sub_7FF91DD1CBF0 @ rva 0xBCBF0 ====
void *__fastcall sub_7FF91DD1CBF0(__int64 a1, unsigned __int64 a2)
{
  size_t v3; // rcx
  void *v4; // rax

  if ( !a2 )
    return nullptr;
  if ( a2 > 0x1FFFFFFFFFFFFFFFLL )
    goto LABEL_8;
  v3 = 8 * a2;
  if ( 8 * a2 >= 0x1000 )
  {
    if ( v3 + 39 >= v3 )
    {
      v4 = operator new(v3 + 39);
      *(_QWORD *)((((unsigned __int64)v4 + 39) & 0xFFFFFFFFFFFFFFE0uLL) - 8) = v4;
      return (void *)(((unsigned __int64)v4 + 39) & 0xFFFFFFFFFFFFFFE0uLL);
    }
LABEL_8:
    Concurrency::cancel_current_task();
  }
  return operator new(v3);
}


// ==== ??$?0U_Exact_args_t@std@@AEBQEAX$$V$0A@@?$tuple@AEBQEAX@std@@QEAA@U_Exact_args_t@1@AEBQEAX@Z_3 @ rva 0xBCC8F ====
_QWORD *__fastcall std::tuple<void * const &>::tuple<void * const &>(_QWORD *a1, __int64 a2, __int64 a3)
{
  *a1 = a3;
  return a1;
}


// ==== sub_7FF91DD1CCC0 @ rva 0xBCCC0 ====
void *sub_7FF91DD1CCC0()
{
  return operator new(0x48u);
}


// ==== sub_7FF91DD1CD30 @ rva 0xBCD30 ====
__int64 __fastcall sub_7FF91DD1CD30(__int64 a1)
{
  return a1 + 25;
}


// ==== sub_7FF91DD1CD40 @ rva 0xBCD40 ====
__int64 __fastcall sub_7FF91DD1CD40(__int64 a1)
{
  return a1 + 24;
}


// ==== sub_7FF91DD1CD50 @ rva 0xBCD50 ====
void *sub_7FF91DD1CD50()
{
  return operator new(0x30u);
}


// ==== sub_7FF91DD1CD60 @ rva 0xBCD60 ====
void **sub_7FF91DD1CD60()
{
  return &Block;
}


// ==== unknown_libname_22 @ rva 0xBCD70 ====
// Microsoft VisualC v7/14 64bit runtime
__int64 unknown_libname_22()
{
  return 0x1FFFFFFFFFFFFFFFLL;
}


// ==== sub_7FF91DD1CD80 @ rva 0xBCD80 ====
void *sub_7FF91DD1CD80()
{
  return operator new(0x48u);
}


// ==== sub_7FF91DD1CD90 @ rva 0xBCD90 ====
void **sub_7FF91DD1CD90()
{
  return &Block;
}


// ==== sub_7FF91DD1CDA0 @ rva 0xBCDA0 ====
__int64 __fastcall sub_7FF91DD1CDA0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1CDB0 @ rva 0xBCDB0 ====
void *sub_7FF91DD1CDB0()
{
  return operator new(0x30u);
}


// ==== sub_7FF91DD1CDC0 @ rva 0xBCDC0 ====
_QWORD *__fastcall sub_7FF91DD1CDC0(_QWORD *a1, int a2)
{
  unsigned __int64 v2; // r9
  unsigned int v3; // r8d
  unsigned int v5; // r8d
  _BYTE v7[19]; // [rsp+35h] [rbp-13h] BYREF

  v2 = (unsigned __int64)v7;
  v3 = a2;
  if ( a2 >= 0 )
  {
    do
    {
      *(_BYTE *)--v2 = v3 % 0xA + 48;
      v3 /= 0xAu;
    }
    while ( v3 );
  }
  else
  {
    v5 = -a2;
    do
    {
      *(_BYTE *)--v2 = v5 % 0xA + 48;
      v5 /= 0xAu;
    }
    while ( v5 );
    *(_BYTE *)--v2 = 45;
  }
  a1[3] = 15;
  a1[2] = 0;
  *(_BYTE *)a1 = 0;
  if ( (_BYTE *)v2 != v7 )
    sub_7FF91DD17EC0(a1, v2, (unsigned __int64)&v7[-v2]);
  return a1;
}


// ==== sub_7FF91DD1CE90 @ rva 0xBCE90 ====
__int64 __fastcall sub_7FF91DD1CE90(__int64 a1)
{
  return a1 + 21;
}


// ==== sub_7FF91DD1CEA0 @ rva 0xBCEA0 ====
__int64 __fastcall sub_7FF91DD1CEA0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1CEB0 @ rva 0xBCEB0 ====
// Hidden C++ exception states: #wind=5
_Thrd_imp_t *__fastcall sub_7FF91DD1CEB0(_Thrd_imp_t *a1)
{
  void **v2; // rsi
  int v3; // eax
  int v4; // ebx
  int v5; // eax
  int v6; // eax
  void *v7; // rax
  int v8; // eax
  int v9; // eax
  void *v10; // rbx
  struct _Cnd_internal_imp_t *v11; // rsi
  struct _Mtx_internal_imp_t *v12; // rbx
  int v13; // eax
  void *v14; // rbx
  void **v16; // [rsp+48h] [rbp-30h] BYREF
  _Cnd_t v17; // [rsp+50h] [rbp-28h] BYREF
  _Mtx_t v18; // [rsp+58h] [rbp-20h] BYREF
  char v19; // [rsp+60h] [rbp-18h]
  void *Block; // [rsp+68h] [rbp-10h]
  void *v21; // [rsp+80h] [rbp+8h] BYREF

  v2 = (void **)sub_7FF91DD1D9B0(&v21);
  v16 = &std::_Pad::`vftable';
  v3 = Cnd_init(&v17);
  if ( v3 )
    std::_Throw_C_error(v3);
  v4 = 1;
  v5 = Mtx_init(&v18, 1);
  if ( v5 )
    std::_Throw_C_error(v5);
  v19 = 0;
  v6 = Mtx_lock(v18);
  if ( v6 )
    std::_Throw_C_error(v6);
  v16 = &std::_LaunchPad<std::unique_ptr<std::tuple<_lambda_1d774048c448fbc19b0ed856226ca1d8_>>>::`vftable';
  v7 = *v2;
  *v2 = nullptr;
  Block = v7;
  v8 = Thrd_start(a1, (_Thrd_callback_t)sub_7FF91DD196B0, &v16);
  if ( v8 != 4 )
    v4 = v8;
  if ( v4 )
    std::_Throw_C_error(v4);
  while ( !v19 )
  {
    v9 = sub_7FF91E2AB4AC(v17, v18);
    if ( v9 )
      std::_Throw_C_error(v9);
  }
  v10 = Block;
  if ( Block )
  {
    sub_7FF91DD19A90(Block);
    j_j_free(v10);
  }
  v16 = &std::_Pad::`vftable';
  v11 = v17;
  v12 = v18;
  v13 = Mtx_unlock(v18);
  if ( v13 )
    std::_Throw_C_error(v13);
  Mtx_destroy(v12);
  Cnd_destroy(v11);
  v14 = v21;
  if ( v21 )
  {
    sub_7FF91DD19A90(v21);
    j_j_free(v14);
  }
  return a1;
}


// ==== sub_7FF91DD1D050 @ rva 0xBD050 ====
_QWORD *__fastcall sub_7FF91DD1D050(_QWORD *a1, _QWORD *a2, _BYTE *a3)
{
  _QWORD *v4; // rax

  v4 = (_QWORD *)sub_7FF91DD1ACF0(a2, a3);
  a1[3] = 15;
  a1[2] = 0;
  *(_BYTE *)a1 = 0;
  sub_7FF91DD18F90(a1, v4);
  return a1;
}


// ==== sub_7FF91DD1D090 @ rva 0xBD090 ====
_QWORD *__fastcall sub_7FF91DD1D090(_QWORD *a1, _QWORD *a2, _QWORD *a3)
{
  unsigned __int64 v5; // rcx
  unsigned __int64 v6; // rdx
  _QWORD *v7; // rax

  v5 = a2[2];
  v6 = a3[2];
  if ( v6 <= a2[3] - v5 || a3[3] - v6 < v5 )
    v7 = sub_7FF91DD1B8A0(a2, a3, 0, 0xFFFFFFFFFFFFFFFFuLL);
  else
    v7 = (_QWORD *)sub_7FF91DD1D6E0((_DWORD)a3, 0, (_DWORD)a2, 0, -1);
  a1[3] = 15;
  a1[2] = 0;
  *(_BYTE *)a1 = 0;
  sub_7FF91DD18F90(a1, v7);
  return a1;
}


// ==== sub_7FF91DD1D120 @ rva 0xBD120 ====
bool sub_7FF91DD1D120()
{
  return (unsigned __int8)sub_7FF91DD1DBC0() == 0;
}


// ==== sub_7FF91DD1D150 @ rva 0xBD150 ====
__int64 __fastcall sub_7FF91DD1D150(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D160 @ rva 0xBD160 ====
void __fastcall sub_7FF91DD1D160(__int64 a1, _QWORD *a2)
{
  sub_7FF91DD17A90(a2);
}


// ==== sub_7FF91DD1D170 @ rva 0xBD170 ====
__int64 __fastcall sub_7FF91DD1D170(_QWORD *a1, __int64 a2, _QWORD *a3)
{
  _QWORD *v4; // rbp
  _QWORD *v6; // rsi
  _QWORD *v7; // rdi
  __int64 v8; // rbx
  __int64 v10; // rax
  __int64 v11; // rcx
  _QWORD *v12; // [rsp+50h] [rbp+8h] BYREF

  v12 = a1;
  v4 = Block;
  v6 = Block;
  v7 = *((_QWORD **)Block + 1);
  if ( !*((_BYTE *)v7 + 25) )
  {
    v8 = *a3;
    do
    {
      if ( (int)sub_7FF91DD652D0(v7[4], v8) >= 0 )
      {
        v6 = v7;
        v7 = (_QWORD *)*v7;
      }
      else
      {
        v7 = (_QWORD *)v7[2];
      }
    }
    while ( !*((_BYTE *)v7 + 25) );
  }
  if ( v6 == v4 || (int)sub_7FF91DD652D0(*a3, v6[4]) < 0 )
  {
    v12 = a3;
    v10 = sub_7FF91DD1E780(a1, a2, &v12);
    sub_7FF91DD1E7E0(v11, &v12, v6, v10 + 32, v10);
    *(_QWORD *)a2 = v12;
    *(_BYTE *)(a2 + 8) = 1;
    return a2;
  }
  else
  {
    *(_QWORD *)a2 = v6;
    *(_BYTE *)(a2 + 8) = 0;
    return a2;
  }
}


// ==== sub_7FF91DD1D250 @ rva 0xBD250 ====
__int64 __fastcall sub_7FF91DD1D250(__int64 *a1, __int64 a2, _QWORD *a3)
{
  __int64 *v3; // r14
  __int64 *v7; // rdi
  __int64 *v8; // rbx
  void *v9; // rax
  _QWORD *v11; // [rsp+50h] [rbp+8h] BYREF

  v3 = (__int64 *)*a1;
  v7 = (__int64 *)*a1;
  v8 = *(__int64 **)(*a1 + 8);
  while ( !*((_BYTE *)v8 + 25) )
  {
    if ( sub_7FF91DD1AC80(v8 + 4, a3) >= 0 )
    {
      v7 = v8;
      v8 = (__int64 *)*v8;
    }
    else
    {
      v8 = (__int64 *)v8[2];
    }
  }
  if ( v7 == v3 || sub_7FF91DD1AC80(a3, v7 + 4) < 0 )
  {
    v11 = a3;
    v9 = (void *)sub_7FF91DD1EAE0(a1, a2, &v11);
    sub_7FF91DD1EB60((int)a1, v9);
    *(_QWORD *)a2 = v11;
    *(_BYTE *)(a2 + 8) = 1;
  }
  else
  {
    *(_QWORD *)a2 = v7;
    *(_BYTE *)(a2 + 8) = 0;
  }
  return a2;
}


// ==== sub_7FF91DD1D320 @ rva 0xBD320 ====
__int64 __fastcall sub_7FF91DD1D320(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D330 @ rva 0xBD330 ====
__int64 __fastcall sub_7FF91DD1D330(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D340 @ rva 0xBD340 ====
__int64 __fastcall sub_7FF91DD1D340(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_4236 @ rva 0xBD350 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4236(__int64 a1, __int64 *a2, __int64 *a3)
{
  __int64 result; // rax

  if ( a2 )
  {
    result = *a3;
    *a2 = *a3;
  }
  return result;
}


// ==== sub_7FF91DD1D360 @ rva 0xBD360 ====
__int64 __fastcall sub_7FF91DD1D360(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_6919 @ rva 0xBD370 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC 64bit universal runtime
_QWORD *__fastcall unknown_libname_6919(_QWORD *a1)
{
  *a1 = 0;
  a1[1] = 0;
  a1[2] = 0;
  return a1;
}


// ==== sub_7FF91DD1D390 @ rva 0xBD390 ====
__int64 *__fastcall sub_7FF91DD1D390(__int64 *a1, _QWORD *a2)
{
  __int64 *v2; // rdi
  __int64 *v4; // rbx

  v2 = (__int64 *)*a1;
  v4 = *(__int64 **)(*a1 + 8);
  while ( !*((_BYTE *)v4 + 25) )
  {
    if ( sub_7FF91DD1AC80(v4 + 4, a2) >= 0 )
    {
      v2 = v4;
      v4 = (__int64 *)*v4;
    }
    else
    {
      v4 = (__int64 *)v4[2];
    }
  }
  return v2;
}


// ==== sub_7FF91DD1D3F0 @ rva 0xBD3F0 ====
void *__fastcall sub_7FF91DD1D3F0(__int64 a1, __int64 *a2)
{
  void *v2; // rsi
  _QWORD *v3; // rdi
  __int64 v4; // rbx

  v2 = Block;
  v3 = *((_QWORD **)Block + 1);
  if ( !*((_BYTE *)v3 + 25) )
  {
    v4 = *a2;
    do
    {
      if ( (int)sub_7FF91DD652D0(v3[4], v4) >= 0 )
      {
        v2 = v3;
        v3 = (_QWORD *)*v3;
      }
      else
      {
        v3 = (_QWORD *)v3[2];
      }
    }
    while ( !*((_BYTE *)v3 + 25) );
  }
  return v2;
}


// ==== sub_7FF91DD1D450 @ rva 0xBD450 ====
__int64 __fastcall sub_7FF91DD1D450(_QWORD *a1, _QWORD *a2)
{
  return (unsigned int)sub_7FF91DD1AC80(a1, a2) >> 31;
}


// ==== sub_7FF91DD1D470 @ rva 0xBD470 ====
__int64 __fastcall sub_7FF91DD1D470(__int64 a1)
{
  return a1;
}


// ==== nullsub_131 @ rva 0xBD480 ====
void nullsub_131()
{
  ;
}


// ==== sub_7FF91DD1D4B0 @ rva 0xBD4B0 ====
__int64 __fastcall sub_7FF91DD1D4B0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D4C0 @ rva 0xBD4C0 ====
__int64 __fastcall sub_7FF91DD1D4C0(__int64 a1)
{
  return a1;
}


// ==== nullsub_132 @ rva 0xBD4D0 ====
void nullsub_132()
{
  ;
}


// ==== sub_7FF91DD1D500 @ rva 0xBD500 ====
__int64 __fastcall sub_7FF91DD1D500(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D510 @ rva 0xBD510 ====
__int64 __fastcall sub_7FF91DD1D510(__int64 a1, __int64 a2, __int64 a3, __int64 a4)
{
  __int64 v4; // rbx

  v4 = a3 - a2;
  sub_7FF91E30DC00(a4, a2, a3 - a2);
  return v4 + a4;
}


// ==== nullsub_133 @ rva 0xBD540 ====
void nullsub_133()
{
  ;
}


// ==== unknown_libname_4237 @ rva 0xBD580 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4237(__int64 a1, __int64 *a2, __int64 *a3)
{
  __int64 result; // rax

  if ( a2 )
  {
    result = *a3;
    *a2 = *a3;
  }
  return result;
}


// ==== sub_7FF91DD1D5A0 @ rva 0xBD5A0 ====
void __fastcall sub_7FF91DD1D5A0(_QWORD **a1)
{
  void *v1; // rbx

  v1 = *a1;
  if ( *a1 )
  {
    sub_7FF91DD19A90(*a1);
    j_j_free(v1);
  }
}


// ==== unknown_libname_6920 @ rva 0xBD5D0 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC 64bit universal runtime
_QWORD *__fastcall unknown_libname_6920(_QWORD *a1)
{
  *a1 = 0;
  a1[1] = 0;
  a1[2] = 0;
  return a1;
}


// ==== sub_7FF91DD1D5F0 @ rva 0xBD5F0 ====
__int64 __fastcall sub_7FF91DD1D5F0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D600 @ rva 0xBD600 ====
__int64 __fastcall sub_7FF91DD1D600(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  return (unsigned int)sub_7FF91DD1AC80(a2, a3) >> 31;
}


// ==== sub_7FF91DD1D620 @ rva 0xBD620 ====
__int64 __fastcall sub_7FF91DD1D620(__int64 a1, _QWORD *a2, _QWORD *a3)
{
  return (unsigned int)sub_7FF91DD652D0(*a2, *a3) >> 31;
}


// ==== sub_7FF91DD1D640 @ rva 0xBD640 ====
__int64 __fastcall sub_7FF91DD1D640(int a1, int a2, int a3)
{
  return sub_7FF91DD1D6E0(a1, a2, a3, 0, -1);
}


// ==== sub_7FF91DD1D660 @ rva 0xBD660 ====
__int64 __fastcall sub_7FF91DD1D660(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D670 @ rva 0xBD670 ====
__int64 __fastcall sub_7FF91DD1D670(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD1D680 @ rva 0xBD680 ====
void __fastcall sub_7FF91DD1D680(__int64 a1, _QWORD *a2)
{
  if ( a2 )
  {
    sub_7FF91DD19A90(a2);
    j_j_free(a2);
  }
}


// ==== sub_7FF91DD1D6B0 @ rva 0xBD6B0 ====
__int64 __fastcall sub_7FF91DD1D6B0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D6C0 @ rva 0xBD6C0 ====
void **sub_7FF91DD1D6C0()
{
  return &Block;
}


// ==== sub_7FF91DD1D6D0 @ rva 0xBD6D0 ====
__int64 __fastcall sub_7FF91DD1D6D0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D6E0 @ rva 0xBD6E0 ====
_QWORD *__fastcall sub_7FF91DD1D6E0(
        _QWORD *a1,
        unsigned __int64 a2,
        _QWORD *a3,
        unsigned __int64 a4,
        unsigned __int64 a5)
{
  unsigned __int64 v7; // r8
  unsigned __int64 v10; // rax
  unsigned __int64 v11; // rax
  unsigned __int64 v12; // rdi
  unsigned __int64 v13; // rbp
  _QWORD *v14; // rcx
  _QWORD *v15; // rax
  unsigned __int64 v16; // r8
  unsigned __int64 v17; // rdx
  _QWORD *v18; // rcx
  _QWORD *v19; // rax
  _QWORD *v20; // rax
  bool v21; // cf
  _QWORD *v22; // rax

  v7 = a1[2];
  if ( v7 < a2 )
    std::vector<void *>::_Xlen();
  v10 = a3[2];
  if ( v10 < a4 )
    std::vector<void *>::_Xlen();
  v11 = v10 - a4;
  v12 = a5;
  if ( a5 > v11 )
    v12 = v11;
  if ( ~v7 <= v12 )
    goto LABEL_44;
  v13 = v7 + v12;
  if ( !v12 )
    return a1;
  if ( v13 == -1 )
LABEL_44:
    std::vector<void *>::_Xlen();
  if ( a1[3] >= v13 )
  {
    if ( !v13 )
    {
      a1[2] = 0;
      if ( a1[3] < 0x10u )
        *(_BYTE *)a1 = 0;
      else
        *(_BYTE *)*a1 = 0;
      return a1;
    }
  }
  else
  {
    sub_7FF91DD18400(a1, v7 + v12, v7);
    if ( !v13 )
      return a1;
  }
  if ( a1[3] < 0x10u )
    v14 = a1;
  else
    v14 = (_QWORD *)*a1;
  if ( a1[3] < 0x10u )
    v15 = a1;
  else
    v15 = (_QWORD *)*a1;
  v16 = a1[2] - a2;
  if ( v16 )
    sub_7FF91E30DC00((char *)v15 + a2 + v12, (char *)v14 + a2, v16);
  if ( a1 == a3 )
  {
    v17 = a4 + v12;
    if ( a2 >= a4 )
      v17 = a4;
    if ( a1[3] < 0x10u )
      v18 = a1;
    else
      v18 = (_QWORD *)*a1;
    if ( a1[3] < 0x10u )
      v19 = a1;
    else
      v19 = (_QWORD *)*a1;
    sub_7FF91E30DC00((char *)v19 + a2, (char *)v18 + v17, v12);
  }
  else
  {
    if ( a3[3] >= 0x10u )
      a3 = (_QWORD *)*a3;
    if ( a1[3] < 0x10u )
      v20 = a1;
    else
      v20 = (_QWORD *)*a1;
    sub_7FF91E30DC00((char *)v20 + a2, (char *)a3 + a4, v12);
  }
  v21 = a1[3] < 0x10u;
  a1[2] = v13;
  if ( v21 )
    v22 = a1;
  else
    v22 = (_QWORD *)*a1;
  *((_BYTE *)v22 + v13) = 0;
  return a1;
}


// ==== sub_7FF91DD1D880 @ rva 0xBD880 ====
_QWORD *__fastcall sub_7FF91DD1D880(_QWORD *Block)
{
  sub_7FF91DD19A90(Block);
  j_j_free(Block);
  return Block;
}


// ==== sub_7FF91DD1D8B0 @ rva 0xBD8B0 ====
// attributes: thunk
void __fastcall sub_7FF91DD1D8B0(_QWORD *a1)
{
  sub_7FF91DD19A90(a1);
}


// ==== sub_7FF91DD1D8C0 @ rva 0xBD8C0 ====
// attributes: thunk
void __fastcall sub_7FF91DD1D8C0(_QWORD *a1)
{
  sub_7FF91DD19A90(a1);
}


// ==== sub_7FF91DD1D8D0 @ rva 0xBD8D0 ====
__int64 __fastcall sub_7FF91DD1D8D0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D8E0 @ rva 0xBD8E0 ====
__int64 __fastcall sub_7FF91DD1D8E0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D8F0 @ rva 0xBD8F0 ====
__int64 __fastcall sub_7FF91DD1D8F0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D900 @ rva 0xBD900 ====
void **sub_7FF91DD1D900()
{
  return &Block;
}


// ==== sub_7FF91DD1D910 @ rva 0xBD910 ====
__int64 __fastcall sub_7FF91DD1D910(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D960 @ rva 0xBD960 ====
_QWORD *__fastcall sub_7FF91DD1D960(_QWORD *a1, unsigned __int64 a2, __int64 a3)
{
  a1[3] = 15;
  a1[2] = 0;
  *(_BYTE *)a1 = 0;
  if ( a2 != a3 )
    sub_7FF91DD17EC0(a1, a2, a3 - a2);
  return a1;
}


// ==== sub_7FF91DD1D9A0 @ rva 0xBD9A0 ====
__int64 __fastcall sub_7FF91DD1D9A0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1D9B0 @ rva 0xBD9B0 ====
__int64 **__fastcall sub_7FF91DD1D9B0(__int64 **a1, __int64 *a2)
{
  __int64 *v4; // r9
  __int64 v5; // rax
  __int64 v6; // rcx
  __int64 v7; // rcx
  __int64 **result; // rax

  v4 = (__int64 *)operator new(0x18u);
  v5 = *a2;
  *v4 = *a2;
  if ( (*(_DWORD *)(v5 - 16) & 0x30000000) == 0 )
    _InterlockedExchangeAdd((volatile signed __int32 *)(v5 - 16), 1u);
  v6 = a2[1];
  v4[1] = v6;
  if ( (*(_DWORD *)(v6 - 16) & 0x30000000) == 0 )
    _InterlockedExchangeAdd((volatile signed __int32 *)(v6 - 16), 1u);
  v7 = a2[2];
  v4[2] = v7;
  result = a1;
  if ( (*(_DWORD *)(v7 - 16) & 0x30000000) == 0 )
    _InterlockedExchangeAdd((volatile signed __int32 *)(v7 - 16), 1u);
  *a1 = v4;
  return result;
}


// ==== sub_7FF91DD1DA40 @ rva 0xBDA40 ====
// Hidden C++ exception states: #wind=4
void __fastcall sub_7FF91DD1DA40(_Thrd_imp_t *a1, void **a2)
{
  int v4; // eax
  int v5; // ebx
  int v6; // eax
  int v7; // eax
  void *v8; // rax
  int v9; // eax
  int v10; // eax
  void *v11; // rbx
  struct _Cnd_internal_imp_t *v12; // rdi
  struct _Mtx_internal_imp_t *v13; // rbx
  int v14; // eax
  void **v15; // [rsp+48h] [rbp-30h] BYREF
  _Cnd_t v16; // [rsp+50h] [rbp-28h] BYREF
  _Mtx_t v17; // [rsp+58h] [rbp-20h] BYREF
  char v18; // [rsp+60h] [rbp-18h]
  void *Block; // [rsp+68h] [rbp-10h]

  v15 = &std::_Pad::`vftable';
  v4 = Cnd_init(&v16);
  if ( v4 )
    std::_Throw_C_error(v4);
  v5 = 1;
  v6 = Mtx_init(&v17, 1);
  if ( v6 )
    std::_Throw_C_error(v6);
  v18 = 0;
  v7 = Mtx_lock(v17);
  if ( v7 )
    std::_Throw_C_error(v7);
  v15 = &std::_LaunchPad<std::unique_ptr<std::tuple<_lambda_1d774048c448fbc19b0ed856226ca1d8_>>>::`vftable';
  v8 = *a2;
  *a2 = nullptr;
  Block = v8;
  v9 = Thrd_start(a1, (_Thrd_callback_t)sub_7FF91DD196B0, &v15);
  if ( v9 != 4 )
    v5 = v9;
  if ( v5 )
    std::_Throw_C_error(v5);
  while ( !v18 )
  {
    v10 = sub_7FF91E2AB4AC(v16, v17);
    if ( v10 )
      std::_Throw_C_error(v10);
  }
  v11 = Block;
  if ( Block )
  {
    sub_7FF91DD19A90(Block);
    j_j_free(v11);
  }
  v15 = &std::_Pad::`vftable';
  v12 = v16;
  v13 = v17;
  v14 = Mtx_unlock(v17);
  if ( v14 )
    std::_Throw_C_error(v14);
  Mtx_destroy(v13);
  Cnd_destroy(v12);
}


// ==== sub_7FF91DD1DBB0 @ rva 0xBDBB0 ====
__int64 __fastcall sub_7FF91DD1DBB0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1DBC0 @ rva 0xBDBC0 ====
bool __fastcall sub_7FF91DD1DBC0(_QWORD *a1, _BYTE *a2)
{
  unsigned __int64 v2; // rbx
  size_t *v3; // rdi
  size_t v4; // rdi
  size_t v5; // r8
  int v6; // eax
  bool v7; // zf

  if ( *a2 )
  {
    v2 = -1;
    do
      ++v2;
    while ( a2[v2] );
  }
  else
  {
    v2 = 0;
  }
  v3 = a1 + 2;
  if ( a1[3] >= 0x10u )
    a1 = (_QWORD *)*a1;
  v4 = *v3;
  v5 = v2;
  if ( v4 < v2 )
    v5 = v4;
  if ( !v5 || (v6 = memcmp(a1, a2, v5), v7 = v6 == 0, !v6) )
  {
    if ( v4 < v2 )
      return 0;
    return v4 <= v2;
  }
  return v7;
}


// ==== sub_7FF91DD1DC50 @ rva 0xBDC50 ====
void __fastcall sub_7FF91DD1DC50(__int64 a1, _QWORD *a2)
{
  sub_7FF91DD17A90(a2);
}


// ==== sub_7FF91DD1DC60 @ rva 0xBDC60 ====
__int64 __fastcall sub_7FF91DD1DC60(_QWORD *a1, __int64 a2, _QWORD *a3)
{
  _QWORD *v4; // rbp
  _QWORD *v6; // rsi
  _QWORD *v7; // rdi
  __int64 v8; // rbx
  __int64 v10; // rax
  __int64 v11; // rcx
  _QWORD *v12; // [rsp+50h] [rbp+8h] BYREF

  v12 = a1;
  v4 = Block;
  v6 = Block;
  v7 = *((_QWORD **)Block + 1);
  if ( !*((_BYTE *)v7 + 25) )
  {
    v8 = *a3;
    do
    {
      if ( (int)sub_7FF91DD652D0(v7[4], v8) >= 0 )
      {
        v6 = v7;
        v7 = (_QWORD *)*v7;
      }
      else
      {
        v7 = (_QWORD *)v7[2];
      }
    }
    while ( !*((_BYTE *)v7 + 25) );
  }
  if ( v6 == v4 || (int)sub_7FF91DD652D0(*a3, v6[4]) < 0 )
  {
    v12 = a3;
    v10 = sub_7FF91DD1E780(a1, a2, &v12);
    sub_7FF91DD1E7E0(v11, &v12, v6, v10 + 32, v10);
    *(_QWORD *)a2 = v12;
    *(_BYTE *)(a2 + 8) = 1;
    return a2;
  }
  else
  {
    *(_QWORD *)a2 = v6;
    *(_BYTE *)(a2 + 8) = 0;
    return a2;
  }
}


// ==== sub_7FF91DD1DD40 @ rva 0xBDD40 ====
__int64 __fastcall sub_7FF91DD1DD40(__int64 *a1, __int64 a2, _QWORD *a3)
{
  __int64 *v3; // r14
  __int64 *v7; // rdi
  __int64 *v8; // rbx
  void *v9; // rax
  _QWORD *v11; // [rsp+50h] [rbp+8h] BYREF

  v3 = (__int64 *)*a1;
  v7 = (__int64 *)*a1;
  v8 = *(__int64 **)(*a1 + 8);
  while ( !*((_BYTE *)v8 + 25) )
  {
    if ( sub_7FF91DD1AC80(v8 + 4, a3) >= 0 )
    {
      v7 = v8;
      v8 = (__int64 *)*v8;
    }
    else
    {
      v8 = (__int64 *)v8[2];
    }
  }
  if ( v7 == v3 || sub_7FF91DD1AC80(a3, v7 + 4) < 0 )
  {
    v11 = a3;
    v9 = (void *)sub_7FF91DD1EAE0(a1, a2, &v11);
    sub_7FF91DD1EB60((int)a1, v9);
    *(_QWORD *)a2 = v11;
    *(_BYTE *)(a2 + 8) = 1;
  }
  else
  {
    *(_QWORD *)a2 = v7;
    *(_BYTE *)(a2 + 8) = 0;
  }
  return a2;
}


// ==== unknown_libname_4239 @ rva 0xBDE10 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4239(__int64 a1, __int64 *a2, __int64 *a3)
{
  __int64 result; // rax

  if ( a2 )
  {
    result = *a3;
    *a2 = *a3;
  }
  return result;
}


// ==== nullsub_134 @ rva 0xBDE20 ====
void nullsub_134()
{
  ;
}


// ==== sub_7FF91DD1DE30 @ rva 0xBDE30 ====
__int64 __fastcall sub_7FF91DD1DE30(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1DE40 @ rva 0xBDE40 ====
__int64 __fastcall sub_7FF91DD1DE40(__int64 a1)
{
  return a1;
}


// ==== nullsub_135 @ rva 0xBDE70 ====
void nullsub_135()
{
  ;
}


// ==== sub_7FF91DD1DE80 @ rva 0xBDE80 ====
__int64 __fastcall sub_7FF91DD1DE80(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1DEB0 @ rva 0xBDEB0 ====
__int64 __fastcall sub_7FF91DD1DEB0(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rbx

  v4 = a2 - a1;
  sub_7FF91E30DC00(a3, a1, a2 - a1);
  return v4 + a3;
}


// ==== nullsub_80 @ rva 0xBDEE0 ====
void nullsub_80()
{
  ;
}


// ==== sub_7FF91DD1DF20 @ rva 0xBDF20 ====
__int64 __fastcall sub_7FF91DD1DF20(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_4240 @ rva 0xBDF30 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4240(__int64 a1, __int64 *a2, __int64 *a3)
{
  __int64 result; // rax

  if ( a2 )
  {
    result = *a3;
    *a2 = *a3;
  }
  return result;
}


// ==== sub_7FF91DD1DF40 @ rva 0xBDF40 ====
__int64 __fastcall sub_7FF91DD1DF40(__int64 a1)
{
  return a1;
}


// ==== unknown_libname_4241 @ rva 0xBDF50 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4241(__int64 a1, __int64 *a2, __int64 *a3)
{
  __int64 result; // rax

  if ( a2 )
  {
    result = *a3;
    *a2 = *a3;
  }
  return result;
}


// ==== sub_7FF91DD1DF60 @ rva 0xBDF60 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91DD1DF60(_QWORD *a1)
{
  void *v2; // rbx
  struct _Cnd_internal_imp_t *v3; // rsi
  struct _Mtx_internal_imp_t *v4; // rbx
  int v5; // eax

  v2 = (void *)a1[4];
  if ( v2 )
  {
    sub_7FF91DD19A90((_QWORD *)a1[4]);
    j_j_free(v2);
  }
  *a1 = &std::_Pad::`vftable';
  v3 = (struct _Cnd_internal_imp_t *)a1[1];
  v4 = (struct _Mtx_internal_imp_t *)a1[2];
  v5 = Mtx_unlock(v4);
  if ( v5 )
    std::_Throw_C_error(v5);
  Mtx_destroy(v4);
  Cnd_destroy(v3);
}


// ==== sub_7FF91DD1DFF0 @ rva 0xBDFF0 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91DD1DFF0(__int64 a1)
{
  _QWORD *v2; // rbx
  int v3; // eax
  int v4; // eax
  int v5; // eax

  v2 = *(_QWORD **)(a1 + 32);
  *(_QWORD *)(a1 + 32) = 0;
  v3 = Mtx_lock(*(_Mtx_t *)(a1 + 16));
  if ( v3 )
    std::_Throw_C_error(v3);
  *(_BYTE *)(a1 + 24) = 1;
  v4 = Cnd_signal(*(_Cnd_t *)(a1 + 8));
  if ( v4 )
    std::_Throw_C_error(v4);
  v5 = Mtx_unlock(*(_Mtx_t *)(a1 + 16));
  if ( v5 )
    std::_Throw_C_error(v5);
  sub_7FF91E3EDC00(v2, v2 + 1);
  if ( v2 )
  {
    sub_7FF91DD19A90(v2);
    j_j_free(v2);
  }
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_10 @ rva 0xBE090 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1E0C0 @ rva 0xBE0C0 ====
void **sub_7FF91DD1E0C0()
{
  return &xmmword_7FF91E91A238;
}


// ==== sub_7FF91DD1E0F0 @ rva 0xBE0F0 ====
void **sub_7FF91DD1E0F0()
{
  return &Block;
}


// ==== sub_7FF91DD1E110 @ rva 0xBE110 ====
void __fastcall sub_7FF91DD1E110(__int64 a1)
{
  _QWORD *v2; // rbx
  int v3; // eax
  int v4; // eax
  int v5; // eax

  v2 = *(_QWORD **)(a1 + 32);
  *(_QWORD *)(a1 + 32) = 0;
  v3 = Mtx_lock(*(_Mtx_t *)(a1 + 16));
  if ( v3 )
    std::_Throw_C_error(v3);
  *(_BYTE *)(a1 + 24) = 1;
  v4 = Cnd_signal(*(_Cnd_t *)(a1 + 8));
  if ( v4 )
    std::_Throw_C_error(v4);
  v5 = Mtx_unlock(*(_Mtx_t *)(a1 + 16));
  if ( v5 )
    std::_Throw_C_error(v5);
  sub_7FF91E3EDC00(v2, v2 + 1);
  if ( v2 )
  {
    sub_7FF91DD19A90(v2);
    j_j_free(v2);
  }
}


// ==== sub_7FF91DD1E1B0 @ rva 0xBE1B0 ====
void **sub_7FF91DD1E1B0()
{
  return &xmmword_7FF91E91A238;
}


// ==== sub_7FF91DD1E1C0 @ rva 0xBE1C0 ====
void **sub_7FF91DD1E1C0()
{
  return &Block;
}


// ==== sub_7FF91DD1E1D0 @ rva 0xBE1D0 ====
__int64 __fastcall sub_7FF91DD1E1D0(__int64 a1)
{
  return *(_QWORD *)a1;
}


// ==== sub_7FF91DD1E1E0 @ rva 0xBE1E0 ====
_QWORD *__fastcall sub_7FF91DD1E1E0(_QWORD *a1, __int64 *a2)
{
  __int64 v2; // rax

  v2 = *a2;
  *a2 = 0;
  *a1 = v2;
  return a1;
}


// ==== ?_Release@_NonReentrantLock@details@Concurrency@@QEAAXXZ @ rva 0xBE204 ====
void __fastcall Concurrency::details::_NonReentrantLock::_Release(Concurrency::details::_NonReentrantLock *this)
{
  *(_DWORD *)this = 0;
}


// ==== sub_7FF91DD1E210 @ rva 0xBE210 ====
__int64 __fastcall sub_7FF91DD1E210(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E220 @ rva 0xBE220 ====
__int64 __fastcall sub_7FF91DD1E220(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E230 @ rva 0xBE230 ====
__int64 __fastcall sub_7FF91DD1E230(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E240 @ rva 0xBE240 ====
__int64 __fastcall sub_7FF91DD1E240(__int64 a1)
{
  *(_QWORD *)(a1 + 16) = 0;
  *(_QWORD *)(a1 + 24) = 0;
  return a1;
}


// ==== sub_7FF91DD1E250 @ rva 0xBE250 ====
__int64 __fastcall sub_7FF91DD1E250(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E2C0 @ rva 0xBE2C0 ====
__int64 __fastcall sub_7FF91DD1E2C0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E2D0 @ rva 0xBE2D0 ====
// Hidden C++ exception states: #wind=2
__int64 __fastcall sub_7FF91DD1E2D0(__int64 a1, __int64 *a2)
{
  int v4; // eax
  int v5; // eax
  int v6; // eax
  __int64 v7; // rax
  struct _Mtx_internal_imp_t *v9; // [rsp+40h] [rbp-18h]

  *(_QWORD *)a1 = &std::_Pad::`vftable';
  v4 = Cnd_init((_Cnd_t *)(a1 + 8));
  if ( v4 )
    std::_Throw_C_error(v4);
  v5 = Mtx_init((_Mtx_t *)(a1 + 16), 1);
  if ( v5 )
    std::_Throw_C_error(v5);
  v9 = *(struct _Mtx_internal_imp_t **)(a1 + 16);
  *(_BYTE *)(a1 + 24) = 0;
  v6 = Mtx_lock(v9);
  if ( v6 )
    std::_Throw_C_error(v6);
  *(_QWORD *)a1 = &std::_LaunchPad<std::unique_ptr<std::tuple<_lambda_1d774048c448fbc19b0ed856226ca1d8_>>>::`vftable';
  v7 = *a2;
  *a2 = 0;
  *(_QWORD *)(a1 + 32) = v7;
  return a1;
}


// ==== sub_7FF91DD1E390 @ rva 0xBE390 ====
void __fastcall sub_7FF91DD1E390(__int64 a1, _QWORD *a2)
{
  sub_7FF91DD17A90(a2);
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_11 @ rva 0xBE3A0 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1E3B0 @ rva 0xBE3B0 ====
__int64 __fastcall sub_7FF91DD1E3B0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E3C0 @ rva 0xBE3C0 ====
__int64 __fastcall sub_7FF91DD1E3C0(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5)
{
  __int64 v7; // rax
  __int64 v8; // rcx

  v7 = sub_7FF91DD1E780(a1, a2, a5);
  sub_7FF91DD1E7E0(v8, a2, a3, v7 + 32, v7);
  return a2;
}


// ==== sub_7FF91DD1E440 @ rva 0xBE440 ====
__int64 __fastcall sub_7FF91DD1E440(__int64 a1)
{
  return a1;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_12 @ rva 0xBE450 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1E460 @ rva 0xBE460 ====
__int64 __fastcall sub_7FF91DD1E460(__int64 a1, __int64 a2, __int64 a3, __int64 a4, __int64 a5)
{
  int v6; // edi
  void *v7; // rax

  v6 = a1;
  v7 = (void *)sub_7FF91DD1EAE0(a1, a2, a5);
  sub_7FF91DD1EB60(v6, v7);
  return a2;
}


// ==== unknown_libname_4242 @ rva 0xBE4F0 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4242(__int64 a1, __int64 *a2, __int64 *a3)
{
  __int64 result; // rax

  if ( a2 )
  {
    result = *a3;
    *a2 = *a3;
  }
  return result;
}


// ==== nullsub_136 @ rva 0xBE500 ====
void nullsub_136()
{
  ;
}


// ==== nullsub_137 @ rva 0xBE510 ====
void nullsub_137()
{
  ;
}


// ==== sub_7FF91DD1E520 @ rva 0xBE520 ====
__int64 __fastcall sub_7FF91DD1E520(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E530 @ rva 0xBE530 ====
__int64 __fastcall sub_7FF91DD1E530(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rbx

  v4 = a2 - a1;
  sub_7FF91E30DC00(a3, a1, a2 - a1);
  return v4 + a3;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_13 @ rva 0xBE560 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== unknown_libname_4243 @ rva 0xBE5A0 ====
// Microsoft VisualC v7/14 64bit runtime
// Microsoft VisualC v14 64bit runtime
__int64 __fastcall unknown_libname_4243(__int64 a1, __int64 *a2, __int64 *a3)
{
  __int64 result; // rax

  if ( a2 )
  {
    result = *a3;
    *a2 = *a3;
  }
  return result;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_14 @ rva 0xBE5C0 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1E5D0 @ rva 0xBE5D0 ====
__int64 __fastcall sub_7FF91DD1E5D0(__int64 a1)
{
  return sub_7FF91E3EDC00(a1, a1 + 8);
}


// ==== sub_7FF91DD1E5E0 @ rva 0xBE5E0 ====
__int64 __fastcall sub_7FF91DD1E5E0(__int64 a1)
{
  return a1;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_15 @ rva 0xBE5F0 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1E600 @ rva 0xBE600 ====
_QWORD *__fastcall sub_7FF91DD1E600(_QWORD *a1)
{
  sub_7FF91DD17A90(a1);
  return a1;
}


// ==== sub_7FF91DD1E620 @ rva 0xBE620 ====
_QWORD *__fastcall sub_7FF91DD1E620(_QWORD *a1)
{
  _DWORD *v2; // rcx

  v2 = (_DWORD *)(*a1 - 16LL);
  if ( (*v2 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v2, 0xFFFFFFFF) )
    j_j_free_0(v2);
  return a1;
}


// ==== sub_7FF91DD1E660 @ rva 0xBE660 ====
// attributes: thunk
void __fastcall sub_7FF91DD1E660(_QWORD *a1)
{
  sub_7FF91DD17A90(a1);
}


// ==== sub_7FF91DD1E6A0 @ rva 0xBE6A0 ====
__int64 __fastcall sub_7FF91DD1E6A0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E6B0 @ rva 0xBE6B0 ====
__int64 __fastcall sub_7FF91DD1E6B0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E6C0 @ rva 0xBE6C0 ====
__int64 __fastcall sub_7FF91DD1E6C0(__int64 a1)
{
  *(_QWORD *)(a1 + 16) = 0;
  *(_QWORD *)(a1 + 24) = 0;
  return a1;
}


// ==== sub_7FF91DD1E6D0 @ rva 0xBE6D0 ====
__int64 __fastcall sub_7FF91DD1E6D0(__int64 a1)
{
  return a1;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_16 @ rva 0xBE740 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1E750 @ rva 0xBE750 ====
__int64 __fastcall sub_7FF91DD1E750(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E760 @ rva 0xBE760 ====
__int64 __fastcall sub_7FF91DD1E760(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E770 @ rva 0xBE770 ====
__int64 __fastcall sub_7FF91DD1E770(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1E780 @ rva 0xBE780 ====
__int64 __fastcall sub_7FF91DD1E780(__int64 a1, __int64 a2, __int64 **a3)
{
  __int64 v4; // r9
  __int64 v5; // rdx

  v4 = sub_7FF91DD1F110();
  *(_WORD *)(v4 + 24) = 0;
  if ( v4 != -32 )
  {
    v5 = **a3;
    *(_QWORD *)(v4 + 32) = v5;
    if ( (*(_DWORD *)(v5 - 16) & 0x30000000) == 0 )
      _InterlockedExchangeAdd((volatile signed __int32 *)(v5 - 16), 1u);
    *(_DWORD *)(v4 + 40) = 0;
  }
  return v4;
}


// ==== sub_7FF91DD1E7E0 @ rva 0xBE7E0 ====
_QWORD *__fastcall sub_7FF91DD1E7E0(int a1, _QWORD *a2, _QWORD *a3, _QWORD *a4, void *Block)
{
  int v5; // r12d
  _QWORD *v6; // rdi
  __int64 v8; // rcx
  _QWORD *v9; // r13
  __int64 *m; // rcx
  int v11; // r8d
  _QWORD *result; // rax
  __int64 v13; // rbx
  __int64 v14; // r14
  _QWORD *v15; // rax
  _QWORD *v16; // rbx
  __int64 j; // rax
  __int64 i; // rcx
  int v19; // ecx
  int v20; // r8d
  _QWORD *v21; // rbx
  __int64 **v22; // rax
  __int64 k; // rax
  int v24; // [rsp+38h] [rbp-30h] BYREF

  v5 = (int)a4;
  v6 = a3;
  if ( *(&::Block + 1) )
  {
    v9 = ::Block;
    if ( a3 == *(_QWORD **)::Block )
    {
      if ( (int)sub_7FF91DD652D0(*a4, a3[4]) < 0 )
      {
        LOBYTE(v11) = 1;
        sub_7FF91DD1F390((_DWORD)m, (_DWORD)a2, v11, (_DWORD)v6);
        return a2;
      }
      goto LABEL_41;
    }
    if ( a3 == ::Block )
    {
      v13 = *((_QWORD *)::Block + 2);
      if ( (int)sub_7FF91DD652D0(*(_QWORD *)(v13 + 32), *a4) < 0 )
      {
        sub_7FF91DD1F390((_DWORD)m, (_DWORD)a2, 0, v13);
        return a2;
      }
      goto LABEL_41;
    }
    v14 = *a4;
    if ( (int)sub_7FF91DD652D0(*a4, a3[4]) >= 0 )
      goto LABEL_36;
    v15 = v6;
    if ( *((_BYTE *)v6 + 25) )
    {
      v16 = (_QWORD *)v6[2];
    }
    else
    {
      v16 = (_QWORD *)*v6;
      if ( *(_BYTE *)(*v6 + 25LL) )
      {
        for ( i = v6[1]; !*(_BYTE *)(i + 25); i = *(_QWORD *)(i + 8) )
        {
          if ( v15 != *(_QWORD **)i )
            break;
          v15 = (_QWORD *)i;
        }
        v16 = v15;
        if ( !*((_BYTE *)v15 + 25) )
          v16 = (_QWORD *)i;
      }
      else
      {
        for ( j = v16[2]; !*(_BYTE *)(j + 25); j = *(_QWORD *)(j + 16) )
          v16 = (_QWORD *)j;
      }
    }
    if ( (int)sub_7FF91DD652D0(v16[4], v14) >= 0 )
    {
LABEL_36:
      if ( (int)sub_7FF91DD652D0(v6[4], v14) >= 0 )
        goto LABEL_41;
      v21 = v6;
      if ( !*((_BYTE *)v6 + 25) )
      {
        v22 = (__int64 **)v6[2];
        if ( *((_BYTE *)v22 + 25) )
        {
          for ( k = v6[1]; !*(_BYTE *)(k + 25); k = *(_QWORD *)(k + 8) )
          {
            if ( v21 != *(_QWORD **)(k + 16) )
              break;
            v21 = (_QWORD *)k;
          }
          v21 = (_QWORD *)k;
        }
        else
        {
          v21 = (_QWORD *)v6[2];
          for ( m = *v22; !*((_BYTE *)m + 25); m = (__int64 *)*m )
            v21 = m;
        }
      }
      if ( v21 != v9 && (int)sub_7FF91DD652D0(v14, v21[4]) >= 0 )
      {
LABEL_41:
        *a2 = *(_QWORD *)sub_7FF91DD1F660((int)m, (int)&v24, v11, v5, Block);
        return a2;
      }
      if ( *(_BYTE *)(v6[2] + 25LL) )
      {
        sub_7FF91DD1F390((_DWORD)m, (_DWORD)a2, 0, (_DWORD)v6);
      }
      else
      {
        LOBYTE(v11) = 1;
        sub_7FF91DD1F390((_DWORD)m, (_DWORD)a2, v11, (_DWORD)v21);
      }
      return a2;
    }
    else
    {
      if ( *(_BYTE *)(v16[2] + 25LL) )
      {
        sub_7FF91DD1F390(v19, (_DWORD)a2, 0, (_DWORD)v16);
      }
      else
      {
        LOBYTE(v20) = 1;
        sub_7FF91DD1F390(v19, (_DWORD)a2, v20, (_DWORD)v6);
      }
      return a2;
    }
  }
  else
  {
    try
    {
      LOBYTE(a3) = 1;
      sub_7FF91DD1F390(a1, (_DWORD)a2, (_DWORD)a3, (_DWORD)::Block);
      result = a2;
    }
    catch ( ... )
    {
      sub_7FF91DD1F160(v8, Block);
      throw;
    }
  }
  return result;
}


// ==== sub_7FF91DD1EAA0 @ rva 0xBEAA0 ====
__int64 __fastcall sub_7FF91DD1EAA0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1EAB0 @ rva 0xBEAB0 ====
__int64 __fastcall sub_7FF91DD1EAB0(__int64 a1)
{
  return a1;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_17 @ rva 0xBEAC0 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1EAD0 @ rva 0xBEAD0 ====
__int64 __fastcall sub_7FF91DD1EAD0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1EAE0 @ rva 0xBEAE0 ====
// Hidden C++ exception states: #wind=1
__int64 __fastcall sub_7FF91DD1EAE0(__int64 a1, __int64 a2, _QWORD **a3)
{
  __int64 v4; // rax
  __int64 v5; // rcx
  __int64 v6; // rdi
  __int64 v7; // rbx
  _QWORD *v8; // rdx
  __int64 result; // rax
  __int64 v10; // [rsp+68h] [rbp+20h]

  v4 = sub_7FF91DD1EFF0(a1);
  try
  {
    v6 = v4;
    v10 = v4;
    *(_WORD *)(v4 + 24) = 0;
    v7 = v4 + 32;
    if ( v4 != -32 )
    {
      v8 = *a3;
      *(_QWORD *)(v4 + 56) = 15;
      *(_QWORD *)(v4 + 48) = 0;
      *(_BYTE *)v7 = 0;
      sub_7FF91DD17FF0((_QWORD *)(v4 + 32), v8, 0, 0xFFFFFFFFFFFFFFFFuLL);
      *(_QWORD *)(v7 + 32) = 0;
    }
    result = v6;
  }
  catch ( ... )
  {
    sub_7FF91DD1EFE0(v5, v10);
    throw;
  }
  return result;
}


// ==== sub_7FF91DD1EB60 @ rva 0xBEB60 ====
_QWORD *__fastcall sub_7FF91DD1EB60(_QWORD *a1, _QWORD *a2, _QWORD *a3, _QWORD *a4, void *Block)
{
  _QWORD *v6; // rdi
  int v8; // r15d
  __int64 v9; // rcx
  _QWORD *v10; // rsi
  int v11; // r8d
  _QWORD *result; // rax
  __int64 v13; // rbx
  _QWORD *v14; // rax
  _QWORD *v15; // rbx
  __int64 j; // rax
  __int64 i; // rcx
  int v18; // r8d
  _QWORD *v19; // rbx
  __int64 **v20; // rax
  __int64 *m; // rcx
  __int64 k; // rax
  int v23; // [rsp+38h] [rbp-30h] BYREF

  v6 = a3;
  v8 = (int)a1;
  if ( a1[1] )
  {
    v10 = (_QWORD *)*a1;
    if ( a3 == *(_QWORD **)*a1 )
    {
      if ( sub_7FF91DD1AC80(a4, a3 + 4) < 0 )
      {
        LOBYTE(v11) = 1;
        sub_7FF91DD1F8E0(v8, (_DWORD)a2, v11, (_DWORD)v6);
        return a2;
      }
      goto LABEL_41;
    }
    if ( a3 == v10 )
    {
      v13 = v10[2];
      if ( sub_7FF91DD1AC80((_QWORD *)(v13 + 32), a4) < 0 )
      {
        sub_7FF91DD1F8E0(v8, (_DWORD)a2, 0, v13);
        return a2;
      }
      goto LABEL_41;
    }
    if ( sub_7FF91DD1AC80(a4, a3 + 4) >= 0 )
      goto LABEL_36;
    v14 = v6;
    if ( *((_BYTE *)v6 + 25) )
    {
      v15 = (_QWORD *)v6[2];
    }
    else
    {
      v15 = (_QWORD *)*v6;
      if ( *(_BYTE *)(*v6 + 25LL) )
      {
        for ( i = v6[1]; !*(_BYTE *)(i + 25); i = *(_QWORD *)(i + 8) )
        {
          if ( v14 != *(_QWORD **)i )
            break;
          v14 = (_QWORD *)i;
        }
        v15 = v14;
        if ( !*((_BYTE *)v14 + 25) )
          v15 = (_QWORD *)i;
      }
      else
      {
        for ( j = v15[2]; !*(_BYTE *)(j + 25); j = *(_QWORD *)(j + 16) )
          v15 = (_QWORD *)j;
      }
    }
    if ( sub_7FF91DD1AC80(v15 + 4, a4) >= 0 )
    {
LABEL_36:
      if ( sub_7FF91DD1AC80(v6 + 4, a4) >= 0 )
        goto LABEL_41;
      v19 = v6;
      if ( !*((_BYTE *)v6 + 25) )
      {
        v20 = (__int64 **)v6[2];
        if ( *((_BYTE *)v20 + 25) )
        {
          for ( k = v6[1]; !*(_BYTE *)(k + 25); k = *(_QWORD *)(k + 8) )
          {
            if ( v19 != *(_QWORD **)(k + 16) )
              break;
            v19 = (_QWORD *)k;
          }
          v19 = (_QWORD *)k;
        }
        else
        {
          v19 = (_QWORD *)v6[2];
          for ( m = *v20; !*((_BYTE *)m + 25); m = (__int64 *)*m )
            v19 = m;
        }
      }
      if ( v19 != v10 && sub_7FF91DD1AC80(a4, v19 + 4) >= 0 )
      {
LABEL_41:
        *a2 = *(_QWORD *)sub_7FF91DD1FB90(v8, (int)&v23, v11, (int)a4, Block);
        return a2;
      }
      if ( *(_BYTE *)(v6[2] + 25LL) )
      {
        sub_7FF91DD1F8E0(v8, (_DWORD)a2, 0, (_DWORD)v6);
      }
      else
      {
        LOBYTE(v11) = 1;
        sub_7FF91DD1F8E0(v8, (_DWORD)a2, v11, (_DWORD)v19);
      }
      return a2;
    }
    else
    {
      if ( *(_BYTE *)(v15[2] + 25LL) )
      {
        sub_7FF91DD1F8E0(v8, (_DWORD)a2, 0, (_DWORD)v15);
      }
      else
      {
        LOBYTE(v18) = 1;
        sub_7FF91DD1F8E0(v8, (_DWORD)a2, v18, (_DWORD)v6);
      }
      return a2;
    }
  }
  else
  {
    try
    {
      LOBYTE(a3) = 1;
      sub_7FF91DD1F8E0((_DWORD)a1, (_DWORD)a2, (_DWORD)a3, *a1);
      result = a2;
    }
    catch ( ... )
    {
      sub_7FF91DD1F030(v9, Block);
      throw;
    }
  }
  return result;
}


// ==== sub_7FF91DD1EE30 @ rva 0xBEE30 ====
__int64 __fastcall sub_7FF91DD1EE30(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1EE40 @ rva 0xBEE40 ====
__int64 __fastcall sub_7FF91DD1EE40(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1EE50 @ rva 0xBEE50 ====
__int64 __fastcall sub_7FF91DD1EE50(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1EE60 @ rva 0xBEE60 ====
__int64 __fastcall sub_7FF91DD1EE60(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rbx

  v4 = a2 - a1;
  sub_7FF91E30DC00(a3, a1, a2 - a1);
  return v4 + a3;
}


// ==== unknown_libname_4245 @ rva 0xBEE90 ====
// Microsoft VisualC v14 64bit runtime
_QWORD *__fastcall unknown_libname_4245(_QWORD *a1, __int64 a2, _QWORD *a3)
{
  *a1 = *a3;
  return a1;
}


// ==== sub_7FF91DD1EEA0 @ rva 0xBEEA0 ====
__int64 __fastcall sub_7FF91DD1EEA0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1EEB0 @ rva 0xBEEB0 ====
__int64 __fastcall sub_7FF91DD1EEB0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1EEC0 @ rva 0xBEEC0 ====
__int64 __fastcall sub_7FF91DD1EEC0(__int64 a1)
{
  return sub_7FF91E3EDC00(a1, a1 + 8);
}


// ==== unknown_libname_4246 @ rva 0xBEED0 ====
// Microsoft VisualC v14 64bit runtime
_QWORD *__fastcall unknown_libname_4246(_QWORD *a1, __int64 a2, __int64 a3, _QWORD *a4)
{
  *a1 = *a4;
  return a1;
}


// ==== sub_7FF91DD1EFE0 @ rva 0xBEFE0 ====
void __fastcall sub_7FF91DD1EFE0(__int64 a1, void *a2)
{
  j_free(a2);
}


// ==== sub_7FF91DD1EFF0 @ rva 0xBEFF0 ====
_QWORD *__fastcall sub_7FF91DD1EFF0(_QWORD *a1)
{
  _QWORD *v2; // r8

  v2 = operator new(0x48u);
  *v2 = *a1;
  if ( v2 != (_QWORD *)-8LL )
    v2[1] = *a1;
  if ( v2 != (_QWORD *)-16LL )
    v2[2] = *a1;
  return v2;
}


// ==== sub_7FF91DD1F030 @ rva 0xBF030 ====
void __fastcall sub_7FF91DD1F030(__int64 a1, _QWORD *a2)
{
  sub_7FF91DD17A90(a2 + 4);
  j_free(a2);
}


// ==== ?file_name@__crt_win32_buffer_debug_info@@QEBAPEBDXZ_0 @ rva 0xBF050 ====
const char *__fastcall __crt_win32_buffer_debug_info::file_name(__crt_win32_buffer_debug_info *this)
{
  return *((const char **)this + 1);
}


// ==== sub_7FF91DD1F100 @ rva 0xBF100 ====
void __fastcall sub_7FF91DD1F100(__int64 a1, void *a2)
{
  j_free(a2);
}


// ==== sub_7FF91DD1F110 @ rva 0xBF110 ====
_QWORD *sub_7FF91DD1F110()
{
  _QWORD *v0; // rdx

  v0 = operator new(0x30u);
  *v0 = Block;
  if ( v0 != (_QWORD *)-8LL )
    v0[1] = Block;
  if ( v0 != (_QWORD *)-16LL )
    v0[2] = Block;
  return v0;
}


// ==== sub_7FF91DD1F160 @ rva 0xBF160 ====
void __fastcall sub_7FF91DD1F160(__int64 a1, _QWORD *a2)
{
  _DWORD *v3; // rcx

  v3 = (_DWORD *)(a2[4] - 16LL);
  if ( (*v3 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v3, 0xFFFFFFFF) )
    j_j_free_0(v3);
  j_free(a2);
}


// ==== sub_7FF91DD1F1A0 @ rva 0xBF1A0 ====
__int64 sub_7FF91DD1F1A0()
{
  return (__int64)*(&Block + 1);
}


// ==== ?GetLocaleT@_LocaleUpdate@@QEAAPEAU__crt_locale_pointers@@XZ_6 @ rva 0xBF2F0 ====
struct __crt_locale_pointers *__fastcall _LocaleUpdate::GetLocaleT(_LocaleUpdate *this)
{
  return (struct __crt_locale_pointers *)((char *)this + 8);
}


// ==== sub_7FF91DD1F300 @ rva 0xBF300 ====
void **sub_7FF91DD1F300()
{
  return &Block + 1;
}


// ==== sub_7FF91DD1F310 @ rva 0xBF310 ====
__int64 __fastcall sub_7FF91DD1F310(__int64 a1)
{
  return sub_7FF91E3EDC00(a1, a1 + 8);
}


// ==== sub_7FF91DD1F320 @ rva 0xBF320 ====
__int64 __fastcall sub_7FF91DD1F320(__int64 a1)
{
  return a1;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_18 @ rva 0xBF330 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1F380 @ rva 0xBF380 ====
__int64 __fastcall sub_7FF91DD1F380(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1F390 @ rva 0xBF390 ====
_QWORD *__fastcall sub_7FF91DD1F390(__int64 a1, _QWORD *a2, char a3, _QWORD *a4, __int64 a5, _QWORD *a6)
{
  _QWORD *v7; // rax
  _QWORD *v8; // rdx
  _QWORD *v9; // rcx
  _QWORD *v10; // r9
  __int64 *v11; // r8
  _QWORD *v12; // r10
  _QWORD *v13; // rax
  _QWORD *v14; // r8
  _QWORD *v15; // rax
  _QWORD *v16; // rcx
  _QWORD *v17; // r8
  __int64 v18; // rax
  _QWORD *v19; // rax
  _QWORD *v20; // rax
  __int64 v21; // rax
  _QWORD *v22; // rax
  _QWORD *v23; // rax
  _QWORD *v24; // rax

  if ( (unsigned __int64)*(&Block + 1) >= 0x555555555555554LL )
  {
    sub_7FF91DD1F160(0x555555555555554LL, a6);
    sub_7FF91E2A81A4("map/set<T> too long");
  }
  *(&Block + 1) = (char *)*(&Block + 1) + 1;
  a6[1] = a4;
  if ( a4 == Block )
  {
    *((_QWORD *)Block + 1) = a6;
    *(_QWORD *)Block = a6;
    v7 = Block;
LABEL_8:
    v7[2] = a6;
    goto LABEL_9;
  }
  if ( !a3 )
  {
    a4[2] = a6;
    v7 = Block;
    if ( a4 != *((_QWORD **)Block + 2) )
      goto LABEL_9;
    goto LABEL_8;
  }
  *a4 = a6;
  if ( a4 == *(_QWORD **)Block )
    *(_QWORD *)Block = a6;
LABEL_9:
  v8 = a6;
  while ( !*(_BYTE *)(v8[1] + 24LL) )
  {
    v9 = (_QWORD *)v8[1];
    v10 = v8 + 1;
    v11 = (__int64 *)v9[1];
    v12 = v9 + 1;
    v13 = (_QWORD *)*v11;
    if ( v9 == (_QWORD *)*v11 )
    {
      v13 = (_QWORD *)v11[2];
      if ( *((_BYTE *)v13 + 24) )
      {
        v14 = (_QWORD *)v9[2];
        if ( v8 == v14 )
        {
          v8 = (_QWORD *)v8[1];
          v9[2] = *v14;
          if ( !*(_BYTE *)(*v14 + 25LL) )
            *(_QWORD *)(*v14 + 8LL) = v9;
          v14[1] = *v12;
          if ( v9 == *((_QWORD **)Block + 1) )
          {
            *((_QWORD *)Block + 1) = v14;
            v10 = v9 + 1;
            *v14 = v9;
            *v12 = v14;
          }
          else
          {
            v15 = (_QWORD *)*v12;
            if ( v9 == *(_QWORD **)*v12 )
              *v15 = v14;
            else
              v15[2] = v14;
            v10 = v9 + 1;
            *v14 = v9;
            *v12 = v14;
          }
        }
        else
        {
          v14 = (_QWORD *)v8[1];
        }
        *((_BYTE *)v14 + 24) = 1;
        *(_BYTE *)(*(_QWORD *)(*v10 + 8LL) + 24LL) = 0;
        v16 = *(_QWORD **)(*v10 + 8LL);
        v17 = (_QWORD *)*v16;
        *v16 = *(_QWORD *)(*v16 + 16LL);
        v18 = v17[2];
        if ( !*(_BYTE *)(v18 + 25) )
          *(_QWORD *)(v18 + 8) = v16;
        v17[1] = v16[1];
        if ( v16 == *((_QWORD **)Block + 1) )
        {
          *((_QWORD *)Block + 1) = v17;
          v17[2] = v16;
        }
        else
        {
          v19 = (_QWORD *)v16[1];
          if ( v16 == (_QWORD *)v19[2] )
            v19[2] = v17;
          else
            *v19 = v17;
          v17[2] = v16;
        }
LABEL_49:
        v16[1] = v17;
        continue;
      }
    }
    else if ( *((_BYTE *)v13 + 24) )
    {
      v20 = (_QWORD *)*v9;
      if ( v8 == (_QWORD *)*v9 )
      {
        v8 = (_QWORD *)v8[1];
        v9 = (_QWORD *)*v9;
        *v8 = v20[2];
        v21 = v20[2];
        if ( !*(_BYTE *)(v21 + 25) )
          *(_QWORD *)(v21 + 8) = v8;
        v9[1] = *v12;
        if ( v8 == *((_QWORD **)Block + 1) )
        {
          *((_QWORD *)Block + 1) = v9;
        }
        else
        {
          v22 = (_QWORD *)*v12;
          if ( v8 == *(_QWORD **)(*v12 + 16LL) )
            v22[2] = v9;
          else
            *v22 = v9;
        }
        v9[2] = v8;
        v10 = v12;
        *v12 = v9;
      }
      *((_BYTE *)v9 + 24) = 1;
      *(_BYTE *)(*(_QWORD *)(*v10 + 8LL) + 24LL) = 0;
      v16 = *(_QWORD **)(*v10 + 8LL);
      v17 = (_QWORD *)v16[2];
      v16[2] = *v17;
      if ( !*(_BYTE *)(*v17 + 25LL) )
        *(_QWORD *)(*v17 + 8LL) = v16;
      v17[1] = v16[1];
      if ( v16 == *((_QWORD **)Block + 1) )
      {
        *((_QWORD *)Block + 1) = v17;
      }
      else
      {
        v23 = (_QWORD *)v16[1];
        if ( v16 == (_QWORD *)*v23 )
          *v23 = v17;
        else
          v23[2] = v17;
      }
      *v17 = v16;
      goto LABEL_49;
    }
    *((_BYTE *)v9 + 24) = 1;
    *((_BYTE *)v13 + 24) = 1;
    *(_BYTE *)(*(_QWORD *)(*v10 + 8LL) + 24LL) = 0;
    v8 = *(_QWORD **)(*v10 + 8LL);
  }
  v24 = Block;
  *a2 = a6;
  *(_BYTE *)(v24[1] + 24LL) = 1;
  return a2;
}


// ==== sub_7FF91DD1F660 @ rva 0xBF660 ====
__int64 __fastcall sub_7FF91DD1F660(__int64 a1, __int64 a2, __int64 a3, __int64 *a4, _QWORD *Block)
{
  void **v7; // r13
  _QWORD *v8; // rdi
  _QWORD *v9; // rsi
  unsigned int v10; // r15d
  __int64 v11; // rbx
  int v12; // eax
  _QWORD *v13; // rcx
  __int64 v14; // rcx
  __int64 result; // rax
  __int64 i; // rax
  __int64 v17; // rax
  _QWORD *v18; // rdx
  __int64 v19; // rcx
  _DWORD *v20; // rcx
  __int64 v21; // [rsp+20h] [rbp-78h]
  __int64 v22; // [rsp+48h] [rbp-50h] BYREF
  __int64 v23; // [rsp+50h] [rbp-48h]
  __int64 v24; // [rsp+58h] [rbp-40h]
  __int64 v25; // [rsp+60h] [rbp-38h] BYREF
  _QWORD *v26; // [rsp+A0h] [rbp+8h]

  v7 = (void **)::Block;
  v8 = *((_QWORD **)::Block + 1);
  v9 = ::Block;
  LOBYTE(v10) = 1;
  if ( !*((_BYTE *)v8 + 25) )
  {
    v11 = *a4;
    do
    {
      v9 = v8;
      v12 = sub_7FF91DD652D0(v11, v8[4]);
      v10 = (unsigned int)v12 >> 31;
      if ( v12 >= 0 )
        v8 = (_QWORD *)v8[2];
      else
        v8 = (_QWORD *)*v8;
    }
    while ( !*((_BYTE *)v8 + 25) );
  }
  try
  {
    v13 = v9;
    v26 = v9;
    if ( (_BYTE)v10 )
    {
      if ( v9 == *v7 )
      {
        *(_QWORD *)a2 = *sub_7FF91DD1F390((__int64)v9, &v22, 1, v9, v21, Block);
        *(_BYTE *)(a2 + 8) = 1;
        return a2;
      }
      if ( *((_BYTE *)v9 + 25) )
      {
        v13 = (_QWORD *)v9[2];
      }
      else if ( *(_BYTE *)(*v9 + 25LL) )
      {
        v17 = v9[1];
        if ( !*(_BYTE *)(v17 + 25) )
        {
          v18 = v9;
          do
          {
            if ( v18 != *(_QWORD **)v17 )
              break;
            v13 = (_QWORD *)v17;
            v17 = *(_QWORD *)(v17 + 8);
            v18 = v13;
          }
          while ( !*(_BYTE *)(v17 + 25) );
        }
        if ( !*((_BYTE *)v13 + 25) )
          v13 = (_QWORD *)v17;
      }
      else
      {
        v13 = (_QWORD *)*v9;
        for ( i = *(_QWORD *)(*v9 + 16LL); !*(_BYTE *)(i + 25); i = *(_QWORD *)(i + 16) )
          v13 = (_QWORD *)i;
      }
      v26 = v13;
    }
    v23 = *a4;
    v24 = v13[4];
    if ( (int)sub_7FF91DD652D0(v24, v23) >= 0 )
    {
      v20 = (_DWORD *)(Block[4] - 16LL);
      if ( (*v20 & 0x30000000) == 0 && !_InterlockedExchangeAdd(v20, 0xFFFFFFFF) )
        j_j_free_0(v20);
      j_free(Block);
      *(_QWORD *)a2 = v26;
      *(_BYTE *)(a2 + 8) = 0;
      result = a2;
    }
    else
    {
      *(_QWORD *)a2 = *sub_7FF91DD1F390(v19, &v25, v10, v9, v21, Block);
      *(_BYTE *)(a2 + 8) = 1;
      result = a2;
    }
  }
  catch ( ... )
  {
    sub_7FF91DD1F160(v14, Block);
    throw;
  }
  return result;
}


// ==== ??0_lambda_9a32fed5bf61b6b509b2d3f6003082a1_@@QEAA@AEBV__crt_stdio_stream@@@Z_19 @ rva 0xBF850 ====
_lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *__fastcall _lambda_9a32fed5bf61b6b509b2d3f6003082a1_::_lambda_9a32fed5bf61b6b509b2d3f6003082a1_(
        _lambda_9a32fed5bf61b6b509b2d3f6003082a1_ *this,
        const struct __crt_stdio_stream *a2)
{
  *(_QWORD *)this = a2;
  return this;
}


// ==== sub_7FF91DD1F860 @ rva 0xBF860 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91DD1F860(__int64 a1, _QWORD *a2, __int64 a3, _QWORD **a4)
{
  _QWORD *v5; // rdx
  _BYTE *v6; // rax

  if ( a2 )
  {
    v5 = *a4;
    a2[3] = 15;
    a2[2] = 0;
    if ( a2[3] < 0x10u )
      v6 = a2;
    else
      v6 = (_BYTE *)*a2;
    *v6 = 0;
    sub_7FF91DD17FF0(a2, v5, 0, 0xFFFFFFFFFFFFFFFFuLL);
    a2[4] = 0;
  }
}


// ==== sub_7FF91DD1F8D0 @ rva 0xBF8D0 ====
__int64 __fastcall sub_7FF91DD1F8D0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1F8E0 @ rva 0xBF8E0 ====
_QWORD *__fastcall sub_7FF91DD1F8E0(_QWORD *a1, _QWORD *a2, char a3, _QWORD *a4, __int64 a5, _QWORD *a6)
{
  unsigned __int64 v6; // rax
  __int64 v9; // rax
  _QWORD *v10; // rdx
  _QWORD *v11; // rcx
  _QWORD *v12; // r9
  __int64 *v13; // r8
  _QWORD *v14; // r10
  _QWORD *v15; // rax
  _QWORD *v16; // r8
  _QWORD *v17; // rax
  _QWORD *v18; // rcx
  _QWORD *v19; // r8
  __int64 v20; // rax
  _QWORD *v21; // rax
  _QWORD *v22; // rax
  __int64 v23; // rax
  _QWORD *v24; // rax
  _QWORD *v25; // rax
  __int64 v26; // rax

  v6 = a1[1];
  if ( v6 >= 0x38E38E38E38E38DLL )
  {
    sub_7FF91DD1F030(0x38E38E38E38E38DLL, a6);
    sub_7FF91E2A81A4("map/set<T> too long");
  }
  a1[1] = v6 + 1;
  a6[1] = a4;
  if ( a4 == (_QWORD *)*a1 )
  {
    *(_QWORD *)(*a1 + 8LL) = a6;
    *(_QWORD *)*a1 = a6;
    v9 = *a1;
LABEL_8:
    *(_QWORD *)(v9 + 16) = a6;
    goto LABEL_9;
  }
  if ( !a3 )
  {
    a4[2] = a6;
    v9 = *a1;
    if ( a4 != *(_QWORD **)(*a1 + 16LL) )
      goto LABEL_9;
    goto LABEL_8;
  }
  *a4 = a6;
  if ( a4 == *(_QWORD **)*a1 )
    *(_QWORD *)*a1 = a6;
LABEL_9:
  v10 = a6;
  while ( !*(_BYTE *)(v10[1] + 24LL) )
  {
    v11 = (_QWORD *)v10[1];
    v12 = v10 + 1;
    v13 = (__int64 *)v11[1];
    v14 = v11 + 1;
    v15 = (_QWORD *)*v13;
    if ( v11 == (_QWORD *)*v13 )
    {
      v15 = (_QWORD *)v13[2];
      if ( *((_BYTE *)v15 + 24) )
      {
        v16 = (_QWORD *)v11[2];
        if ( v10 == v16 )
        {
          v10 = (_QWORD *)v10[1];
          v11[2] = *v16;
          if ( !*(_BYTE *)(*v16 + 25LL) )
            *(_QWORD *)(*v16 + 8LL) = v11;
          v16[1] = *v14;
          if ( v11 == *(_QWORD **)(*a1 + 8LL) )
          {
            *(_QWORD *)(*a1 + 8LL) = v16;
            v12 = v11 + 1;
            *v16 = v11;
            *v14 = v16;
          }
          else
          {
            v17 = (_QWORD *)*v14;
            if ( v11 == *(_QWORD **)*v14 )
              *v17 = v16;
            else
              v17[2] = v16;
            v12 = v11 + 1;
            *v16 = v11;
            *v14 = v16;
          }
        }
        else
        {
          v16 = (_QWORD *)v10[1];
        }
        *((_BYTE *)v16 + 24) = 1;
        *(_BYTE *)(*(_QWORD *)(*v12 + 8LL) + 24LL) = 0;
        v18 = *(_QWORD **)(*v12 + 8LL);
        v19 = (_QWORD *)*v18;
        *v18 = *(_QWORD *)(*v18 + 16LL);
        v20 = v19[2];
        if ( !*(_BYTE *)(v20 + 25) )
          *(_QWORD *)(v20 + 8) = v18;
        v19[1] = v18[1];
        if ( v18 == *(_QWORD **)(*a1 + 8LL) )
        {
          *(_QWORD *)(*a1 + 8LL) = v19;
          v19[2] = v18;
        }
        else
        {
          v21 = (_QWORD *)v18[1];
          if ( v18 == (_QWORD *)v21[2] )
            v21[2] = v19;
          else
            *v21 = v19;
          v19[2] = v18;
        }
LABEL_49:
        v18[1] = v19;
        continue;
      }
    }
    else if ( *((_BYTE *)v15 + 24) )
    {
      v22 = (_QWORD *)*v11;
      if ( v10 == (_QWORD *)*v11 )
      {
        v10 = (_QWORD *)v10[1];
        v11 = (_QWORD *)*v11;
        *v10 = v22[2];
        v23 = v22[2];
        if ( !*(_BYTE *)(v23 + 25) )
          *(_QWORD *)(v23 + 8) = v10;
        v11[1] = *v14;
        if ( v10 == *(_QWORD **)(*a1 + 8LL) )
        {
          *(_QWORD *)(*a1 + 8LL) = v11;
        }
        else
        {
          v24 = (_QWORD *)*v14;
          if ( v10 == *(_QWORD **)(*v14 + 16LL) )
            v24[2] = v11;
          else
            *v24 = v11;
        }
        v11[2] = v10;
        v12 = v14;
        *v14 = v11;
      }
      *((_BYTE *)v11 + 24) = 1;
      *(_BYTE *)(*(_QWORD *)(*v12 + 8LL) + 24LL) = 0;
      v18 = *(_QWORD **)(*v12 + 8LL);
      v19 = (_QWORD *)v18[2];
      v18[2] = *v19;
      if ( !*(_BYTE *)(*v19 + 25LL) )
        *(_QWORD *)(*v19 + 8LL) = v18;
      v19[1] = v18[1];
      if ( v18 == *(_QWORD **)(*a1 + 8LL) )
      {
        *(_QWORD *)(*a1 + 8LL) = v19;
      }
      else
      {
        v25 = (_QWORD *)v18[1];
        if ( v18 == (_QWORD *)*v25 )
          *v25 = v19;
        else
          v25[2] = v19;
      }
      *v19 = v18;
      goto LABEL_49;
    }
    *((_BYTE *)v11 + 24) = 1;
    *((_BYTE *)v15 + 24) = 1;
    *(_BYTE *)(*(_QWORD *)(*v12 + 8LL) + 24LL) = 0;
    v10 = *(_QWORD **)(*v12 + 8LL);
  }
  v26 = *a1;
  *a2 = a6;
  *(_BYTE *)(*(_QWORD *)(v26 + 8) + 24LL) = 1;
  return a2;
}


// ==== sub_7FF91DD1FB90 @ rva 0xBFB90 ====
__int64 __fastcall sub_7FF91DD1FB90(__int64 ***a1, __int64 a2, __int64 a3, _QWORD *a4, _QWORD *Block)
{
  __int64 **v8; // r15
  __int64 *v9; // rbx
  __int64 *v10; // rdi
  unsigned int v11; // r14d
  int v12; // eax
  __int64 *v13; // rbx
  __int64 *v14; // rcx
  __int64 v15; // rcx
  __int64 result; // rax
  __int64 *i; // rax
  __int64 *v18; // rax
  __int64 *v19; // rdx
  void *v20; // rdi
  __int64 v21; // [rsp+20h] [rbp-48h]
  __int64 v22; // [rsp+70h] [rbp+8h] BYREF

  v8 = *a1;
  v9 = (*a1)[1];
  v10 = (__int64 *)*a1;
  LOBYTE(v11) = 1;
  while ( !*((_BYTE *)v9 + 25) )
  {
    v10 = v9;
    v12 = sub_7FF91DD1AC80(a4, v9 + 4);
    v11 = (unsigned int)v12 >> 31;
    if ( v12 >= 0 )
      v9 = (__int64 *)v9[2];
    else
      v9 = (__int64 *)*v9;
  }
  try
  {
    v13 = v10;
    v14 = v10;
    if ( (_BYTE)v11 )
    {
      if ( v10 == *v8 )
      {
        *(_QWORD *)a2 = *sub_7FF91DD1F8E0(a1, &v22, 1, v10, v21, Block);
        *(_BYTE *)(a2 + 8) = 1;
        return a2;
      }
      if ( *((_BYTE *)v10 + 25) )
      {
        v13 = (__int64 *)v10[2];
        v14 = v13;
      }
      else if ( *(_BYTE *)(*v10 + 25) )
      {
        v18 = (__int64 *)v10[1];
        if ( !*((_BYTE *)v18 + 25) )
        {
          v19 = v10;
          do
          {
            v14 = v19;
            if ( v19 != (__int64 *)*v18 )
              break;
            v13 = v18;
            v18 = (__int64 *)v18[1];
            v19 = v13;
            v14 = v13;
          }
          while ( !*((_BYTE *)v18 + 25) );
        }
        if ( !*((_BYTE *)v13 + 25) )
        {
          v13 = v18;
          v14 = v18;
        }
      }
      else
      {
        v13 = (__int64 *)*v10;
        for ( i = *(__int64 **)(*v10 + 16); !*((_BYTE *)i + 25); i = (__int64 *)i[2] )
          v13 = i;
        v14 = v13;
      }
    }
    if ( sub_7FF91DD1AC80(v14 + 4, a4) >= 0 )
    {
      v20 = Block;
      sub_7FF91DD17A90(Block + 4);
      j_free(v20);
      *(_QWORD *)a2 = v13;
      *(_BYTE *)(a2 + 8) = 0;
    }
    else
    {
      *(_QWORD *)a2 = *sub_7FF91DD1F8E0(a1, &v22, v11, v10, v21, Block);
      *(_BYTE *)(a2 + 8) = 1;
    }
    result = a2;
  }
  catch ( ... )
  {
    sub_7FF91DD1F030(v15, Block);
    throw;
  }
  return result;
}


// ==== sub_7FF91DD1FD40 @ rva 0xBFD40 ====
__int64 __fastcall sub_7FF91DD1FD40(__int64 a1, __int64 a2, __int64 a3)
{
  __int64 v4; // rbx

  v4 = a2 - a1;
  sub_7FF91E30DC00(a3, a1, a2 - a1);
  return v4 + a3;
}


// ==== sub_7FF91DD1FD70 @ rva 0xBFD70 ====
__int64 __fastcall sub_7FF91DD1FD70(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1FE20 @ rva 0xBFE20 ====
__int64 sub_7FF91DD1FE20()
{
  return 0x38E38E38E38E38ELL;
}


// ==== sub_7FF91DD1FED0 @ rva 0xBFED0 ====
__int64 sub_7FF91DD1FED0()
{
  return 0x555555555555555LL;
}


// ==== sub_7FF91DD1FEE0 @ rva 0xBFEE0 ====
__int64 sub_7FF91DD1FEE0()
{
  return 0x38E38E38E38E38ELL;
}


// ==== sub_7FF91DD1FEF0 @ rva 0xBFEF0 ====
__int64 __fastcall sub_7FF91DD1FEF0(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1FF00 @ rva 0xBFF00 ====
__int64 sub_7FF91DD1FF00()
{
  return 0x555555555555555LL;
}


// ==== sub_7FF91DD1FF10 @ rva 0xBFF10 ====
void **sub_7FF91DD1FF10()
{
  return &Block;
}


// ==== sub_7FF91DD1FF20 @ rva 0xBFF20 ====
__int64 __fastcall sub_7FF91DD1FF20(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1FF30 @ rva 0xBFF30 ====
__int64 sub_7FF91DD1FF30()
{
  return 0x38E38E38E38E38ELL;
}


// ==== sub_7FF91DD1FF40 @ rva 0xBFF40 ====
__int64 __fastcall sub_7FF91DD1FF40(__int64 a1)
{
  return a1;
}


// ==== sub_7FF91DD1FF50 @ rva 0xBFF50 ====
__int64 sub_7FF91DD1FF50()
{
  return 0x555555555555555LL;
}


// ==== sub_7FF91DD1FF60 @ rva 0xBFF60 ====
__int64 sub_7FF91DD1FF60()
{
  return 0x38E38E38E38E38ELL;
}


// ==== sub_7FF91DD1FF70 @ rva 0xBFF70 ====
__int64 sub_7FF91DD1FF70()
{
  return 0x555555555555555LL;
}


// ==== sub_7FF91DD1FFC0 @ rva 0xBFFC0 ====
__int64 __fastcall sub_7FF91DD1FFC0(__int64 a1, __int64 a2)
{
  return a2;
}


// ==== sub_7FF91DD1FFD0 @ rva 0xBFFD0 ====
// Hidden C++ exception states: #wind=1
void __fastcall sub_7FF91DD1FFD0(__int64 a1, _QWORD *a2, __int64 a3, _QWORD **a4)
{
  _QWORD *v5; // rdx
  _BYTE *v6; // rax

  if ( a2 )
  {
    v5 = *a4;
    a2[3] = 15;
    a2[2] = 0;
    if ( a2[3] < 0x10u )
      v6 = a2;
    else
      v6 = (_BYTE *)*a2;
    *v6 = 0;
    sub_7FF91DD17FF0(a2, v5, 0, 0xFFFFFFFFFFFFFFFFuLL);
    a2[4] = 0;
  }
}

